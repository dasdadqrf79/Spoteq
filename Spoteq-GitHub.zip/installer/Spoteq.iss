#define MyAppName "Spoteq"
#define MyAppVersion "0.17.1"
#define MyAppPublisher "Spoteq contributors"
#define MyAppExeName "spoteq.exe"

[Setup]
AppId={{3B084E70-74D1-4B17-9E14-6A8E91E29C8A}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\Spoteq
DefaultGroupName=Spoteq
OutputDir=..\dist
OutputBaseFilename=Spoteq-{#MyAppVersion}-windows-x64-setup
SetupIconFile=..\assets\branding\spoteq.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible

[Files]
Source: "..\target\release\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\Spoteq"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\Spoteq"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch Spoteq"; Flags: nowait postinstall skipifsilent
