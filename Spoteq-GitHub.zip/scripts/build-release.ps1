param(
    [switch]$Installer
)

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
Push-Location $ProjectRoot
try {
    cargo fmt --check
    cargo check
    cargo test
    cargo build --release

    if ($Installer) {
        $Iscc = Get-Command ISCC.exe -ErrorAction SilentlyContinue
        if (-not $Iscc) {
            throw "Inno Setup 6 (ISCC.exe) was not found in PATH."
        }
        & $Iscc.Source "installer\Spoteq.iss"
    }
}
finally {
    Pop-Location
}
