use crate::ui::i18n::tr;
use std::path::Path;

use eframe::egui::{self, Align, Layout, RichText, ScrollArea, Stroke, Ui, Vec2};

use crate::{
    settings::{AppSettings, AudioSettings, ThemeMode},
    soundcloud::{SoundCloudAvatar, SoundCloudRuntime, SoundCloudViewState},
    spotify::SpotifyRuntime,
    state::{SettingsSection, SpotifyViewState},
    ui::{
        branding, connections_page, equalizer,
        theme::{self, colors},
        widgets,
    },
};

/// Draws the settings page and the selected settings section.
pub fn show_page(
    ui: &mut Ui,
    section: &mut SettingsSection,
    settings: &mut AppSettings,
    settings_path: &Path,
    persistence_message: Option<&str>,
    spotify: &mut SpotifyViewState,
    spotify_runtime: &SpotifyRuntime,
    soundcloud: &mut SoundCloudViewState,
    soundcloud_runtime: &SoundCloudRuntime,
    soundcloud_avatar: &SoundCloudAvatar,
    changed: &mut bool,
) {
    let scroll = ScrollArea::vertical()
        .id_salt("settings-scroll")
        .auto_shrink([false, false]);
    #[cfg(test)]
    let scroll = if let Some(offset) = ui
        .ctx()
        .data(|d| d.get_temp::<f32>(egui::Id::new("preview-settings-scroll")))
    {
        let maximum = ui
            .ctx()
            .data(|d| d.get_temp::<f32>(egui::Id::new("preview-settings-scroll-max")))
            .unwrap_or(0.0);
        scroll.vertical_scroll_offset(offset.min(maximum))
    } else {
        scroll
    };
    let _scroll_output = scroll.show(ui, |ui| {
        ui.set_min_width(ui.available_width());
        // Keep the draggable navigation at the same position for every section.
        ui.add_space(12.0);
        ui.horizontal(|ui| {
            ui.label(
                RichText::new(tr("Settings"))
                    .size(26.0)
                    .strong()
                    .color(colors::text()),
            );
            ui.label(
                RichText::new(tr("Customize Spoteq to your preferences."))
                    .color(colors::text_muted()),
            );
        });
        ui.add_space(12.0);
        let sections = [
            (SettingsSection::General, "General"),
            (SettingsSection::Playback, "Playback"),
            (SettingsSection::Audio, "Audio"),
            (SettingsSection::BassStudio, "Bass Studio"),
            (SettingsSection::Appearance, "Appearance"),
            (SettingsSection::Integrations, "Accounts"),
            (SettingsSection::About, "About"),
        ];
        let labels: Vec<String> = sections
            .iter()
            .map(|(_, label)| tr(label).into_owned())
            .collect();
        let mut selected = sections
            .iter()
            .position(|(candidate, _)| candidate == section)
            .unwrap_or(0);
        if super::segments::text(ui, "settings-navigation", &mut selected, &labels, 0.0, 36.0)
            .changed()
        {
            *section = sections[selected].0;
        }
        ui.add_space(18.0);
        if *section == SettingsSection::BassStudio {
            super::bass_studio::show(
                ui,
                &mut settings.audio,
                &spotify_runtime.dsp_controls(),
                changed,
            );
        } else if *section == SettingsSection::Audio {
            equalizer::show(ui, &mut settings.audio, spotify, spotify_runtime, changed);
        } else if *section == SettingsSection::Integrations {
            connections_page::show(
                ui,
                spotify,
                spotify_runtime,
                soundcloud,
                soundcloud_runtime,
                soundcloud_avatar,
            );
        } else {
            settings_dashboard(
                ui,
                section,
                settings,
                settings_path,
                persistence_message,
                spotify,
                spotify_runtime,
                changed,
            );
        }
    });
    #[cfg(test)]
    ui.ctx().data_mut(|d| {
        d.insert_temp(
            egui::Id::new("preview-settings-scroll-max"),
            (_scroll_output.content_size.y - _scroll_output.inner_rect.height()).max(0.0),
        )
    });
}

fn settings_dashboard(
    ui: &mut Ui,
    section: &mut SettingsSection,
    settings: &mut AppSettings,
    settings_path: &Path,
    persistence_message: Option<&str>,
    spotify: &mut SpotifyViewState,
    runtime: &SpotifyRuntime,
    changed: &mut bool,
) {
    if *section == SettingsSection::About {
        about_column(ui, settings_path, persistence_message);
    } else if ui.available_width() > 860.0 && *section == SettingsSection::General {
        let total = ui.available_width();
        let side_width = 320.0;
        ui.horizontal(|ui| {
            ui.allocate_ui_with_layout(
                Vec2::new(total - side_width - 14.0, ui.available_height()),
                Layout::top_down(Align::Min),
                |ui| settings_main(ui, section, settings, spotify, runtime, changed),
            );
            ui.allocate_ui_with_layout(
                Vec2::new(side_width, ui.available_height()),
                Layout::top_down(Align::Min),
                |ui| about_column(ui, settings_path, persistence_message),
            );
        });
    } else {
        settings_main(ui, section, settings, spotify, runtime, changed);
        ui.add_space(14.0);
        if *section == SettingsSection::General {
            about_column(ui, settings_path, persistence_message);
        }
    }
    ui.add_space(24.0);
}

fn settings_main(
    ui: &mut Ui,
    section: &mut SettingsSection,
    settings: &mut AppSettings,
    spotify: &mut SpotifyViewState,
    runtime: &SpotifyRuntime,
    changed: &mut bool,
) {
    if *section == SettingsSection::General {
        card(
            ui,
            "Language",
            "Choose the interface language. Changes apply immediately.",
            |ui| {
                ui.horizontal_wrapped(|ui| {
                    for (language, label) in [
                        (crate::settings::Language::Russian, "Русский"),
                        (crate::settings::Language::English, "English"),
                    ] {
                        if crate::ui::motion::selectable_value(
                            ui,
                            &mut settings.appearance.language,
                            language,
                            tr(label),
                        )
                        .changed()
                        {
                            super::i18n::set_language(settings.appearance.language);
                            *changed = true;
                            ui.ctx().request_repaint();
                        }
                    }
                });
            },
        );
        ui.add_space(14.0);
    }
    if matches!(
        *section,
        SettingsSection::General | SettingsSection::Appearance
    ) {
        card(
            ui,
            "Appearance",
            "Switch between light and dark appearance.",
            |ui| {
                let mut selected = if settings.appearance.theme == ThemeMode::Dark {
                    1
                } else {
                    0
                };
                let labels = vec![
                    tr("Light theme").into_owned(),
                    tr("Dark theme").into_owned(),
                ];
                if super::segments::text(ui, "theme-mode", &mut selected, &labels, 140.0, 42.0)
                    .changed()
                {
                    settings.appearance.theme = if selected == 1 {
                        ThemeMode::Dark
                    } else {
                        ThemeMode::Light
                    };
                    theme::apply_appearance(ui.ctx(), &settings.appearance);
                    *changed = true;
                }
                ui.separator();
                *changed |= crate::ui::motion::checkbox(
                    ui,
                    &mut settings.appearance.motion_enabled,
                    tr("Motion · smooth screens and interactive controls"),
                )
                .changed();
                *changed |= crate::ui::motion::checkbox(
                    ui,
                    &mut settings.appearance.depth_enabled,
                    tr("Liquid Glass · translucent surfaces and reflections"),
                )
                .changed();
                ui.add_space(8.0);
                *changed |= ui
                    .add(crate::ui::motion::control(
                        egui::Slider::new(&mut settings.appearance.glass_transparency, 0..=100)
                            .text(tr("Glass transparency"))
                            .suffix(" %"),
                        crate::ui::motion::Kind::Slider,
                    ))
                    .changed();
                ui.label(
                    RichText::new(tr(
                        "Drag to choose how clearly content shows through the glass.",
                    ))
                    .small()
                    .color(colors::text_muted()),
                );
            },
        );
        ui.add_space(14.0);
    }
    if matches!(
        *section,
        SettingsSection::General | SettingsSection::Playback
    ) {
        card(
            ui,
            "Playback",
            "Control how music continues when your queue ends.",
            |ui| {
                ui.horizontal(|ui| {
                    let text_width = (ui.available_width() - 84.0).max(1.0);
                    ui.vertical(|ui| {
                        ui.set_width(text_width);
                        ui.label(
                            RichText::new(tr("Autoplay similar tracks")).color(colors::text()),
                        );
                        ui.label(
                            RichText::new(tr(
                                "Keep 5–10 real recommendations ready from Spotify and SoundCloud.",
                            ))
                            .size(11.0)
                            .color(colors::text_muted()),
                        );
                    });
                    ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                        *changed |= widgets::eq_toggle(ui, &mut settings.playback.autoplay_similar)
                            .clicked();
                    });
                });
                ui.separator();
                ui.horizontal(|ui| {
                    let text_width = (ui.available_width() - 84.0).max(1.0);
                    ui.vertical(|ui| {
                        ui.set_width(text_width);
                        ui.label(RichText::new(tr("Shuffle future queue")).color(colors::text()));
                        ui.label(
                            RichText::new(tr(
                                &("Keeps the current track fixed and leaves Autoplay separate."),
                            ))
                            .size(11.0)
                            .color(colors::text_muted()),
                        );
                    });
                    ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                        *changed |=
                            widgets::eq_toggle(ui, &mut settings.playback.shuffle).clicked();
                    });
                });
                ui.separator();
                ui.horizontal(|ui| {
                    ui.label(RichText::new(tr("Repeat mode")).color(colors::text()));
                    ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                        if ui
                            .add(crate::ui::motion::control(
                                egui::Button::new(tr(&(settings.playback.repeat.label())))
                                    .fill(colors::surface_raised())
                                    .stroke(Stroke::new(1.0, colors::border()))
                                    .corner_radius(8),
                                crate::ui::motion::Kind::Button,
                            ))
                            .clicked()
                        {
                            settings.playback.repeat = settings.playback.repeat.next();
                            *changed = true;
                        }
                    });
                });
                ui.separator();
                ui.label(
                    RichText::new(tr("Track transitions"))
                        .size(14.0)
                        .strong()
                        .color(colors::text()),
                );
                ui.add_space(4.0);

                let mut crossfade_enabled = settings.playback.crossfade_seconds > 0;
                ui.horizontal(|ui| {
                    let text_width = (ui.available_width() - 84.0).max(1.0);
                    ui.vertical(|ui| {
                        ui.set_width(text_width);
                        ui.label(RichText::new(tr("Crossfade between tracks")).color(colors::text()));
                        ui.label(
                        RichText::new(
                            tr("Smoothly fade the current track out while the next track fades in."),
                        )
                        .size(11.0)
                        .color(colors::text_muted()),
                    );
                    });
                    ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                        let label = if crossfade_enabled { "ON" } else { "OFF" };
                        if ui
                            .add(
                                crate::ui::motion::control(egui::Button::new(RichText::new(tr(label)).size(11.0).strong().color(
                                    if crossfade_enabled {
                                        colors::accent()
                                    } else {
                                        colors::text_muted()
                                    },
                                ))
                                .fill(if crossfade_enabled {
                                    colors::accent_tint()
                                } else {
                                    colors::surface_raised()
                                })
                                .stroke(Stroke::new(
                                    1.0,
                                    if crossfade_enabled {
                                        colors::accent().gamma_multiply(0.55)
                                    } else {
                                        colors::border()
                                    },
                                ))
                                .corner_radius(12)
                                .min_size(Vec2::new(62.0, 32.0)), crate::ui::motion::Kind::Button),
                            )
                            .clicked()
                        {
                            crossfade_enabled = !crossfade_enabled;
                            settings.playback.crossfade_seconds =
                                if crossfade_enabled { 4 } else { 0 };
                            *changed = true;
                        }
                    });
                });

                if crossfade_enabled {
                    ui.add_space(8.0);
                    let mut crossfade_seconds =
                        f32::from(settings.playback.crossfade_seconds.max(1));
                    let response = widgets::labeled_slider(
                        ui,
                        "Crossfade duration",
                        &mut crossfade_seconds,
                        1.0..=12.0,
                        " s",
                        1.0,
                    );
                    if response.changed() {
                        settings.playback.crossfade_seconds = crossfade_seconds.round() as u8;
                        *changed = true;
                    }
                } else {
                    ui.add_space(5.0);
                    ui.label(
                        RichText::new(tr(
                            &("Crossfade is disabled. Tracks switch without overlap."),
                        ))
                        .size(11.0)
                        .color(colors::text_disabled()),
                    );
                }

                ui.separator();
                ui.horizontal(|ui| {
                let text_width = (ui.available_width() - 84.0).max(1.0);
                ui.vertical(|ui| {
                    ui.set_width(text_width);
                    ui.label(RichText::new(tr("Gapless transitions")).color(colors::text()));
                    ui.label(
                        RichText::new(
                            tr("Preload the next track so natural track boundaries switch with minimal silence."),
                        )
                        .size(11.0)
                        .color(colors::text_muted()),
                    );
                });
                ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                    if crate::ui::motion::checkbox(ui, &mut settings.playback.gapless_enabled, tr(""))
                        .changed()
                    {
                        *changed = true;
                    }
                });
            });

                ui.separator();
                ui.label(RichText::new(tr("Pause / Resume fade")).color(colors::text()));
                ui.label(
                    RichText::new(tr(
                        &("Smooth volume ramp when pausing or resuming playback."),
                    ))
                    .size(11.0)
                    .color(colors::text_muted()),
                );
                let mut fade_ms = f32::from(settings.playback.pause_fade_ms);
                let response = widgets::labeled_slider(
                    ui,
                    "Pause / Resume fade duration",
                    &mut fade_ms,
                    100.0..=300.0,
                    " ms",
                    10.0,
                );
                if response.changed() {
                    settings.playback.pause_fade_ms = fade_ms.round() as u16;
                    *changed = true;
                }
            },
        );
        ui.add_space(14.0);
    }
    if *section == SettingsSection::General {
        card(
            ui,
            "Audio",
            "Configure audio and playback settings.",
            |ui| {
                output_selector(ui, &mut settings.audio, spotify, runtime, changed);
                ui.add_space(18.0);
                *changed |= widgets::labeled_slider(
                    ui,
                    "Output volume",
                    &mut settings.audio.master_volume,
                    0.0..=1.0,
                    "",
                    0.01,
                )
                .changed();
            },
        );
        ui.add_space(14.0);
        card(ui, "Equalizer", "Manage equalizer behavior.", |ui| {
            if ui
                .add(crate::ui::motion::control(
                    egui::Button::new(tr("Open full Equalizer"))
                        .fill(colors::accent_dark())
                        .stroke(Stroke::new(1.0, colors::accent().gamma_multiply(0.55)))
                        .corner_radius(10)
                        .min_size(Vec2::new(180.0, 38.0)),
                    crate::ui::motion::Kind::Button,
                ))
                .clicked()
            {
                *section = SettingsSection::Audio;
            }
            ui.add_space(10.0);
            ui.horizontal(|ui| {
                ui.label(RichText::new(tr("Enable EQ on startup")).color(colors::text_muted()));
                ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                    *changed |= widgets::eq_toggle(ui, &mut settings.audio.eq_enabled).clicked();
                });
            });
            ui.separator();
            ui.horizontal(|ui| {
                ui.label(
                    RichText::new(tr("Save EQ settings automatically")).color(colors::text_muted()),
                );
                ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                    ui.label(RichText::new(tr("On")).color(colors::text()));
                });
            });
            ui.separator();
            ui.horizontal(|ui| {
                ui.label(RichText::new(tr("Reset EQ to default")).color(colors::text_muted()));
                ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                    if ui
                        .add(crate::ui::motion::control(
                            egui::Button::new(tr("Reset"))
                                .fill(colors::surface_raised())
                                .stroke(Stroke::new(1.0, colors::border()))
                                .corner_radius(8),
                            crate::ui::motion::Kind::Button,
                        ))
                        .clicked()
                    {
                        let defaults = AudioSettings::default();
                        settings.audio.preamp_db = defaults.preamp_db;
                        settings.audio.sub_bass_db = defaults.sub_bass_db;
                        settings.audio.bass_gain_db = defaults.bass_gain_db;
                        settings.audio.bass_frequency_hz = defaults.bass_frequency_hz;
                        settings.audio.bass_q = defaults.bass_q;
                        settings.audio.eq_db = defaults.eq_db;
                        *changed = true;
                    }
                });
            });
        });
    }
}

fn about_column(ui: &mut Ui, settings_path: &Path, persistence_message: Option<&str>) {
    card(ui, "About", "Spoteq", |ui| {
        if let Some(texture) = branding::logo_texture(ui.ctx()) {
            ui.add(egui::Image::new((texture.id(), egui::Vec2::splat(104.0))).corner_radius(22.0));
            ui.add_space(8.0);
        }
        ui.label(
            RichText::new(tr(&(format!("v{}", env!("CARGO_PKG_VERSION")))))
                .color(colors::text_muted()),
        );
        ui.add_space(8.0);
        ui.label(
            RichText::new(tr(
                &("A unified music experience with a real-time equalizer."),
            ))
            .color(colors::text_muted()),
        );
        ui.add_space(14.0);
        ui.separator();
        ui.label(RichText::new(tr("Spotify + SoundCloud")).color(colors::text()));
        ui.label(RichText::new(tr("Native playback and DSP")).color(colors::text()));
    });
    ui.add_space(14.0);
    card(ui, "Data", "Local settings", |ui| {
        ui.add(
            egui::Label::new(
                RichText::new(settings_path.display().to_string())
                    .monospace()
                    .size(10.0)
                    .color(colors::text_muted()),
            )
            .wrap(),
        );
        if let Some(message) = persistence_message {
            ui.add_space(10.0);
            ui.label(RichText::new(tr(message)).color(colors::warning()));
        }
    });
}

fn card(ui: &mut Ui, title: &str, subtitle: &str, content: impl FnOnce(&mut Ui)) {
    theme::elevated_frame(colors::surface(), theme::layout::CARD_RADIUS)
        .inner_margin(egui::Margin::symmetric(22, 20))
        .show(ui, |ui| {
            ui.set_min_width(ui.available_width());
            ui.label(
                RichText::new(tr(title))
                    .size(19.0)
                    .strong()
                    .color(colors::text()),
            );
            ui.label(
                RichText::new(tr(subtitle))
                    .size(12.0)
                    .color(colors::text_muted()),
            );
            ui.add_space(18.0);
            content(ui);
        });
}

fn output_selector(
    ui: &mut Ui,
    audio: &mut AudioSettings,
    spotify: &mut SpotifyViewState,
    runtime: &SpotifyRuntime,
    changed: &mut bool,
) {
    ui.label(RichText::new(tr("Output device")).color(colors::text_muted()));
    let default_label = spotify
        .default_audio_device
        .as_deref()
        .map(|name| format!("Default ({name})"))
        .unwrap_or_else(|| "Default System Device".to_owned());
    let selected = audio
        .output_device
        .as_deref()
        .unwrap_or(default_label.as_str())
        .to_owned();
    let mut requested = audio.output_device.clone();
    let width = ui.available_width();
    egui::ComboBox::from_id_salt("settings-output-device")
        .selected_text(tr(&selected))
        .truncate()
        .width(width)
        .show_ui(ui, |ui| {
            ui.set_min_width(width);
            crate::ui::motion::selectable_value(ui, &mut requested, None, &default_label);
            for device in &spotify.audio_devices {
                crate::ui::motion::selectable_value(
                    ui,
                    &mut requested,
                    Some(device.clone()),
                    device,
                );
            }
        });
    if requested != audio.output_device {
        audio.output_device = requested.clone();
        spotify.set_output_device(runtime, requested);
        *changed = true;
    }
}
