use crate::ui::i18n::tr;
use eframe::egui::{self, Align, Layout, Pos2, Rect, RichText, Sense, Stroke, Ui, Vec2};

use crate::{
    settings::{AudioSettings, EQ_FREQUENCIES_HZ},
    spotify::SpotifyRuntime,
    state::SpotifyViewState,
    ui::{
        theme::{self, colors, layout},
        widgets,
    },
};

/// Draws the equalizer and audio output controls.
pub fn show(
    ui: &mut Ui,
    audio: &mut AudioSettings,
    spotify: &mut SpotifyViewState,
    runtime: &SpotifyRuntime,
    changed: &mut bool,
) {
    ui.add_space(if ui.ctx().content_rect().height() < 720.0 {
        12.0
    } else {
        28.0
    });
    if ui.available_width() >= 960.0 {
        let total_width = ui.available_width();
        let right_width = 320.0;
        let left_width = total_width - right_width - 14.0;
        ui.horizontal(|ui| {
            ui.allocate_ui_with_layout(
                Vec2::new(left_width, ui.available_height()),
                Layout::top_down(Align::Min),
                |ui| equalizer_card(ui, audio, changed),
            );
            ui.allocate_ui_with_layout(
                Vec2::new(right_width, ui.available_height()),
                Layout::top_down(Align::Min),
                |ui| output_column(ui, audio, spotify, runtime, changed),
            );
        });
    } else {
        // Stack the graph and output controls in the page scroll area.
        equalizer_card(ui, audio, changed);
        ui.add_space(14.0);
        output_column(ui, audio, spotify, runtime, changed);
    }
    ui.add_space(24.0);
}

fn equalizer_card(ui: &mut Ui, audio: &mut AudioSettings, changed: &mut bool) {
    theme::elevated_frame(colors::surface(), layout::CARD_RADIUS)
        .inner_margin(egui::Margin::symmetric(28, 24))
        .show(ui, |ui| {
            ui.set_min_width(ui.available_width());
            ui.horizontal(|ui| {
                let title_width = (ui.available_width() - 156.0).max(1.0);
                ui.vertical(|ui| {
                    ui.set_width(title_width);
                    ui.label(
                        RichText::new(tr("Equalizer"))
                            .size(34.0)
                            .strong()
                            .color(colors::text()),
                    );
                    ui.label(
                        RichText::new(tr("Shape your sound. Feel the difference."))
                            .size(15.0)
                            .color(colors::text_muted()),
                    );
                });
                ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                    *changed |= widgets::eq_toggle(ui, &mut audio.eq_enabled).clicked();
                    ui.label(
                        RichText::new(tr(&(if audio.eq_enabled {
                            "Enabled"
                        } else {
                            "Disabled"
                        })))
                        .size(15.0)
                        .color(colors::text()),
                    );
                });
            });
            ui.add_space(24.0);
            let curve_changed = response_graph(ui, &mut audio.eq_db);
            *changed |= curve_changed;
            if curve_changed {
                ui.ctx().request_repaint();
            }
            ui.add_space(6.0);
            ui.label(
                RichText::new(tr("Drag the curve or its points to shape the sound. Double-click a point to reset it."))
                    .size(11.0)
                    .color(colors::text_disabled()),
            );
            ui.add_space(18.0);
            let available = ui.available_width();
            let band_width = ((available - 18.0) / audio.eq_db.len() as f32).max(54.0);
            egui::ScrollArea::horizontal()
                .id_salt("equalizer-bands")
                .auto_shrink([false, true])
                .show(ui, |ui| {
                    ui.horizontal(|ui| {
                        ui.spacing_mut().item_spacing.x = 2.0;
                        for (index, gain) in audio.eq_db.iter_mut().enumerate() {
                            ui.allocate_ui_with_layout(
                                Vec2::new(band_width, 286.0),
                                Layout::top_down(Align::Center),
                                |ui| {
                                    ui.label(
                                        RichText::new(tr(&(format!("{gain:+.1}"))))
                                            .size(13.0)
                                            .color(colors::text()),
                                    );
                                    ui.add_space(6.0);
                                    ui.spacing_mut().slider_width = 218.0;
                                    let slider = ui.add_sized(
                                        [24.0, 218.0],
                                        crate::ui::motion::control(egui::Slider::new(gain, -12.0..=12.0)
                                            .vertical()
                                            .show_value(false)
                                            .trailing_fill(false)
                                            .step_by(0.5), crate::ui::motion::Kind::Slider),
                                    );
                                    if slider.changed() {
                                        *changed = true;
                                        ui.ctx().request_repaint();
                                    }
                                    ui.add_space(4.0);
                                    ui.label(
                                        RichText::new(format_frequency(EQ_FREQUENCIES_HZ[index]))
                                            .size(12.0)
                                            .color(colors::text_muted()),
                                    );
                                },
                            );
                        }
                    });
                });
            ui.add_space(14.0);
            ui.horizontal_wrapped(|ui| {
                if ui
                    .add(
                        crate::ui::motion::control(egui::Button::new(tr("Reset"))
                            .fill(colors::surface_low())
                            .stroke(Stroke::new(1.0, colors::border()))
                            .corner_radius(9)
                            .min_size(Vec2::new(126.0, 40.0)), crate::ui::motion::Kind::Button),
                    )
                    .clicked()
                {
                    audio.eq_db.fill(0.0);
                    *changed = true;
                }
                ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                    ui.label(
                        RichText::new(tr("Your settings are saved automatically"))
                            .size(12.0)
                            .color(colors::text_muted()),
                    );
                });
            });
        });
}

fn response_graph(ui: &mut Ui, gains: &mut [f32]) -> bool {
    let height = (ui.available_width() * 0.38)
        .min(ui.ctx().content_rect().height() * 0.26)
        .clamp(150.0, 238.0);
    let (rect, mut response) = ui.allocate_exact_size(
        Vec2::new(ui.available_width(), height),
        Sense::click_and_drag(),
    );
    ui.painter().rect_filled(rect, 10, colors::surface_low());
    ui.painter().rect_stroke(
        rect,
        10,
        Stroke::new(1.0, colors::border()),
        egui::StrokeKind::Inside,
    );
    for row in 0..=4 {
        let y = egui::lerp(rect.top()..=rect.bottom(), row as f32 / 4.0);
        ui.painter().line_segment(
            [
                Pos2::new(rect.left() + 42.0, y),
                Pos2::new(rect.right() - 12.0, y),
            ],
            Stroke::new(1.0, colors::border()),
        );
    }
    for column in 0..gains.len() {
        let x = egui::lerp(
            (rect.left() + 42.0)..=(rect.right() - 12.0),
            column as f32 / (gains.len() - 1).max(1) as f32,
        );
        ui.painter().line_segment(
            [Pos2::new(x, rect.top()), Pos2::new(x, rect.bottom())],
            Stroke::new(1.0, colors::border().gamma_multiply(0.7)),
        );
    }
    for (label, fraction) in [
        ("+12", 0.0),
        ("+6", 0.25),
        ("0", 0.5),
        ("-6", 0.75),
        ("-12", 1.0),
    ] {
        ui.painter().text(
            Pos2::new(
                rect.left() + 10.0,
                egui::lerp(rect.top()..=rect.bottom(), fraction),
            ),
            egui::Align2::LEFT_CENTER,
            tr(label),
            egui::FontId::proportional(11.0),
            colors::text_muted(),
        );
    }
    let usable = Rect::from_min_max(
        Pos2::new(rect.left() + 42.0, rect.top() + 10.0),
        Pos2::new(rect.right() - 12.0, rect.bottom() - 10.0),
    );
    let mut changed = false;
    let pointer = response.interact_pointer_pos();
    if (response.dragged() || response.clicked()) && pointer.is_some() && !gains.is_empty() {
        let pointer = pointer.unwrap_or(usable.center());
        let index = nearest_band(usable, pointer.x, gains.len());
        let gain = gain_from_y(usable, pointer.y);
        if (gains[index] - gain).abs() > f32::EPSILON {
            gains[index] = gain;
            changed = true;
            response.mark_changed();
        }
    }
    if response.double_clicked() && !gains.is_empty() {
        if let Some(pointer) = pointer {
            let index = nearest_band(usable, pointer.x, gains.len());
            if gains[index].abs() > f32::EPSILON {
                gains[index] = 0.0;
                changed = true;
                response.mark_changed();
            }
        }
    }

    let control_points: Vec<_> = gains
        .iter()
        .enumerate()
        .map(|(index, gain)| point_for_gain(usable, index, gains.len(), *gain))
        .collect();
    let curve = smooth_curve(&control_points, 14);

    for pair in curve.windows(2) {
        let first = pair[0];
        let second = pair[1];
        ui.painter().add(egui::Shape::convex_polygon(
            vec![
                first,
                second,
                Pos2::new(second.x, usable.bottom()),
                Pos2::new(first.x, usable.bottom()),
            ],
            colors::accent().gamma_multiply(0.035),
            Stroke::NONE,
        ));
    }
    ui.painter().add(egui::Shape::line(
        curve.clone(),
        Stroke::new(7.0, colors::accent().gamma_multiply(0.045)),
    ));
    ui.painter()
        .add(egui::Shape::line(curve, Stroke::new(1.8, colors::accent())));

    let hovered_band = response
        .hover_pos()
        .map(|position| nearest_band(usable, position.x, gains.len()));
    for (index, point) in control_points.iter().enumerate() {
        let highlighted = hovered_band == Some(index) || response.dragged();
        let radius = if highlighted { 6.0 } else { 4.5 };
        if highlighted {
            ui.painter()
                .circle_filled(*point, 13.0, colors::accent().gamma_multiply(0.12));
        }
        ui.painter().circle_filled(
            *point,
            radius + 3.0,
            colors::background().gamma_multiply(0.88),
        );
        ui.painter().circle_filled(
            *point,
            radius,
            if highlighted {
                colors::accent_bright()
            } else {
                colors::surface_raised()
            },
        );
        ui.painter()
            .circle_stroke(*point, radius, Stroke::new(1.4, colors::accent()));
    }

    if let Some(index) = hovered_band {
        let point = control_points[index];
        let bubble = Rect::from_center_size(point - Vec2::new(0.0, 24.0), Vec2::new(92.0, 24.0))
            .translate(Vec2::new(
                (usable.left() + 46.0 - point.x).max(0.0)
                    + (usable.right() - 46.0 - point.x).min(0.0),
                0.0,
            ));
        ui.painter().rect_filled(bubble, 7, colors::surface_hover());
        ui.painter().rect_stroke(
            bubble,
            7,
            Stroke::new(1.0, colors::border_strong()),
            egui::StrokeKind::Inside,
        );
        ui.painter().text(
            bubble.center(),
            egui::Align2::CENTER_CENTER,
            tr(&(format!(
                "{}  {:+.1} dB",
                format_frequency(EQ_FREQUENCIES_HZ[index]),
                gains[index]
            ))),
            egui::FontId::proportional(11.0),
            colors::text(),
        );
    }

    response = response.on_hover_cursor(egui::CursorIcon::ResizeVertical);
    let _ = response;
    changed
}

fn nearest_band(area: Rect, pointer_x: f32, band_count: usize) -> usize {
    if band_count <= 1 {
        return 0;
    }
    let fraction = ((pointer_x - area.left()) / area.width()).clamp(0.0, 1.0);
    (fraction * (band_count - 1) as f32).round() as usize
}

fn gain_from_y(area: Rect, pointer_y: f32) -> f32 {
    let gain = egui::remap_clamp(pointer_y, area.bottom()..=area.top(), -12.0..=12.0);
    (gain * 10.0).round() / 10.0
}

fn point_for_gain(area: Rect, index: usize, band_count: usize, gain: f32) -> Pos2 {
    Pos2::new(
        egui::lerp(
            area.left()..=area.right(),
            index as f32 / band_count.saturating_sub(1).max(1) as f32,
        ),
        egui::remap_clamp(gain, -12.0..=12.0, area.bottom()..=area.top()),
    )
}

fn smooth_curve(points: &[Pos2], subdivisions: usize) -> Vec<Pos2> {
    if points.len() < 2 {
        return points.to_vec();
    }
    let mut curve = Vec::with_capacity((points.len() - 1) * subdivisions + 1);
    for pair in points.windows(2) {
        for step in 0..subdivisions {
            let fraction = step as f32 / subdivisions as f32;
            let eased = fraction * fraction * (3.0 - 2.0 * fraction);
            curve.push(Pos2::new(
                egui::lerp(pair[0].x..=pair[1].x, fraction),
                egui::lerp(pair[0].y..=pair[1].y, eased),
            ));
        }
    }
    curve.push(*points.last().unwrap_or(&points[0]));
    curve
}

fn output_column(
    ui: &mut Ui,
    audio: &mut AudioSettings,
    spotify: &mut SpotifyViewState,
    runtime: &SpotifyRuntime,
    changed: &mut bool,
) {
    card(ui, |ui| {
        ui.label(
            RichText::new(tr("Output"))
                .size(20.0)
                .strong()
                .color(colors::text()),
        );
        ui.add_space(12.0);
        output_selector(ui, audio, spotify, runtime, changed);
        ui.add_space(18.0);
        *changed |= widgets::labeled_slider(
            ui,
            "Output volume",
            &mut audio.master_volume,
            0.0..=1.0,
            "",
            0.01,
        )
        .changed();
    });
    ui.add_space(14.0);
    card(ui, |ui| {
        ui.label(
            RichText::new(tr("Audio"))
                .size(20.0)
                .strong()
                .color(colors::text()),
        );
        ui.add_space(12.0);
        *changed |=
            widgets::labeled_slider(ui, "Preamp", &mut audio.preamp_db, -24.0..=6.0, " dB", 0.5)
                .changed();
        ui.add_space(8.0);
        *changed |= widgets::labeled_slider(
            ui,
            "Bass",
            &mut audio.bass_gain_db,
            -12.0..=12.0,
            " dB",
            0.5,
        )
        .changed();
        ui.add_space(8.0);
        *changed |= widgets::labeled_slider(
            ui,
            "Sub bass",
            &mut audio.sub_bass_db,
            -12.0..=12.0,
            " dB",
            0.5,
        )
        .changed();
        ui.add_space(8.0);
        *changed |= widgets::labeled_slider(
            ui,
            "Bass frequency",
            &mut audio.bass_frequency_hz,
            35.0..=180.0,
            " Hz",
            1.0,
        )
        .changed();
        ui.add_space(8.0);
        *changed |= widgets::labeled_slider(ui, "Bass Q", &mut audio.bass_q, 0.30..=3.00, "", 0.05)
            .changed();
        ui.separator();
        ui.horizontal(|ui| {
            ui.label(
                RichText::new(tr("Limiter / clipping protection")).color(colors::text_muted()),
            );
            ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                ui.label(
                    RichText::new(tr(&(if audio.eq_enabled { "On" } else { "Off" })))
                        .color(colors::text()),
                );
            });
        });
    });
    ui.add_space(14.0);
    card(ui, |ui| {
        ui.label(
            RichText::new(tr(
                &("Spoteq applies equalization to the active local Spotify or SoundCloud output."),
            ))
            .size(13.0)
            .color(colors::text_muted()),
        );
    });
}

fn output_selector(
    ui: &mut Ui,
    audio: &mut AudioSettings,
    spotify: &mut SpotifyViewState,
    runtime: &SpotifyRuntime,
    changed: &mut bool,
) {
    let default_label = spotify
        .default_audio_device
        .as_deref()
        .map(|name| format!("Default ({name})"))
        .unwrap_or_else(|| "Default System Device".to_owned());
    let selected = audio
        .output_device
        .as_deref()
        .unwrap_or(default_label.as_str())
        .to_owned();
    let mut requested = audio.output_device.clone();
    let width = ui.available_width();
    egui::ComboBox::from_id_salt("equalizer-output-device")
        .selected_text(tr(&selected))
        .truncate()
        .width(width)
        .show_ui(ui, |ui| {
            ui.set_min_width(width);
            crate::ui::motion::selectable_value(ui, &mut requested, None, &default_label);
            for device in &spotify.audio_devices {
                crate::ui::motion::selectable_value(
                    ui,
                    &mut requested,
                    Some(device.clone()),
                    device,
                );
            }
        });
    if requested != audio.output_device {
        audio.output_device = requested.clone();
        spotify.set_output_device(runtime, requested);
        *changed = true;
    }
}

fn card(ui: &mut Ui, content: impl FnOnce(&mut Ui)) {
    theme::elevated_frame(colors::surface(), 14)
        .inner_margin(egui::Margin::symmetric(22, 20))
        .show(ui, |ui| {
            ui.set_min_width(ui.available_width());
            content(ui);
        });
}

fn format_frequency(frequency: f32) -> String {
    if frequency >= 1_000.0 {
        format!("{} kHz", frequency / 1_000.0)
    } else {
        format!("{frequency:.0} Hz")
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn curve_pointer_maps_to_the_expected_band() {
        let area = Rect::from_min_max(Pos2::ZERO, Pos2::new(900.0, 120.0));
        assert_eq!(nearest_band(area, 0.0, 10), 0);
        assert_eq!(nearest_band(area, 450.0, 10), 5);
        assert_eq!(nearest_band(area, 900.0, 10), 9);
    }

    #[test]
    fn curve_y_maps_to_gain_and_clamps() {
        let area = Rect::from_min_max(Pos2::ZERO, Pos2::new(900.0, 120.0));
        assert_eq!(gain_from_y(area, 0.0), 12.0);
        assert_eq!(gain_from_y(area, 60.0), 0.0);
        assert_eq!(gain_from_y(area, 120.0), -12.0);
        assert_eq!(gain_from_y(area, 500.0), -12.0);
    }

    #[test]
    fn smoothed_wave_keeps_control_point_endpoints() {
        let points = [Pos2::new(0.0, 10.0), Pos2::new(20.0, 30.0)];
        let curve = smooth_curve(&points, 8);
        assert_eq!(curve.first(), Some(&points[0]));
        assert_eq!(curve.last(), Some(&points[1]));
    }
}
