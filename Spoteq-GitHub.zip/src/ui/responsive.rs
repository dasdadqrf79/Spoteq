//! Geometry in egui logical points; never changes the user's DPI or zoom.
use eframe::egui::{Pos2, Rect};

pub fn sidebar_width(width: f32) -> f32 {
    if width < 1100.0 {
        148.0
    } else if width < 1600.0 {
        202.0
    } else {
        238.0
    }
}

pub fn player_height(height: f32) -> f32 {
    if height < 720.0 { 122.0 } else { 138.0 }
}

pub fn grid(width: f32, minimum: f32, gap: f32) -> (usize, f32) {
    let columns = (((width + gap) / (minimum + gap)).floor() as usize).clamp(1, 4);
    (
        columns,
        ((width - gap * (columns - 1) as f32) / columns as f32).max(1.0),
    )
}

pub fn player_zones(rect: Rect) -> [Rect; 3] {
    let center = (rect.width() * 0.40).clamp(210.0, 640.0).min(rect.width());
    let side = (rect.width() - center) * 0.5;
    [
        Rect::from_min_max(rect.min, Pos2::new(rect.left() + side, rect.bottom())),
        Rect::from_min_max(
            Pos2::new(rect.left() + side, rect.top()),
            Pos2::new(rect.right() - side, rect.bottom()),
        ),
        Rect::from_min_max(Pos2::new(rect.right() - side, rect.top()), rect.max),
    ]
}

#[cfg(test)]
mod tests {
    use super::*;
    use eframe::egui::{Vec2, pos2};

    #[test]
    fn resize_and_dpi_matrix_keeps_transport_centered_and_cards_inside_parent() {
        for (width, height) in [
            (900., 650.),
            (1024., 768.),
            (1280., 720.),
            (1366., 768.),
            (1600., 900.),
            (1920., 1080.),
            (2560., 1440.),
        ] {
            for dpi in [1.0_f32, 1.25, 1.5, 1.75] {
                // Physical pixels converted to logical points; native minimum is 900x650 points.
                let w = (width / dpi).max(900.0);
                let h = (height / dpi).max(650.0);
                check(w, h);
            }
        }
        // Every intermediate point, including the breakpoint boundaries in both directions.
        for step in 0..=1660 {
            check(900.0 + step as f32, 650.0 + step as f32 * 0.45);
        }
    }

    fn check(width: f32, height: f32) {
        let rect = Rect::from_min_size(
            pos2(32.0, height - player_height(height)),
            Vec2::new(width - 64.0, 90.0),
        );
        let [left, center, right] = player_zones(rect);
        assert!((center.center().x - rect.center().x).abs() < 0.01);
        assert!(left.width() >= 230.0 && right.width() >= 230.0);
        assert!(center.width() >= 162.0);
        assert!(left.right() <= center.left() && center.right() <= right.left());
        let available = width - sidebar_width(width) - 60.0;
        let (columns, card) = grid(available, 214.0, 8.0);
        assert!(card * columns as f32 + 8.0 * (columns - 1) as f32 <= available + 0.01);
    }
}
