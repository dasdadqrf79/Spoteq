//! One-frame Start Radio request shared by track context menus.

use crate::{autoplay::RadioKind, catalog::TrackRow};

const RADIO_ID: &str = "spoteq-start-radio-request";

/// Provider-neutral Radio seed selected by the user.
#[derive(Debug, Clone)]
pub struct RadioRequest {
    /// Real provider track used by the recommendation engine.
    pub seed: TrackRow,
    /// Track-centered or artist-centered station.
    pub kind: RadioKind,
}

/// Stores the newest Radio request for the application coordinator.
pub fn request(context: &eframe::egui::Context, seed: &TrackRow, kind: RadioKind) {
    context.data_mut(|data| {
        data.insert_temp(
            eframe::egui::Id::new(RADIO_ID),
            RadioRequest {
                seed: seed.clone(),
                kind,
            },
        );
    });
}

/// Takes one pending request without accumulating old menu actions.
pub fn take(context: &eframe::egui::Context) -> Option<RadioRequest> {
    context.data_mut(|data| {
        let id = eframe::egui::Id::new(RADIO_ID);
        let request = data.get_temp::<RadioRequest>(id);
        data.remove::<RadioRequest>(id);
        request
    })
}
