//! Computed playlists backed by provider libraries and local listening history.
use crate::ui::i18n::tr;

use std::collections::HashMap;

use chrono::{DateTime, Local, Timelike, Utc};
use eframe::egui::{self, Align, Layout, RichText, ScrollArea, Ui, Vec2};

use crate::{
    autoplay::{AutoplayQueue, QueueOrigin},
    catalog::TrackRow,
    image_cache::CoverCache,
    provider_library::ProviderLibraryState,
    settings::SessionSettings,
    soundcloud::{SoundCloudRuntime, SoundCloudViewState},
    spotify::{PlaybackStatus, SpotifyRuntime},
    state::{MusicPage, SmartPlaylistKind, SpotifyViewState},
    ui::{
        search_page::{activate_row, centered_state, track_row},
        session_request,
        theme::{colors, layout},
        widgets,
    },
};

#[derive(Clone)]
struct PlayStats {
    key: String,
    track: TrackRow,
    plays: usize,
    skips: usize,
    completed: usize,
    night_plays: usize,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct SourceRevisions {
    history: u64,
    spotify_likes: u64,
    soundcloud_likes: u64,
}

/// Transient ordered rows; rebuilt only when a category or its source data changes.
#[derive(Debug, Default)]
pub struct SmartLibraryCache {
    category: Option<SmartPlaylistKind>,
    sources: Option<SourceRevisions>,
    rows: Vec<TrackRow>,
    #[cfg(test)]
    rebuilds: usize,
}

impl SmartLibraryCache {
    /// Coalesces changes from playback history and both provider libraries before rendering.
    pub fn refresh(
        &mut self,
        kind: SmartPlaylistKind,
        session: &SessionSettings,
        spotify: &SpotifyViewState,
        soundcloud: &SoundCloudViewState,
    ) {
        let sources = SourceRevisions {
            history: session.history_revision,
            spotify_likes: spotify.liked.revision,
            soundcloud_likes: soundcloud.likes.revision,
        };
        if self.category == Some(kind) && self.sources == Some(sources) {
            return;
        }
        let reason = if self.category != Some(kind) {
            "category changed"
        } else {
            "history or provider likes changed"
        };
        self.rows = computed_rows(kind, session, spotify, soundcloud);
        #[cfg(test)]
        {
            self.rebuilds += 1;
        }
        self.category = Some(kind);
        self.sources = Some(sources);
        tracing::debug!(
            category = kind.label(),
            reason,
            tracks = self.rows.len(),
            "Smart Library rebuilt"
        );
    }

    fn rows_for(&self, kind: SmartPlaylistKind) -> Option<&[TrackRow]> {
        (self.category == Some(kind)).then_some(self.rows.as_slice())
    }
}

/// Draws Smart Playlists without creating a second favorites database.
#[allow(clippy::too_many_arguments)]
pub fn show(
    ui: &mut Ui,
    selected: &mut SmartPlaylistKind,
    cache: &SmartLibraryCache,
    session: &mut SessionSettings,
    vibe_rename: &mut Option<(usize, String)>,
    settings_changed: &mut bool,
    spotify: &mut SpotifyViewState,
    soundcloud: &mut SoundCloudViewState,
    autoplay: &mut AutoplayQueue,
    provider_library: &mut ProviderLibraryState,
    covers: &mut CoverCache,
    spotify_runtime: &SpotifyRuntime,
    soundcloud_runtime: &SoundCloudRuntime,
) {
    widgets::page_header(ui, "Library", "Everything you return to.");

    let liked_count = spotify.liked.tracks.len() + soundcloud.likes.tracks.len();
    let cards = [
        (
            "Liked Songs",
            format!("{liked_count} provider likes"),
            Some(MusicPage::LikedSongs),
        ),
        (
            "Recently Played",
            format!("{} plays", session.history.len()),
            Some(MusicPage::History),
        ),
        (
            "Smart Playlists",
            "Made from your listening".to_owned(),
            None,
        ),
        (
            "Saved Vibes",
            format!("{} sessions", session.vibes.len()),
            None,
        ),
    ];
    let (_, card_width) =
        super::responsive::grid(ui.available_width(), 214.0, ui.spacing().item_spacing.x);
    ui.horizontal_wrapped(|ui| {
        for (title, subtitle, destination) in cards {
            let response = ui.add(crate::ui::motion::control(
                egui::Button::new(tr(&(format!("{title}\n{subtitle}"))))
                    .min_size(Vec2::new(card_width, 78.0))
                    .fill(colors::surface_raised())
                    .stroke(egui::Stroke::new(
                        1.0,
                        colors::border().gamma_multiply(0.82),
                    ))
                    .corner_radius(layout::CARD_RADIUS),
                crate::ui::motion::Kind::Button,
            ));
            if response.clicked()
                && let Some(destination) = destination
            {
                ui.ctx().data_mut(|data| {
                    data.insert_temp(egui::Id::new("spoteq-library-destination"), destination)
                });
            }
        }
    });
    ui.add_space(22.0);

    if !session.vibes.is_empty() {
        ui.label(
            RichText::new(tr("Saved Vibes"))
                .size(18.0)
                .strong()
                .color(colors::text()),
        );
        ui.label(
            RichText::new(tr("A Vibe is a saved snapshot of the current track, your upcoming queue, and Radio/Autoplay recommendations. Save one from Queue → Save current Vibe."))
                .size(12.0)
                .color(colors::text_muted()),
        );
        ui.add_space(10.0);
        let (vibe_columns, vibe_width) =
            super::responsive::grid(ui.available_width(), 250.0, ui.spacing().item_spacing.x);
        ScrollArea::vertical()
            .id_salt("saved-vibes")
            .max_height((ui.ctx().content_rect().height() * 0.30).clamp(120.0, 340.0))
            .auto_shrink([false, true])
            .show(ui, |ui| {
                egui::Grid::new("saved-vibe-grid")
                    .num_columns(vibe_columns)
                    .spacing(Vec2::new(8.0, 8.0))
                    .show(ui, |ui| {
                        let mut delete_vibe = None;
                        for (index, vibe) in session.vibes.iter().enumerate() {
                            crate::ui::motion::frame(
                                egui::Frame::new()
                                    .fill(colors::surface_raised())
                                    .stroke(egui::Stroke::new(1.0, colors::border()))
                                    .corner_radius(layout::CARD_RADIUS)
                                    .inner_margin(16),
                            )
                            .show(ui, |ui| {
                                ui.vertical(|ui| {
                                    ui.set_width((vibe_width - 34.0).max(1.0));
                                    ui.add(
                                        egui::Label::new(
                                            RichText::new(&vibe.title)
                                                .strong()
                                                .color(colors::text()),
                                        )
                                        .truncate(),
                                    );
                                    if let Some(time) =
                                        DateTime::<Utc>::from_timestamp_millis(vibe.saved_at_ms)
                                    {
                                        ui.label(
                                            RichText::new(
                                                time.with_timezone(&Local)
                                                    .format("%d.%m.%Y %H:%M")
                                                    .to_string(),
                                            )
                                            .size(11.0)
                                            .color(colors::text_muted()),
                                        );
                                    }
                                    let next_count = vibe.session.next_up.len();
                                    let auto_count = vibe.session.autoplay.len();
                                    ui.label(
                                        RichText::new(tr(&(format!(
                                            "{} tracks · {} queued · {} recommendations",
                                            1 + next_count + auto_count,
                                            next_count,
                                            auto_count
                                        ))))
                                        .size(11.0)
                                        .color(colors::text_disabled()),
                                    );
                                    ui.add_space(8.0);
                                    ui.horizontal(|ui| {
                                        if crate::ui::motion::button(ui, tr("Play"))
                                            .on_hover_text(tr(
                                                "Restore this queue and play its first track",
                                            ))
                                            .clicked()
                                        {
                                            session_request::request(
                                                ui.ctx(),
                                                vibe.session.clone(),
                                            );
                                        }
                                        ui.menu_button("More", |ui| {
                                            if crate::ui::motion::button(ui, tr("Play")).clicked() {
                                                session_request::request(
                                                    ui.ctx(),
                                                    vibe.session.clone(),
                                                );
                                                ui.close();
                                            }
                                            if crate::ui::motion::button(ui, tr("Rename")).clicked()
                                            {
                                                *vibe_rename = Some((index, vibe.title.clone()));
                                                ui.close();
                                            }
                                            if crate::ui::motion::button(
                                                ui,
                                                tr("Start Radio from Vibe"),
                                            )
                                            .clicked()
                                            {
                                                if let Some(track) = &vibe.session.current {
                                                    crate::ui::radio_request::request(
                                                        ui.ctx(),
                                                        track,
                                                        crate::autoplay::RadioKind::Track,
                                                    );
                                                }
                                                ui.close();
                                            }
                                            if crate::ui::motion::button(ui, tr("Delete")).clicked()
                                            {
                                                delete_vibe = Some(index);
                                                ui.close();
                                            }
                                        });
                                    });
                                });
                            });
                            if index % vibe_columns == vibe_columns - 1 {
                                ui.end_row();
                            }
                        }
                        if let Some(index) = delete_vibe {
                            session.vibes.remove(index);
                            *settings_changed = true;
                        }
                    });
            });
        ui.add_space(18.0);
    }

    let mut rename_result = None;
    if let Some((index, title)) = vibe_rename.as_mut() {
        egui::Window::new(crate::ui::i18n::tr("Rename Vibe"))
            .id(egui::Id::new("spoteq-rename-vibe"))
            .max_width((ui.ctx().content_rect().width() - 64.0).max(200.0))
            .max_height((ui.ctx().content_rect().height() - 100.0).max(100.0))
            .vscroll(true)
            .collapsible(false)
            .resizable(false)
            .show(ui.ctx(), |ui| {
                crate::ui::glass::window_contents(ui, |ui| {
                    ui.add_sized(
                        [ui.available_width().min(320.0), 38.0],
                        crate::ui::motion::control(
                            egui::TextEdit::singleline(title),
                            crate::ui::motion::Kind::Input,
                        ),
                    );
                    ui.horizontal(|ui| {
                        if crate::ui::motion::button(ui, tr("Cancel")).clicked() {
                            rename_result = Some(false);
                        }
                        if ui
                            .add_enabled(
                                !title.trim().is_empty(),
                                crate::ui::motion::control(
                                    egui::Button::new(tr("Save")),
                                    crate::ui::motion::Kind::Button,
                                ),
                            )
                            .clicked()
                        {
                            rename_result = Some(true);
                        }
                    });
                })
            });
        if let Some(save) = rename_result {
            if save && let Some(vibe) = session.vibes.get_mut(*index) {
                vibe.title = title.trim().chars().take(80).collect();
                *settings_changed = true;
            }
            *vibe_rename = None;
        }
    }

    if !session.history.is_empty() {
        ui.label(
            RichText::new(tr("Recently played"))
                .size(19.0)
                .strong()
                .color(colors::text()),
        );
        ui.horizontal_wrapped(|ui| {
            for entry in session.history.iter().take(4) {
                if ui
                    .add(crate::ui::motion::control(
                        egui::Button::new(tr(&(format!(
                            "{} · {}",
                            entry.track.title, entry.track.artist
                        ))))
                        .min_size(Vec2::new(190.0, 42.0))
                        .fill(colors::surface_raised())
                        .corner_radius(10),
                        crate::ui::motion::Kind::Button,
                    ))
                    .clicked()
                {
                    session_request::request(
                        ui.ctx(),
                        crate::settings::ResumeSession {
                            current: Some(entry.track.clone()),
                            ..Default::default()
                        },
                    );
                }
            }
        });
        ui.add_space(18.0);
    }

    ui.horizontal_wrapped(|ui| {
        for kind in SmartPlaylistKind::ALL {
            let active = *selected == kind;
            if ui
                .add(crate::ui::motion::control(
                    egui::Button::new(tr(&(kind.label())))
                        .min_size(Vec2::new(142.0, 38.0))
                        .fill(if active {
                            colors::surface_hover()
                        } else {
                            colors::surface_low()
                        })
                        .stroke(egui::Stroke::new(
                            1.0,
                            if active {
                                colors::accent()
                            } else {
                                colors::border()
                            },
                        ))
                        .corner_radius(9),
                    crate::ui::motion::Kind::Button,
                ))
                .clicked()
            {
                *selected = kind;
            }
        }
    });
    ui.add_space(16.0);

    let Some(rows) = cache.rows_for(*selected) else {
        ui.ctx().request_repaint();
        centered_state(ui, "Preparing Smart Library", None, false);
        return;
    };
    if rows.is_empty() {
        centered_state(
            ui,
            "Not enough listening data yet",
            Some("Play and like more tracks; this playlist updates automatically."),
            false,
        );
        return;
    }

    ui.horizontal(|ui| {
        ui.label(
            RichText::new(tr(&(format!(
                "{} - {} tracks",
                selected.label(),
                rows.len()
            ))))
            .color(colors::text_muted()),
        );
        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
            if crate::ui::motion::button(ui, tr("Start Radio")).clicked()
                && let Some(seed) = rows.first()
            {
                crate::ui::radio_request::request(
                    ui.ctx(),
                    seed,
                    crate::autoplay::RadioKind::Track,
                );
            }
        });
    });
    ui.add_space(8.0);

    let current_key = soundcloud
        .playback
        .track
        .as_ref()
        .map(TrackRow::stable_key)
        .or_else(|| {
            spotify
                .playback
                .track
                .as_ref()
                .map(|track| TrackRow::from_spotify(track).stable_key())
        });
    let playing = if soundcloud.playback.track.is_some() {
        soundcloud.playback.status == PlaybackStatus::Playing
    } else {
        spotify.playback.status == PlaybackStatus::Playing
    };
    let mut clicked = None;

    ScrollArea::vertical()
        .id_salt(("smart-library-tracks", selected.label()))
        .max_height((ui.ctx().content_rect().height() * 0.55).max(160.0))
        .auto_shrink([false, false])
        .show_rows(ui, layout::TRACK_ROW, rows.len(), |ui, range| {
            for index in range {
                let track = &rows[index];
                provider_library.ensure_loaded(track, spotify_runtime, soundcloud_runtime);
                let pending = provider_library.visual(track).pending;
                let current = current_key.as_deref() == Some(track.stable_key().as_str());
                let action = ui
                    .push_id(track.stable_key(), |ui| {
                        track_row(
                            ui,
                            index + 1,
                            track,
                            pending,
                            current,
                            current && playing,
                            covers,
                            spotify_runtime,
                            soundcloud_runtime,
                            provider_library,
                        )
                    })
                    .inner;
                if action.clicked || action.queue_action == Some(QueueOrigin::Normal) {
                    clicked = Some(track.stable_key());
                }
                match action.queue_action {
                    Some(QueueOrigin::PlayNext) => {
                        let _ = autoplay.enqueue_play_next(track.clone());
                    }
                    Some(QueueOrigin::Manual) => {
                        let _ = autoplay.enqueue_manual(track.clone());
                    }
                    _ => {}
                }
                if let Some(change) = action.library_change
                    && let Err(error) =
                        provider_library.toggle(&change, spotify_runtime, soundcloud_runtime)
                {
                    spotify.toast_error(error);
                }
            }
        });

    if let Some(key) = clicked {
        activate_row(
            rows,
            &key,
            spotify,
            soundcloud,
            autoplay,
            spotify_runtime,
            soundcloud_runtime,
        );
    }
}

fn computed_rows(
    kind: SmartPlaylistKind,
    session: &SessionSettings,
    spotify: &SpotifyViewState,
    soundcloud: &SoundCloudViewState,
) -> Vec<TrackRow> {
    match kind {
        SmartPlaylistKind::RecentlyLiked | SmartPlaylistKind::ProviderMix => {
            liked_rows(spotify, soundcloud)
                .into_iter()
                .take(100)
                .collect()
        }
        SmartPlaylistKind::Discovery => {
            let stats = play_stats(session);
            liked_rows(spotify, soundcloud)
                .into_iter()
                .filter(|track| {
                    stats
                        .get(&track.stable_key())
                        .is_none_or(|stat| stat.plays <= 1)
                })
                .take(100)
                .collect()
        }
        SmartPlaylistKind::MostPlayed => {
            let mut values = play_stats(session).into_values().collect::<Vec<_>>();
            values.sort_by(|left, right| {
                right
                    .plays
                    .cmp(&left.plays)
                    .then_with(|| right.completed.cmp(&left.completed))
                    .then_with(|| left.key.cmp(&right.key))
            });
            values
                .into_iter()
                .map(|stat| stat.track)
                .take(100)
                .collect()
        }
        SmartPlaylistKind::NeverSkipped => {
            let mut values = play_stats(session)
                .into_values()
                .filter(|stat| stat.plays > 0 && stat.skips == 0)
                .collect::<Vec<_>>();
            values.sort_by(|left, right| {
                right
                    .completed
                    .cmp(&left.completed)
                    .then_with(|| right.plays.cmp(&left.plays))
                    .then_with(|| left.key.cmp(&right.key))
            });
            values
                .into_iter()
                .map(|stat| stat.track)
                .take(100)
                .collect()
        }
        SmartPlaylistKind::Night => {
            let mut values = play_stats(session)
                .into_values()
                .filter(|stat| stat.night_plays > 0)
                .collect::<Vec<_>>();
            values.sort_by(|left, right| {
                right
                    .night_plays
                    .cmp(&left.night_plays)
                    .then_with(|| right.plays.cmp(&left.plays))
                    .then_with(|| left.key.cmp(&right.key))
            });
            values
                .into_iter()
                .map(|stat| stat.track)
                .take(100)
                .collect()
        }
    }
}

fn liked_rows(spotify: &SpotifyViewState, soundcloud: &SoundCloudViewState) -> Vec<TrackRow> {
    let spotify_likes = spotify
        .liked
        .tracks
        .iter()
        .map(TrackRow::from_spotify)
        .collect::<Vec<_>>();
    interleave(&spotify_likes, &soundcloud.likes.tracks)
}

fn play_stats(session: &SessionSettings) -> HashMap<String, PlayStats> {
    let mut stats = HashMap::new();
    for entry in &session.history {
        let key = entry.track.stable_key();
        let stat = stats.entry(key.clone()).or_insert_with(|| PlayStats {
            key,
            track: entry.track.clone(),
            plays: 0,
            skips: 0,
            completed: 0,
            night_plays: 0,
        });
        stat.plays += 1;
        stat.skips += usize::from(entry.skipped);
        stat.completed += usize::from(entry.completed);
        if let Some(time) = DateTime::<Utc>::from_timestamp_millis(entry.started_at_ms) {
            let hour = time.with_timezone(&Local).hour();
            if hour >= 21 || hour < 6 {
                stat.night_plays += 1;
            }
        }
    }
    stats
}

fn interleave(spotify: &[TrackRow], soundcloud: &[TrackRow]) -> Vec<TrackRow> {
    let mut rows = Vec::with_capacity(spotify.len() + soundcloud.len());
    let length = spotify.len().max(soundcloud.len());
    for index in 0..length {
        if let Some(track) = spotify.get(index) {
            rows.push(track.clone());
        }
        if let Some(track) = soundcloud.get(index) {
            rows.push(track.clone());
        }
    }
    rows
}

#[cfg(test)]
mod tests {
    use chrono::{Local, TimeZone};

    use super::{SmartLibraryCache, interleave, play_stats};
    use crate::{
        catalog::{ProviderTrackId, TrackProvider, TrackRow},
        settings::SessionSettings,
        soundcloud::SoundCloudViewState,
        state::{SmartPlaylistKind, SpotifyViewState},
    };

    fn track(provider: TrackProvider, id: &str) -> TrackRow {
        let provider_id = match provider {
            TrackProvider::Spotify => ProviderTrackId::Spotify {
                id: id.to_owned(),
                uri: format!("spotify:track:{id}"),
            },
            TrackProvider::SoundCloud => ProviderTrackId::SoundCloud {
                id: id.to_owned(),
                urn: Some(format!("soundcloud:tracks:{id}")),
                permalink_url: None,
            },
        };
        TrackRow {
            provider,
            provider_id,
            title: format!("Track {id}"),
            artist: "Artist".to_owned(),
            collection: "Collection".to_owned(),
            duration_ms: 100_000,
            artwork_url: None,
            liked: Some(true),
            playable: true,
        }
    }

    #[test]
    fn provider_mix_interleaves_without_cross_provider_deduplication() {
        let spotify = vec![track(TrackProvider::Spotify, "one")];
        let soundcloud = vec![track(TrackProvider::SoundCloud, "one")];
        let mixed = interleave(&spotify, &soundcloud);
        assert_eq!(mixed.len(), 2);
        assert_eq!(mixed[0].provider, TrackProvider::Spotify);
        assert_eq!(mixed[1].provider, TrackProvider::SoundCloud);
    }

    #[test]
    fn local_stats_use_observed_completion_and_skip_outcomes() {
        let completed = track(TrackProvider::Spotify, "complete");
        let skipped = track(TrackProvider::SoundCloud, "skip");
        let mut session = SessionSettings::default();
        session.record_started(&completed, 1);
        session.finish_play(&completed.stable_key(), 90_000, 100_000);
        session.record_started(&skipped, 2);
        session.finish_play(&skipped.stable_key(), 2_000, 100_000);

        let stats = play_stats(&session);
        assert_eq!(stats[&completed.stable_key()].completed, 1);
        assert_eq!(stats[&skipped.stable_key()].skips, 1);
    }

    #[test]
    fn tied_scores_have_a_provider_qualified_deterministic_order() {
        let spotify = SpotifyViewState::default();
        let soundcloud = SoundCloudViewState::default();
        let mut session = SessionSettings::default();
        for id in ["z", "a", "m"] {
            let row = track(TrackProvider::Spotify, id);
            session.record_started(&row, 1);
            session.finish_play(&row.stable_key(), 90_000, 100_000);
        }
        let mut cache = SmartLibraryCache::default();
        for category in [
            SmartPlaylistKind::MostPlayed,
            SmartPlaylistKind::NeverSkipped,
        ] {
            cache.refresh(category, &session, &spotify, &soundcloud);
            let ids = cache
                .rows
                .iter()
                .map(TrackRow::stable_key)
                .collect::<Vec<_>>();
            let expected = ["a", "m", "z"]
                .into_iter()
                .map(|id| track(TrackProvider::Spotify, id).stable_key())
                .collect::<Vec<_>>();
            assert_eq!(ids, expected);
        }
    }

    #[test]
    fn category_and_source_revisions_rebuild_only_when_needed() {
        let spotify = SpotifyViewState::default();
        let mut soundcloud = SoundCloudViewState::default();
        let mut session = SessionSettings::default();
        soundcloud.likes.tracks = vec![
            track(TrackProvider::SoundCloud, "b"),
            track(TrackProvider::SoundCloud, "a"),
        ];
        let mut cache = SmartLibraryCache::default();
        cache.refresh(
            SmartPlaylistKind::RecentlyLiked,
            &session,
            &spotify,
            &soundcloud,
        );
        let initial = cache
            .rows
            .iter()
            .map(TrackRow::stable_key)
            .collect::<Vec<_>>();
        for _ in 0..100 {
            cache.refresh(
                SmartPlaylistKind::RecentlyLiked,
                &session,
                &spotify,
                &soundcloud,
            );
        }
        assert_eq!(cache.rebuilds, 1);
        assert_eq!(
            cache
                .rows
                .iter()
                .map(TrackRow::stable_key)
                .collect::<Vec<_>>(),
            initial
        );

        cache.refresh(
            SmartPlaylistKind::Discovery,
            &session,
            &spotify,
            &soundcloud,
        );
        assert_eq!(cache.rebuilds, 2);
        session.record_started(&track(TrackProvider::SoundCloud, "a"), 2);
        cache.refresh(
            SmartPlaylistKind::Discovery,
            &session,
            &spotify,
            &soundcloud,
        );
        assert_eq!(cache.rebuilds, 3);
        soundcloud.likes.tracks.pop();
        soundcloud.likes.revision += 1;
        cache.refresh(
            SmartPlaylistKind::Discovery,
            &session,
            &spotify,
            &soundcloud,
        );
        assert_eq!(cache.rebuilds, 4);
    }

    #[test]
    fn every_category_keeps_its_order_across_repeated_refreshes() {
        let spotify = SpotifyViewState::default();
        let mut soundcloud = SoundCloudViewState::default();
        soundcloud.likes.tracks = vec![
            track(TrackProvider::SoundCloud, "z"),
            track(TrackProvider::SoundCloud, "a"),
        ];
        let mut session = SessionSettings::default();
        let night = Local
            .with_ymd_and_hms(2025, 1, 15, 23, 0, 0)
            .single()
            .expect("valid local night")
            .timestamp_millis();
        for id in ["z", "a"] {
            let row = track(TrackProvider::SoundCloud, id);
            session.record_started(&row, night);
            session.finish_play(&row.stable_key(), 90_000, row.duration_ms);
        }
        let mut cache = SmartLibraryCache::default();
        for category in SmartPlaylistKind::ALL {
            cache.refresh(category, &session, &spotify, &soundcloud);
            let ordered = cache
                .rows
                .iter()
                .map(TrackRow::stable_key)
                .collect::<Vec<_>>();
            if category == SmartPlaylistKind::Night {
                let expected = ["a", "z"]
                    .into_iter()
                    .map(|id| track(TrackProvider::SoundCloud, id).stable_key())
                    .collect::<Vec<_>>();
                assert_eq!(ordered, expected);
            }
            for _ in 0..30 {
                cache.refresh(category, &session, &spotify, &soundcloud);
                assert_eq!(
                    ordered,
                    cache
                        .rows
                        .iter()
                        .map(TrackRow::stable_key)
                        .collect::<Vec<_>>()
                );
            }
        }
        assert_eq!(cache.rebuilds, SmartPlaylistKind::ALL.len());
    }
}
