use crate::ui::i18n::tr;
use eframe::egui::{self, Align, Layout, RichText, ScrollArea, TextEdit, Ui};

use crate::{
    autoplay::{AutoplayQueue, QueueOrigin},
    catalog::{ProviderFilter, TrackRow},
    image_cache::CoverCache,
    provider_library::ProviderLibraryState,
    soundcloud::{SoundCloudRuntime, SoundCloudViewState},
    spotify::{PlaybackStatus, SpotifyRuntime},
    state::SpotifyViewState,
    ui::{
        search_page::{activate_row, centered_state, inline_notice, provider_filters, track_row},
        theme::{self, colors, layout},
        widgets,
    },
};

/// Draws the authenticated Spotify and SoundCloud libraries in one surface.
pub fn show(
    ui: &mut Ui,
    library_query: &mut String,
    filter: &mut ProviderFilter,
    spotify: &mut SpotifyViewState,
    soundcloud: &mut SoundCloudViewState,
    autoplay: &mut AutoplayQueue,
    provider_library: &mut ProviderLibraryState,
    covers: &mut CoverCache,
    spotify_runtime: &SpotifyRuntime,
    soundcloud_runtime: &SoundCloudRuntime,
) {
    widgets::page_header(
        ui,
        "Liked Songs",
        "Your favorite tracks from Spotify and SoundCloud, all in one place.",
    );
    let compact = ui.available_width() < 850.0;
    let toolbar = |ui: &mut Ui| {
        crate::ui::motion::frame(
            egui::Frame::new()
                .fill(colors::search_well())
                .stroke(egui::Stroke::new(1.0, colors::border()))
                .corner_radius(11)
                .shadow(theme::control_shadow())
                .inner_margin(egui::Margin::symmetric(4, 4)),
        )
        .show(ui, |ui| provider_filters(ui, filter));
        ui.allocate_ui_with_layout(
            egui::vec2(ui.available_width(), 50.0),
            Layout::right_to_left(Align::Center),
            |ui| {
                let input_width = (ui.available_width() - 40.0).clamp(120.0, 330.0);
                crate::ui::motion::frame(
                    egui::Frame::new()
                        .fill(colors::search_well())
                        .stroke(egui::Stroke::new(1.0, colors::border()))
                        .corner_radius(11)
                        .shadow(theme::control_shadow())
                        .inner_margin(egui::Margin::symmetric(14, 7)),
                )
                .show(ui, |ui| {
                    ui.add_sized(
                        [input_width, 34.0],
                        crate::ui::motion::control(
                            TextEdit::singleline(library_query)
                                .hint_text(tr("Search in your liked songs..."))
                                .frame(egui::Frame::NONE),
                            crate::ui::motion::Kind::Input,
                        ),
                    );
                });
            },
        );
    };
    if compact {
        ui.vertical(toolbar);
    } else {
        ui.horizontal(toolbar);
    }
    ui.add_space(16.0);

    let spotify_connected = spotify.is_authenticated();
    let soundcloud_connected = soundcloud.is_authenticated();
    if *filter == ProviderFilter::Spotify && !spotify_connected {
        centered_state(
            ui,
            "Spotify account required",
            Some("Connect Spotify to load your real Liked Songs."),
            false,
        );
        return;
    }
    if *filter == ProviderFilter::SoundCloud && !soundcloud_connected {
        centered_state(
            ui,
            "SoundCloud account required",
            Some("Connect SoundCloud from Settings > Accounts."),
            false,
        );
        return;
    }
    if *filter == ProviderFilter::All && !spotify_connected && !soundcloud_connected {
        centered_state(
            ui,
            "Connect a music service",
            Some("Open Settings > Accounts to load your real liked tracks."),
            false,
        );
        return;
    }

    let mut display_rows = library_rows(*filter, spotify, soundcloud);
    let normalized_query = library_query.trim().to_lowercase();
    if !normalized_query.is_empty() {
        display_rows.retain(|track| {
            track.title.to_lowercase().contains(&normalized_query)
                || track.artist.to_lowercase().contains(&normalized_query)
                || track.collection.to_lowercase().contains(&normalized_query)
        });
    }
    let track_count = display_rows.len();
    let loading = (filter.includes_spotify()
        && spotify_connected
        && spotify.liked.loading
        && spotify.liked.tracks.is_empty())
        || (filter.includes_soundcloud()
            && soundcloud_connected
            && soundcloud.likes.loading
            && soundcloud.likes.tracks.is_empty());
    let errors = library_errors(*filter, spotify, soundcloud);

    if track_count == 0 {
        if !errors.is_empty() {
            centered_state(
                ui,
                "Could not load Liked Songs",
                Some(&errors.join("\n")),
                false,
            );
            ui.add_space(8.0);
            if crate::ui::motion::button(ui, tr("Try again")).clicked() {
                if filter.includes_spotify() && spotify_connected {
                    spotify.load_liked(spotify_runtime, 0);
                }
                if filter.includes_soundcloud() && soundcloud_connected {
                    soundcloud.load_likes(soundcloud_runtime, false);
                }
            }
        } else if loading {
            centered_state(ui, "Loading liked tracks…", None, true);
        } else {
            centered_state(
                ui,
                "Your library is empty",
                Some("Tracks liked in the selected service will appear here."),
                false,
            );
        }
        return;
    }

    for error in errors {
        inline_notice(ui, &error, true);
    }
    if *filter == ProviderFilter::All && !soundcloud_connected {
        inline_notice(
            ui,
            "SoundCloud is not connected; showing Spotify Liked Songs only.",
            false,
        );
    }
    if *filter == ProviderFilter::All && !spotify_connected {
        inline_notice(
            ui,
            "Spotify is not connected; showing SoundCloud Likes only.",
            false,
        );
    }

    ui.horizontal(|ui| {
        ui.label(
            RichText::new(tr(&(format!("{} tracks", track_count))))
                .size(13.0)
                .color(colors::text_muted()),
        );
        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
            let spotify_ready = !filter.includes_spotify() || !spotify.liked.loading;
            let soundcloud_ready = !filter.includes_soundcloud() || !soundcloud.likes.loading;
            if ui
                .add_enabled(
                    spotify_ready && soundcloud_ready,
                    crate::ui::motion::control(
                        egui::Button::new(tr("Refresh"))
                            .fill(colors::surface())
                            .stroke(egui::Stroke::new(1.0, colors::border()))
                            .corner_radius(8),
                        crate::ui::motion::Kind::Button,
                    ),
                )
                .clicked()
            {
                if filter.includes_spotify() && spotify_connected {
                    provider_library.invalidate_provider(crate::catalog::TrackProvider::Spotify);
                    spotify.load_liked(spotify_runtime, 0);
                }
                if filter.includes_soundcloud() && soundcloud_connected {
                    provider_library.invalidate_provider(crate::catalog::TrackProvider::SoundCloud);
                    soundcloud.load_likes(soundcloud_runtime, false);
                }
            }
        });
    });
    ui.add_space(8.0);
    let current_key = soundcloud
        .playback
        .track
        .as_ref()
        .map(TrackRow::stable_key)
        .or_else(|| {
            spotify
                .playback
                .track
                .as_ref()
                .map(|track| TrackRow::from_spotify(track).stable_key())
        });
    let is_playing = if soundcloud.playback.track.is_some() {
        soundcloud.playback.status == PlaybackStatus::Playing
    } else {
        spotify.playback.status == PlaybackStatus::Playing
    };
    let mut clicked_key = None;
    let mut spotify_more = false;
    let mut soundcloud_more = false;

    let has_pagination = (filter.includes_spotify() && spotify.liked.has_more)
        || (filter.includes_soundcloud() && soundcloud.likes.next_href.is_some());
    // The extra virtual row is an infinite-scroll sentinel. It only becomes
    // visible near the bottom and starts one guarded request per provider.
    let visible_count = track_count + usize::from(has_pagination);
    ScrollArea::vertical()
        .auto_shrink([false, false])
        .show_rows(ui, layout::TRACK_ROW, visible_count, |ui, visible_rows| {
            for index in visible_rows {
                let Some(track) = display_rows.get(index).cloned() else {
                    pagination_sentinel(
                        ui,
                        *filter,
                        spotify,
                        soundcloud,
                        &mut spotify_more,
                        &mut soundcloud_more,
                    );
                    continue;
                };
                provider_library.ensure_loaded(&track, spotify_runtime, soundcloud_runtime);
                let pending = provider_library.visual(&track).pending;
                let current = current_key.as_deref() == Some(track.stable_key().as_str());
                let action = track_row(
                    ui,
                    index + 1,
                    &track,
                    pending,
                    current,
                    current && is_playing,
                    covers,
                    spotify_runtime,
                    soundcloud_runtime,
                    provider_library,
                );
                if action.clicked {
                    clicked_key = Some(track.stable_key());
                }
                match action.queue_action {
                    Some(QueueOrigin::Normal) => clicked_key = Some(track.stable_key()),
                    Some(QueueOrigin::PlayNext) => {
                        let _ = autoplay.enqueue_play_next(track.clone());
                    }
                    Some(QueueOrigin::Manual) => {
                        let _ = autoplay.enqueue_manual(track.clone());
                    }
                    Some(QueueOrigin::Autoplay) | None => {}
                }
                if let Some(change) = action.library_change
                    && let Err(error) =
                        provider_library.toggle(&change, spotify_runtime, soundcloud_runtime)
                {
                    spotify.toast_error(error);
                }
                ui.add_space(1.0);
            }
        });

    if spotify_more {
        spotify.load_liked(spotify_runtime, spotify.liked.next_offset);
    }
    if soundcloud_more {
        soundcloud.load_likes(soundcloud_runtime, true);
    }
    if let Some(key) = clicked_key {
        activate_row(
            &display_rows,
            &key,
            spotify,
            soundcloud,
            autoplay,
            spotify_runtime,
            soundcloud_runtime,
        );
    }
}

fn pagination_sentinel(
    ui: &mut Ui,
    filter: ProviderFilter,
    spotify: &SpotifyViewState,
    soundcloud: &SoundCloudViewState,
    spotify_more: &mut bool,
    soundcloud_more: &mut bool,
) {
    if filter.includes_spotify()
        && spotify.liked.has_more
        && !spotify.liked.loading
        && spotify.liked.error.is_none()
    {
        *spotify_more = true;
    }
    if filter.includes_soundcloud()
        && soundcloud.likes.next_href.is_some()
        && !soundcloud.likes.loading
        && soundcloud.likes.error.is_none()
    {
        *soundcloud_more = true;
    }
    let loading = *spotify_more
        || *soundcloud_more
        || (filter.includes_spotify() && spotify.liked.loading)
        || (filter.includes_soundcloud() && soundcloud.likes.loading);
    ui.allocate_ui_with_layout(
        egui::vec2(ui.available_width(), 54.0),
        Layout::centered_and_justified(egui::Direction::TopDown),
        |ui| {
            if loading {
                ui.horizontal(|ui| {
                    ui.spinner();
                    ui.label(
                        RichText::new(tr("Loading more liked tracks…"))
                            .size(12.0)
                            .color(colors::text_muted()),
                    );
                });
            } else {
                ui.label(
                    RichText::new(tr(
                        &("Scroll paused after a loading error. Use Refresh to retry."),
                    ))
                    .size(12.0)
                    .color(colors::text_muted()),
                );
            }
        },
    );
}

fn library_rows(
    filter: ProviderFilter,
    spotify: &SpotifyViewState,
    soundcloud: &SoundCloudViewState,
) -> Vec<TrackRow> {
    let mut rows = Vec::new();
    if filter.includes_spotify() && spotify.is_authenticated() {
        rows.extend(spotify.liked.tracks.iter().map(TrackRow::from_spotify));
    }
    if filter.includes_soundcloud() && soundcloud.is_authenticated() {
        rows.extend(soundcloud.likes.tracks.iter().cloned());
    }
    rows
}

fn library_errors(
    filter: ProviderFilter,
    spotify: &SpotifyViewState,
    soundcloud: &SoundCloudViewState,
) -> Vec<String> {
    let mut errors = Vec::new();
    if filter.includes_spotify() {
        if let Some(error) = &spotify.liked.error {
            errors.push(format!("Spotify: {error}"));
        }
    }
    if filter.includes_soundcloud() {
        if let Some(error) = &soundcloud.likes.error {
            errors.push(format!("SoundCloud: {error}"));
        }
    }
    errors
}
