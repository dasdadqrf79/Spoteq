//! Native always-on-top compact player sharing the main playback state.
use crate::ui::i18n::tr;

use eframe::egui::{self, Align, Layout, RichText, Sense, Vec2};

use crate::{
    autoplay::AutoplayQueue,
    catalog::{TrackProvider, TrackRow},
    image_cache::CoverCache,
    provider_library::ProviderLibraryState,
    settings::{PlaybackSettings, SessionSettings},
    soundcloud::{SoundCloudRuntime, SoundCloudViewState},
    spotify::{PlaybackStatus, SpotifyRuntime},
    state::SpotifyViewState,
    ui::{session_request, theme::colors, widgets},
};

/// Shows the compact secondary viewport. No playback backend is created here.
#[allow(clippy::too_many_arguments)]
pub fn show(
    context: &egui::Context,
    open: &mut bool,
    spotify: &mut SpotifyViewState,
    soundcloud: &mut SoundCloudViewState,
    autoplay: &mut AutoplayQueue,
    provider_library: &mut ProviderLibraryState,
    covers: &mut CoverCache,
    spotify_runtime: &SpotifyRuntime,
    soundcloud_runtime: &SoundCloudRuntime,
    playback: &PlaybackSettings,
    session: &SessionSettings,
    queue_open: &mut bool,
    toggle_playback_requested: &mut bool,
) {
    if !*open {
        return;
    }

    context.show_viewport_immediate(
        egui::ViewportId::from_hash_of("spoteq-mini-player"),
        egui::ViewportBuilder::default()
            .with_title("Spoteq Mini Player")
            .with_decorations(false)
            .with_resizable(false)
            .with_taskbar(false)
            .with_always_on_top()
            .with_inner_size([600.0, 148.0])
            .with_min_inner_size([600.0, 148.0])
            .with_max_inner_size([600.0, 148.0]),
        |ui, _class| {
            super::glass::background(ui);
            if super::motion::enabled(ui.ctx()) {
                ui.ctx()
                    .request_repaint_after(std::time::Duration::from_millis(50));
            }
            if ui.input(|input| input.viewport().close_requested()) {
                *open = false;
                return;
            }

            let soundcloud_active = soundcloud.playback.track.is_some();
            let active_track = if soundcloud_active {
                soundcloud.playback.track.clone()
            } else {
                spotify.playback.track.as_ref().map(TrackRow::from_spotify)
            };
            let shown_track = active_track.clone().or_else(|| {
                session
                    .resume
                    .as_ref()
                    .and_then(|resume| resume.current.clone())
            });
            let status = if soundcloud_active {
                soundcloud.playback.status.clone()
            } else {
                spotify.playback.status.clone()
            };

            egui::CentralPanel::default()
                .frame(
                    egui::Frame::new()
                        .fill(colors::surface_low())
                        .stroke(egui::Stroke::new(1.0, colors::border_strong()))
                        .corner_radius(14)
                        .inner_margin(12),
                )
                .show(ui, |ui| {
                    let drag_rect = ui.max_rect();
                    let drag =
                        ui.interact(drag_rect, egui::Id::new("mini-player-drag"), Sense::drag());
                    if drag.drag_started() {
                        ui.ctx().send_viewport_cmd(egui::ViewportCommand::StartDrag);
                    }

                    ui.with_layout(Layout::right_to_left(Align::Min), |ui| {
                        if ui
                            .add(crate::ui::motion::control(
                                egui::Button::new(RichText::new(tr("X")).size(12.0))
                                    .min_size(Vec2::splat(24.0))
                                    .fill(egui::Color32::TRANSPARENT)
                                    .corner_radius(6),
                                crate::ui::motion::Kind::Button,
                            ))
                            .on_hover_text(tr("Close Mini Player"))
                            .clicked()
                        {
                            *open = false;
                        }
                    });

                    ui.horizontal(|ui| {
                        match shown_track.as_ref().map(|track| track.provider) {
                            Some(TrackProvider::SoundCloud) => {
                                let _ = covers.show_soundcloud(
                                    ui,
                                    shown_track
                                        .as_ref()
                                        .and_then(|track| track.artwork_url.as_deref()),
                                    soundcloud_runtime,
                                    Vec2::splat(78.0),
                                );
                            }
                            _ => {
                                let _ = covers.show(
                                    ui,
                                    shown_track
                                        .as_ref()
                                        .and_then(|track| track.artwork_url.as_deref()),
                                    spotify_runtime,
                                    Vec2::splat(78.0),
                                );
                            }
                        }
                        ui.add_space(10.0);
                        ui.vertical(|ui| {
                            ui.set_width(158.0);
                            if let Some(track) = &shown_track {
                                ui.add(
                                    egui::Label::new(
                                        RichText::new(&track.title)
                                            .strong()
                                            .size(15.0)
                                            .color(colors::text()),
                                    )
                                    .truncate(),
                                );
                                ui.add(
                                    egui::Label::new(
                                        RichText::new(&track.artist)
                                            .size(12.0)
                                            .color(colors::text_muted()),
                                    )
                                    .truncate(),
                                );
                            } else {
                                ui.label(
                                    RichText::new(tr("Nothing playing")).color(colors::text()),
                                );
                                ui.label(
                                    RichText::new(tr("Choose a track"))
                                        .size(12.0)
                                        .color(colors::text_muted()),
                                );
                            }
                        });

                        if let Some(track) = active_track.as_ref() {
                            provider_library.ensure_loaded(
                                track,
                                spotify_runtime,
                                soundcloud_runtime,
                            );
                            let liked = provider_library.visual(track);
                            if widgets::heart_button(ui, liked.liked, !liked.pending).clicked()
                                && let Err(error) = provider_library.toggle(
                                    track,
                                    spotify_runtime,
                                    soundcloud_runtime,
                                )
                            {
                                spotify.toast_error(error);
                            }
                        } else {
                            ui.add_space(28.0);
                        }

                        let previous = widgets::player_button(
                            ui,
                            widgets::PlayerIcon::Previous,
                            active_track.is_some(),
                            false,
                        )
                        .on_hover_text(tr("Previous"))
                        .clicked();
                        let icon = if status == PlaybackStatus::Playing {
                            widgets::PlayerIcon::Pause
                        } else {
                            widgets::PlayerIcon::Play
                        };
                        let can_play = active_track.is_some()
                            || session
                                .resume
                                .as_ref()
                                .is_some_and(|resume| resume.current.is_some());
                        let toggle = widgets::player_button(ui, icon, can_play, true)
                            .on_hover_text(tr(&(if status == PlaybackStatus::Playing {
                                "Pause"
                            } else {
                                "Play"
                            })))
                            .clicked();
                        let next = widgets::player_button(
                            ui,
                            widgets::PlayerIcon::Next,
                            active_track.is_some()
                                && (autoplay.has_next(playback.autoplay_similar)
                                    || playback.repeat != crate::settings::RepeatMode::Off),
                            false,
                        )
                        .on_hover_text(tr("Next"))
                        .clicked();

                        if ui
                            .add(crate::ui::motion::control(
                                egui::Button::new(tr("Queue"))
                                    .min_size(Vec2::new(58.0, 34.0))
                                    .fill(colors::surface_raised())
                                    .corner_radius(8),
                                crate::ui::motion::Kind::Button,
                            ))
                            .clicked()
                        {
                            *queue_open = true;
                        }

                        let position = if soundcloud_active {
                            soundcloud.playback.displayed_position_ms()
                        } else {
                            spotify.playback.displayed_position_ms()
                        };
                        if previous {
                            autoplay.previous(
                                position,
                                spotify,
                                soundcloud,
                                spotify_runtime,
                                soundcloud_runtime,
                            );
                        }
                        if toggle {
                            if active_track.is_some() {
                                *toggle_playback_requested = true;
                            } else if let Some(resume) = session.resume.clone() {
                                session_request::request(ui.ctx(), resume);
                            }
                        }
                        if next {
                            autoplay.next(
                                position,
                                playback.autoplay_similar,
                                playback.repeat,
                                spotify,
                                soundcloud,
                                spotify_runtime,
                                soundcloud_runtime,
                            );
                        }
                    });
                });
        },
    );
}
