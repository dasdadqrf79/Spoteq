use crate::ui::i18n::tr;
use eframe::egui::{self, Align, Layout, RichText, ScrollArea, Sense, Vec2};

use crate::{
    autoplay::{AutoplayQueue, QueueEntryId, QueueSnapshotItem},
    catalog::{TrackProvider, TrackRow},
    image_cache::CoverCache,
    provider_library::ProviderLibraryState,
    settings::{ResumeSession, SessionSettings},
    soundcloud::{SoundCloudRuntime, SoundCloudViewState},
    spotify::SpotifyRuntime,
    state::SpotifyViewState,
    ui::{
        search_page::format_duration,
        theme::{self, colors},
    },
};

enum QueueAction {
    Play(QueueEntryId),
    PlayNext(QueueEntryId),
    AddToQueue(QueueEntryId),
    Remove(QueueEntryId),
    ToggleLike(TrackRow),
    Reorder(QueueEntryId, QueueEntryId),
    StartRadio(TrackRow),
    SaveVibe,
    Clear,
}

/// Draws the provider-neutral queue above the player without changing page layout.
#[allow(clippy::too_many_arguments)]
pub fn show(
    context: &egui::Context,
    open: &mut bool,
    clear_armed: &mut bool,
    vibe_draft: &mut Option<ResumeSession>,
    vibe_name: &mut String,
    queue: &mut AutoplayQueue,
    provider_library: &mut ProviderLibraryState,
    spotify: &mut SpotifyViewState,
    soundcloud: &mut SoundCloudViewState,
    covers: &mut CoverCache,
    spotify_runtime: &SpotifyRuntime,
    soundcloud_runtime: &SoundCloudRuntime,
    session: &mut SessionSettings,
    settings_changed: &mut bool,
) {
    let appearance = super::motion::visibility(context, egui::Id::new("queue-visibility"), *open);
    if !*open && appearance <= 0.01 {
        return;
    }
    let snapshot = queue.snapshot();
    let mut action = None;
    let position_ms = if soundcloud.playback.track.is_some() {
        soundcloud.playback.displayed_position_ms()
    } else {
        spotify.playback.displayed_position_ms()
    };

    let viewport = context.content_rect();
    let player_height = super::responsive::player_height(viewport.height());
    let queue_width = if viewport.width() < 1100.0 {
        (viewport.width() - 72.0).min(520.0)
    } else {
        440.0
    };
    egui::Area::new(egui::Id::new("spoteq-queue-panel"))
        .anchor(
            egui::Align2::RIGHT_BOTTOM,
            Vec2::new(-22.0, -player_height - 12.0),
        )
        .order(egui::Order::Foreground)
        .show(context, |ui| {
            if !*open {
                ui.disable();
            }
            ui.multiply_opacity(appearance);
            crate::ui::motion::frame(
                egui::Frame::new()
                    .fill(colors::surface_low())
                    .stroke(egui::Stroke::new(1.0, colors::border_strong()))
                    .corner_radius(16)
                    .shadow(theme::player_shadow())
                    .inner_margin(egui::Margin::symmetric(16, 14)),
            )
            .show(ui, |ui| {
                ui.set_width(queue_width);
                ui.vertical(|ui| {
                    ui.label(
                        RichText::new(
                            queue
                                .radio_title()
                                .map(std::borrow::Cow::Borrowed)
                                .unwrap_or_else(|| tr("Queue")),
                        )
                        .strong()
                        .size(22.0)
                        .color(colors::text()),
                    );
                    ui.allocate_ui_with_layout(
                        Vec2::new(queue_width, 36.0),
                        Layout::right_to_left(Align::Center),
                        |ui| {
                            if crate::ui::motion::button(ui, tr("Close")).clicked() {
                                *open = false;
                                *vibe_draft = None;
                            }
                            if snapshot.current.is_some()
                                && crate::ui::motion::button(ui, tr("Save current Vibe")).clicked()
                            {
                                action = Some(QueueAction::SaveVibe);
                            }
                            if let Some(current) = &snapshot.current
                                && crate::ui::motion::button(ui, tr("Radio")).clicked()
                            {
                                action = Some(QueueAction::StartRadio(current.track.clone()));
                            }
                            let clear_label = if *clear_armed {
                                "Confirm clear"
                            } else {
                                "Clear"
                            };
                            if crate::ui::motion::button(ui, tr(clear_label)).clicked() {
                                if *clear_armed {
                                    action = Some(QueueAction::Clear);
                                    *clear_armed = false;
                                } else {
                                    *clear_armed = true;
                                }
                            }
                        },
                    );
                });
                ui.add_space(8.0);
                ScrollArea::vertical()
                    .id_salt("unified-queue-scroll")
                    .max_height((viewport.height() - player_height - 180.0).max(80.0))
                    .auto_shrink([false, false])
                    .show(ui, |ui| {
                        section_label(ui, "Now Playing");
                        if let Some(current) = &snapshot.current {
                            if current_row(
                                ui,
                                current,
                                covers,
                                spotify_runtime,
                                soundcloud_runtime,
                                provider_library,
                            ) {
                                action = Some(QueueAction::ToggleLike(current.track.clone()));
                            }
                        } else {
                            empty_label(ui, "Nothing playing");
                        }

                        ui.add_space(12.0);
                        section_label(ui, "Next Up");
                        if snapshot.next_up.is_empty() {
                            empty_label(ui, "No user tracks queued");
                        }
                        for item in &snapshot.next_up {
                            if let Some(next) = future_row(
                                ui,
                                item,
                                covers,
                                spotify_runtime,
                                soundcloud_runtime,
                                provider_library,
                            ) {
                                action = Some(next);
                            }
                        }

                        ui.add_space(12.0);
                        section_label(
                            ui,
                            if queue.is_radio() {
                                "Radio"
                            } else {
                                "Autoplay"
                            },
                        );
                        if snapshot.autoplay.is_empty() {
                            empty_label(
                                ui,
                                if queue.is_radio() {
                                    "Radio recommendations are loading"
                                } else {
                                    "Recommendations will appear near queue end"
                                },
                            );
                        }
                        for item in &snapshot.autoplay {
                            if let Some(next) = future_row(
                                ui,
                                item,
                                covers,
                                spotify_runtime,
                                soundcloud_runtime,
                                provider_library,
                            ) {
                                action = Some(next);
                            }
                        }
                    });
            });
        });

    match action {
        Some(QueueAction::Play(id)) => {
            let _ = queue.play_now(
                &id,
                position_ms,
                spotify,
                soundcloud,
                spotify_runtime,
                soundcloud_runtime,
            );
        }
        Some(QueueAction::Remove(id)) => {
            let _ = queue.remove(&id);
        }
        Some(QueueAction::PlayNext(id)) => {
            let _ = queue.promote_play_next(&id);
        }
        Some(QueueAction::AddToQueue(id)) => {
            let _ = queue.move_to_manual(&id);
        }
        Some(QueueAction::Reorder(source, target)) => {
            let _ = queue.reorder(&source, &target);
        }
        Some(QueueAction::Clear) => queue.clear_future(),
        Some(QueueAction::StartRadio(track)) => {
            crate::ui::radio_request::request(context, &track, crate::autoplay::RadioKind::Track);
        }
        Some(QueueAction::SaveVibe) => {
            if let Some(current) = &snapshot.current {
                *vibe_name = queue.radio_title().map(str::to_owned).unwrap_or_else(|| {
                    format!("Vibe · {} — {}", current.track.artist, current.track.title)
                });
                *vibe_draft = Some(ResumeSession {
                    current: Some(current.track.clone()),
                    position_ms,
                    next_up: snapshot
                        .next_up
                        .iter()
                        .map(|item| item.track.clone())
                        .collect(),
                    autoplay: snapshot
                        .autoplay
                        .iter()
                        .map(|item| item.track.clone())
                        .collect(),
                    radio_title: queue.radio_title().map(str::to_owned),
                });
            }
        }
        Some(QueueAction::ToggleLike(track)) => {
            if let Err(error) = provider_library.toggle(&track, spotify_runtime, soundcloud_runtime)
            {
                spotify.toast_error(error);
            }
        }
        None => {}
    }

    let mut close_draft = false;
    let mut confirm_draft = false;
    if let Some(draft) = vibe_draft.as_ref() {
        let queued = draft.next_up.len();
        let recommended = draft.autoplay.len();
        egui::Window::new(crate::ui::i18n::tr("Save Vibe"))
            .id(egui::Id::new("spoteq-save-vibe-dialog"))
            .collapsible(false)
            .resizable(false)
            .default_width(390.0)
            .max_width((viewport.width() - 64.0).max(200.0))
            .max_height((viewport.height() - 100.0).max(100.0))
            .vscroll(true)
            .anchor(egui::Align2::CENTER_CENTER, Vec2::ZERO)
            .show(context, |ui| {
                crate::ui::glass::window_contents(ui, |ui| {
                    ui.label(RichText::new(tr("Name")).color(colors::text_muted()));
                    ui.add_sized(
                        [ui.available_width(), 38.0],
                        crate::ui::motion::control(
                            egui::TextEdit::singleline(vibe_name),
                            crate::ui::motion::Kind::Input,
                        ),
                    );
                    ui.add_space(12.0);
                    ui.label(
                    RichText::new(tr(&(format!(
                        "Includes: current track + {queued} queued + {recommended} recommendations"
                    ))))
                    .color(colors::text_muted()),
                );
                    ui.label(
                        RichText::new(tr(
                            &("Play Vibe restores this queue and starts its first track."),
                        ))
                        .size(12.0)
                        .color(colors::text_disabled()),
                    );
                    ui.add_space(16.0);
                    ui.horizontal(|ui| {
                        close_draft = crate::ui::motion::button(ui, tr("Cancel")).clicked();
                        confirm_draft = ui
                            .add_enabled(
                                !vibe_name.trim().is_empty(),
                                crate::ui::motion::control(
                                    egui::Button::new(tr("Save Vibe")).fill(colors::accent_dark()),
                                    crate::ui::motion::Kind::Button,
                                ),
                            )
                            .clicked();
                    });
                })
            });
    }
    if confirm_draft {
        if let Some(draft) = vibe_draft.take() {
            let title = vibe_name.trim().chars().take(80).collect::<String>();
            session.save_vibe(title.clone(), draft, chrono::Utc::now().timestamp_millis());
            *settings_changed = true;
            spotify.toast_success(format!("Saved Vibe: {title}"));
        }
    } else if close_draft {
        *vibe_draft = None;
    }
}

fn section_label(ui: &mut egui::Ui, label: &str) {
    ui.label(
        RichText::new(tr(label).to_uppercase())
            .size(11.0)
            .strong()
            .color(colors::text_muted()),
    );
    ui.add_space(4.0);
}

fn empty_label(ui: &mut egui::Ui, label: &str) {
    ui.label(
        RichText::new(tr(label))
            .size(13.0)
            .color(colors::text_disabled()),
    );
}

fn current_row(
    ui: &mut egui::Ui,
    item: &QueueSnapshotItem,
    covers: &mut CoverCache,
    spotify_runtime: &SpotifyRuntime,
    soundcloud_runtime: &SoundCloudRuntime,
    provider_library: &mut ProviderLibraryState,
) -> bool {
    provider_library.ensure_loaded(&item.track, spotify_runtime, soundcloud_runtime);
    let mut toggle_like = false;
    let frame = crate::ui::motion::frame(
        egui::Frame::new()
            .fill(colors::surface_hover())
            .stroke(egui::Stroke::new(
                1.0,
                colors::accent().gamma_multiply(0.35),
            ))
            .corner_radius(10)
            .inner_margin(egui::Margin::symmetric(8, 7)),
    )
    .show(ui, |ui| {
        row_content(
            ui,
            item,
            covers,
            spotify_runtime,
            soundcloud_runtime,
            false,
            provider_library,
            &mut toggle_like,
        )
    });
    frame.response.context_menu(|ui| {
        catalog_context_menu(ui, &item.track);
    });
    toggle_like
}

fn future_row(
    ui: &mut egui::Ui,
    item: &QueueSnapshotItem,
    covers: &mut CoverCache,
    spotify_runtime: &SpotifyRuntime,
    soundcloud_runtime: &SoundCloudRuntime,
    provider_library: &mut ProviderLibraryState,
) -> Option<QueueAction> {
    let mut toggle_like = false;
    provider_library.ensure_loaded(&item.track, spotify_runtime, soundcloud_runtime);
    let frame = crate::ui::motion::frame(
        egui::Frame::new()
            .fill(colors::surface())
            .corner_radius(10)
            .inner_margin(egui::Margin::symmetric(8, 6)),
    )
    .show(ui, |ui| {
        row_content(
            ui,
            item,
            covers,
            spotify_runtime,
            soundcloud_runtime,
            true,
            provider_library,
            &mut toggle_like,
        );
    });
    let response = frame
        .response
        .interact(Sense::click_and_drag())
        .on_hover_cursor(egui::CursorIcon::PointingHand);
    let drag_id = egui::Id::new("spoteq-queue-drag-item");
    if response.drag_started() {
        ui.ctx()
            .data_mut(|data| data.insert_temp(drag_id, item.id.clone()));
    }
    if response.hovered() && ui.input(|input| input.pointer.any_released()) {
        if let Some(source) = ui.ctx().data(|data| data.get_temp::<QueueEntryId>(drag_id)) {
            ui.ctx()
                .data_mut(|data| data.remove::<QueueEntryId>(drag_id));
            if source != item.id {
                return Some(QueueAction::Reorder(source, item.id.clone()));
            }
        }
    }
    let mut context_action = None;
    response.context_menu(|ui| {
        if crate::ui::motion::button(ui, tr("Play now")).clicked() {
            context_action = Some(QueueAction::Play(item.id.clone()));
            ui.close();
        }
        if crate::ui::motion::button(ui, tr("Play next")).clicked() {
            context_action = Some(QueueAction::PlayNext(item.id.clone()));
            ui.close();
        }
        if crate::ui::motion::button(ui, tr("Add to queue")).clicked() {
            context_action = Some(QueueAction::AddToQueue(item.id.clone()));
            ui.close();
        }
        if crate::ui::motion::button(ui, tr("Remove from queue")).clicked() {
            context_action = Some(QueueAction::Remove(item.id.clone()));
            ui.close();
        }
        if crate::ui::motion::button(
            ui,
            tr(&(if provider_library.visual(&item.track).liked {
                "Unlike"
            } else {
                "Like"
            })),
        )
        .clicked()
        {
            context_action = Some(QueueAction::ToggleLike(item.track.clone()));
            ui.close();
        }
        ui.separator();
        catalog_context_menu(ui, &item.track);
    });
    if toggle_like {
        Some(QueueAction::ToggleLike(item.track.clone()))
    } else if let Some(action) = context_action {
        Some(action)
    } else if response.clicked() {
        Some(QueueAction::Play(item.id.clone()))
    } else {
        None
    }
}

fn catalog_context_menu(ui: &mut egui::Ui, track: &TrackRow) {
    if crate::ui::motion::button(ui, tr("Start Radio from track")).clicked() {
        crate::ui::radio_request::request(ui.ctx(), track, crate::autoplay::RadioKind::Track);
        ui.close();
    }
    if crate::ui::motion::button(ui, tr("Start Radio from artist")).clicked() {
        crate::ui::radio_request::request(ui.ctx(), track, crate::autoplay::RadioKind::Artist);
        ui.close();
    }
    ui.separator();
    if crate::ui::motion::button(ui, tr("Browse artist")).clicked() {
        crate::ui::catalog_navigation::request(
            ui.ctx(),
            track,
            crate::catalog::SearchScope::Artists,
        );
        ui.close();
    }
    if !track.collection.trim().is_empty()
        && !track.collection.eq_ignore_ascii_case("soundcloud")
        && crate::ui::motion::button(ui, tr("Browse album")).clicked()
    {
        crate::ui::catalog_navigation::request(
            ui.ctx(),
            track,
            crate::catalog::SearchScope::Albums,
        );
        ui.close();
    }
    if crate::ui::motion::button(ui, tr("Find in playlists")).clicked() {
        crate::ui::catalog_navigation::request(
            ui.ctx(),
            track,
            crate::catalog::SearchScope::Playlists,
        );
        ui.close();
    }
}

fn row_content(
    ui: &mut egui::Ui,
    item: &QueueSnapshotItem,
    covers: &mut CoverCache,
    spotify_runtime: &SpotifyRuntime,
    soundcloud_runtime: &SoundCloudRuntime,
    compact: bool,
    provider_library: &ProviderLibraryState,
    toggle_like: &mut bool,
) {
    let metadata_width = ui.available_width() - 176.0;
    let _ = compact;
    ui.horizontal(|ui| {
        match item.track.provider {
            TrackProvider::Spotify => {
                let _ = covers.show(
                    ui,
                    item.track.artwork_url.as_deref(),
                    spotify_runtime,
                    Vec2::splat(42.0),
                );
            }
            TrackProvider::SoundCloud => {
                let _ = covers.show_soundcloud(
                    ui,
                    item.track.artwork_url.as_deref(),
                    soundcloud_runtime,
                    Vec2::splat(42.0),
                );
            }
        }
        ui.add_space(8.0);
        ui.vertical(|ui| {
            ui.set_width(metadata_width.max(1.0));
            ui.add(
                egui::Label::new(
                    RichText::new(&item.track.title)
                        .size(14.0)
                        .color(colors::text()),
                )
                .truncate(),
            );
            ui.add(
                egui::Label::new(
                    RichText::new(tr(&(format!(
                        "{} · {} · {}",
                        item.track.artist,
                        provider_label(item.track.provider),
                        item.origin.label()
                    ))))
                    .size(11.0)
                    .color(colors::text_muted()),
                )
                .truncate(),
            );
        });
        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
            ui.label(
                RichText::new(format_duration(item.track.duration_ms))
                    .monospace()
                    .size(11.0)
                    .color(colors::text_muted()),
            );
            let liked = provider_library.visual(&item.track);
            if crate::ui::widgets::heart_button(ui, liked.liked, !liked.pending)
                .on_hover_text(tr(&(match (item.track.provider, liked.liked) {
                    (TrackProvider::Spotify, true) => "Remove from Spotify Liked Songs",
                    (TrackProvider::Spotify, false) => "Save to Spotify Liked Songs",
                    (TrackProvider::SoundCloud, true) => "Unlike on SoundCloud",
                    (TrackProvider::SoundCloud, false) => "Like on SoundCloud",
                })))
                .clicked()
            {
                *toggle_like = true;
            }
        });
    });
}

fn provider_label(provider: TrackProvider) -> &'static str {
    match provider {
        TrackProvider::Spotify => "Spotify",
        TrackProvider::SoundCloud => "SoundCloud",
    }
}
