//! Small UI-only bridge used by context menus to open provider-aware catalog views.

use eframe::egui;

use crate::catalog::{ProviderFilter, SearchScope, TrackProvider, TrackRow};

const NAVIGATION_ID: &str = "spoteq-catalog-navigation";

/// A provider-scoped catalog destination derived from real track metadata.
#[derive(Debug, Clone)]
pub struct CatalogNavigation {
    pub query: String,
    pub filter: ProviderFilter,
    pub scope: SearchScope,
}

/// Queues navigation without coupling reusable row widgets to `AppState`.
pub fn request(context: &egui::Context, track: &TrackRow, scope: SearchScope) {
    let query = match scope {
        SearchScope::Artists => track.artist.trim(),
        SearchScope::Albums => track.collection.trim(),
        SearchScope::Tracks | SearchScope::Playlists => track.title.trim(),
    };
    if query.is_empty() || query.eq_ignore_ascii_case("soundcloud") {
        return;
    }
    let filter = match track.provider {
        TrackProvider::Spotify => ProviderFilter::Spotify,
        TrackProvider::SoundCloud => ProviderFilter::SoundCloud,
    };
    context.data_mut(|data| {
        data.insert_temp(
            egui::Id::new(NAVIGATION_ID),
            CatalogNavigation {
                query: query.to_owned(),
                filter,
                scope,
            },
        );
    });
}

/// Takes the latest requested destination. One action replaces an older one.
pub fn take(context: &egui::Context) -> Option<CatalogNavigation> {
    context.data_mut(|data| {
        let id = egui::Id::new(NAVIGATION_ID);
        let navigation = data.get_temp::<CatalogNavigation>(id);
        data.remove::<CatalogNavigation>(id);
        navigation
    })
}
