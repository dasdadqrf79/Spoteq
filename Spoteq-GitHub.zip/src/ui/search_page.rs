use crate::ui::i18n::tr;
use eframe::egui::{
    self, Align, Layout, Rect, RichText, ScrollArea, Sense, Stroke, TextEdit, Ui, Vec2,
};

use crate::{
    autoplay::{AutoplayQueue, QueueOrigin},
    catalog::{ProviderFilter, SearchScope, TrackProvider, TrackRow},
    image_cache::CoverCache,
    provider_library::ProviderLibraryState,
    settings::SearchHistorySettings,
    soundcloud::{SoundCloudRuntime, SoundCloudSearchStatus, SoundCloudViewState},
    spotify::{PlaybackStatus, SpotifyCommand, SpotifyRuntime},
    state::{AuthView, SearchStatus, SpotifyViewState},
    ui::{
        theme::{self, colors, layout},
        widgets,
    },
};

/// Draws one unified Search surface backed by Spotify and SoundCloud.
pub fn show(
    ui: &mut Ui,
    query: &mut String,
    filter: &mut ProviderFilter,
    scope: &mut SearchScope,
    spotify: &mut SpotifyViewState,
    soundcloud: &mut SoundCloudViewState,
    autoplay: &mut AutoplayQueue,
    provider_library: &mut ProviderLibraryState,
    history: &mut SearchHistorySettings,
    settings_changed: &mut bool,
    covers: &mut CoverCache,
    spotify_runtime: &SpotifyRuntime,
    soundcloud_runtime: &SoundCloudRuntime,
) {
    widgets::page_header(ui, "Search", "Find tracks from Spotify and SoundCloud.");
    let mut search_response = None;
    let mut clear_query = false;
    let available = ui.available_width();
    let search_width = if available < 850.0 {
        available
    } else {
        available - 480.0
    };
    let toolbar = |ui: &mut Ui| {
        let search = crate::ui::motion::frame(
            egui::Frame::new()
                .fill(colors::search_well())
                .stroke(Stroke::new(1.0, colors::border()))
                .corner_radius(11)
                .shadow(theme::control_shadow())
                .inner_margin(egui::Margin::symmetric(12, 6)),
        )
        .show(ui, |ui| {
            ui.horizontal(|ui| {
                search_icon(ui);
                let response = ui.add_sized(
                    [(search_width - 112.0).max(160.0), 40.0],
                    crate::ui::motion::control(
                        TextEdit::singleline(query)
                            .hint_text(tr("Search tracks and artists"))
                            .font(egui::TextStyle::Body)
                            .frame(egui::Frame::NONE),
                        crate::ui::motion::Kind::Input,
                    ),
                );
                clear_query |= clear_button(ui, !query.is_empty()).clicked();
                response
            })
            .inner
        });
        search_response = Some((search.response.rect, search.inner.has_focus()));
        if available >= 850.0 {
            ui.add_space(12.0);
        }
        crate::ui::motion::frame(
            egui::Frame::new()
                .fill(colors::search_well())
                .stroke(Stroke::new(1.0, colors::border()))
                .corner_radius(11)
                .shadow(theme::control_shadow())
                .inner_margin(egui::Margin::symmetric(4, 4)),
        )
        .show(ui, |ui| provider_filters(ui, filter));
    };
    // A toolbar must measure its content instead of centering in the page height.
    if available < 850.0 {
        ui.vertical(toolbar);
    } else {
        ui.horizontal(toolbar);
    }
    if clear_query {
        query.clear();
        spotify.search_edited(query);
        soundcloud.search_edited(query);
    }
    let (search_rect, search_focused) = search_response.unwrap_or((egui::Rect::NOTHING, false));
    if search_focused {
        ui.painter().rect_stroke(
            search_rect,
            11,
            Stroke::new(1.0, colors::border_strong()),
            egui::StrokeKind::Inside,
        );
    }
    ui.add_space(20.0);

    if query.trim().is_empty() {
        show_recent_activity(
            ui,
            query,
            *filter,
            spotify,
            soundcloud,
            autoplay,
            provider_library,
            history,
            settings_changed,
            covers,
            spotify_runtime,
            soundcloud_runtime,
        );
        return;
    }

    let spotify_connected = spotify.is_authenticated();
    let soundcloud_connected = soundcloud.is_authenticated();
    if *filter == ProviderFilter::Spotify && !spotify_connected {
        account_required(ui, &spotify.auth);
        return;
    }
    if *filter == ProviderFilter::SoundCloud && !soundcloud_connected {
        centered_state(
            ui,
            "SoundCloud account required",
            Some("Connect SoundCloud from Settings > Accounts."),
            false,
        );
        return;
    }
    if *filter == ProviderFilter::All && !spotify_connected && !soundcloud_connected {
        centered_state(
            ui,
            "Connect a music service",
            Some("Open Settings > Accounts to connect Spotify or SoundCloud."),
            false,
        );
        return;
    }

    let rows = search_rows(*filter, spotify, soundcloud);
    let loading = (filter.includes_spotify()
        && spotify_connected
        && matches!(
            spotify.search.status,
            SearchStatus::Debouncing | SearchStatus::Loading
        ))
        || (filter.includes_soundcloud()
            && soundcloud_connected
            && matches!(
                soundcloud.search.status,
                SoundCloudSearchStatus::Debouncing | SoundCloudSearchStatus::Loading
            ));

    if rows.is_empty() {
        let errors = search_errors(*filter, spotify, soundcloud);
        if !errors.is_empty() {
            centered_state(ui, "Search failed", Some(&errors.join("\n")), false);
            ui.add_space(8.0);
            if crate::ui::motion::button(ui, tr("Try again")).clicked() {
                if filter.includes_spotify() {
                    spotify.search_edited(query);
                }
                if filter.includes_soundcloud() {
                    soundcloud.search_edited(query);
                }
            }
        } else if loading {
            centered_state(ui, "Searching connected services…", None, true);
        } else {
            let detail = format!("No playable tracks match “{}”.", query.trim());
            centered_state(ui, "Nothing found", Some(&detail), false);
        }
        return;
    }

    for error in search_errors(*filter, spotify, soundcloud) {
        inline_notice(ui, &error, true);
    }
    if *filter == ProviderFilter::All && !soundcloud_connected {
        inline_notice(
            ui,
            "SoundCloud is not connected; showing Spotify results only.",
            false,
        );
    }
    if *filter == ProviderFilter::All && !spotify_connected {
        inline_notice(
            ui,
            "Spotify is not connected; showing SoundCloud results only.",
            false,
        );
    }

    let current_key = soundcloud
        .playback
        .track
        .as_ref()
        .map(TrackRow::stable_key)
        .or_else(|| {
            spotify
                .playback
                .track
                .as_ref()
                .map(|track| TrackRow::from_spotify(track).stable_key())
        });
    let is_playing = if soundcloud.playback.track.is_some() {
        soundcloud.playback.status == PlaybackStatus::Playing
    } else {
        spotify.playback.status == PlaybackStatus::Playing
    };
    let mut clicked_key = None;

    ui.horizontal(|ui| {
        for candidate in SearchScope::ALL {
            let selected = *scope == candidate;
            let response = ui.add_sized(
                [88.0, 38.0],
                crate::ui::motion::control(
                    egui::Button::new(
                        RichText::new(tr(&(candidate.label())))
                            .size(if selected { 16.0 } else { 15.0 })
                            .color(if selected {
                                colors::text()
                            } else {
                                colors::text_muted()
                            }),
                    )
                    .fill(egui::Color32::TRANSPARENT)
                    .stroke(Stroke::NONE)
                    .corner_radius(7),
                    crate::ui::motion::Kind::Button,
                ),
            );
            if response.clicked() {
                *scope = candidate;
            }
            if selected {
                ui.painter().rect_filled(
                    egui::Rect::from_center_size(
                        egui::Pos2::new(response.rect.center().x, response.rect.bottom() - 1.0),
                        Vec2::new(62.0, 3.0),
                    ),
                    2,
                    colors::accent(),
                );
            }
        }
        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
            ui.add(crate::ui::motion::control(
                egui::Button::new(tr("Most relevant"))
                    .fill(colors::surface())
                    .stroke(Stroke::new(1.0, colors::border()))
                    .corner_radius(9)
                    .min_size(Vec2::new(170.0, 40.0)),
                crate::ui::motion::Kind::Button,
            ))
            .on_hover_text(tr("Search results are ordered by provider relevance"));
            ui.label(
                RichText::new(tr(&(format!("About {} results", rows.len()))))
                    .size(13.0)
                    .color(colors::text_muted()),
            );
        });
    });
    ui.add_space(8.0);
    if *scope == SearchScope::Playlists && filter.includes_spotify() {
        inline_notice(
            ui,
            "Spotify limits access to public playlist contents; showing playable tracks matching the query.",
            false,
        );
        ui.add_space(4.0);
    }
    let has_more = filter.includes_soundcloud() && soundcloud.search.next_href.is_some();
    let visible_count = rows.len() + usize::from(has_more);
    ScrollArea::vertical()
        .auto_shrink([false, false])
        .show_rows(ui, layout::TRACK_ROW, visible_count, |ui, visible_rows| {
            for index in visible_rows {
                let Some(track) = rows.get(index) else {
                    ui.allocate_ui_with_layout(
                        Vec2::new(ui.available_width(), 54.0),
                        Layout::centered_and_justified(egui::Direction::TopDown),
                        |ui| {
                            if !soundcloud.search.loading_more && soundcloud.search.error.is_none()
                            {
                                soundcloud.load_more_search(query, soundcloud_runtime);
                            }
                            if soundcloud.search.loading_more {
                                ui.horizontal(|ui| {
                                    ui.spinner();
                                    ui.label(
                                        RichText::new(tr("Loading more results…"))
                                            .size(12.0)
                                            .color(colors::text_muted()),
                                    );
                                });
                            }
                        },
                    );
                    continue;
                };
                provider_library.ensure_loaded(track, spotify_runtime, soundcloud_runtime);
                let pending = provider_library.visual(track).pending;
                let current = current_key.as_deref() == Some(track.stable_key().as_str());
                let action = track_row(
                    ui,
                    index + 1,
                    track,
                    pending,
                    current,
                    current && is_playing,
                    covers,
                    spotify_runtime,
                    soundcloud_runtime,
                    provider_library,
                );
                if action.clicked {
                    clicked_key = Some(track.stable_key());
                }
                match action.queue_action {
                    Some(QueueOrigin::Normal) => clicked_key = Some(track.stable_key()),
                    Some(QueueOrigin::PlayNext) => {
                        let _ = autoplay.enqueue_play_next(track.clone());
                    }
                    Some(QueueOrigin::Manual) => {
                        let _ = autoplay.enqueue_manual(track.clone());
                    }
                    Some(QueueOrigin::Autoplay) | None => {}
                }
                if let Some(change) = action.library_change
                    && let Err(error) =
                        provider_library.toggle(&change, spotify_runtime, soundcloud_runtime)
                {
                    spotify.toast_error(error);
                }
                ui.add_space(1.0);
            }
        });

    if let Some(key) = clicked_key {
        // Search is a discovery surface, not an implicit queue. Only the
        // explicitly selected result enters the normal queue; similar-track
        // Autoplay may continue after that single item finishes.
        if let Some(selected) = rows.iter().find(|track| track.stable_key() == key) {
            *settings_changed |= history.record_track(selected);
            activate_row(
                std::slice::from_ref(selected),
                &key,
                spotify,
                soundcloud,
                autoplay,
                spotify_runtime,
                soundcloud_runtime,
            );
        }
    }
}

#[allow(clippy::too_many_arguments)]
fn show_recent_activity(
    ui: &mut Ui,
    query: &mut String,
    filter: ProviderFilter,
    spotify: &mut SpotifyViewState,
    soundcloud: &mut SoundCloudViewState,
    autoplay: &mut AutoplayQueue,
    provider_library: &mut ProviderLibraryState,
    history: &mut SearchHistorySettings,
    settings_changed: &mut bool,
    covers: &mut CoverCache,
    spotify_runtime: &SpotifyRuntime,
    soundcloud_runtime: &SoundCloudRuntime,
) {
    if history.queries.is_empty() && history.tracks.is_empty() {
        centered_state(
            ui,
            "Start searching",
            Some("Find music across Spotify and SoundCloud."),
            false,
        );
        return;
    }

    if !history.queries.is_empty() {
        ui.horizontal(|ui| {
            ui.label(
                RichText::new(tr("Recent searches"))
                    .size(18.0)
                    .strong()
                    .color(colors::text()),
            );
            ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                if ui
                    .add(crate::ui::motion::control(
                        egui::Button::new(tr("Clear searches"))
                            .fill(colors::surface())
                            .stroke(Stroke::new(1.0, colors::border()))
                            .corner_radius(8),
                        crate::ui::motion::Kind::Button,
                    ))
                    .clicked()
                {
                    history.queries.clear();
                    *settings_changed = true;
                }
            });
        });
        ui.add_space(10.0);
        let recent_queries = history.queries.clone();
        ui.horizontal_wrapped(|ui| {
            ui.spacing_mut().item_spacing = Vec2::new(8.0, 8.0);
            for recent in recent_queries {
                if ui
                    .add(crate::ui::motion::control(
                        egui::Button::new(RichText::new(&recent).color(colors::text()))
                            .fill(colors::surface_raised())
                            .stroke(Stroke::new(1.0, colors::border()))
                            .corner_radius(10)
                            .min_size(Vec2::new(84.0, 36.0)),
                        crate::ui::motion::Kind::Button,
                    ))
                    .on_hover_text(tr("Search again"))
                    .clicked()
                {
                    *query = recent;
                }
            }
        });
        ui.add_space(24.0);
    }

    let recent_tracks = history
        .tracks
        .iter()
        .filter(|track| match track.provider {
            TrackProvider::Spotify => filter.includes_spotify(),
            TrackProvider::SoundCloud => filter.includes_soundcloud(),
        })
        .cloned()
        .collect::<Vec<_>>();
    if recent_tracks.is_empty() {
        return;
    }

    ui.horizontal(|ui| {
        ui.label(
            RichText::new(tr("Recently selected tracks"))
                .size(18.0)
                .strong()
                .color(colors::text()),
        );
        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
            if ui
                .add(crate::ui::motion::control(
                    egui::Button::new(tr("Clear tracks"))
                        .fill(colors::surface())
                        .stroke(Stroke::new(1.0, colors::border()))
                        .corner_radius(8),
                    crate::ui::motion::Kind::Button,
                ))
                .clicked()
            {
                history.tracks.clear();
                *settings_changed = true;
            }
        });
    });
    ui.add_space(8.0);

    let current_key = soundcloud
        .playback
        .track
        .as_ref()
        .map(TrackRow::stable_key)
        .or_else(|| {
            spotify
                .playback
                .track
                .as_ref()
                .map(|track| TrackRow::from_spotify(track).stable_key())
        });
    let is_playing = if soundcloud.playback.track.is_some() {
        soundcloud.playback.status == PlaybackStatus::Playing
    } else {
        spotify.playback.status == PlaybackStatus::Playing
    };
    let mut clicked_key = None;
    for (index, track) in recent_tracks.iter().enumerate() {
        provider_library.ensure_loaded(track, spotify_runtime, soundcloud_runtime);
        let current = current_key.as_deref() == Some(track.stable_key().as_str());
        let action = track_row(
            ui,
            index + 1,
            track,
            false,
            current,
            current && is_playing,
            covers,
            spotify_runtime,
            soundcloud_runtime,
            provider_library,
        );
        if action.clicked {
            clicked_key = Some(track.stable_key());
        }
        match action.queue_action {
            Some(QueueOrigin::Normal) => clicked_key = Some(track.stable_key()),
            Some(QueueOrigin::PlayNext) => {
                let _ = autoplay.enqueue_play_next(track.clone());
            }
            Some(QueueOrigin::Manual) => {
                let _ = autoplay.enqueue_manual(track.clone());
            }
            Some(QueueOrigin::Autoplay) | None => {}
        }
        if let Some(change) = action.library_change
            && let Err(error) =
                provider_library.toggle(&change, spotify_runtime, soundcloud_runtime)
        {
            spotify.toast_error(error);
        }
        ui.add_space(1.0);
    }

    if let Some(key) = clicked_key {
        let Some(selected) = recent_tracks.iter().find(|track| track.stable_key() == key) else {
            return;
        };
        let connected = match selected.provider {
            TrackProvider::Spotify => spotify.is_authenticated(),
            TrackProvider::SoundCloud => soundcloud.is_authenticated(),
        };
        if !connected {
            spotify.toast_error("Reconnect this track's music service before playback");
            return;
        }
        *settings_changed |= history.record_track(selected);
        activate_row(
            std::slice::from_ref(selected),
            &key,
            spotify,
            soundcloud,
            autoplay,
            spotify_runtime,
            soundcloud_runtime,
        );
    }
}

fn search_rows(
    filter: ProviderFilter,
    spotify: &SpotifyViewState,
    soundcloud: &SoundCloudViewState,
) -> Vec<TrackRow> {
    let mut rows = Vec::new();
    if filter.includes_spotify() && spotify.is_authenticated() {
        rows.extend(spotify.search.tracks.iter().map(TrackRow::from_spotify));
    }
    if filter.includes_soundcloud() && soundcloud.is_authenticated() {
        rows.extend(soundcloud.search.tracks.iter().cloned());
    }
    rows
}

fn search_errors(
    filter: ProviderFilter,
    spotify: &SpotifyViewState,
    soundcloud: &SoundCloudViewState,
) -> Vec<String> {
    let mut errors = Vec::new();
    if filter.includes_spotify() {
        if let SearchStatus::Error(error) = &spotify.search.status {
            errors.push(format!("Spotify: {error}"));
        }
    }
    if filter.includes_soundcloud() {
        if let Some(error) = &soundcloud.search.error {
            errors.push(format!("SoundCloud: {error}"));
        }
    }
    errors
}

pub(crate) fn activate_row(
    rows: &[TrackRow],
    key: &str,
    spotify: &mut SpotifyViewState,
    soundcloud: &mut SoundCloudViewState,
    autoplay: &mut AutoplayQueue,
    runtime: &SpotifyRuntime,
    soundcloud_runtime: &SoundCloudRuntime,
) {
    autoplay.start(rows, key, spotify, soundcloud, runtime, soundcloud_runtime);
}

pub(crate) struct TrackRowAction {
    pub clicked: bool,
    pub library_change: Option<TrackRow>,
    pub queue_action: Option<QueueOrigin>,
}

#[allow(clippy::too_many_arguments)]
pub(crate) fn track_row(
    ui: &mut Ui,
    index: usize,
    track: &TrackRow,
    pending: bool,
    current: bool,
    playing: bool,
    covers: &mut CoverCache,
    spotify_runtime: &SpotifyRuntime,
    soundcloud_runtime: &SoundCloudRuntime,
    provider_library: &ProviderLibraryState,
) -> TrackRowAction {
    let mut library_change = None;
    let mut cover_rect = None;
    let stable_key = track.stable_key();
    let hovered_id = ui.make_persistent_id(("track-hover", &stable_key));
    let fill = if current {
        colors::surface_hover()
    } else {
        colors::background()
    };

    let pointer_over_row = ui.ctx().pointer_hover_pos().is_some_and(|pointer| {
        let available = ui.available_rect_before_wrap();
        Rect::from_min_size(available.min, Vec2::new(available.width(), 54.0)).contains(pointer)
    });
    let row = crate::ui::motion::frame(
        egui::Frame::new()
            .fill(fill)
            .stroke(if current {
                Stroke::new(1.0, colors::accent().gamma_multiply(0.26))
            } else {
                Stroke::NONE
            })
            .corner_radius(8)
            .shadow(if current || pointer_over_row {
                theme::control_shadow()
            } else {
                egui::Shadow::NONE
            })
            .inner_margin(egui::Margin::symmetric(8, 1)),
    )
    .show(ui, |ui| {
        ui.set_min_width(ui.available_width());
        ui.set_min_height(52.0);
        ui.horizontal(|ui| {
            ui.allocate_ui_with_layout(
                Vec2::new(28.0, 52.0),
                Layout::centered_and_justified(egui::Direction::TopDown),
                |ui| {
                    if playing {
                        widgets::playing_eq_bars(ui);
                    } else {
                        ui.label(
                            RichText::new(index.to_string())
                                .monospace()
                                .size(11.0)
                                .color(colors::text_disabled()),
                        );
                    }
                },
            );
            let cover = match track.provider {
                TrackProvider::Spotify => covers.show(
                    ui,
                    track.artwork_url.as_deref(),
                    spotify_runtime,
                    Vec2::splat(50.0),
                ),
                TrackProvider::SoundCloud => covers.show_soundcloud(
                    ui,
                    track.artwork_url.as_deref(),
                    soundcloud_runtime,
                    Vec2::splat(50.0),
                ),
            };
            cover_rect = Some(cover.rect);
            ui.add_space(18.0);
            let available = ui.available_width();
            let compact_row = available < 650.0;
            let trailing_width = if compact_row { 120.0 } else { 250.0 };
            let text_width = (available - trailing_width - 28.0).max(1.0);
            let title_width = text_width * 0.57;
            let artist_width = (text_width - title_width).max(1.0);
            ui.allocate_ui_with_layout(
                Vec2::new(title_width, 52.0),
                Layout::left_to_right(Align::Center),
                |ui| {
                    ui.set_max_width(title_width);
                    ui.add(
                        egui::Label::new(RichText::new(&track.title).size(16.0).color(
                            if current {
                                colors::accent()
                            } else {
                                colors::text()
                            },
                        ))
                        .truncate(),
                    );
                },
            );
            ui.allocate_ui_with_layout(
                Vec2::new(artist_width, 52.0),
                Layout::left_to_right(Align::Center),
                |ui| {
                    ui.set_max_width(artist_width);
                    ui.add(
                        egui::Label::new(
                            RichText::new(&track.artist)
                                .size(14.0)
                                .color(colors::text_muted()),
                        )
                        .truncate(),
                    );
                },
            );
            ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                more_button(ui);
                let liked = provider_library.visual(track);
                let tooltip = match (track.provider, liked.liked) {
                    (TrackProvider::Spotify, true) => "Remove from Spotify Liked Songs",
                    (TrackProvider::Spotify, false) => "Save to Spotify Liked Songs",
                    (TrackProvider::SoundCloud, true) => "Unlike on SoundCloud",
                    (TrackProvider::SoundCloud, false) => "Like on SoundCloud",
                };
                if widgets::heart_button(ui, liked.liked, !pending)
                    .on_hover_text(tooltip)
                    .clicked()
                {
                    library_change = Some(track.clone());
                }
                ui.add(
                    egui::Label::new(
                        RichText::new(format_duration(track.duration_ms))
                            .size(13.0)
                            .color(colors::text_muted()),
                    )
                    .wrap_mode(egui::TextWrapMode::Truncate),
                );
                ui.add_space(12.0);
                if !compact_row {
                    provider_badge(ui, track.provider);
                }
            });
        });
    });

    let response = row
        .response
        .interact(Sense::click())
        .on_hover_cursor(egui::CursorIcon::PointingHand);
    if current {
        ui.painter().rect_filled(
            egui::Rect::from_min_size(
                response.rect.left_top(),
                Vec2::new(2.0, response.rect.height()),
            ),
            0,
            colors::accent(),
        );
    }
    if response.hovered() && !current {
        let animation = if theme::motion_enabled() {
            ui.ctx().animate_bool_with_time(hovered_id, true, 0.12)
        } else {
            1.0
        };
        if track.playable && animation > 0.65 {
            maybe_preload_hover(ui, track, spotify_runtime, soundcloud_runtime);
        }
        ui.painter().rect_filled(
            response.rect,
            8,
            colors::text().gamma_multiply(0.03 * animation),
        );
        if track.playable {
            if let Some(rect) = cover_rect {
                widgets::paint_cover_action(ui.painter(), rect, playing);
            }
        }
    }
    if !current {
        ui.painter().line_segment(
            [response.rect.left_bottom(), response.rect.right_bottom()],
            Stroke::new(1.0, colors::border().gamma_multiply(0.58)),
        );
    }

    let mut queue_action = None;
    response.context_menu(|ui| {
        if crate::ui::motion::button(ui, tr("Play now")).clicked() {
            queue_action = Some(QueueOrigin::Normal);
            ui.close();
        }
        if crate::ui::motion::button(ui, tr("Play next")).clicked() {
            queue_action = Some(QueueOrigin::PlayNext);
            ui.close();
        }
        if crate::ui::motion::button(ui, tr("Add to queue")).clicked() {
            queue_action = Some(QueueOrigin::Manual);
            ui.close();
        }
        if crate::ui::motion::button(
            ui,
            tr(&(if provider_library.visual(track).liked {
                "Unlike"
            } else {
                "Like"
            })),
        )
        .clicked()
        {
            library_change = Some(track.clone());
            ui.close();
        }
        ui.separator();
        if crate::ui::motion::button(ui, tr("Start Radio from track")).clicked() {
            crate::ui::radio_request::request(ui.ctx(), track, crate::autoplay::RadioKind::Track);
            ui.close();
        }
        if crate::ui::motion::button(ui, tr("Start Radio from artist")).clicked() {
            crate::ui::radio_request::request(ui.ctx(), track, crate::autoplay::RadioKind::Artist);
            ui.close();
        }
        ui.separator();
        if crate::ui::motion::button(ui, tr("Browse artist")).clicked() {
            crate::ui::catalog_navigation::request(ui.ctx(), track, SearchScope::Artists);
            ui.close();
        }
        if !track.collection.trim().is_empty()
            && !track.collection.eq_ignore_ascii_case("soundcloud")
            && crate::ui::motion::button(ui, tr("Browse album")).clicked()
        {
            crate::ui::catalog_navigation::request(ui.ctx(), track, SearchScope::Albums);
            ui.close();
        }
        if crate::ui::motion::button(ui, tr("Find in playlists")).clicked() {
            crate::ui::catalog_navigation::request(ui.ctx(), track, SearchScope::Playlists);
            ui.close();
        }
    });

    TrackRowAction {
        clicked: response.clicked() && library_change.is_none(),
        library_change,
        queue_action,
    }
}

fn maybe_preload_hover(
    ui: &mut Ui,
    track: &TrackRow,
    spotify_runtime: &SpotifyRuntime,
    soundcloud_runtime: &SoundCloudRuntime,
) {
    let id = egui::Id::new("audio-hover-preload-key");
    let key = track.stable_key();
    let already = ui
        .ctx()
        .data(|data| data.get_temp::<String>(id))
        .is_some_and(|cached| cached == key);
    if already {
        return;
    }

    match track.provider {
        TrackProvider::Spotify => {
            if let Some(track) = track.to_spotify_track() {
                let _ = spotify_runtime.send(SpotifyCommand::PreloadTrack { uri: track.uri });
            }
        }
        TrackProvider::SoundCloud => {
            // SoundCloud direct playback now starts progressively from the first HLS
            // segment. Avoid downloading an entire random track just because the
            // pointer briefly crossed a row; queue prefetch handles the true next item.
            let _ = soundcloud_runtime;
        }
    }
    ui.ctx().data_mut(|data| data.insert_temp(id, key));
}

fn more_button(ui: &mut Ui) {
    let (rect, response) = ui.allocate_exact_size(Vec2::splat(32.0), Sense::hover());
    for offset in [-6.0, 0.0, 6.0] {
        ui.painter().circle_filled(
            egui::Pos2::new(rect.center().x + offset, rect.center().y),
            1.6,
            colors::text_muted(),
        );
    }
    let _ = response.on_hover_text(tr("More"));
}

pub(crate) fn provider_filters(ui: &mut Ui, selected: &mut ProviderFilter) {
    let filters = [
        ProviderFilter::All,
        ProviderFilter::Spotify,
        ProviderFilter::SoundCloud,
    ];
    let labels: Vec<String> = ["All", "Spotify", "SoundCloud"]
        .iter()
        .map(|label| tr(label).into_owned())
        .collect();
    let widths = if ui.available_width() < 470.0 {
        [58.0, 118.0, 150.0]
    } else {
        [110.0, 150.0, 184.0]
    };
    let mut index = filters
        .iter()
        .position(|filter| filter == selected)
        .unwrap_or(0);
    let response = super::segments::show(
        ui,
        "provider-navigation",
        &mut index,
        &labels,
        &widths,
        44.0,
        |ui, index, rect, active| {
            let color = if active {
                colors::text()
            } else {
                colors::text_muted()
            };
            let (text_center, icon_center) = match filters[index] {
                ProviderFilter::All => (rect.center(), None),
                ProviderFilter::Spotify => (
                    rect.center() + Vec2::new(11.0, 0.0),
                    Some(rect.center() - Vec2::new(28.0, 0.0)),
                ),
                ProviderFilter::SoundCloud => (
                    rect.center() + Vec2::new(18.0, 0.0),
                    Some(rect.center() - Vec2::new(43.0, 0.0)),
                ),
            };
            if let Some(center) = icon_center {
                paint_provider_mark(ui.painter(), filters[index], center, color);
            }
            ui.painter().text(
                text_center,
                egui::Align2::CENTER_CENTER,
                &labels[index],
                egui::FontId::proportional(15.0),
                color,
            );
        },
    );
    if response.changed() {
        *selected = filters[index];
    }
}
fn search_icon(ui: &mut Ui) {
    let (rect, _) = ui.allocate_exact_size(Vec2::splat(28.0), Sense::hover());
    let center = rect.center() - Vec2::new(2.0, 2.0);
    ui.painter()
        .circle_stroke(center, 7.0, Stroke::new(1.6, colors::text()));
    ui.painter().line_segment(
        [center + Vec2::new(5.0, 5.0), center + Vec2::new(10.0, 10.0)],
        Stroke::new(1.8, colors::text()),
    );
}

fn clear_button(ui: &mut Ui, visible: bool) -> egui::Response {
    let sense = if visible {
        Sense::click()
    } else {
        Sense::hover()
    };
    let (rect, response) = ui.allocate_exact_size(Vec2::splat(30.0), sense);
    if visible {
        let color = if response.hovered() {
            colors::text()
        } else {
            colors::text_muted()
        };
        ui.painter().line_segment(
            [
                rect.center() - Vec2::splat(5.0),
                rect.center() + Vec2::splat(5.0),
            ],
            Stroke::new(1.6, color),
        );
        ui.painter().line_segment(
            [
                rect.center() + Vec2::new(-5.0, 5.0),
                rect.center() + Vec2::new(5.0, -5.0),
            ],
            Stroke::new(1.6, color),
        );
    }
    response
}

fn paint_provider_mark(
    painter: &egui::Painter,
    provider: ProviderFilter,
    center: egui::Pos2,
    color: egui::Color32,
) {
    match provider {
        ProviderFilter::Spotify => {
            painter.circle_filled(center, 9.0, color);
            for offset in [-3.0, 0.0, 3.0] {
                painter.line_segment(
                    [
                        center + Vec2::new(-5.0, offset - 1.0),
                        center + Vec2::new(5.0, offset + 1.0),
                    ],
                    Stroke::new(1.0, colors::background()),
                );
            }
        }
        ProviderFilter::SoundCloud => {
            painter.circle_filled(center + Vec2::new(-3.0, 1.0), 4.5, color);
            painter.circle_filled(center + Vec2::new(2.5, -1.0), 6.0, color);
            painter.rect_filled(
                egui::Rect::from_center_size(center + Vec2::new(0.0, 3.5), Vec2::new(18.0, 6.5)),
                3,
                color,
            );
        }
        ProviderFilter::All => {}
    }
}

fn provider_badge(ui: &mut Ui, provider: TrackProvider) {
    let (label, color) = match provider {
        TrackProvider::Spotify => ("Spotify", colors::text()),
        TrackProvider::SoundCloud => ("SoundCloud", colors::text()),
    };
    crate::ui::motion::frame(
        egui::Frame::new()
            .fill(colors::surface_raised())
            .stroke(Stroke::new(1.0, colors::border()))
            .corner_radius(12)
            .shadow(theme::control_shadow())
            .inner_margin(egui::Margin::symmetric(10, 5)),
    )
    .show(ui, |ui| {
        ui.horizontal(|ui| {
            ui.spacing_mut().item_spacing.x = 7.0;
            let (rect, _) = ui.allocate_exact_size(Vec2::splat(14.0), Sense::hover());
            paint_provider_mark(
                ui.painter(),
                match provider {
                    TrackProvider::Spotify => ProviderFilter::Spotify,
                    TrackProvider::SoundCloud => ProviderFilter::SoundCloud,
                },
                rect.center(),
                color,
            );
            ui.label(RichText::new(tr(label)).size(11.0).color(color));
        });
    });
}

pub(crate) fn inline_notice(ui: &mut Ui, message: &str, error: bool) {
    let color = if error {
        colors::error()
    } else {
        colors::text_muted()
    };
    crate::ui::motion::frame(
        egui::Frame::new()
            .fill(colors::surface())
            .stroke(Stroke::new(1.0, color.gamma_multiply(0.35)))
            .corner_radius(7)
            .shadow(theme::control_shadow())
            .inner_margin(8),
    )
    .show(ui, |ui| {
        ui.label(RichText::new(tr(message)).small().color(color));
    });
    ui.add_space(8.0);
}

fn account_required(ui: &mut Ui, auth: &AuthView) {
    let detail = match auth {
        AuthView::Restoring => "Checking the saved Spotify session…",
        AuthView::Authorizing => "Finish authorization in your browser.",
        AuthView::Error(error) => error,
        _ => "Connect Spotify from Settings > Accounts.",
    };
    centered_state(
        ui,
        "Spotify account required",
        Some(detail),
        matches!(auth, AuthView::Restoring | AuthView::Authorizing),
    );
}

pub(crate) fn centered_state(ui: &mut Ui, title: &str, detail: Option<&str>, spinner: bool) {
    theme::elevated_frame(colors::surface(), layout::CARD_RADIUS)
        .inner_margin(24)
        .show(ui, |ui| {
            ui.set_min_height(if spinner { 180.0 } else { 80.0 });
            ui.set_min_width(ui.available_width());
            ui.with_layout(Layout::top_down(Align::Center), |ui| {
                ui.add_space(8.0);
                ui.label(
                    RichText::new(tr(title))
                        .size(18.0)
                        .strong()
                        .color(colors::text()),
                );
                if let Some(detail) = detail {
                    ui.label(RichText::new(tr(detail)).color(colors::text_muted()));
                }
                if spinner {
                    let pulse = (ui.ctx().input(|input| input.time) * 3.0).sin() as f32;
                    let fill = theme::mix(
                        colors::surface_raised(),
                        colors::surface_hover(),
                        (pulse + 1.0) * 0.5,
                    );
                    ui.add_space(16.0);
                    for _ in 0..3 {
                        let (rect, _) = ui.allocate_exact_size(
                            Vec2::new(ui.available_width().min(560.0), 24.0),
                            Sense::hover(),
                        );
                        ui.painter().rect_filled(rect, 8, fill);
                        ui.add_space(7.0);
                    }
                    ui.ctx()
                        .request_repaint_after(std::time::Duration::from_millis(80));
                }
            });
        });
}

pub(crate) fn format_duration(duration_ms: u64) -> String {
    let seconds = duration_ms / 1_000;
    format!("{}:{:02}", seconds / 60, seconds % 60)
}
