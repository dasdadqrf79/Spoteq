//! User interface modules. They contain no network or disk I/O.

pub mod account_window;
pub mod audio_panel;
pub mod branding;
pub mod catalog_navigation;
pub mod connections_page;
pub mod equalizer;
pub mod glass;
pub mod history_page;
pub mod i18n;
pub mod liked_page;
pub mod mini_player;
pub mod motion;
pub mod player_bar;
pub mod queue_panel;
pub mod radio_request;
pub mod responsive;
pub mod root;
pub mod search_page;
pub mod segments;
pub mod session_request;
pub mod settings_window;
pub mod sidebar;
pub mod smart_library_page;
pub mod theme;
pub mod title_bar;
pub mod transport_request;
pub mod widgets;

#[cfg(test)]
mod responsive_tests;

pub mod bass_studio;
