//! Offline native rendering of the real three controls, with scripted pointer gestures.
use super::*;
use crate::{
    catalog::ProviderFilter,
    settings::AppearanceSettings,
    ui::{i18n::tr, search_page, theme},
};

#[test]
#[ignore = "native GPU capture of spring gestures"]
fn native_spring_preview() {
    use winit::platform::windows::EventLoopBuilderExtWindows;
    struct Demo {
        directory: std::path::PathBuf,
        frame: usize,
        targets: Vec<(Pos2, Pos2)>,
        cursor: Option<Pos2>,
        navigation: usize,
        settings: usize,
        provider: ProviderFilter,
    }
    impl eframe::App for Demo {
        fn raw_input_hook(&mut self, _ctx: &egui::Context, input: &mut egui::RawInput) {
            input.time = Some(self.frame as f64 / 30.0);
            input.focused = true;
            if self.targets.len() != 3 {
                return;
            }
            let gesture = if (15..=35).contains(&self.frame) {
                Some((0, 15, 35))
            } else if (70..=90).contains(&self.frame) {
                Some((1, 70, 90))
            } else if (125..=145).contains(&self.frame) {
                Some((2, 125, 145))
            } else {
                None
            };
            if let Some((index, start, end)) = gesture {
                let (from, to) = self.targets[index];
                let t = ((self.frame - start) as f32 / (end - start - 2) as f32).clamp(0.0, 1.0);
                let p = from.lerp(to, t) + Vec2::new(0.0, (t * std::f32::consts::PI).sin() * 9.0);
                self.cursor = Some(p);
                input.events.push(egui::Event::PointerMoved(p));
                if self.frame == start || self.frame == end {
                    input.events.push(egui::Event::PointerButton {
                        pos: p,
                        button: egui::PointerButton::Primary,
                        pressed: self.frame == start,
                        modifiers: Default::default(),
                    });
                }
            }
        }
        fn logic(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
            for event in ctx.input(|i| i.events.clone()) {
                if let egui::Event::Screenshot { image, .. } = event {
                    let bytes: Vec<u8> = image.pixels.iter().flat_map(|p| p.to_array()).collect();
                    image::save_buffer(
                        self.directory.join(format!("{:04}.png", self.frame)),
                        &bytes,
                        image.size[0] as u32,
                        image.size[1] as u32,
                        image::ColorType::Rgba8,
                    )
                    .unwrap();
                    self.frame += 1;
                    if self.frame >= 180 {
                        assert_eq!(self.navigation, 0);
                        assert_eq!(self.settings, 4);
                        assert_eq!(self.provider, ProviderFilter::SoundCloud);
                        glass::validate_renderer(ctx).unwrap();
                        println!(
                            "Captured 180 frames; all three native drag selections committed correctly"
                        );
                        ctx.send_viewport_cmd(egui::ViewportCommand::Close);
                    }
                }
            }
        }
        fn ui(&mut self, ui: &mut Ui, _frame: &mut eframe::Frame) {
            motion::configure(ui.ctx(), &AppearanceSettings::default());
            glass::background(ui);
            ui.add_space(28.0);
            ui.label(
                egui::RichText::new("Упругое стекло")
                    .size(28.0)
                    .color(colors::text()),
            );
            ui.label(
                egui::RichText::new(
                    "Потяните плашку — она растягивается и мягко возвращается на место.",
                )
                .color(colors::text_muted()),
            );
            ui.add_space(32.0);
            let mut targets = Vec::new();
            ui.label(
                egui::RichText::new("Навигация")
                    .small()
                    .color(colors::text_muted()),
            );
            let id = ui.make_persistent_id("demo-navigation");
            let labels: Vec<String> = ["Search", "Liked Songs", "Settings"]
                .iter()
                .map(|s| tr(s).into_owned())
                .collect();
            text(
                ui,
                "demo-navigation",
                &mut self.navigation,
                &labels,
                112.0,
                40.0,
            );
            let rects = ui
                .ctx()
                .data(|d| d.get_temp::<Vec<Rect>>(id.with("geometry")))
                .unwrap();
            targets.push((rects[2].center(), rects[0].center()));
            ui.add_space(24.0);
            ui.label(
                egui::RichText::new("Разделы настроек")
                    .small()
                    .color(colors::text_muted()),
            );
            let id = ui.make_persistent_id("demo-settings");
            let labels: Vec<String> = [
                "General",
                "Playback",
                "Audio",
                "Bass Studio",
                "Appearance",
                "Accounts",
                "About",
            ]
            .iter()
            .map(|s| tr(s).into_owned())
            .collect();
            text(ui, "demo-settings", &mut self.settings, &labels, 0.0, 40.0);
            let rects = ui
                .ctx()
                .data(|d| d.get_temp::<Vec<Rect>>(id.with("geometry")))
                .unwrap();
            targets.push((rects[2].center(), rects[4].center()));
            ui.add_space(24.0);
            ui.label(
                egui::RichText::new("Источники музыки")
                    .small()
                    .color(colors::text_muted()),
            );
            let id = ui.make_persistent_id("provider-navigation");
            search_page::provider_filters(ui, &mut self.provider);
            let rects = ui
                .ctx()
                .data(|d| d.get_temp::<Vec<Rect>>(id.with("geometry")))
                .unwrap();
            targets.push((rects[0].center(), rects[2].center()));
            self.targets = targets;
            if let Some(p) = self.cursor {
                ui.painter().circle_filled(p, 4.0, colors::accent());
                ui.painter().circle_stroke(
                    p,
                    8.0,
                    Stroke::new(1.0, Color32::from_white_alpha(180)),
                );
            }
            ui.ctx()
                .send_viewport_cmd(egui::ViewportCommand::Screenshot(Default::default()));
            ui.ctx().request_repaint();
        }
    }
    eframe::run_native(
        "Spoteq — offline spring preview",
        eframe::NativeOptions {
            viewport: egui::ViewportBuilder::default()
                .with_inner_size([1000.0, 470.0])
                .with_decorations(false)
                .with_resizable(false),
            event_loop_builder: Some(Box::new(|builder| {
                builder.with_any_thread(true);
            })),
            ..Default::default()
        },
        Box::new(|cc| {
            theme::install(&cc.egui_ctx, Default::default());
            let directory = std::path::PathBuf::from(
                std::env::var_os("SPOTEQ_SPRING_CAPTURE_DIR").expect("capture directory required"),
            );
            std::fs::create_dir_all(&directory).unwrap();
            Ok(Box::new(Demo {
                directory,
                frame: 0,
                targets: Vec::new(),
                cursor: None,
                navigation: 2,
                settings: 2,
                provider: ProviderFilter::All,
            }))
        }),
    )
    .unwrap();
}
