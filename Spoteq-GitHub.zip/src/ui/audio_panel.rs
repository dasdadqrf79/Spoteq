use crate::ui::i18n::tr;
use eframe::egui::{self, Align, Layout, RichText, Ui};

use crate::{
    settings::{AudioSettings, EQ_FREQUENCIES_HZ},
    spotify::SpotifyRuntime,
    state::SpotifyViewState,
    ui::{
        theme::{self, colors},
        widgets,
    },
};

/// Compact popup view of the live audio and DSP controls.
pub fn show(
    ui: &mut Ui,
    audio: &mut AudioSettings,
    spotify: &mut SpotifyViewState,
    runtime: &SpotifyRuntime,
    changed: &mut bool,
) {
    ui.horizontal(|ui| {
        ui.vertical(|ui| {
            widgets::eyebrow(ui, "Audio & Equalizer");
            ui.label(
                RichText::new(tr("Audio & Equalizer"))
                    .size(18.0)
                    .strong()
                    .color(colors::text()),
            );
        });
        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
            *changed |= widgets::eq_toggle(ui, &mut audio.eq_enabled).clicked();
        });
    });
    ui.add_space(10.0);

    output_selector(ui, audio, spotify, runtime, changed);
    ui.add_space(12.0);

    crate::ui::motion::frame(
        egui::Frame::new()
            .fill(colors::surface_low())
            .stroke(egui::Stroke::new(1.0, colors::border()))
            .corner_radius(8)
            .shadow(theme::control_shadow())
            .inner_margin(12),
    )
    .show(ui, |ui| {
        ui.horizontal(|ui| {
            ui.label(
                RichText::new(tr("Equalizer"))
                    .strong()
                    .color(colors::text()),
            );
            ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                ui.label(
                    RichText::new(tr(&(if audio.eq_enabled { "EQ ON" } else { "EQ OFF" })))
                        .size(10.0)
                        .strong()
                        .color(if audio.eq_enabled {
                            colors::accent()
                        } else {
                            colors::text_disabled()
                        }),
                );
            });
        });
        ui.add_space(8.0);
        let band_width =
            ((ui.available_width() - 8.0) / EQ_FREQUENCIES_HZ.len() as f32).clamp(22.0, 30.0);
        egui::ScrollArea::horizontal()
            .id_salt("popup-eq-bands")
            .show(ui, |ui| {
                ui.horizontal(|ui| {
                    ui.spacing_mut().item_spacing.x = 2.0;
                    for (index, gain) in audio.eq_db.iter_mut().enumerate() {
                        ui.allocate_ui_with_layout(
                            egui::Vec2::new(band_width, 168.0),
                            Layout::top_down(Align::Center),
                            |ui| {
                                ui.label(
                                    RichText::new(short_frequency(EQ_FREQUENCIES_HZ[index]))
                                        .monospace()
                                        .size(9.0)
                                        .color(colors::text_disabled()),
                                );
                                ui.spacing_mut().slider_width = 118.0;
                                let response = ui.add_sized(
                                    [18.0, 118.0],
                                    crate::ui::motion::control(
                                        egui::Slider::new(gain, -12.0..=12.0)
                                            .vertical()
                                            .show_value(false)
                                            .trailing_fill(true)
                                            .step_by(0.5),
                                        crate::ui::motion::Kind::Slider,
                                    ),
                                );
                                *changed |= response.changed();
                                ui.label(
                                    RichText::new(tr(&(format!("{gain:+.0}"))))
                                        .monospace()
                                        .size(9.0)
                                        .color(colors::text_muted()),
                                );
                            },
                        );
                    }
                });
            });
    });

    ui.add_space(12.0);
    crate::ui::motion::frame(
        egui::Frame::new()
            .fill(colors::surface_low())
            .stroke(egui::Stroke::new(1.0, colors::border()))
            .corner_radius(8)
            .shadow(theme::control_shadow())
            .inner_margin(12),
    )
    .show(ui, |ui| {
        ui.label(
            RichText::new(tr("Tone & protection"))
                .strong()
                .color(colors::text()),
        );
        ui.add_space(8.0);
        *changed |=
            widgets::labeled_slider(ui, "Preamp", &mut audio.preamp_db, -24.0..=6.0, " dB", 0.5)
                .changed();
        *changed |= widgets::labeled_slider(
            ui,
            "Bass",
            &mut audio.bass_gain_db,
            -12.0..=12.0,
            " dB",
            0.5,
        )
        .changed();
        ui.add_space(6.0);
        ui.horizontal(|ui| {
            widgets::status_dot(
                ui,
                if audio.eq_enabled {
                    colors::accent()
                } else {
                    colors::text_disabled()
                },
            );
            ui.label(
                RichText::new(tr(&(if audio.eq_enabled {
                    "Limiter active"
                } else {
                    "Limiter standby"
                })))
                .small()
                .color(colors::text_muted()),
            );
        });
    });
}

fn output_selector(
    ui: &mut Ui,
    audio: &mut AudioSettings,
    spotify: &mut SpotifyViewState,
    runtime: &SpotifyRuntime,
    changed: &mut bool,
) {
    widgets::eyebrow(ui, "Output Device");
    let default_label = spotify
        .default_audio_device
        .as_deref()
        .map(|name| format!("Default System Device · {name}"))
        .unwrap_or_else(|| "Default System Device".to_owned());
    let selected = audio
        .output_device
        .as_deref()
        .unwrap_or(default_label.as_str())
        .to_owned();
    let mut requested = audio.output_device.clone();
    let width = ui.available_width();
    egui::ComboBox::from_id_salt("inspector-output-device")
        .selected_text(tr(&selected))
        .truncate()
        .width(width)
        .show_ui(ui, |ui| {
            ui.set_min_width(width);
            crate::ui::motion::selectable_value(ui, &mut requested, None, &default_label);
            for device in &spotify.audio_devices {
                crate::ui::motion::selectable_value(
                    ui,
                    &mut requested,
                    Some(device.clone()),
                    device,
                );
            }
        });
    if requested != audio.output_device {
        audio.output_device = requested.clone();
        spotify.set_output_device(runtime, requested);
        *changed = true;
    }
}

fn short_frequency(frequency: f32) -> String {
    if frequency >= 1_000.0 {
        format!("{}k", frequency / 1_000.0)
    } else {
        format!("{frequency:.0}")
    }
}
