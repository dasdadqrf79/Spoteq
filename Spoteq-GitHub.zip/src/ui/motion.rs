//! Shared visual effects. Hit boxes and audio/settings state never move with the decoration.
use crate::{
    settings::AppearanceSettings,
    ui::theme::{self, colors},
};
use eframe::egui::{
    self, Color32, Frame, Id, InnerResponse, Pos2, Rect, Response, Shape, Stroke, Ui, Vec2, Widget,
    WidgetText,
};
use std::time::Duration;

#[derive(Clone, Copy, PartialEq)]
pub struct Options {
    pub motion: bool,
    pub depth: bool,
    pub transparency: u8,
}

pub fn configure(ctx: &egui::Context, appearance: &AppearanceSettings) {
    theme::sync_mode(ctx, appearance.theme);
    let old = ctx.data(|d| d.get_temp::<Options>(Id::new("visual-effects-options")));
    if old.is_none_or(|old| old.motion != appearance.motion_enabled) {
        ctx.global_style_mut(|s| {
            s.animation_time = if appearance.motion_enabled { 0.18 } else { 0.0 }
        });
    }
    ctx.data_mut(|d| {
        d.insert_temp(
            Id::new("visual-effects-options"),
            Options {
                motion: appearance.motion_enabled,
                depth: appearance.depth_enabled,
                transparency: appearance.glass_transparency.min(100),
            },
        )
    });
}

pub fn enabled(ctx: &egui::Context) -> bool {
    options(ctx).motion
}

pub fn glass_enabled(ctx: &egui::Context) -> bool {
    options(ctx).depth
}

pub fn transparency(ctx: &egui::Context) -> f32 {
    f32::from(options(ctx).transparency) / 100.0
}

fn options(ctx: &egui::Context) -> Options {
    ctx.data(|d| d.get_temp(Id::new("visual-effects-options")))
        .unwrap_or(Options {
            motion: theme::motion_enabled(),
            depth: theme::depth_enabled(),
            transparency: 90,
        })
}

pub fn hover(ui: &Ui, response: &Response) -> f32 {
    let active = ui.is_enabled() && (response.hovered() || response.has_focus());
    if options(ui.ctx()).motion {
        ui.ctx()
            .animate_bool_with_time(response.id.with("hover-depth"), active, 0.18)
    } else {
        if active { 1.0 } else { 0.0 }
    }
}

fn press(ui: &Ui, response: &Response) -> f32 {
    let down = ui.is_enabled() && response.is_pointer_button_down_on();
    if options(ui.ctx()).motion {
        ui.ctx()
            .animate_bool_with_time(response.id.with("press-depth"), down, 0.09)
    } else {
        if down { 1.0 } else { 0.0 }
    }
}

/// A rounded gradient mesh gives panels a lit top face and a shaded lower edge.
fn face(rect: Rect, radius: f32, hot: f32, light: f32) -> Shape {
    super::glass::sheen(rect, radius, hot, light)
}

fn bevel(ui: &Ui, rect: Rect, radius: f32, hot: f32) {
    super::glass::rim(ui, rect, radius, hot);
}

/// Hover highlights follow the pointer only while a visible control is active.
fn light_x(ui: &Ui, rect: Rect, hot: f32) -> f32 {
    if options(ui.ctx()).motion && hot > 0.01 {
        if let Some(pointer) = ui.ctx().pointer_hover_pos() {
            return pointer.x.clamp(rect.left(), rect.right());
        }
    }
    rect.left() + rect.width() * 0.3
}

fn ripple(ui: &Ui, response: &Response, rect: Rect) {
    if !options(ui.ctx()).motion || !ui.is_enabled() {
        return;
    }
    let id = response.id.with("click-wave");
    let now = ui.input(|i| i.time);
    if response.clicked() {
        let origin = response.interact_pointer_pos().unwrap_or(rect.center());
        ui.ctx().data_mut(|d| d.insert_temp(id, (origin, now)));
    }
    if let Some((origin, started)) = ui.ctx().data(|d| d.get_temp::<(Pos2, f64)>(id)) {
        let t = ((now - started) / 0.45) as f32;
        if (0.0..1.0).contains(&t) {
            let painter = ui.painter().with_clip_rect(rect.intersect(ui.clip_rect()));
            painter.circle_stroke(
                origin,
                3.0 + t * rect.size().length() * 0.65,
                Stroke::new(1.5, colors::accent_bright().gamma_multiply((1.0 - t) * 0.5)),
            );
            ui.ctx().request_repaint_after(Duration::from_millis(16));
        } else {
            ui.ctx().data_mut(|d| d.remove::<(Pos2, f64)>(id));
        }
    }
}

#[derive(Clone, Copy)]
pub enum Kind {
    Button,
    Slider,
    Input,
    Toggle,
}

pub struct Control<W> {
    widget: W,
    kind: Kind,
}
pub fn control<W: Widget>(widget: W, kind: Kind) -> Control<W> {
    Control { widget, kind }
}

impl<W: Widget> Widget for Control<W> {
    fn ui(self, ui: &mut Ui) -> Response {
        render(ui, self.kind, |ui| self.widget.ui(ui))
    }
}

fn render(ui: &mut Ui, kind: Kind, draw: impl FnOnce(&mut Ui) -> Response) -> Response {
    let effects = options(ui.ctx());
    if !effects.motion && !effects.depth {
        return draw(ui);
    }
    let shadow = ui.painter().add(Shape::Noop);
    let glass_base = ui.painter().add(Shape::Noop);
    let layer = ui.layer_id();
    let start = ui.ctx().graphics_mut(|g| g.entry(layer).next_idx());
    let response = draw(ui);
    if !ui.is_rect_visible(response.rect) {
        return response;
    }
    let hot = hover(ui, &response);
    let down = press(ui, &response);
    if effects.depth && matches!(kind, Kind::Button) {
        let target = response.rect;
        fn soften(shape: &mut Shape, target: Rect) {
            match shape {
                Shape::Rect(rect)
                    if (rect.rect.center() - target.center()).length() < 3.0
                        && rect.rect.width() >= target.width() - 4.0
                        && rect.rect.height() >= target.height() - 4.0 =>
                {
                    rect.fill = rect.fill.gamma_multiply(0.55);
                    rect.stroke = Stroke::NONE;
                }
                Shape::Vec(shapes) => {
                    for shape in shapes {
                        soften(shape, target);
                    }
                }
                _ => {}
            }
        }
        ui.ctx().graphics_mut(|g| {
            let list = g.entry(layer);
            let end = list.next_idx();
            for index in start.0..end.0 {
                list.mutate_shape(egui::layers::ShapeIdx(index), |shape| {
                    soften(&mut shape.shape, target)
                });
            }
        });
    }
    let offset = if effects.motion && matches!(kind, Kind::Button) && ui.is_enabled() {
        Vec2::new(0.0, -0.5 * hot + 1.0 * down)
    } else {
        Vec2::ZERO
    };
    if offset != Vec2::ZERO {
        ui.ctx().graphics_mut(|g| {
            let list = g.entry(layer);
            list.transform_range(
                start,
                list.next_idx(),
                egui::emath::TSTransform::from_translation(offset),
            );
        });
    }
    let rect = response.rect.translate(offset);
    if effects.depth && matches!(kind, Kind::Button) {
        ui.painter().set(
            glass_base,
            super::glass::panel(
                ui,
                rect,
                rect.height().min(40.0) * 0.5,
                hot,
                light_x(ui, rect, hot),
            ),
        );
        ui.painter().set(
            shadow,
            super::glass::outer_shadow(rect, rect.height() * 0.5, (4.0 + hot * 8.0) as u8),
        );
        ui.painter().add(face(
            rect.shrink(0.5),
            rect.height() * 0.5,
            hot,
            light_x(ui, rect, hot),
        ));
        bevel(ui, rect, rect.height() * 0.5, hot);
    } else if effects.depth && hot > 0.01 && !matches!(kind, Kind::Slider) {
        bevel(ui, rect, 7.0, hot * 0.7);
    }
    if effects.depth && matches!(kind, Kind::Slider) {
        glass_slider_thumb(ui, &response, layer, start, hot);
    }
    ripple(ui, &response, rect);
    response
}

fn glass_slider_thumb(
    ui: &Ui,
    response: &Response,
    layer: egui::LayerId,
    start: egui::layers::ShapeIdx,
    hot: f32,
) {
    let mut center = None;
    ui.ctx().graphics_mut(|g| {
        let list = g.entry(layer);
        let end = list.next_idx();
        for index in start.0..end.0 {
            list.mutate_shape(egui::layers::ShapeIdx(index), |painted| {
                if center.is_some() {
                    return;
                }
                match &painted.shape {
                    Shape::Circle(circle) if circle.radius >= 3.0 && circle.radius <= 20.0 => {
                        center = Some(circle.center);
                    }
                    Shape::Rect(rect)
                        if rect.rect.width() <= 30.0
                            && rect.rect.height() <= 32.0
                            && rect.rect.width() >= 3.0
                            && rect.rect.height() >= 8.0 =>
                    {
                        center = Some(rect.rect.center());
                    }
                    _ => {}
                }
                if center.is_some() {
                    painted.shape = Shape::Noop;
                }
            });
            if center.is_some() {
                break;
            }
        }
    });
    let Some(center) = center else {
        return;
    };
    let pressed = if enabled(ui.ctx()) {
        ui.ctx().animate_bool_with_time(
            response.id.with("glass-thumb-press"),
            response.dragged(),
            0.16,
        )
    } else {
        0.0
    };
    let vertical = response.rect.height() > response.rect.width() * 2.0;
    let size = if vertical {
        Vec2::new(30.0, 22.0)
    } else {
        Vec2::new(38.0, 24.0)
    };
    let rect = Rect::from_center_size(center, size * (1.0 + pressed * 0.16));
    ui.painter()
        .add(super::glass::outer_shadow(rect, rect.height() * 0.5, 18));
    ui.painter()
        .add(super::glass::thumb(ui, rect, hot.max(pressed)));
    super::glass::rim(ui, rect, rect.height() * 0.5, hot.max(pressed));
    ui.painter().rect_stroke(
        rect.shrink(0.5),
        rect.height() * 0.5,
        Stroke::new(
            0.8,
            if theme::is_dark() {
                Color32::from_white_alpha((65.0 + pressed * 40.0) as u8)
            } else {
                Color32::from_rgba_unmultiplied(55, 72, 99, (55.0 + pressed * 35.0) as u8)
            },
        ),
        egui::StrokeKind::Inside,
    );
}

/// Quiet navigation: only the selected destination receives a floating glass capsule.
pub fn tab(ui: &mut Ui, label: &str, selected: bool, size: Vec2) -> Response {
    let background = ui.painter().add(Shape::Noop);
    let label_width = ui
        .painter()
        .layout_no_wrap(
            label.to_owned(),
            egui::TextStyle::Button.resolve(ui.style()),
            colors::text(),
        )
        .size()
        .x;
    let size = Vec2::new(size.x.max(label_width + 28.0), size.y);
    let response = ui.add(
        egui::Button::new(egui::RichText::new(label).color(if selected {
            colors::text()
        } else {
            colors::text_muted()
        }))
        .min_size(size)
        .frame(false),
    );
    let hot = hover(ui, &response);
    let rect = response.rect;
    let radius = rect.height() * 0.5;
    if selected {
        let material = if glass_enabled(ui.ctx()) {
            super::glass::panel(ui, rect, radius, hot, rect.center().x)
        } else {
            Shape::Noop
        };
        ui.painter().set(
            background,
            Shape::Vec(vec![
                material,
                Shape::rect_filled(
                    rect,
                    radius,
                    Color32::from_white_alpha(if theme::is_dark() { 16 } else { 95 }),
                ),
            ]),
        );
        super::glass::rim(ui, rect, radius, hot);
    } else if hot > 0.01 {
        ui.painter().set(
            background,
            Shape::rect_filled(rect, radius, Color32::from_white_alpha((9.0 * hot) as u8)),
        );
    }
    ripple(ui, &response, rect);
    response
}

pub fn button(ui: &mut Ui, text: impl Into<WidgetText>) -> Response {
    ui.add(control(egui::Button::new(text), Kind::Button))
}
pub fn small_button(ui: &mut Ui, text: impl Into<WidgetText>) -> Response {
    ui.add(control(egui::Button::new(text).small(), Kind::Button))
}
pub fn checkbox(ui: &mut Ui, value: &mut bool, text: impl Into<WidgetText>) -> Response {
    ui.add(control(egui::Checkbox::new(value, text), Kind::Toggle))
}
pub fn selectable_value<T: PartialEq>(
    ui: &mut Ui,
    value: &mut T,
    selected: T,
    text: impl Into<WidgetText>,
) -> Response {
    render(ui, Kind::Button, |ui| {
        ui.selectable_value(value, selected, text)
    })
}
pub fn selectable_label(ui: &mut Ui, selected: bool, text: impl Into<WidgetText>) -> Response {
    render(ui, Kind::Button, |ui| ui.selectable_label(selected, text))
}

pub struct DepthFrame {
    frame: Frame,
    radius: f32,
}

pub fn frame(frame: Frame) -> DepthFrame {
    let radius = frame.corner_radius.nw;
    DepthFrame::new(frame, radius)
}
impl DepthFrame {
    pub fn new(frame: Frame, radius: u8) -> Self {
        Self {
            frame,
            radius: f32::from(radius),
        }
    }
    pub fn inner_margin(mut self, margin: impl Into<egui::Margin>) -> Self {
        self.frame = self.frame.inner_margin(margin);
        self
    }
    pub fn show<R>(self, ui: &mut Ui, contents: impl FnOnce(&mut Ui) -> R) -> InnerResponse<R> {
        let shadow = ui.painter().add(Shape::Noop);
        let mut frame = self.frame;
        if glass_enabled(ui.ctx()) {
            frame.fill = Color32::from_white_alpha(2);
            frame.stroke = Stroke::new(0.7, colors::border());
            frame.shadow = egui::Shadow::NONE;
        }
        let mut prepared = frame.begin(ui);
        let painter = prepared.content_ui.painter().clone();
        let decoration = painter.add(Shape::Noop);
        let inner = contents(&mut prepared.content_ui);
        let response = prepared.end(ui);
        if options(ui.ctx()).depth && ui.is_rect_visible(response.rect) {
            ui.painter().set(
                shadow,
                super::glass::outer_shadow(response.rect, self.radius, 12),
            );
            let hot = if options(ui.ctx()).motion {
                ui.ctx().animate_bool_with_time(
                    response.id.with("card-light"),
                    ui.rect_contains_pointer(response.rect),
                    0.22,
                )
            } else {
                if ui.rect_contains_pointer(response.rect) {
                    1.0
                } else {
                    0.0
                }
            };
            let rect = response.rect.shrink(0.7);
            painter.set(
                decoration,
                super::glass::panel(ui, rect, self.radius, hot * 0.65, light_x(ui, rect, hot)),
            );
            // The edge is painted after content, without covering text or receiving input.
            bevel(ui, rect, self.radius, hot * 0.6);
        }
        InnerResponse::new(inner, response)
    }
}

/// Finite entry animation: no permanent repaint loop once the screen has appeared.
pub fn page_entry(ui: &mut Ui, key: String) {
    if !options(ui.ctx()).motion {
        return;
    }
    let id = ui.make_persistent_id("screen-entry");
    let now = ui.input(|i| i.time);
    let previous = ui.ctx().data(|d| d.get_temp::<(String, f64)>(id));
    let started = match previous {
        Some((old, started)) if old == key => started,
        _ => {
            ui.ctx().data_mut(|d| d.insert_temp(id, (key, now)));
            now
        }
    };
    let t = ((now - started) as f32 / 0.28).clamp(0.0, 1.0);
    let eased = 1.0 - (1.0 - t).powi(3);
    ui.multiply_opacity(0.55 + 0.45 * eased);
    if t < 1.0 {
        ui.ctx().request_repaint_after(Duration::from_millis(16));
    }
}

/// Decorative light fields behind the content, never above controls or album art.
pub fn ambient(ui: &Ui) {
    let effects = options(ui.ctx());
    if !effects.depth {
        return;
    }
    let rect = ui.max_rect().intersect(ui.clip_rect());
    if !rect.is_positive() {
        return;
    }
    let time = if effects.motion {
        ui.input(|i| i.time) as f32
    } else {
        0.0
    };
    let drift = Vec2::new((time * 0.25).sin() * 35.0, (time * 0.19).cos() * 18.0);
    for (center, radius, alpha) in [
        (
            rect.left_top() + Vec2::new(rect.width() * 0.18, 30.0) + drift,
            320.0,
            14,
        ),
        (
            rect.right_bottom() - Vec2::new(20.0, 60.0) - drift,
            260.0,
            9,
        ),
    ] {
        let mut mesh = egui::epaint::Mesh::default();
        mesh.colored_vertex(
            center,
            colors::accent().gamma_multiply(f32::from(alpha as u8) / 255.0),
        );
        for i in 0..=32 {
            mesh.colored_vertex(
                center + Vec2::angled(i as f32 / 32.0 * std::f32::consts::TAU) * radius,
                Color32::TRANSPARENT,
            );
            if i > 0 {
                mesh.add_triangle(0, i, i + 1);
            }
        }
        ui.painter().add(Shape::mesh(mesh));
    }
    if effects.motion {
        ui.ctx().request_repaint_after(Duration::from_millis(50));
    }
}

pub fn custom_feedback(ui: &Ui, response: &Response, rect: Rect, radius: f32) {
    if options(ui.ctx()).depth {
        let hot = hover(ui, response);
        ui.painter()
            .add(face(rect, radius, hot, light_x(ui, rect, hot)));
        bevel(ui, rect, radius, hot);
    }
    ripple(ui, response, rect);
}

pub fn visibility(ctx: &egui::Context, id: Id, visible: bool) -> f32 {
    if options(ctx).motion {
        ctx.animate_bool_with_time(id, visible, 0.2)
    } else if visible {
        1.0
    } else {
        0.0
    }
}

/// Only the drawn response is eased; the real audio parameters update immediately.
pub fn smooth_series(ui: &Ui, id: Id, target: &[f32]) -> Vec<f32> {
    if !options(ui.ctx()).motion {
        return target.to_vec();
    }
    let now = ui.input(|i| i.time);
    let previous = ui.ctx().data(|d| d.get_temp::<(Vec<f32>, f64)>(id));
    let (mut shown, time) = previous
        .filter(|(v, _)| v.len() == target.len())
        .unwrap_or_else(|| (target.to_vec(), now));
    let mix = 1.0 - (-((now - time).max(0.0) as f32).min(0.1) / 0.065).exp();
    let mut animating = false;
    for (shown, target) in shown.iter_mut().zip(target) {
        if (*target - *shown).abs() < 0.001 {
            *shown = *target;
        } else {
            *shown += (*target - *shown) * mix;
            animating = true;
        }
    }
    ui.ctx()
        .data_mut(|d| d.insert_temp(id, (shown.clone(), now)));
    if animating {
        ui.ctx().request_repaint_after(Duration::from_millis(16));
    }
    shown
}

#[cfg(test)]
mod tests {
    use super::*;

    fn frame(
        ctx: &egui::Context,
        time: f64,
        events: Vec<egui::Event>,
        draw: impl FnOnce(&mut Ui) -> Response,
    ) -> Response {
        let mut draw = Some(draw);
        let mut response = None;
        let mut output = ctx.run_ui(
            egui::RawInput {
                screen_rect: Some(Rect::from_min_size(Pos2::ZERO, Vec2::new(700.0, 500.0))),
                time: Some(time),
                events,
                ..Default::default()
            },
            |ui| {
                response = Some(draw.take().unwrap()(ui));
            },
        );
        output.textures_delta.clear();
        assert!(output.shapes.iter().all(|s| s.clip_rect.is_finite()));
        response.unwrap()
    }

    fn pointer(pos: Pos2, pressed: bool) -> Vec<egui::Event> {
        vec![
            egui::Event::PointerMoved(pos),
            egui::Event::PointerButton {
                pos,
                pressed,
                button: egui::PointerButton::Primary,
                modifiers: Default::default(),
            },
        ]
    }

    #[test]
    fn decorated_button_keeps_its_hit_box_and_clicks_once_with_effects_on_or_off() {
        for enabled in [true, false] {
            let ctx = egui::Context::default();
            configure(
                &ctx,
                &AppearanceSettings {
                    motion_enabled: enabled,
                    depth_enabled: enabled,
                    ..Default::default()
                },
            );
            let initial = frame(&ctx, 0.0, vec![], |ui| button(ui, "Action"));
            let at = initial.rect.center();
            let down = frame(&ctx, 0.1, pointer(at, true), |ui| button(ui, "Action"));
            assert_eq!(down.rect, initial.rect);
            assert!(!down.clicked());
            let up = frame(&ctx, 0.25, pointer(at, false), |ui| button(ui, "Action"));
            assert_eq!(up.rect, initial.rect);
            assert!(up.clicked());
            let idle = frame(&ctx, 0.3, vec![], |ui| button(ui, "Action"));
            assert!(!idle.clicked());
            assert_eq!(idle.rect, initial.rect);
            let wave = ctx.data(|d| d.get_temp::<(Pos2, f64)>(up.id.with("click-wave")));
            assert_eq!(wave.is_some(), enabled);
        }
    }

    #[test]
    fn animated_switch_changes_only_on_click_and_remains_stable_on_hover() {
        let ctx = egui::Context::default();
        let mut enabled = false;
        let first = frame(&ctx, 0.0, vec![], |ui| {
            super::super::widgets::eq_toggle(ui, &mut enabled)
        });
        let at = first.rect.center();
        frame(&ctx, 0.1, pointer(at, true), |ui| {
            super::super::widgets::eq_toggle(ui, &mut enabled)
        });
        let changed = frame(&ctx, 0.2, pointer(at, false), |ui| {
            super::super::widgets::eq_toggle(ui, &mut enabled)
        });
        assert!(changed.changed() && enabled);
        for index in 0..12 {
            let response = frame(
                &ctx,
                0.3 + f64::from(index) * 0.05,
                vec![egui::Event::PointerMoved(at)],
                |ui| super::super::widgets::eq_toggle(ui, &mut enabled),
            );
            assert_eq!(response.rect, first.rect);
            assert!(!response.changed());
            assert!(enabled);
        }
    }

    #[test]
    fn navigation_capsule_keeps_hit_box_when_selected() {
        let ctx = egui::Context::default();
        configure(&ctx, &AppearanceSettings::default());
        let draw = |ui: &mut Ui, selected| tab(ui, "Settings", selected, Vec2::new(112.0, 40.0));
        let idle = frame(&ctx, 0.0, vec![], |ui| draw(ui, false));
        let at = idle.rect.center();
        frame(&ctx, 0.1, pointer(at, true), |ui| draw(ui, false));
        let clicked = frame(&ctx, 0.2, pointer(at, false), |ui| draw(ui, false));
        assert!(clicked.clicked());
        let selected = frame(&ctx, 0.3, vec![], |ui| draw(ui, true));
        assert_eq!(selected.rect, idle.rect);
    }

    #[test]
    fn glass_slider_tracks_pointer_without_changing_its_hit_box() {
        let ctx = egui::Context::default();
        configure(&ctx, &AppearanceSettings::default());
        let mut value = 25.0_f32;
        let draw = |ui: &mut Ui, value: &mut f32| {
            ui.spacing_mut().slider_width = 300.0;
            ui.add(control(
                egui::Slider::new(value, 0.0..=100.0).show_value(false),
                Kind::Slider,
            ))
        };
        let initial = frame(&ctx, 0.0, vec![], |ui| draw(ui, &mut value));
        let start = Pos2::new(
            initial.rect.left() + initial.rect.width() * 0.25,
            initial.rect.center().y,
        );
        frame(&ctx, 0.1, pointer(start, true), |ui| draw(ui, &mut value));
        let end = Pos2::new(
            initial.rect.left() + initial.rect.width() * 0.85,
            initial.rect.center().y,
        );
        let dragged = frame(&ctx, 0.2, vec![egui::Event::PointerMoved(end)], |ui| {
            draw(ui, &mut value)
        });
        assert!(dragged.changed() && value > 75.0);
        assert_eq!(dragged.rect, initial.rect);
        let released = frame(&ctx, 0.3, pointer(end, false), |ui| draw(ui, &mut value));
        assert_eq!(released.rect, initial.rect);
        assert!(value > 75.0);
    }

    #[test]
    fn curve_animation_settles_and_reduced_motion_updates_immediately() {
        let ctx = egui::Context::default();
        let id = Id::new("curve-under-test");
        let render = |time, target: f32| {
            let mut shown = Vec::new();
            let mut output = ctx.run_ui(
                egui::RawInput {
                    time: Some(time),
                    ..Default::default()
                },
                |ui| shown = smooth_series(ui, id, &[target]),
            );
            output.textures_delta.clear();
            shown[0]
        };
        assert_eq!(render(0.0, 0.0), 0.0);
        let intermediate = render(0.05, 9.0);
        assert!(intermediate > 0.0 && intermediate < 9.0);
        for i in 2..32 {
            render(f64::from(i) * 0.05, 9.0);
        }
        assert_eq!(render(2.0, 9.0), 9.0);
        configure(
            &ctx,
            &AppearanceSettings {
                motion_enabled: false,
                depth_enabled: false,
                ..Default::default()
            },
        );
        assert_eq!(render(2.1, -12.0), -12.0);
        assert_eq!(visibility(&ctx, Id::new("panel"), true), 1.0);
        assert_eq!(visibility(&ctx, Id::new("panel"), false), 0.0);
    }
}
