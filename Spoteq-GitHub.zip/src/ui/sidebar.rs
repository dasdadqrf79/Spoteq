//! Compact top navigation; the content no longer reserves an empty vertical rail.
use crate::{
    state::{AppState, MusicPage, SettingsSection},
    ui::{i18n::tr, segments, theme::colors},
};
use eframe::egui::{RichText, Ui};

pub fn show(ui: &mut Ui, state: &mut AppState) {
    ui.horizontal_centered(|ui| {
        ui.label(
            RichText::new("SPOTEQ")
                .size(23.0)
                .strong()
                .color(colors::text()),
        );
        ui.add_space(18.0);
        let pages = [
            (MusicPage::Search, "Search"),
            (MusicPage::LikedSongs, "Liked Songs"),
            (MusicPage::Settings, "Settings"),
        ];
        let labels: Vec<String> = pages
            .iter()
            .map(|(_, label)| tr(label).into_owned())
            .collect();
        let mut selected = pages
            .iter()
            .position(|(page, _)| *page == state.page)
            .unwrap_or(0);
        if segments::text(
            ui,
            "primary-navigation",
            &mut selected,
            &labels,
            112.0,
            40.0,
        )
        .changed()
        {
            state.page = pages[selected].0;
            if state.page == MusicPage::Settings {
                state.settings_section = SettingsSection::General;
            }
        }
    });
}
