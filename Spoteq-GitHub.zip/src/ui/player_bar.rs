use crate::ui::i18n::tr;
use eframe::egui::{self, Align, Layout, Pos2, Rect, RichText, Sense, Ui, UiBuilder, Vec2};

use crate::{
    autoplay::AutoplayQueue,
    catalog::{TrackProvider, TrackRow},
    image_cache::CoverCache,
    provider_library::ProviderLibraryState,
    settings::{AudioSettings, PlaybackSettings, RepeatMode},
    soundcloud::{SoundCloudRuntime, SoundCloudViewState},
    spotify::{PlaybackStatus, SpotifyRuntime},
    state::SpotifyViewState,
    ui::{
        search_page::format_duration,
        theme::colors,
        widgets::{self, PlayerAuxIcon, PlayerIcon},
    },
};

/// Draws the compact Spotify-style local player.
/// Returns true when the output-device utility button asks to toggle the Audio popup.
pub fn show(
    ui: &mut Ui,
    state: &mut SpotifyViewState,
    soundcloud: &mut SoundCloudViewState,
    autoplay: &mut AutoplayQueue,
    provider_library: &mut ProviderLibraryState,
    covers: &mut CoverCache,
    runtime: &SpotifyRuntime,
    soundcloud_runtime: &SoundCloudRuntime,
    audio: &mut AudioSettings,
    playback: &mut PlaybackSettings,
    queue_open: &mut bool,
    settings_changed: &mut bool,
    toggle_playback_requested: &mut bool,
) -> bool {
    let soundcloud_active = soundcloud.playback.track.is_some();
    let track = if soundcloud_active {
        soundcloud.playback.track.clone()
    } else {
        state.playback.track.as_ref().map(TrackRow::from_spotify)
    };
    let status = if soundcloud_active {
        soundcloud.playback.status.clone()
    } else {
        state.playback.status.clone()
    };
    let duration_ms = track.as_ref().map(|track| track.duration_ms).unwrap_or(0);
    let displayed_ms = u64::from(if soundcloud_active {
        soundcloud.playback.displayed_position_ms()
    } else {
        state.playback.displayed_position_ms()
    })
    .min(duration_ms);
    let mut progress_ms = (if soundcloud_active {
        soundcloud.playback.seek_preview_ms
    } else {
        state.playback.seek_preview_ms
    })
    .map(f64::from)
    .unwrap_or(displayed_ms as f64);
    let mut seek_preview = if soundcloud_active {
        soundcloud.playback.seek_preview_ms
    } else {
        state.playback.seek_preview_ms
    };
    let mut seek_target = None;
    let previous;
    let toggle;
    let next;
    let mut shuffle = false;
    let mut repeat = false;
    let toggle_audio_popup;
    let volume_changed;
    let mut player_library_change = None;

    let height = ui.available_height();
    let (rect, _) = ui.allocate_exact_size(Vec2::new(ui.available_width(), height), Sense::hover());

    // Keep transport geometrically centered. Left and right zones mirror each other,
    // so metadata and volume controls can never move the playback controls sideways.
    let [left, center, right] = super::responsive::player_zones(rect);
    let compact = rect.width() < 1100.0;
    let cover_size = if compact { 56.0 } else { 80.0 };

    // Raise all player content a little above the native window/taskbar boundary.
    let content_y = rect.center().y - 4.0;

    // LEFT — cover + title + artist.
    {
        let content_height = 96.0_f32.min(left.height());
        let content = Rect::from_center_size(
            Pos2::new(left.center().x, content_y),
            Vec2::new(left.width(), content_height),
        );
        let mut child = ui.new_child(
            UiBuilder::new()
                .max_rect(content)
                .layout(Layout::left_to_right(Align::Center)),
        );
        child.set_min_size(content.size());

        match track.as_ref().map(|track| track.provider) {
            Some(TrackProvider::SoundCloud) => {
                let _ = covers.show_soundcloud(
                    &mut child,
                    track
                        .as_ref()
                        .and_then(|track| track.artwork_url.as_deref()),
                    soundcloud_runtime,
                    Vec2::splat(cover_size),
                );
            }
            _ => {
                let _ = covers.show(
                    &mut child,
                    track
                        .as_ref()
                        .and_then(|track| track.artwork_url.as_deref()),
                    runtime,
                    Vec2::splat(cover_size),
                );
            }
        }
        child.add_space(8.0);
        child.vertical(|ui| {
            ui.set_max_width((left.width() - cover_size - 60.0).max(1.0));
            if let Some(track) = &track {
                ui.add(
                    egui::Label::new(
                        RichText::new(&track.title)
                            .strong()
                            .size(18.0)
                            .color(colors::text()),
                    )
                    .truncate(),
                );
                ui.add(
                    egui::Label::new(
                        RichText::new(&track.artist)
                            .size(14.0)
                            .color(colors::text_muted()),
                    )
                    .truncate(),
                );
                let provider = match track.provider {
                    TrackProvider::Spotify => "Spotify",
                    TrackProvider::SoundCloud => "SoundCloud",
                };
                let source = if autoplay.current_is_recommended() {
                    format!("{provider} · Autoplay")
                } else {
                    provider.to_owned()
                };
                ui.label(RichText::new(source).size(13.0).color(colors::text_muted()));
            } else {
                ui.label(
                    RichText::new(tr("Nothing playing"))
                        .strong()
                        .size(18.0)
                        .color(colors::text()),
                );
                ui.label(
                    RichText::new(tr("Choose a track"))
                        .size(13.0)
                        .color(colors::text_muted()),
                );
            }
        });

        if let Some(track) = &track {
            provider_library.ensure_loaded(track, runtime, soundcloud_runtime);
            let heart_rect = Rect::from_center_size(
                Pos2::new(left.right() - 30.0, content_y),
                Vec2::splat(38.0),
            );
            let mut heart_ui = ui.new_child(
                UiBuilder::new()
                    .max_rect(heart_rect)
                    .layout(Layout::centered_and_justified(egui::Direction::TopDown)),
            );
            let liked = provider_library.visual(track);
            let tooltip = match (track.provider, liked.liked) {
                (TrackProvider::Spotify, true) => "Remove from Spotify Liked Songs",
                (TrackProvider::Spotify, false) => "Save to Spotify Liked Songs",
                (TrackProvider::SoundCloud, true) => "Unlike on SoundCloud",
                (TrackProvider::SoundCloud, false) => "Like on SoundCloud",
            };
            if widgets::heart_button(&mut heart_ui, liked.liked, !liked.pending)
                .on_hover_text(tooltip)
                .clicked()
            {
                player_library_change = Some(track.clone());
            }
        }
    }

    // CENTER — transport controls are geometrically centered over the timeline.
    // Both rows share exactly the same center X, independent of text widths or side content.
    {
        let center_x = rect.center().x;
        let controls_width = 162.0_f32.min(center.width());
        let controls_rect = Rect::from_center_size(
            Pos2::new(center_x, rect.bottom() - 34.0),
            Vec2::new(controls_width, 68.0),
        );
        let mut controls_ui = ui.new_child(
            UiBuilder::new()
                .max_rect(controls_rect)
                .layout(Layout::left_to_right(Align::Center)),
        );
        controls_ui.set_min_size(controls_rect.size());
        controls_ui.spacing_mut().item_spacing.x = 18.0;

        previous = widgets::player_button(
            &mut controls_ui,
            PlayerIcon::Previous,
            track.is_some(),
            false,
        )
        .on_hover_text(tr("Previous"))
        .clicked();

        let can_toggle = matches!(status, PlaybackStatus::Playing | PlaybackStatus::Paused);
        let icon = if status == PlaybackStatus::Playing {
            PlayerIcon::Pause
        } else {
            PlayerIcon::Play
        };
        toggle = widgets::player_button(&mut controls_ui, icon, can_toggle, true)
            .on_hover_text(tr(&(if status == PlaybackStatus::Playing {
                "Pause"
            } else {
                "Play"
            })))
            .clicked();

        next = widgets::player_button(
            &mut controls_ui,
            PlayerIcon::Next,
            autoplay.has_next(playback.autoplay_similar) || playback.repeat != RepeatMode::Off,
            false,
        )
        .on_hover_text(tr("Next"))
        .clicked();

        let slider_width = (center.width() - 100.0).clamp(80.0, 560.0);
        let timeline_width = (slider_width + 92.0).min(center.width());
        let timeline_rect = Rect::from_center_size(
            Pos2::new(center_x, rect.top() + 9.0),
            Vec2::new(timeline_width, 14.0),
        );
        let mut timeline_ui = ui.new_child(
            UiBuilder::new()
                .max_rect(timeline_rect)
                .layout(Layout::left_to_right(Align::Center)),
        );
        timeline_ui.set_min_size(timeline_rect.size());
        timeline_ui.spacing_mut().item_spacing.x = 6.0;

        timeline_ui.label(
            RichText::new(format_duration(displayed_ms))
                .monospace()
                .size(12.0)
                .color(colors::text_muted()),
        );

        timeline_ui.spacing_mut().slider_width = slider_width;
        let slider = timeline_ui.add_sized(
            [slider_width, 10.0],
            crate::ui::motion::control(
                egui::Slider::new(&mut progress_ms, 0.0..=(duration_ms.max(1) as f64))
                    .show_value(false)
                    .trailing_fill(true),
                crate::ui::motion::Kind::Slider,
            ),
        );
        if slider.changed() || slider.dragged() {
            let preview = progress_ms
                .round()
                .clamp(0.0, duration_ms.min(u64::from(u32::MAX)) as f64)
                as u32;
            seek_preview = Some(preview);
        }
        if slider.drag_stopped() || (slider.changed() && !slider.dragged()) {
            seek_target = seek_preview;
        }

        timeline_ui.label(
            RichText::new(format_duration(duration_ms))
                .monospace()
                .size(12.0)
                .color(colors::text_muted()),
        );
    }

    // RIGHT — secondary modes are quiet; Queue/Audio and volume remain visible.
    {
        let content_height = 96.0_f32.min(right.height());
        let content = Rect::from_center_size(
            Pos2::new(right.center().x, content_y),
            Vec2::new(right.width(), content_height),
        );
        let mut child = ui.new_child(
            UiBuilder::new()
                .max_rect(content)
                .layout(Layout::top_down(Align::Max)),
        );
        child.set_min_size(content.size());
        let mut audio_clicked = false;
        let mut volume_edited = false;
        child.horizontal(|ui| {
            ui.spacing_mut().item_spacing.x = 8.0;
            if ui
                .add_sized(
                    [78.0, 32.0],
                    crate::ui::motion::control(
                        egui::Button::new(tr("Queue"))
                            .fill(if *queue_open {
                                colors::accent_tint()
                            } else {
                                colors::surface_raised()
                            })
                            .corner_radius(10),
                        crate::ui::motion::Kind::Button,
                    ),
                )
                .on_hover_text(tr("Open queue"))
                .clicked()
            {
                *queue_open = !*queue_open;
            }
            audio_clicked = widgets::player_aux_button(ui, PlayerAuxIcon::Device, true)
                .on_hover_text(tr("Audio & Equalizer"))
                .clicked();
        });
        child.add_space(6.0);
        child.horizontal(|ui| {
            ui.spacing_mut().item_spacing.x = 4.0;
            shuffle = ui
                .add_enabled(
                    track.is_some(),
                    crate::ui::motion::control(
                        egui::Button::new(RichText::new(tr("S")).size(11.0).color(
                            if playback.shuffle {
                                colors::accent()
                            } else {
                                colors::text_disabled()
                            },
                        ))
                        .min_size(Vec2::new(27.0, 26.0))
                        .fill(egui::Color32::TRANSPARENT),
                        crate::ui::motion::Kind::Button,
                    ),
                )
                .on_hover_text(tr("Shuffle"))
                .clicked();
            repeat = ui
                .add_enabled(
                    track.is_some(),
                    crate::ui::motion::control(
                        egui::Button::new(
                            RichText::new(tr(&(if playback.repeat == RepeatMode::Track {
                                "R1"
                            } else {
                                "R"
                            })))
                            .size(11.0)
                            .color(
                                if playback.repeat == RepeatMode::Off {
                                    colors::text_disabled()
                                } else {
                                    colors::accent()
                                },
                            ),
                        )
                        .min_size(Vec2::new(27.0, 26.0))
                        .fill(egui::Color32::TRANSPARENT),
                        crate::ui::motion::Kind::Button,
                    ),
                )
                .on_hover_text(tr(&(playback.repeat.label())))
                .clicked();
            widgets::player_aux_button(ui, PlayerAuxIcon::Volume, false)
                .on_hover_text(tr("Volume"));
            let slider_width = (right.width() - 108.0).clamp(54.0, 154.0);
            ui.spacing_mut().slider_width = slider_width;
            volume_edited = ui
                .add_sized(
                    [slider_width, 12.0],
                    crate::ui::motion::control(
                        egui::Slider::new(&mut audio.master_volume, 0.0..=1.0)
                            .show_value(false)
                            .trailing_fill(true),
                        crate::ui::motion::Kind::Slider,
                    ),
                )
                .changed();
        });
        toggle_audio_popup = audio_clicked;
        volume_changed = volume_edited;
    }

    if soundcloud_active {
        soundcloud.playback.seek_preview_ms = seek_preview;
    } else {
        state.playback.seek_preview_ms = seek_preview;
    }
    if previous {
        autoplay.previous(
            displayed_ms.min(u64::from(u32::MAX)) as u32,
            state,
            soundcloud,
            runtime,
            soundcloud_runtime,
        );
    }
    if shuffle {
        playback.shuffle = !playback.shuffle;
        autoplay.set_shuffle(playback.shuffle);
        *settings_changed = true;
    }
    if repeat {
        playback.repeat = playback.repeat.next();
        *settings_changed = true;
    }
    if toggle {
        *toggle_playback_requested = true;
    }
    if next {
        crate::ui::transport_request::request(
            ui.ctx(),
            crate::ui::transport_request::TransportRequest::Next,
        );
    }
    if let Some(position_ms) = seek_target {
        if soundcloud_active {
            soundcloud.seek(soundcloud_runtime, position_ms);
        } else {
            state.seek(runtime, position_ms);
        }
    }
    if volume_changed {
        state.set_volume(runtime, audio.master_volume);
        soundcloud.set_volume(soundcloud_runtime, audio.master_volume);
        *settings_changed = true;
    }
    if let Some(track) = player_library_change
        && let Err(error) = provider_library.toggle(&track, runtime, soundcloud_runtime)
    {
        state.toast_error(error);
    }

    toggle_audio_popup
}
