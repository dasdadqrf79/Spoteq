use eframe::egui::{
    self, Align, Align2, CentralPanel, Color32, Layout, Panel, RichText, ScrollArea, Ui, Vec2,
};

use crate::{
    image_cache::CoverCache,
    settings::AppSettings,
    soundcloud::{SoundCloudAvatar, SoundCloudRuntime},
    spotify::SpotifyRuntime,
    state::{AppState, MusicPage, ToastKind},
    ui::{
        account_window, audio_panel, connections_page, history_page, liked_page, player_bar,
        queue_panel, search_page, settings_window, sidebar, smart_library_page,
        theme::{self, colors},
        title_bar, widgets,
    },
};

/// Draws the full application shell.
pub fn show(
    ui: &mut Ui,
    state: &mut AppState,
    settings: &mut AppSettings,
    settings_path: &std::path::Path,
    persistence_message: Option<&str>,
    covers: &mut CoverCache,
    spotify_runtime: &SpotifyRuntime,
    soundcloud_runtime: &SoundCloudRuntime,
    soundcloud_avatar: &SoundCloudAvatar,
    toggle_playback_requested: &mut bool,
) -> bool {
    super::i18n::set_language(settings.appearance.language);
    super::motion::configure(ui.ctx(), &settings.appearance);
    super::glass::background(ui);
    tracing::debug!("[UI] root render entered");
    let mut settings_changed = false;
    if state.page == MusicPage::Connections {
        state.page = MusicPage::Settings;
        state.settings_section = crate::state::SettingsSection::Integrations;
    }
    title_bar::show(ui);
    let viewport = ui.ctx().content_rect();
    let player_height = super::responsive::player_height(viewport.height());
    let margin = if viewport.width() < 1100.0 { 12 } else { 24 };

    if should_render_authorization(state) {
        tracing::debug!(
            spotify = ?state.spotify.auth,
            soundcloud = ?state.soundcloud.auth,
            "[UI] rendering authorization page"
        );
        CentralPanel::default()
            .frame(
                egui::Frame::new()
                    .fill(Color32::TRANSPARENT)
                    .inner_margin(egui::Margin::symmetric(36, 24)),
            )
            .show(ui, |ui| {
                super::motion::ambient(ui);
                connections_page::show(
                    ui,
                    &mut state.spotify,
                    spotify_runtime,
                    &mut state.soundcloud,
                    soundcloud_runtime,
                    soundcloud_avatar,
                );
            });
        if state.spotify.login_open {
            account_window::show(ui.ctx(), &mut state.spotify, spotify_runtime);
        }
        show_toast(ui.ctx(), &state.spotify);
        return settings_changed;
    }

    tracing::debug!(page = ?state.page, "[UI] rendering main application");

    Panel::top("main-navigation")
        .exact_size(58.0)
        .frame(
            egui::Frame::new()
                .fill(Color32::TRANSPARENT)
                .inner_margin(egui::Margin::symmetric(16, 7)),
        )
        .show(ui, |ui| sidebar::show(ui, state));

    Panel::bottom("player-bar")
        .exact_size(player_height)
        .frame(
            egui::Frame::new()
                .fill(Color32::TRANSPARENT)
                .inner_margin(egui::Margin {
                    left: margin,
                    right: margin,
                    top: 0,
                    bottom: 18,
                }),
        )
        .show(ui, |ui| {
            crate::ui::motion::frame(
                egui::Frame::new()
                    .fill(colors::surface_low())
                    .stroke(egui::Stroke::new(1.0, colors::border()))
                    .corner_radius(26)
                    .shadow(theme::player_shadow())
                    .inner_margin(egui::Margin::symmetric(margin, 10)),
            )
            .show(ui, |ui| {
                if player_bar::show(
                    ui,
                    &mut state.spotify,
                    &mut state.soundcloud,
                    &mut state.autoplay,
                    &mut state.provider_library,
                    covers,
                    spotify_runtime,
                    soundcloud_runtime,
                    &mut settings.audio,
                    &mut settings.playback,
                    &mut state.queue_open,
                    &mut settings_changed,
                    toggle_playback_requested,
                ) {
                    state.audio_popup_open = !state.audio_popup_open;
                }
            });
        });

    CentralPanel::default()
        .frame(
            egui::Frame::new()
                .fill(Color32::TRANSPARENT)
                .inner_margin(egui::Margin::symmetric(12, 12)),
        )
        .show(ui, |ui| {
            super::motion::ambient(ui);
            ui.horizontal_top(|ui| {
                ui.add_space(0.0);
                let content_width = ui.available_width().max(1.0);
                let content_height = ui.available_height().max(1.0);
                ui.allocate_ui_with_layout(
                    Vec2::new(content_width, content_height),
                    Layout::top_down(Align::Min),
                    |ui| {
                        super::motion::page_entry(
                            ui,
                            format!(
                                "{:?}/{:?}/{:?}",
                                state.page, state.settings_section, settings.appearance.language
                            ),
                        );
                        match state.page {
                            MusicPage::Search => search_page::show(
                                ui,
                                &mut state.search_query,
                                &mut state.search_filter,
                                &mut state.search_scope,
                                &mut state.spotify,
                                &mut state.soundcloud,
                                &mut state.autoplay,
                                &mut state.provider_library,
                                &mut settings.search_history,
                                &mut settings_changed,
                                covers,
                                spotify_runtime,
                                soundcloud_runtime,
                            ),
                            MusicPage::LikedSongs => liked_page::show(
                                ui,
                                &mut state.library_query,
                                &mut state.library_filter,
                                &mut state.spotify,
                                &mut state.soundcloud,
                                &mut state.autoplay,
                                &mut state.provider_library,
                                covers,
                                spotify_runtime,
                                soundcloud_runtime,
                            ),
                            MusicPage::Settings => settings_window::show_page(
                                ui,
                                &mut state.settings_section,
                                settings,
                                settings_path,
                                persistence_message,
                                &mut state.spotify,
                                spotify_runtime,
                                &mut state.soundcloud,
                                soundcloud_runtime,
                                soundcloud_avatar,
                                &mut settings_changed,
                            ),
                            MusicPage::Connections => {
                                unreachable!("Accounts is routed to Settings")
                            }
                            MusicPage::History => history_page::show(
                                ui,
                                &settings.session,
                                covers,
                                spotify_runtime,
                                soundcloud_runtime,
                            ),
                            MusicPage::SmartLibrary => {
                                ScrollArea::vertical()
                                    .id_salt("library-page-scroll")
                                    .auto_shrink([false, false])
                                    .show(ui, |ui| {
                                        smart_library_page::show(
                                            ui,
                                            &mut state.smart_playlist,
                                            &state.smart_library_cache,
                                            &mut settings.session,
                                            &mut state.vibe_rename,
                                            &mut settings_changed,
                                            &mut state.spotify,
                                            &mut state.soundcloud,
                                            &mut state.autoplay,
                                            &mut state.provider_library,
                                            covers,
                                            spotify_runtime,
                                            soundcloud_runtime,
                                        )
                                    });
                            }
                        }
                    },
                );
            });
        });

    let library_destination_id = egui::Id::new("spoteq-library-destination");
    if let Some(destination) = ui
        .ctx()
        .data(|data| data.get_temp::<MusicPage>(library_destination_id))
    {
        ui.ctx()
            .data_mut(|data| data.remove::<MusicPage>(library_destination_id));
        state.page = destination;
    }

    queue_panel::show(
        ui.ctx(),
        &mut state.queue_open,
        &mut state.queue_clear_armed,
        &mut state.vibe_draft,
        &mut state.vibe_name,
        &mut state.autoplay,
        &mut state.provider_library,
        &mut state.spotify,
        &mut state.soundcloud,
        covers,
        spotify_runtime,
        soundcloud_runtime,
        &mut settings.session,
        &mut settings_changed,
    );

    if let Some(navigation) = crate::ui::catalog_navigation::take(ui.ctx()) {
        state.page = MusicPage::Search;
        state.search_query = navigation.query;
        state.search_filter = navigation.filter;
        state.search_scope = navigation.scope;
        state.spotify.clear_toast();
    }

    show_audio_popup(
        ui.ctx(),
        state,
        settings,
        spotify_runtime,
        &mut settings_changed,
    );

    if state.spotify.login_open {
        account_window::show(ui.ctx(), &mut state.spotify, spotify_runtime);
    }

    show_toast(ui.ctx(), &state.spotify);

    settings_changed
}

fn should_render_authorization(state: &AppState) -> bool {
    !state.spotify.is_authenticated() && !state.soundcloud.is_authenticated()
}

#[cfg(test)]
mod tests {
    use super::should_render_authorization;
    use crate::state::AppState;

    #[test]
    fn clean_start_always_has_an_authorization_render_path() {
        assert!(should_render_authorization(&AppState::default()));
    }
}

fn show_audio_popup(
    context: &egui::Context,
    state: &mut AppState,
    settings: &mut AppSettings,
    spotify_runtime: &SpotifyRuntime,
    settings_changed: &mut bool,
) {
    if !state.audio_popup_open {
        return;
    }

    let mut popup_open = state.audio_popup_open;
    let viewport = context.content_rect();
    let player_height = super::responsive::player_height(viewport.height());
    let popup_height = (viewport.height() - player_height - 90.0).max(100.0);
    let window = egui::Window::new(crate::ui::i18n::tr("Audio & Equalizer"))
        .id(egui::Id::new("audio-equalizer-popup"))
        .anchor(
            Align2::RIGHT_BOTTOM,
            Vec2::new(-18.0, -(player_height + 12.0)),
        )
        .default_width(410.0)
        .min_width(280.0)
        .max_width((viewport.width() - 60.0).min(520.0))
        .default_height(560.0)
        .min_height(100.0)
        .max_height(popup_height)
        .collapsible(false)
        .resizable(true)
        .open(&mut popup_open)
        .frame(
            egui::Frame::new()
                .fill(crate::ui::glass::window_fill())
                .stroke(egui::Stroke::new(1.0, colors::border()))
                .corner_radius(20)
                .shadow(theme::card_shadow())
                .inner_margin(14),
        );
    crate::ui::glass::show_window(
        context,
        egui::Id::new("audio-equalizer-popup"),
        window,
        |ui| {
            ScrollArea::vertical()
                .id_salt("audio-equalizer-popup-scroll")
                .max_height(popup_height - 40.0)
                .auto_shrink([false, false])
                .show(ui, |ui| {
                    audio_panel::show(
                        ui,
                        &mut settings.audio,
                        &mut state.spotify,
                        spotify_runtime,
                        settings_changed,
                    );
                });
        },
    );

    state.audio_popup_open = popup_open;
}

fn show_toast(context: &egui::Context, state: &crate::state::SpotifyViewState) {
    let Some(toast) = &state.toast else {
        return;
    };
    let color = match toast.kind {
        ToastKind::Success => colors::accent(),
        ToastKind::Error => colors::error(),
    };
    egui::Area::new(egui::Id::new("spoteq-toast"))
        .anchor(egui::Align2::RIGHT_TOP, Vec2::new(-28.0, 56.0))
        .order(egui::Order::Foreground)
        .interactable(false)
        .show(context, |ui| {
            crate::ui::motion::frame(
                egui::Frame::new()
                    .fill(colors::surface())
                    .stroke(egui::Stroke::new(1.0, color.gamma_multiply(0.8)))
                    .corner_radius(14)
                    .shadow(theme::card_shadow())
                    .inner_margin(egui::Margin::symmetric(16, 12)),
            )
            .show(ui, |ui| {
                ui.set_max_width(330.0);
                ui.horizontal(|ui| {
                    widgets::status_dot(ui, color);
                    ui.label(RichText::new(&toast.message).color(colors::text()));
                });
            });
        });
}
