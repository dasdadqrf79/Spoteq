use crate::ui::i18n::tr;
use eframe::egui::{
    self, Button, Color32, Painter, Pos2, Rect, Response, RichText, Sense, Shape, Stroke, Ui, Vec2,
};

use crate::ui::theme::{self, colors, layout};

/// Shared title geometry across primary pages.
pub fn page_header(ui: &mut Ui, title: &str, subtitle: &str) {
    ui.add_space(layout::PAGE_TOP);
    ui.label(
        RichText::new(tr(title))
            .size(layout::PAGE_TITLE)
            .strong()
            .color(colors::text()),
    );
    ui.label(
        RichText::new(tr(subtitle))
            .size(15.0)
            .color(colors::text_muted()),
    );
    ui.add_space(18.0);
}

/// Rounded navigation button with a short selection animation.
pub fn nav_button(ui: &mut Ui, id_source: &str, label: &str, selected: bool) -> Response {
    let animation = if super::motion::enabled(ui.ctx()) {
        ui.ctx()
            .animate_bool_with_time(ui.make_persistent_id(("nav", id_source)), selected, 0.18)
    } else {
        if selected { 1.0 } else { 0.0 }
    };
    let fill = theme::mix(
        colors::surface(),
        colors::accent_dark().gamma_multiply(0.58),
        animation,
    );
    let text = theme::mix(colors::text_muted(), colors::text(), animation);
    let stroke = Stroke::new(1.0, colors::accent().gamma_multiply(0.42 * animation));

    ui.add(crate::ui::motion::control(
        Button::new(RichText::new(tr(label)).color(text).strong())
            .fill(fill)
            .stroke(stroke)
            .corner_radius(8)
            .min_size(Vec2::new(112.0, 38.0)),
        crate::ui::motion::Kind::Button,
    ))
}

/// Full-width navigation row used by the persistent left sidebar.
pub fn sidebar_button(ui: &mut Ui, id_source: &str, label: &str, selected: bool) -> Response {
    let animation = if super::motion::enabled(ui.ctx()) {
        ui.ctx().animate_bool_with_time(
            ui.make_persistent_id(("sidebar-nav", id_source)),
            selected,
            0.16,
        )
    } else {
        if selected { 1.0 } else { 0.0 }
    };
    let fill = theme::mix(Color32::TRANSPARENT, colors::accent_tint(), animation);
    let text = theme::mix(colors::text_muted(), colors::text(), animation);
    let selected_text = theme::mix(text, colors::accent(), animation);
    let response = ui.add_sized(
        [ui.available_width(), 36.0],
        crate::ui::motion::control(
            Button::new(RichText::new(tr(label)).color(selected_text).strong())
                .fill(fill)
                .stroke(Stroke::NONE)
                .corner_radius(4),
            crate::ui::motion::Kind::Button,
        ),
    );
    if selected {
        ui.painter().rect_filled(
            Rect::from_min_size(
                Pos2::new(response.rect.left(), response.rect.top() + 6.0),
                Vec2::new(2.0, response.rect.height() - 12.0),
            ),
            1,
            colors::accent(),
        );
    }
    if response.hovered() {
        response.on_hover_cursor(egui::CursorIcon::PointingHand)
    } else {
        response
    }
}

/// Uppercase micro-heading shared by sidebar and inspector sections.
pub fn eyebrow(ui: &mut Ui, label: &str) {
    ui.label(
        RichText::new(tr(label).to_uppercase())
            .size(10.0)
            .strong()
            .color(colors::text_disabled()),
    );
}

/// Small circular indicator that does not depend on icon fonts.
pub fn status_dot(ui: &mut Ui, color: Color32) {
    let (rect, _) = ui.allocate_exact_size(Vec2::splat(8.0), Sense::hover());
    ui.painter().circle_filled(rect.center(), 3.5, color);
}

/// Small status capsule.
pub fn status_pill(ui: &mut Ui, label: &str, color: Color32) {
    crate::ui::motion::frame(
        egui::Frame::new()
            .fill(color.gamma_multiply(0.16))
            .corner_radius(4)
            .inner_margin(egui::Margin::symmetric(8, 4)),
    )
    .show(ui, |ui| {
        ui.label(RichText::new(tr(label)).color(color).small().strong());
    });
}

/// Painter-drawn like button that does not depend on an icon font.
pub fn heart_button(ui: &mut Ui, filled: bool, enabled: bool) -> Response {
    let (rect, response) = ui.allocate_exact_size(
        Vec2::splat(32.0),
        if enabled {
            Sense::click()
        } else {
            Sense::hover()
        },
    );
    if response.hovered() && enabled {
        ui.painter()
            .circle_filled(rect.center(), 15.0, colors::surface_hover());
    }
    let hot = super::motion::hover(ui, &response);
    let c = rect.center();
    let scale = 1.0 + hot * 0.12;
    let points = vec![
        Pos2::new(c.x, c.y + 9.0),
        Pos2::new(c.x - 9.0, c.y),
        Pos2::new(c.x - 7.5, c.y - 6.0),
        Pos2::new(c.x - 2.0, c.y - 7.5),
        Pos2::new(c.x, c.y - 4.0),
        Pos2::new(c.x + 2.0, c.y - 7.5),
        Pos2::new(c.x + 7.5, c.y - 6.0),
        Pos2::new(c.x + 9.0, c.y),
    ];
    let points = points.into_iter().map(|p| c + (p - c) * scale).collect();
    let color = if enabled && filled {
        colors::accent_bright()
    } else if enabled {
        colors::text()
    } else {
        colors::text_disabled()
    };
    if filled {
        ui.painter()
            .add(Shape::convex_polygon(points, color, Stroke::NONE));
    } else {
        ui.painter()
            .add(Shape::closed_line(points, Stroke::new(1.6, color)));
    }
    response.on_hover_cursor(if enabled {
        egui::CursorIcon::PointingHand
    } else {
        egui::CursorIcon::Default
    })
}

/// Stable painter-drawn player icon without font glyph dependencies.
#[derive(Debug, Clone, Copy)]
pub enum PlayerIcon {
    Previous,
    Play,
    Pause,
    Next,
}

/// Small Spotify-style utility icons used on the right side of the player.
#[derive(Debug, Clone, Copy)]
pub enum PlayerAuxIcon {
    Device,
    Volume,
}

/// Draws a consistently sized playback button.
pub fn player_button(ui: &mut Ui, icon: PlayerIcon, enabled: bool, primary: bool) -> Response {
    let size = if primary {
        Vec2::splat(66.0)
    } else {
        Vec2::splat(30.0)
    };
    let sense = if enabled {
        Sense::click()
    } else {
        Sense::hover()
    };
    let (rect, response) = ui.allocate_exact_size(size, sense);
    let hot = super::motion::hover(ui, &response);
    let rect = if super::motion::enabled(ui.ctx()) && enabled {
        rect.translate(Vec2::new(
            0.0,
            -2.0 * hot
                + if response.is_pointer_button_down_on() {
                    2.0
                } else {
                    0.0
                },
        ))
    } else {
        rect
    };
    let hovered = response.hovered() && enabled;
    let lift = if primary && enabled && super::motion::enabled(ui.ctx()) {
        ui.ctx().animate_bool_with_time(response.id, hovered, 0.14)
    } else {
        0.0
    };
    let fill = if primary {
        if !enabled {
            colors::surface_raised()
        } else if hovered {
            colors::accent_bright()
        } else {
            colors::accent()
        }
    } else if hovered {
        colors::surface_hover()
    } else {
        Color32::TRANSPARENT
    };
    if primary {
        ui.painter()
            .add(theme::control_shadow().as_shape(rect.shrink(2.0 - lift), rect.height() / 2.0));
    }
    ui.painter().rect_filled(rect, rect.height() / 2.0, fill);
    if primary {
        ui.painter().circle_stroke(
            rect.center(),
            rect.width() * 0.5 - 1.0,
            Stroke::new(
                1.4,
                if enabled {
                    colors::accent_bright()
                } else {
                    colors::text_disabled()
                },
            ),
        );
    }
    let color = if !enabled {
        colors::text_disabled()
    } else if primary {
        colors::background()
    } else {
        colors::text()
    };
    let icon_inset = if primary { 14.0 } else { 7.0 };
    paint_player_icon(ui.painter(), rect.shrink(icon_inset), icon, color);
    super::motion::custom_feedback(ui, &response, rect, rect.height() * 0.5);
    if enabled {
        response.on_hover_cursor(egui::CursorIcon::PointingHand)
    } else {
        response
    }
}

/// Draws a compact utility button without relying on icon fonts.
pub fn player_aux_button(ui: &mut Ui, icon: PlayerAuxIcon, enabled: bool) -> Response {
    let size = match icon {
        PlayerAuxIcon::Device => Vec2::splat(42.0),
        PlayerAuxIcon::Volume => Vec2::splat(24.0),
    };
    let sense = if enabled {
        Sense::click()
    } else {
        Sense::hover()
    };
    let (rect, response) = ui.allocate_exact_size(size, sense);
    let hovered = response.hovered() && enabled;

    if hovered {
        ui.painter()
            .rect_filled(rect, 4, colors::surface_hover().gamma_multiply(0.85));
    }

    if matches!(icon, PlayerAuxIcon::Device) {
        ui.painter().rect_stroke(
            rect,
            8,
            Stroke::new(1.0, colors::border_strong()),
            egui::StrokeKind::Inside,
        );
    }

    let color = colors::text_muted();
    let inset = if matches!(icon, PlayerAuxIcon::Device) {
        11.0
    } else {
        4.0
    };
    paint_player_aux_icon(ui.painter(), rect.shrink(inset), icon, color);
    super::motion::custom_feedback(ui, &response, rect, 8.0);

    if enabled {
        response.on_hover_cursor(egui::CursorIcon::PointingHand)
    } else {
        response
    }
}

/// Compact EQ ON / EQ OFF control used by Settings and the inspector.
pub fn eq_toggle(ui: &mut Ui, enabled: &mut bool) -> Response {
    let (rect, mut response) = ui.allocate_exact_size(Vec2::new(88.0, 32.0), Sense::click());
    if response.clicked() {
        *enabled = !*enabled;
        response.mark_changed();
    }
    let phase = if super::motion::enabled(ui.ctx()) {
        ui.ctx()
            .animate_bool_with_time(response.id.with("switch-position"), *enabled, 0.2)
    } else {
        if *enabled { 1.0 } else { 0.0 }
    };
    let fill = theme::mix(colors::surface_raised(), colors::accent_dark(), phase);
    ui.painter().rect(
        rect,
        16,
        fill,
        Stroke::new(
            1.0,
            theme::mix(colors::border_strong(), colors::accent(), phase),
        ),
        egui::StrokeKind::Inside,
    );
    let center = Pos2::new(
        egui::lerp(rect.left() + 16.0..=rect.right() - 16.0, phase),
        rect.center().y,
    );
    if theme::depth_enabled() {
        ui.painter().circle_filled(
            center + Vec2::new(0.0, 2.0),
            12.0,
            Color32::from_black_alpha(100),
        );
    }
    ui.painter().circle_filled(
        center,
        11.0,
        theme::mix(colors::text_muted(), colors::accent_bright(), phase),
    );
    ui.painter().circle_stroke(
        center,
        10.0,
        Stroke::new(1.0, Color32::from_white_alpha(90)),
    );
    ui.painter().text(
        rect.center() + Vec2::new(if *enabled { -12.0 } else { 12.0 }, 0.0),
        egui::Align2::CENTER_CENTER,
        tr(if *enabled { "On" } else { "Off" }),
        egui::FontId::proportional(11.0),
        colors::text(),
    );
    super::motion::custom_feedback(ui, &response, rect, 16.0);
    response.on_hover_cursor(egui::CursorIcon::PointingHand)
}

/// Label above a full-width slider so values never clip the rail.
pub fn labeled_slider(
    ui: &mut Ui,
    label: &str,
    value: &mut f32,
    range: std::ops::RangeInclusive<f32>,
    suffix: &str,
    step: f64,
) -> Response {
    ui.horizontal(|ui| {
        ui.label(RichText::new(tr(label)).color(colors::text_muted()));
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            let readout = if suffix.contains("dB") {
                format!("{value:+.1}{suffix}")
            } else if suffix.is_empty() {
                format!("{value:.2}")
            } else {
                format!("{value:.1}{suffix}")
            };
            ui.label(
                RichText::new(tr(&(readout)))
                    .monospace()
                    .size(11.0)
                    .color(colors::accent()),
            );
        });
    });
    let width = ui.available_width().max(80.0);
    ui.scope(|ui| {
        ui.spacing_mut().slider_width = width;
        ui.add_sized(
            [width, 18.0],
            crate::ui::motion::control(
                egui::Slider::new(value, range)
                    .show_value(false)
                    .trailing_fill(true)
                    .step_by(step),
                crate::ui::motion::Kind::Slider,
            ),
        )
    })
    .inner
}

/// Animated three-bar indicator for the currently playing track.
pub fn playing_eq_bars(ui: &mut Ui) {
    let time = ui.input(|input| input.time) as f32;
    let (rect, _) = ui.allocate_exact_size(Vec2::new(14.0, 16.0), Sense::hover());
    for index in 0..3 {
        let phase = time * (2.5 + index as f32 * 0.65) + index as f32;
        let height = 4.0 + (phase.sin() * 0.5 + 0.5) * 11.0;
        let x = rect.left() + 3.0 + index as f32 * 4.0;
        ui.painter().rect_filled(
            Rect::from_center_size(
                Pos2::new(x, rect.bottom() - height * 0.5),
                Vec2::new(2.0, height),
            ),
            1,
            colors::accent(),
        );
    }
}

/// Paints a play or pause glyph over album artwork.
pub fn paint_cover_action(painter: &Painter, rect: Rect, playing: bool) {
    painter.rect_filled(rect, 6, Color32::from_black_alpha(150));
    let icon = if playing {
        PlayerIcon::Pause
    } else {
        PlayerIcon::Play
    };
    paint_player_icon(
        painter,
        rect.shrink(rect.width() * 0.31),
        icon,
        Color32::WHITE,
    );
}

fn paint_player_aux_icon(painter: &Painter, rect: Rect, icon: PlayerAuxIcon, color: Color32) {
    let center = rect.center();
    let w = rect.width();
    let h = rect.height();

    match icon {
        PlayerAuxIcon::Device => {
            let monitor = Rect::from_min_max(
                Pos2::new(rect.left() + w * 0.04, rect.top() + h * 0.18),
                Pos2::new(rect.right() - w * 0.28, rect.bottom() - h * 0.18),
            );
            painter.rect_stroke(
                monitor,
                2,
                Stroke::new(1.5, color),
                egui::StrokeKind::Inside,
            );
            painter.line_segment(
                [
                    Pos2::new(monitor.center().x, monitor.bottom()),
                    Pos2::new(monitor.center().x, rect.bottom()),
                ],
                Stroke::new(1.4, color),
            );
            painter.line_segment(
                [
                    Pos2::new(monitor.center().x - w * 0.13, rect.bottom()),
                    Pos2::new(monitor.center().x + w * 0.13, rect.bottom()),
                ],
                Stroke::new(1.4, color),
            );
            let phone = Rect::from_min_max(
                Pos2::new(rect.right() - w * 0.25, rect.top() + h * 0.33),
                Pos2::new(rect.right() - w * 0.02, rect.bottom() - h * 0.06),
            );
            painter.rect_stroke(phone, 2, Stroke::new(1.4, color), egui::StrokeKind::Inside);
        }
        PlayerAuxIcon::Volume => {
            let speaker = vec![
                Pos2::new(rect.left() + w * 0.04, center.y - h * 0.16),
                Pos2::new(rect.left() + w * 0.25, center.y - h * 0.16),
                Pos2::new(rect.left() + w * 0.49, center.y - h * 0.35),
                Pos2::new(rect.left() + w * 0.49, center.y + h * 0.35),
                Pos2::new(rect.left() + w * 0.25, center.y + h * 0.16),
                Pos2::new(rect.left() + w * 0.04, center.y + h * 0.16),
            ];
            painter.add(Shape::convex_polygon(speaker, color, Stroke::NONE));
            painter.circle_stroke(
                Pos2::new(rect.left() + w * 0.46, center.y),
                w * 0.30,
                Stroke::new(1.3, color),
            );
            painter.rect_filled(
                Rect::from_min_max(
                    Pos2::new(rect.left() + w * 0.40, rect.top()),
                    Pos2::new(rect.left() + w * 0.52, rect.bottom()),
                ),
                0,
                colors::surface_low(),
            );
        }
    }
}

fn paint_player_icon(painter: &Painter, rect: Rect, icon: PlayerIcon, color: Color32) {
    let center = rect.center();
    let width = rect.width();
    let height = rect.height();
    match icon {
        PlayerIcon::Play => {
            let points = vec![
                Pos2::new(center.x - width * 0.22, center.y - height * 0.34),
                Pos2::new(center.x - width * 0.22, center.y + height * 0.34),
                Pos2::new(center.x + width * 0.34, center.y),
            ];
            painter.add(Shape::convex_polygon(points, color, Stroke::NONE));
        }
        PlayerIcon::Pause => {
            let bar_width = width * 0.20;
            let gap = width * 0.12;
            painter.rect_filled(
                Rect::from_center_size(
                    Pos2::new(center.x - gap, center.y),
                    Vec2::new(bar_width, height * 0.68),
                ),
                1,
                color,
            );
            painter.rect_filled(
                Rect::from_center_size(
                    Pos2::new(center.x + gap, center.y),
                    Vec2::new(bar_width, height * 0.68),
                ),
                1,
                color,
            );
        }
        PlayerIcon::Previous | PlayerIcon::Next => {
            let direction = if matches!(icon, PlayerIcon::Previous) {
                -1.0
            } else {
                1.0
            };
            let points = vec![
                Pos2::new(center.x + direction * width * 0.28, center.y),
                Pos2::new(
                    center.x - direction * width * 0.18,
                    center.y - height * 0.30,
                ),
                Pos2::new(
                    center.x - direction * width * 0.18,
                    center.y + height * 0.30,
                ),
            ];
            painter.add(Shape::convex_polygon(points, color, Stroke::NONE));
            let line_x = center.x + direction * width * 0.34;
            painter.line_segment(
                [
                    Pos2::new(line_x, center.y - height * 0.30),
                    Pos2::new(line_x, center.y + height * 0.30),
                ],
                Stroke::new(2.0, color),
            );
        }
    }
}
