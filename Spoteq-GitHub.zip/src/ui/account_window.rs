use crate::ui::i18n::tr;
use eframe::egui::{self, Context, RichText, TextEdit, Vec2};

use crate::{
    spotify::{REGISTERED_REDIRECT_URI, SpotifyCommand, SpotifyRuntime},
    state::{AuthView, SpotifyViewState},
    ui::theme::{self, colors},
};

/// Draws Spotify setup, account status and logout controls.
pub fn show(context: &Context, state: &mut SpotifyViewState, runtime: &SpotifyRuntime) {
    let mut open = state.login_open;
    let window = egui::Window::new(crate::ui::i18n::tr("Spotify account"))
        .open(&mut open)
        .collapsible(false)
        .resizable(false)
        .default_size(Vec2::new(520.0, 360.0))
        .max_width((context.content_rect().width() - 64.0).max(240.0))
        .max_height((context.content_rect().height() - 100.0).max(120.0))
        .vscroll(true)
        .frame(
            egui::Frame::new()
                .fill(crate::ui::glass::window_fill())
                .stroke(egui::Stroke::new(1.0, colors::border()))
                .corner_radius(18)
                .shadow(theme::card_shadow())
                .inner_margin(20),
        );
    crate::ui::glass::show_window(context, egui::Id::new("spotify-account"), window, |ui| {
        match state.auth.clone() {
            AuthView::LoggedIn(profile) => {
                ui.label(
                    RichText::new(tr("CONNECTED ACCOUNT"))
                        .size(10.0)
                        .strong()
                        .color(colors::accent()),
                );
                ui.heading(tr(&(profile.label())));
                ui.label(
                    RichText::new(tr(&(format!(
                        "Spotify ID: {}{}",
                        profile.id,
                        profile
                            .product
                            .as_deref()
                            .map(|product| format!(" · {product}"))
                            .unwrap_or_default()
                    ))))
                    .color(colors::text_muted()),
                );
                if let Some(country) = profile.country {
                    ui.label(
                        RichText::new(tr(&(format!("Country: {country}"))))
                            .color(colors::text_muted()),
                    );
                }
                ui.add_space(10.0);
                ui.label(
                    RichText::new(tr(
                        &("Direct playback is local and requires Spotify Premium."),
                    ))
                    .color(colors::text_muted()),
                );
                ui.label(
                    RichText::new(tr(
                        &("Playback authorization is separate and opens in the browser \
                         on the first track click."),
                    ))
                    .color(colors::text_muted()),
                );
                ui.add_space(24.0);
                if ui
                    .add(crate::ui::motion::control(
                        egui::Button::new(tr("Log out from this app"))
                            .fill(colors::surface_raised())
                            .corner_radius(11),
                        crate::ui::motion::Kind::Button,
                    ))
                    .clicked()
                {
                    if let Err(error) = runtime.send(SpotifyCommand::Logout) {
                        state.toast_error(error.to_string());
                    }
                }
            }
            AuthView::Authorizing => {
                ui.heading(tr("Finish authorization in your browser"));
                ui.spinner();
                ui.label(tr(
                    &("This window will update automatically after Spotify redirects back."),
                ));
            }
            AuthView::Restoring => {
                ui.heading(tr("Restoring Spotify session"));
                ui.spinner();
            }
            AuthView::LoggedOut | AuthView::Error(_) => {
                ui.heading(tr("Connect Spotify"));
                ui.label(tr(
                    &("Create an app in Spotify Developer Dashboard and copy its Client ID."),
                ));
                ui.add_space(12.0);
                ui.label(RichText::new(tr("Redirect URI to register")).strong());
                ui.horizontal(|ui| {
                    ui.monospace(REGISTERED_REDIRECT_URI);
                    if crate::ui::motion::small_button(ui, tr("Copy")).clicked() {
                        ui.ctx().copy_text(REGISTERED_REDIRECT_URI.to_owned());
                    }
                });
                ui.add_space(12.0);
                ui.label(RichText::new(tr("Client ID")).strong());
                ui.add_sized(
                    [ui.available_width(), 38.0],
                    crate::ui::motion::control(
                        TextEdit::singleline(&mut state.client_id_input)
                            .hint_text(tr("Spotify Client ID")),
                        crate::ui::motion::Kind::Input,
                    ),
                );
                if let AuthView::Error(error) = &state.auth {
                    ui.add_space(10.0);
                    ui.label(RichText::new(error).color(colors::warning()));
                }
                ui.add_space(16.0);
                let enabled = !state.client_id_input.trim().is_empty();
                if ui
                    .add_enabled(
                        enabled,
                        crate::ui::motion::control(
                            egui::Button::new(tr("Open Spotify authorization"))
                                .fill(colors::accent_dark())
                                .corner_radius(11),
                            crate::ui::motion::Kind::Button,
                        ),
                    )
                    .clicked()
                {
                    let client_id = state.client_id_input.trim().to_owned();
                    if let Err(error) = runtime.send(SpotifyCommand::Login { client_id }) {
                        state.auth = AuthView::Error(error.to_string());
                    }
                }
            }
        }
    });
    state.login_open = open;
}
