//! Listening history grouped by local calendar day.
use crate::ui::i18n::tr;

use chrono::{DateTime, Local, Utc};
use eframe::egui::{self, Align, Layout, RichText, ScrollArea, Ui, Vec2};

use crate::{
    image_cache::CoverCache,
    settings::{ResumeSession, SessionSettings},
    soundcloud::SoundCloudRuntime,
    spotify::SpotifyRuntime,
    ui::{search_page::format_duration, session_request, theme::colors},
};

/// Draws persisted playback history and an explicit resume-session card.
pub fn show(
    ui: &mut Ui,
    session: &SessionSettings,
    covers: &mut CoverCache,
    spotify_runtime: &SpotifyRuntime,
    soundcloud_runtime: &SoundCloudRuntime,
) {
    ui.add_space(28.0);
    ui.label(
        RichText::new(tr("Listening History"))
            .size(34.0)
            .strong()
            .color(colors::text()),
    );
    ui.label(
        RichText::new(tr(
            &("Tracks played on this device, stored locally in Spoteq."),
        ))
        .size(15.0)
        .color(colors::text_muted()),
    );
    ui.add_space(20.0);

    if let Some(resume) = session.resume.as_ref()
        && let Some(track) = resume.current.as_ref()
    {
        crate::ui::motion::frame(
            egui::Frame::new()
                .fill(colors::surface_raised())
                .stroke(egui::Stroke::new(1.0, colors::border_strong()))
                .corner_radius(12)
                .inner_margin(16),
        )
        .show(ui, |ui| {
            ui.horizontal(|ui| {
                let text_width = (ui.available_width() - 116.0).max(1.0);
                ui.vertical(|ui| {
                    ui.set_width(text_width);
                    ui.label(
                        RichText::new(tr("Resume session"))
                            .strong()
                            .color(colors::text()),
                    );
                    ui.label(
                        RichText::new(tr(&(format!(
                            "{} - {} at {}",
                            track.artist,
                            track.title,
                            format_duration(u64::from(resume.position_ms))
                        ))))
                        .color(colors::text_muted()),
                    );
                });
                ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                    if ui
                        .add(crate::ui::motion::control(
                            egui::Button::new(tr("Resume"))
                                .min_size(Vec2::new(96.0, 38.0))
                                .fill(colors::surface_hover())
                                .corner_radius(9),
                            crate::ui::motion::Kind::Button,
                        ))
                        .clicked()
                    {
                        session_request::request(ui.ctx(), resume.clone());
                    }
                });
            });
        });
        ui.add_space(18.0);
    }

    if session.history.is_empty() {
        crate::ui::motion::frame(
            egui::Frame::new()
                .fill(colors::surface_low())
                .stroke(egui::Stroke::new(1.0, colors::border()))
                .corner_radius(12)
                .inner_margin(20),
        )
        .show(ui, |ui| {
            ui.label(
                RichText::new(tr("No listening history yet"))
                    .strong()
                    .color(colors::text()),
            );
            ui.label(
                RichText::new(tr("Played tracks will appear here automatically."))
                    .color(colors::text_muted()),
            );
        });
        return;
    }

    ScrollArea::vertical()
        .id_salt("listening-history-scroll")
        .auto_shrink([false, false])
        .show(ui, |ui| {
            let today = Local::now().date_naive();
            let yesterday = today.pred_opt();
            let mut previous_group = String::new();
            for entry in &session.history {
                let Some(timestamp) = DateTime::<Utc>::from_timestamp_millis(entry.started_at_ms)
                else {
                    continue;
                };
                let local = timestamp.with_timezone(&Local);
                let group = if local.date_naive() == today {
                    "Today".to_owned()
                } else if Some(local.date_naive()) == yesterday {
                    "Yesterday".to_owned()
                } else {
                    "Earlier".to_owned()
                };
                if group != previous_group {
                    if !previous_group.is_empty() {
                        ui.add_space(14.0);
                    }
                    ui.label(
                        RichText::new(&group)
                            .size(18.0)
                            .strong()
                            .color(colors::text()),
                    );
                    ui.add_space(8.0);
                    previous_group = group;
                }

                let track = &entry.track;
                let response = crate::ui::motion::frame(
                    egui::Frame::new()
                        .fill(colors::surface_low())
                        .stroke(egui::Stroke::new(1.0, colors::border()))
                        .corner_radius(10)
                        .inner_margin(8),
                )
                .show(ui, |ui| {
                    ui.horizontal(|ui| {
                        match track.provider {
                            crate::catalog::TrackProvider::Spotify => {
                                let _ = covers.show(
                                    ui,
                                    track.artwork_url.as_deref(),
                                    spotify_runtime,
                                    Vec2::splat(48.0),
                                );
                            }
                            crate::catalog::TrackProvider::SoundCloud => {
                                let _ = covers.show_soundcloud(
                                    ui,
                                    track.artwork_url.as_deref(),
                                    soundcloud_runtime,
                                    Vec2::splat(48.0),
                                );
                            }
                        }
                        ui.add_space(10.0);
                        let text_width = (ui.available_width() - 184.0).max(1.0);
                        ui.vertical(|ui| {
                            ui.set_width(text_width);
                            ui.add(
                                egui::Label::new(
                                    RichText::new(&track.title).strong().color(colors::text()),
                                )
                                .truncate(),
                            );
                            ui.add(
                                egui::Label::new(
                                    RichText::new(&track.artist)
                                        .size(12.0)
                                        .color(colors::text_muted()),
                                )
                                .truncate(),
                            );
                        });
                        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                            ui.label(
                                RichText::new(local.format("%H:%M").to_string())
                                    .monospace()
                                    .color(colors::text_muted()),
                            );
                            ui.label(
                                RichText::new(format_duration(track.duration_ms))
                                    .monospace()
                                    .color(colors::text_muted()),
                            );
                        });
                    });
                })
                .response
                .interact(egui::Sense::click());
                if response
                    .on_hover_text(tr("Play this track again"))
                    .clicked()
                {
                    session_request::request(
                        ui.ctx(),
                        ResumeSession {
                            current: Some(track.clone()),
                            position_ms: 0,
                            next_up: Vec::new(),
                            autoplay: Vec::new(),
                            radio_title: None,
                        },
                    );
                }
                ui.add_space(6.0);
            }
        });
}
