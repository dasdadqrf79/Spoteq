//! One-frame playback transport requests that need application-level coordination.

use eframe::egui;

const TRANSPORT_ID: &str = "spoteq-transport-request";

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TransportRequest {
    Next,
}

pub fn request(context: &egui::Context, request: TransportRequest) {
    context.data_mut(|data| {
        data.insert_temp(egui::Id::new(TRANSPORT_ID), request);
    });
}

pub fn take(context: &egui::Context) -> Option<TransportRequest> {
    context.data_mut(|data| {
        let id = egui::Id::new(TRANSPORT_ID);
        let request = data.get_temp::<TransportRequest>(id);
        data.remove::<TransportRequest>(id);
        request
    })
}
