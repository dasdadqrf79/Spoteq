//! Clear light surfaces, ink typography and accessible accents.

use std::sync::atomic::{AtomicU8, Ordering};

use eframe::egui::{
    self, Color32, FontFamily, FontId, Frame, Shadow, Stroke, TextStyle, Vec2, Visuals,
};

use crate::settings::{AccentColor, AppearanceSettings};

thread_local! { static DARK_MODE: std::cell::Cell<bool> = const { std::cell::Cell::new(true) }; }
static MOTION_ENABLED: AtomicU8 = AtomicU8::new(1);
static DEPTH_ENABLED: AtomicU8 = AtomicU8::new(1);

/// Whether optional interface motion is enabled.
pub fn motion_enabled() -> bool {
    MOTION_ENABLED.load(Ordering::Relaxed) != 0
}

/// Whether optional ambient depth is enabled.
pub fn depth_enabled() -> bool {
    DEPTH_ENABLED.load(Ordering::Relaxed) != 0
}

/// Applies persisted, UI-only visual preferences.
pub fn apply_appearance(context: &egui::Context, appearance: &AppearanceSettings) {
    MOTION_ENABLED.store(u8::from(appearance.motion_enabled), Ordering::Relaxed);
    DEPTH_ENABLED.store(u8::from(appearance.depth_enabled), Ordering::Relaxed);
    sync_mode(context, appearance.theme);
    context.global_style_mut(|style| {
        style.visuals.window_shadow = floating_shadow();
        style.visuals.popup_shadow = floating_shadow();
        style.animation_time = if appearance.motion_enabled { 0.18 } else { 0.0 };
    });
}

/// Shared application colors.
pub fn is_dark() -> bool {
    DARK_MODE.with(|mode| mode.get())
}

pub fn sync_mode(ctx: &egui::Context, mode: crate::settings::ThemeMode) {
    DARK_MODE.with(|value| value.set(mode == crate::settings::ThemeMode::Dark));
    let id = egui::Id::new("appearance-theme-mode");
    if ctx.data(|d| d.get_temp::<crate::settings::ThemeMode>(id)) != Some(mode) {
        install(ctx, AccentColor::Neutral);
        ctx.data_mut(|d| d.insert_temp(id, mode));
        ctx.request_repaint();
    }
}

pub mod colors {
    use eframe::egui::Color32;
    fn choose(light: Color32, dark: Color32) -> Color32 {
        if super::is_dark() { dark } else { light }
    }
    pub fn background() -> Color32 {
        choose(
            Color32::from_rgb(242, 246, 252),
            Color32::from_rgb(12, 14, 20),
        )
    }
    pub fn surface_low() -> Color32 {
        choose(Color32::from_white_alpha(24), Color32::from_white_alpha(6))
    }
    pub fn surface() -> Color32 {
        choose(Color32::from_white_alpha(34), Color32::from_white_alpha(12))
    }
    pub fn surface_raised() -> Color32 {
        choose(Color32::from_white_alpha(65), Color32::from_white_alpha(20))
    }
    pub fn surface_hover() -> Color32 {
        choose(Color32::from_white_alpha(88), Color32::from_white_alpha(28))
    }
    pub fn surface_gloss() -> Color32 {
        choose(
            Color32::from_white_alpha(110),
            Color32::from_white_alpha(35),
        )
    }
    pub fn search_well() -> Color32 {
        choose(Color32::from_white_alpha(40), Color32::from_black_alpha(18))
    }
    pub fn border() -> Color32 {
        choose(
            Color32::from_rgba_unmultiplied(53, 71, 98, 24),
            Color32::from_white_alpha(20),
        )
    }
    pub fn border_strong() -> Color32 {
        choose(
            Color32::from_rgba_unmultiplied(53, 71, 98, 65),
            Color32::from_white_alpha(65),
        )
    }
    pub fn highlight() -> Color32 {
        Color32::from_white_alpha(140)
    }
    pub fn text() -> Color32 {
        choose(
            Color32::from_rgb(24, 33, 49),
            Color32::from_rgb(242, 244, 247),
        )
    }
    pub fn text_muted() -> Color32 {
        choose(
            Color32::from_rgb(69, 82, 102),
            Color32::from_rgb(177, 186, 204),
        )
    }
    pub fn text_disabled() -> Color32 {
        choose(
            Color32::from_rgb(103, 115, 134),
            Color32::from_rgb(128, 142, 165),
        )
    }
    pub fn warning() -> Color32 {
        choose(
            Color32::from_rgb(143, 82, 0),
            Color32::from_rgb(245, 178, 66),
        )
    }
    pub fn error() -> Color32 {
        choose(
            Color32::from_rgb(186, 35, 53),
            Color32::from_rgb(255, 116, 130),
        )
    }
    pub fn accent() -> Color32 {
        choose(
            Color32::from_rgb(0, 77, 182),
            Color32::from_rgb(156, 180, 255),
        )
    }
    pub fn accent_bright() -> Color32 {
        super::mix(accent(), text(), 0.12)
    }
    pub fn accent_dark() -> Color32 {
        super::mix(surface_low(), accent(), 0.34)
    }
    pub fn accent_tint() -> Color32 {
        super::mix(surface_low(), accent(), 0.16)
    }
}
/// Layout constants chosen so egui panels do not clip each other.
pub mod layout {
    pub const TITLE_BAR: f32 = 42.0;
    pub const TOP_BAR: f32 = 42.0;
    pub const SIDEBAR: f32 = 238.0;
    pub const SIDEBAR_COLLAPSED: f32 = 238.0;
    pub const SIDEBAR_HOVER_TRIGGER: f32 = 238.0;
    pub const PLAYER: f32 = 138.0;
    pub const CONTENT_MAX: f32 = 1480.0;
    pub const PAGE_TOP: f32 = 14.0;
    pub const PAGE_TITLE: f32 = 30.0;
    pub const CARD_RADIUS: u8 = 16;
    pub const TRACK_ROW: f32 = 56.0;
}

/// Installs the global fonts, spacing and light visual palette.
pub fn install(context: &egui::Context, _accent: AccentColor) {
    context.set_theme(if is_dark() {
        egui::Theme::Dark
    } else {
        egui::Theme::Light
    });
    context.global_style_mut(|style| {
        style.visuals = if is_dark() {
            Visuals::dark()
        } else {
            Visuals::light()
        };
        style.visuals.panel_fill = colors::background();
        style.visuals.window_fill = if is_dark() {
            Color32::from_rgba_unmultiplied(22, 26, 36, 245)
        } else {
            Color32::from_white_alpha(235)
        };
        style.visuals.widgets.open.weak_bg_fill =
            Color32::from_rgba_unmultiplied(118, 161, 204, 44);
        style.visuals.widgets.open.bg_fill = colors::surface_hover();
        style.visuals.extreme_bg_color = colors::surface_low();
        style.visuals.faint_bg_color = colors::surface_low();
        style.visuals.hyperlink_color = colors::text();
        style.visuals.selection.bg_fill = colors::accent().gamma_multiply(0.28);
        style.visuals.selection.stroke.color = colors::accent();

        style.visuals.widgets.noninteractive.bg_fill = colors::surface();
        style.visuals.widgets.noninteractive.weak_bg_fill = colors::surface_low();
        style.visuals.widgets.noninteractive.bg_stroke = Stroke::new(1.0, colors::border());
        style.visuals.widgets.noninteractive.fg_stroke = Stroke::new(1.0, colors::text_muted());
        style.visuals.widgets.noninteractive.corner_radius = 14.0.into();

        style.visuals.widgets.inactive.bg_fill = colors::surface();
        style.visuals.widgets.inactive.weak_bg_fill = colors::surface_low();
        style.visuals.widgets.inactive.bg_stroke = Stroke::new(1.0, colors::border());
        style.visuals.widgets.inactive.fg_stroke = Stroke::new(1.0, colors::text_muted());
        style.visuals.widgets.inactive.corner_radius = 14.0.into();

        style.visuals.widgets.hovered.bg_fill = colors::surface_raised();
        style.visuals.widgets.hovered.weak_bg_fill = colors::surface_hover();
        style.visuals.widgets.hovered.bg_stroke = Stroke::new(1.0, colors::border_strong());
        style.visuals.widgets.hovered.fg_stroke = Stroke::new(1.0, colors::text());
        style.visuals.widgets.hovered.corner_radius = 14.0.into();
        style.visuals.widgets.hovered.expansion = 0.0;

        style.visuals.widgets.active.bg_fill = colors::surface_low();
        style.visuals.widgets.active.weak_bg_fill = colors::surface_low();
        style.visuals.widgets.active.bg_stroke =
            Stroke::new(1.0, colors::accent().gamma_multiply(0.55));
        style.visuals.widgets.active.fg_stroke = Stroke::new(1.0, colors::text());
        style.visuals.widgets.active.corner_radius = 14.0.into();

        style.visuals.window_stroke = Stroke::new(1.0, colors::border());
        style.visuals.window_shadow = floating_shadow();
        style.visuals.popup_shadow = floating_shadow();
        style.visuals.window_corner_radius = 18.0.into();
        style.visuals.menu_corner_radius = 16.0.into();

        style.spacing.item_spacing = Vec2::new(10.0, 10.0);
        style.spacing.button_padding = Vec2::new(16.0, 10.0);
        style.spacing.slider_width = 220.0;
        style.spacing.interact_size = Vec2::new(36.0, 24.0);
        style.spacing.scroll.bar_width = 6.0;

        style.text_styles.insert(
            TextStyle::Heading,
            FontId::new(32.0, FontFamily::Proportional),
        );
        style
            .text_styles
            .insert(TextStyle::Body, FontId::new(15.0, FontFamily::Proportional));
        style.text_styles.insert(
            TextStyle::Button,
            FontId::new(14.0, FontFamily::Proportional),
        );
        style.text_styles.insert(
            TextStyle::Small,
            FontId::new(12.0, FontFamily::Proportional),
        );
        style.text_styles.insert(
            TextStyle::Monospace,
            FontId::new(12.0, FontFamily::Monospace),
        );
    });
}

/// A restrained shadow for cards that sit above the application canvas.
pub fn card_shadow() -> Shadow {
    if !depth_enabled() {
        return Shadow::NONE;
    }
    Shadow {
        offset: [0, 6],
        blur: 22,
        spread: 0,
        color: Color32::from_black_alpha(20),
    }
}

/// Stronger upward shadow that visually separates the persistent player.
pub fn player_shadow() -> Shadow {
    if !depth_enabled() {
        return Shadow::NONE;
    }
    Shadow {
        offset: [0, -8],
        blur: 30,
        spread: 0,
        color: Color32::from_black_alpha(175),
    }
}

/// Sideways depth for the navigation rail.
pub fn sidebar_shadow() -> Shadow {
    if !depth_enabled() {
        return Shadow::NONE;
    }
    Shadow {
        offset: [10, 0],
        blur: 28,
        spread: 0,
        color: Color32::from_black_alpha(140),
    }
}

/// Compact shadow for interactive rows and input wells.
pub fn control_shadow() -> Shadow {
    if !depth_enabled() {
        return Shadow::NONE;
    }
    Shadow {
        offset: [0, 6],
        blur: 16,
        spread: 0,
        color: Color32::from_black_alpha(32),
    }
}

/// Consistent elevated card used by main dashboard surfaces.
pub fn elevated_frame(fill: Color32, radius: u8) -> super::motion::DepthFrame {
    super::motion::DepthFrame::new(
        Frame::new()
            .fill(fill)
            .stroke(Stroke::new(1.0, colors::border().gamma_multiply(0.82)))
            .corner_radius(radius)
            .shadow(card_shadow()),
        radius,
    )
}

fn floating_shadow() -> Shadow {
    if !depth_enabled() {
        return Shadow::NONE;
    }
    Shadow {
        offset: [0, 10],
        blur: 34,
        spread: 0,
        color: Color32::from_black_alpha(28),
    }
}

#[cfg(test)]
pub(crate) fn luminance(color: Color32) -> f32 {
    let linear = |v: u8| {
        let v = f32::from(v) / 255.0;
        if v <= 0.04045 {
            v / 12.92
        } else {
            ((v + 0.055) / 1.055).powf(2.4)
        }
    };
    0.2126 * linear(color.r()) + 0.7152 * linear(color.g()) + 0.0722 * linear(color.b())
}

/// Mixes two colors for short hover and selection animations.
pub fn mix(a: Color32, b: Color32, amount: f32) -> Color32 {
    let amount = amount.clamp(0.0, 1.0);
    let channel =
        |from: u8, to: u8| (from as f32 + (to as f32 - from as f32) * amount).round() as u8;
    Color32::from_rgba_premultiplied(
        channel(a.r(), b.r()),
        channel(a.g(), b.g()),
        channel(a.b(), b.b()),
        channel(a.a(), b.a()),
    )
}
