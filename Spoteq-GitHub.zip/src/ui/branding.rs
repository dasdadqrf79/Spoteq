//! Spoteq brand assets shared by the native window and egui interface.

use eframe::egui::{self, ColorImage, IconData, TextureHandle, TextureOptions};
use image::imageops::FilterType;

const LOGO_BYTES: &[u8] = include_bytes!("../../assets/branding/spoteq-logo.png");

/// Decodes the bundled Spoteq logo for the native application window.
pub fn app_icon() -> Option<IconData> {
    let image = brand_mark_image()?;
    let (width, height) = image.dimensions();
    Some(IconData {
        rgba: image.into_raw(),
        width,
        height,
    })
}

/// Returns the compact symbol used beside the application name.
pub fn mark_texture(context: &egui::Context) -> Option<TextureHandle> {
    let texture_id = egui::Id::new("spoteq-brand-mark");
    if let Some(texture) = context.data(|data| data.get_temp::<TextureHandle>(texture_id)) {
        return Some(texture);
    }

    let image = brand_mark_image()?;
    let size = [image.width() as usize, image.height() as usize];
    let color_image = ColorImage::from_rgba_unmultiplied(size, image.as_raw());
    let texture = context.load_texture("spoteq-brand-mark", color_image, TextureOptions::LINEAR);
    context.data_mut(|data| data.insert_temp(texture_id, texture.clone()));
    Some(texture)
}

/// Returns a cached egui texture containing the bundled Spoteq logo.
pub fn logo_texture(context: &egui::Context) -> Option<TextureHandle> {
    let texture_id = egui::Id::new("spoteq-brand-logo");
    if let Some(texture) = context.data(|data| data.get_temp::<TextureHandle>(texture_id)) {
        return Some(texture);
    }

    let image = image::load_from_memory(LOGO_BYTES).ok()?.into_rgba8();
    let size = [image.width() as usize, image.height() as usize];
    let color_image = ColorImage::from_rgba_unmultiplied(size, image.as_raw());
    let texture = context.load_texture("spoteq-brand-logo", color_image, TextureOptions::LINEAR);
    context.data_mut(|data| data.insert_temp(texture_id, texture.clone()));
    Some(texture)
}

fn brand_mark_image() -> Option<image::RgbaImage> {
    let image = image::load_from_memory(LOGO_BYTES).ok()?;
    let crop_size = image.width().min(image.height()).saturating_mul(7) / 10;
    let left = image.width().saturating_sub(crop_size) / 2;
    let top = image.height().saturating_mul(7) / 100;
    Some(
        image
            .crop_imm(left, top, crop_size, crop_size)
            .resize_exact(256, 256, FilterType::Lanczos3)
            .into_rgba8(),
    )
}
