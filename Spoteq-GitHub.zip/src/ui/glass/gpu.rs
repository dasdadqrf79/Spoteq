//! Samples the actual framebuffer underneath each glass surface, not a painted imitation.
use eframe::{
    egui::{self, Id, Rect, Shape, Ui},
    glow::{self, HasContext},
};
use std::sync::{Arc, Mutex};

const VERTEX: &str = r#"#version 140
uniform vec4 u_rect;
uniform vec2 u_screen;
out vec2 v_local;
void main() {
    vec2 p[6] = vec2[6](vec2(0,0),vec2(1,0),vec2(0,1),vec2(0,1),vec2(1,0),vec2(1,1));
    v_local = p[gl_VertexID] * u_rect.zw;
    vec2 pixel = u_rect.xy + v_local;
    gl_Position = vec4(pixel / u_screen * 2.0 - 1.0, 0.0, 1.0);
}"#;

const FRAGMENT: &str = r#"#version 140
uniform sampler2D u_scene;
uniform vec4 u_rect;
uniform vec4 u_copy;
uniform vec2 u_screen;
uniform float u_radius;
uniform float u_clarity;
uniform float u_hot;
uniform float u_thumb;
uniform float u_frost;
uniform float u_dark;
in vec2 v_local;
out vec4 out_color;

float distanceToGlass(vec2 p) {
    vec2 q = abs(p - u_rect.zw * 0.5) - u_rect.zw * 0.5 + u_radius;
    return length(max(q,0.0)) + min(max(q.x,q.y),0.0) - u_radius;
}
vec3 readScene(vec2 p) {
    return texture(u_scene, clamp(p, u_copy.xy + vec2(1.0), u_copy.zw - vec2(1.0)) / u_screen).rgb;
}
void main() {
    float sd = distanceToGlass(v_local);
    float coverage = 1.0 - smoothstep(-0.8,0.8,sd);
    if (coverage <= 0.0) discard;
    vec2 normal = normalize(vec2(distanceToGlass(v_local+vec2(0.7,0.0))-distanceToGlass(v_local-vec2(0.7,0.0)),
        distanceToGlass(v_local+vec2(0.0,0.7))-distanceToGlass(v_local-vec2(0.0,0.7))) + vec2(0.00001));
    float thickness = mix(2.0,min(12.0,max(3.0,u_radius*0.48)),u_thumb);
    float edge = exp(-max(-sd,0.0)/thickness);
    vec2 lens = normal * edge * (3.0 + u_radius*0.20 + u_hot*1.4)*mix(0.35,1.0,u_thumb);
    vec2 center = u_rect.zw*0.5;
    vec2 local = center + (v_local-center)/(1.0 + u_thumb*(0.10+u_hot*0.05));
    vec2 pixel = u_rect.xy + local + lens;
    float blur = mix(2.2,0.35,u_clarity) * (1.0-u_thumb*0.7);
    vec3 scene = readScene(pixel)*0.5;
    scene += (readScene(pixel+vec2(blur,0.0))+readScene(pixel-vec2(blur,0.0))
        +readScene(pixel+vec2(0.0,blur))+readScene(pixel-vec2(0.0,blur)))*0.125;
    if (u_frost > 0.5) {
        scene = vec3(0.0);
        float weights = 0.0;
        for (int y=-3; y<=3; ++y) {
            for (int x=-3; x<=3; ++x) {
                vec2 offset = vec2(float(x),float(y));
                float weight = exp(-dot(offset,offset)/7.0);
                scene += readScene(pixel+offset*5.5)*weight;
                weights += weight;
            }
        }
        scene = mix(scene/weights,mix(vec3(0.98,0.99,1.0),vec3(0.04,0.07,0.12),u_dark),mix(0.35,0.20,u_dark));
    }
    // A tiny spectral split at the rounded edge, while the center remains clear.
    scene.r = mix(scene.r,readScene(pixel+lens*0.10).r,edge*0.35);
    scene.b = mix(scene.b,readScene(pixel-lens*0.10).b,edge*0.35);
    float veil = mix(0.28,0.02,u_clarity);
    vec3 color = mix(mix(scene,vec3(1.0),veil),scene*(1.0-mix(0.24,0.015,u_clarity)),u_dark);
    float light = max(dot(normal,normalize(vec2(-0.55,0.85))),0.0);
    float rim = exp(-abs(sd+1.0)*1.6);
    color -= vec3(0.025)*rim*(1.0-u_thumb*0.5);
    color += vec3(0.94,0.98,1.0)*rim*mix(0.025+0.10*pow(light,2.0),0.10+0.34*pow(light,2.0),u_thumb);
    color += vec3(0.65,0.82,1.0)*edge*0.012;
    color += vec3(u_thumb*0.055+u_hot*0.008);
    out_color = vec4(clamp(color,0.0,1.0)*coverage,coverage);
}"#;

struct Renderer {
    program: glow::Program,
    vao: glow::VertexArray,
    scene: glow::Texture,
    size: [i32; 2],
}

impl Renderer {
    // All GL calls occur on egui_glow's rendering thread with its context current.
    unsafe fn new(gl: &glow::Context) -> Result<Self, String> {
        unsafe {
            let program = gl.create_program()?;
            let mut shaders = Vec::new();
            for (kind, source) in [
                (glow::VERTEX_SHADER, VERTEX),
                (glow::FRAGMENT_SHADER, FRAGMENT),
            ] {
                let shader = gl.create_shader(kind)?;
                gl.shader_source(shader, source);
                gl.compile_shader(shader);
                if !gl.get_shader_compile_status(shader) {
                    let error = gl.get_shader_info_log(shader);
                    gl.delete_shader(shader);
                    for shader in shaders {
                        gl.delete_shader(shader);
                    }
                    gl.delete_program(program);
                    return Err(error);
                }
                gl.attach_shader(program, shader);
                shaders.push(shader);
            }
            gl.link_program(program);
            for shader in shaders {
                gl.detach_shader(program, shader);
                gl.delete_shader(shader);
            }
            if !gl.get_program_link_status(program) {
                let error = gl.get_program_info_log(program);
                gl.delete_program(program);
                return Err(error);
            }
            let vao = gl.create_vertex_array()?;
            let scene = gl.create_texture()?;
            gl.bind_texture(glow::TEXTURE_2D, Some(scene));
            for (parameter, value) in [
                (glow::TEXTURE_MIN_FILTER, glow::LINEAR),
                (glow::TEXTURE_MAG_FILTER, glow::LINEAR),
                (glow::TEXTURE_WRAP_S, glow::CLAMP_TO_EDGE),
                (glow::TEXTURE_WRAP_T, glow::CLAMP_TO_EDGE),
            ] {
                gl.tex_parameter_i32(glow::TEXTURE_2D, parameter, value as i32);
            }
            Ok(Self {
                program,
                vao,
                scene,
                size: [0, 0],
            })
        }
    }

    unsafe fn paint(
        &mut self,
        gl: &glow::Context,
        info: &egui::PaintCallbackInfo,
        radius: f32,
        clarity: f32,
        hot: f32,
        thumb: bool,
        frosted: bool,
        dark: bool,
    ) {
        unsafe {
            let size = [info.screen_size_px[0] as i32, info.screen_size_px[1] as i32];
            if size[0] <= 0 || size[1] <= 0 {
                return;
            }
            gl.active_texture(glow::TEXTURE0);
            gl.bind_texture(glow::TEXTURE_2D, Some(self.scene));
            if self.size != size {
                gl.tex_image_2d(
                    glow::TEXTURE_2D,
                    0,
                    glow::RGBA8 as i32,
                    size[0],
                    size[1],
                    0,
                    glow::RGBA,
                    glow::UNSIGNED_BYTE,
                    glow::PixelUnpackData::Slice(None),
                );
                self.size = size;
            }
            let scale = info.pixels_per_point;
            let rect = [
                info.viewport.left() * scale,
                size[1] as f32 - info.viewport.bottom() * scale,
                info.viewport.width() * scale,
                info.viewport.height() * scale,
            ];
            let margin = (radius * scale * 0.5 + 20.0).ceil() as i32;
            let x = (rect[0].floor() as i32 - margin).clamp(0, size[0]);
            let y = (rect[1].floor() as i32 - margin).clamp(0, size[1]);
            let right = ((rect[0] + rect[2]).ceil() as i32 + margin).clamp(x, size[0]);
            let top = ((rect[1] + rect[3]).ceil() as i32 + margin).clamp(y, size[1]);
            if right - x < 2 || top - y < 2 {
                return;
            }
            gl.copy_tex_sub_image_2d(glow::TEXTURE_2D, 0, x, y, x, y, right - x, top - y);
            gl.viewport(0, 0, size[0], size[1]);
            gl.use_program(Some(self.program));
            gl.bind_vertex_array(Some(self.vao));
            let location = |name| gl.get_uniform_location(self.program, name);
            gl.uniform_1_i32(location("u_scene").as_ref(), 0);
            gl.uniform_2_f32(
                location("u_screen").as_ref(),
                size[0] as f32,
                size[1] as f32,
            );
            gl.uniform_4_f32(
                location("u_rect").as_ref(),
                rect[0],
                rect[1],
                rect[2],
                rect[3],
            );
            gl.uniform_4_f32(
                location("u_copy").as_ref(),
                x as f32,
                y as f32,
                right as f32,
                top as f32,
            );
            gl.uniform_1_f32(
                location("u_radius").as_ref(),
                radius
                    .min(info.viewport.width() * 0.5)
                    .min(info.viewport.height() * 0.5)
                    * scale,
            );
            gl.uniform_1_f32(location("u_clarity").as_ref(), clarity.clamp(0.0, 1.0));
            gl.uniform_1_f32(location("u_hot").as_ref(), hot.clamp(0.0, 1.0));
            gl.uniform_1_f32(location("u_thumb").as_ref(), if thumb { 1.0 } else { 0.0 });
            gl.uniform_1_f32(
                location("u_frost").as_ref(),
                if frosted { 1.0 } else { 0.0 },
            );
            gl.uniform_1_f32(location("u_dark").as_ref(), if dark { 1.0 } else { 0.0 });
            gl.draw_arrays(glow::TRIANGLES, 0, 6);
            // egui_glow restores its viewport, blend state, program and VAO after the callback.
        }
    }
}

// Resource lifetime follows the shared OpenGL context; all viewports use the same egui_glow painter.
type State = Arc<Mutex<Option<Result<Renderer, String>>>>;

#[cfg(test)]
pub(super) fn validate(ctx: &egui::Context) -> Result<(), String> {
    let state = ctx
        .data(|d| d.get_temp::<State>(Id::new("clear-glass-renderer")))
        .ok_or_else(|| "glass renderer was never created".to_owned())?;
    let state = state
        .lock()
        .map_err(|_| "glass renderer lock was poisoned".to_owned())?;
    match state.as_ref() {
        Some(Ok(_)) => Ok(()),
        Some(Err(error)) => Err(error.clone()),
        None => Err("glass callbacks were never painted".to_owned()),
    }
}

pub fn surface(ui: &Ui, rect: Rect, radius: f32, hot: f32, thumb: bool) -> Shape {
    surface_context(ui.ctx(), rect, radius, hot, thumb, false)
}

pub fn frosted(ctx: &egui::Context, rect: Rect, radius: f32) -> Shape {
    surface_context(ctx, rect, radius, 0.0, false, true)
}

fn surface_context(
    ctx: &egui::Context,
    rect: Rect,
    radius: f32,
    hot: f32,
    thumb: bool,
    frosted: bool,
) -> Shape {
    if !rect.is_positive() || !rect.is_finite() {
        return Shape::Noop;
    }
    let id = Id::new("clear-glass-renderer");
    let state = ctx.data_mut(|d| {
        d.get_temp::<State>(id).unwrap_or_else(|| {
            let state = Arc::new(Mutex::new(None));
            d.insert_temp(id, state.clone());
            state
        })
    });
    let clarity = super::super::motion::transparency(ctx);
    let dark = super::super::theme::is_dark();
    Shape::Callback(egui::PaintCallback {
        rect,
        callback: Arc::new(eframe::egui_glow::CallbackFn::new(move |info, painter| {
            let Ok(mut state) = state.lock() else {
                return;
            };
            if state.is_none() {
                let result = unsafe { Renderer::new(painter.gl()) };
                if let Err(error) = &result {
                    tracing::error!(%error,"Clear-glass renderer initialization failed");
                }
                *state = Some(result);
            }
            if let Some(Ok(renderer)) = state.as_mut() {
                unsafe {
                    renderer.paint(
                        painter.gl(),
                        &info,
                        radius,
                        clarity,
                        hot,
                        thumb,
                        frosted,
                        dark,
                    );
                }
            }
        })),
    })
}
