//! UI-only translation. Provider metadata, settings keys and network requests stay untouched.
use crate::settings::Language;
use std::{borrow::Cow, cell::Cell};

thread_local! { static LANGUAGE: Cell<Language> = const { Cell::new(Language::Russian) }; }

pub fn set_language(language: Language) {
    LANGUAGE.set(language);
}

pub fn tr(text: &str) -> Cow<'_, str> {
    if LANGUAGE.get() == Language::English {
        return Cow::Borrowed(text);
    }
    let translated = match text {
        "Language" => "Язык",
        "Glass transparency" => "Прозрачность стекла",
        "Drag to choose how clearly content shows through the glass." => {
            "Перетащите ползунок: чем правее, тем прозрачнее стекло."
        }
        "Find music across Spotify and SoundCloud." => "Ищите музыку в Spotify и SoundCloud.",
        "A Vibe is a saved snapshot of the current track, your upcoming queue, and Radio/Autoplay recommendations. Save one from Queue → Save current Vibe." => {
            "Подборка сохраняет текущий трек, очередь и рекомендации радио. Чтобы создать её, откройте Очередь → Сохранить текущую подборку."
        }
        "Direct playback is local and requires Spotify Premium." => {
            "Для встроенного воспроизведения нужен Spotify Premium."
        }
        "OAuth 2.1 + PKCE · Search, Library and native playback" => {
            "OAuth 2.1 + PKCE · Поиск, медиатека и встроенный плеер"
        }
        "OAuth · Playback ready" => "OAuth · Воспроизведение доступно",
        "OAuth · Playback unavailable" => "OAuth · Воспроизведение недоступно",
        "Open Spotify authorization" => "Открыть вход в Spotify",
        "Restoring Spotify session" => "Восстанавливаем сеанс Spotify",
        "Spotify Client ID" => "ID приложения Spotify",
        "Spotify account" => "Аккаунт Spotify",
        "Reconnect SoundCloud" => "Переподключить SoundCloud",
        "Like on SoundCloud" => "В избранное SoundCloud",
        "Unlike on SoundCloud" => "Убрать из избранного SoundCloud",
        "Save to Spotify Liked Songs" => "Добавить в любимые треки Spotify",
        "Remove from Spotify Liked Songs" => "Убрать из любимых треков Spotify",
        "Recently Played" => "Недавно прослушано",
        "Tracks played on this device, stored locally in Spoteq." => {
            "История прослушиваний на этом устройстве хранится локально."
        }
        "Spoteq applies equalization to the active local Spotify or SoundCloud output." => {
            "Spoteq обрабатывает звук встроенного плеера Spotify или SoundCloud."
        }
        "SoundCloud is not connected; showing Spotify Liked Songs only." => {
            "SoundCloud не подключён. Показаны любимые треки Spotify."
        }
        "Spotify is not connected; showing SoundCloud Likes only." => {
            "Spotify не подключён. Показаны любимые треки SoundCloud."
        }
        "Spotify limits access to public playlist contents; showing playable tracks matching the query." => {
            "Spotify ограничивает доступ к публичным плейлистам. Показаны доступные треки по вашему запросу."
        }
        "Recently liked" => "Недавно добавленные",
        "Most played" => "Часто слушаете",
        "Never skipped" => "Без пропусков",
        "Night" => "Ночное",
        "Discovery" => "Открытия",
        "Spotify + SoundCloud mix" => "Микс Spotify и SoundCloud",
        "Choose the interface language. Changes apply immediately." => {
            "Выберите язык интерфейса. Изменения применяются сразу."
        }
        "Search" => "Поиск",
        "Liked Songs" => "Любимые треки",
        "Settings" => "Настройки",
        "General" => "Основные",
        "Playback" => "Воспроизведение",
        "Audio" => "Звук",
        "Appearance" => "Оформление",
        "Light theme" => "Светлая",
        "Dark theme" => "Тёмная",
        "Switch between light and dark appearance." => {
            "Переключайтесь между светлой и тёмной темой. Выбор сохраняется автоматически."
        }
        "Accounts" => "Аккаунты",
        "About" => "О приложении",
        "Bass Studio" => "Бас-студия",
        "SPOTEQ / Bass Studio" => "SPOTEQ / Бас-студия",
        "Premium player" => "Музыкальный плеер",
        "Equalizer" => "Эквалайзер",
        "Audio & Equalizer" => "Звук и эквалайзер",
        "Queue" => "Очередь",
        "On" | "ON" => "Вкл.",
        "Off" | "OFF" => "Выкл.",
        "Enabled" => "Включено",
        "Disabled" => "Выключено",
        "EQ ON" => "Эквалайзер вкл.",
        "EQ OFF" => "Эквалайзер выкл.",
        "Save" => "Сохранить",
        "Cancel" => "Отмена",
        "Close" => "Закрыть",
        "Clear" => "Очистить",
        "Reset" => "Сбросить",
        "Refresh" => "Обновить",
        "Try again" => "Повторить",
        "Play" => "Воспроизвести",
        "Pause" => "Пауза",
        "Previous" => "Предыдущий",
        "Next" => "Следующий",
        "Nothing playing" => "Ничего не играет",
        "Choose a track" => "Выберите трек",
        "Open queue" => "Открыть очередь",
        "Volume" => "Громкость",
        "Shuffle" => "Перемешать",
        "Repeat off" => "Без повтора",
        "Repeat queue" => "Повтор очереди",
        "Repeat track" => "Повтор трека",
        "All" => "Все",
        "Tracks" => "Треки",
        "Artists" => "Исполнители",
        "Albums" => "Альбомы",
        "Playlists" => "Плейлисты",
        "Play now" => "Воспроизвести",
        "Play next" => "Играть следующим",
        "Add to queue" => "В очередь",
        "Like" => "В избранное",
        "Unlike" => "Убрать из избранного",
        "More" => "Ещё",
        "Browse album" => "Открыть альбом",
        "Browse artist" => "Открыть исполнителя",
        "Find in playlists" => "Найти в плейлистах",
        "Start Radio from track" => "Радио по треку",
        "Start Radio from artist" => "Радио по исполнителю",
        "Find tracks from Spotify and SoundCloud." => "Ищите треки в Spotify и SoundCloud.",
        "Search tracks and artists" => "Поиск треков и исполнителей",
        "Most relevant" => "По соответствию",
        "Search results are ordered by provider relevance" => {
            "Порядок результатов определяет музыкальный сервис"
        }
        "Recent searches" => "Недавние запросы",
        "Recently selected tracks" => "Недавно выбранные треки",
        "Clear searches" => "Очистить запросы",
        "Clear tracks" => "Очистить треки",
        "Search again" => "Повторить поиск",
        "Start searching" => "Начните поиск",
        "Search failed" => "Ошибка поиска",
        "Nothing found" => "Ничего не найдено",
        "Searching connected services…" => "Поиск в подключённых сервисах…",
        "Loading more results…" => "Загрузка результатов…",
        "Connect a music service" => "Подключите музыкальный сервис",
        "Open Settings > Accounts to connect Spotify or SoundCloud." => {
            "Откройте Настройки → Аккаунты и подключите Spotify или SoundCloud."
        }
        "Spotify account required" => "Нужен аккаунт Spotify",
        "SoundCloud account required" => "Нужен аккаунт SoundCloud",
        "Connect Spotify from Settings > Accounts." => {
            "Подключите Spotify в Настройках → Аккаунты."
        }
        "Connect SoundCloud from Settings > Accounts." => {
            "Подключите SoundCloud в Настройках → Аккаунты."
        }
        "Finish authorization in your browser." => "Завершите вход в браузере.",
        "Checking the saved Spotify session…" => "Проверяем сохранённый сеанс Spotify…",
        "SoundCloud is not connected; showing Spotify results only." => {
            "SoundCloud не подключён. Показаны результаты Spotify."
        }
        "Spotify is not connected; showing SoundCloud results only." => {
            "Spotify не подключён. Показаны результаты SoundCloud."
        }
        "Reconnect this track's music service before playback" => {
            "Для воспроизведения подключите сервис этого трека"
        }
        "Your favorite tracks from Spotify and SoundCloud, all in one place." => {
            "Любимые треки из Spotify и SoundCloud в одном месте."
        }
        "Search in your liked songs..." => "Поиск в любимых треках…",
        "Loading liked tracks…" => "Загрузка любимых треков…",
        "Loading more liked tracks…" => "Загрузка следующих треков…",
        "Could not load Liked Songs" => "Не удалось загрузить любимые треки",
        "Your library is empty" => "Ваша медиатека пуста",
        "Tracks liked in the selected service will appear here." => {
            "Здесь появятся любимые треки из выбранного сервиса."
        }
        "Open Settings > Accounts to load your real liked tracks." => {
            "Подключите сервис в Настройках → Аккаунты, чтобы загрузить любимые треки."
        }
        "Scroll paused after a loading error. Use Refresh to retry." => {
            "Загрузка остановлена из-за ошибки. Нажмите «Обновить»."
        }
        "Connect Spotify to load your real Liked Songs." => {
            "Подключите Spotify, чтобы загрузить любимые треки."
        }
        "Connect SoundCloud to load your real Liked Songs." => {
            "Подключите SoundCloud, чтобы загрузить любимые треки."
        }
        "Precision low-frequency control · 20–250 Hz" => {
            "Точная настройка низких частот · 20–250 Гц"
        }
        "A · Processed" => "A · С обработкой",
        "B · Bypass" => "B · Без обработки",
        "Global EQ is bypassed. Enable it to hear Bass Studio." => {
            "Эквалайзер выключен. Включите его, чтобы услышать обработку баса."
        }
        "Enable global EQ" => "Включить эквалайзер",
        "Frequency bands" => "Частотные полосы",
        "Infra" => "Инфрабас",
        "Sub" => "Саб-бас",
        "Punch" => "Удар",
        "Body" => "Плотность",
        "Warmth" => "Теплота",
        "20–35 Hz · vibration" => "20–35 Гц · вибрация",
        "35–60 Hz · foundation" => "35–60 Гц · основа",
        "60–100 Hz · impact" => "60–100 Гц · удар",
        "100–160 Hz · density" => "100–160 Гц · плотность",
        "160–250 Hz · warmth" => "160–250 Гц · теплота",
        "Gain" => "Усиление",
        "Frequency" => "Частота",
        "Type" => "Тип",
        "Width (Q)" => "Ширина (Q)",
        "Advanced" => "Дополнительно",
        "Bell" => "Колокол",
        "Low Shelf" => "НЧ-полка",
        "Reset band" => "Сброс полосы",
        "Reset Bass Studio" => "Сбросить бас-студию",
        "Sound character" => "Характер звука",
        "Reset character" => "Сбросить эффекты",
        "Start with Deep bass for more weight. Add Punch for a sharper kick." => {
            "Добавьте глубину для весомого баса и атаку для более чёткого удара."
        }
        "Deep bass" => "Глубокий бас",
        "Punch / attack" => "Панч / атака",
        "Saturation" => "Насыщение",
        "Density" => "Плотность баса",
        "Rumble cut" => "Убрать гул",
        "Dynamic bass" => "Динамический бас",
        "Stereo width" => "Ширина стерео",
        "More depth and weight below 40 Hz. 0 dB = original." => {
            "Глубина и вес ниже 40 Гц. 0 дБ — без изменений."
        }
        "Left: softer kick. Right: stronger attack. 0% = original." => {
            "Влево — мягче, вправо — резче удар. 0% — без изменений."
        }
        "Adds bass harmonics, from clean to gritty. 0% = off." => {
            "Гармоники баса: от чистого к насыщенному. 0% — выкл."
        }
        "Brings quiet bass forward and controls louder notes. 0% = off." => {
            "Делает тихий бас заметнее, а громкий — ровнее. 0% — выкл."
        }
        "Removes rumble below the selected frequency. Off, or 15–45 Hz." => {
            "Срезает гул ниже выбранной частоты. Выкл. или 15–45 Гц."
        }
        "Reduces bass during loud peaks to leave more headroom. 0% = off." => {
            "Умеряет бас на громких пиках. 0% — выкл."
        }
        "0% = mono, 100% = original, 150% = wider stereo." => {
            "0% — моно, 100% — исходное стерео, 150% — шире."
        }
        "Keep low bass centered" => "Низкий бас по центру",
        "Centers the low band with a gradual crossover around 180 Hz; higher frequencies remain stereo." => {
            "Собирает низкий бас по центру с плавным переходом около 180 Гц. Верхние частоты остаются стерео."
        }
        "EQ / depth / rumble response" => "Частотная характеристика",
        "Shows frequency bands, Deep bass and Rumble cut. Punch, dynamics, saturation, stereo width and global EQ are not plotted." => {
            "Показаны полосы, глубина баса и срез гула. Атака, динамика, насыщение, стерео и общий эквалайзер не отображаются."
        }
        "Headroom / clipping" => "Запас громкости / перегрузка",
        "Preamp (shared with EQ)" => "Предусиление (общее с эквалайзером)",
        "Limiter active / reduce Preamp" => "Работает лимитер — уменьшите предусиление",
        "Sample peaks before master volume; this is not a true-peak meter or spectrum analyzer." => {
            "Пики сигнала до общей громкости. Это не измеритель истинных пиков и не анализатор спектра."
        }
        "A/B switches Bass Studio only. Global EQ, legacy bass controls and preamp remain active." => {
            "A/B переключает только бас-студию. Общий эквалайзер, прежние настройки баса и предусиление остаются активны."
        }
        "Preamp" => "Предусиление",
        "Bass" => "Бас",
        "Sub bass" => "Саб-бас",
        "Bass frequency" => "Частота баса",
        "Bass Q" => "Добротность баса",
        "Output" => "Выход",
        "Output Device" | "Output device" => "Устройство вывода",
        "Output volume" => "Громкость вывода",
        "Default System Device" => "Системное устройство",
        "Tone & protection" => "Звучание и защита",
        "Limiter active" => "Лимитер работает",
        "Limiter standby" => "Лимитер в ожидании",
        "Limiter / clipping protection" => "Лимитер / защита от перегрузки",
        "Shape your sound. Feel the difference." => "Настройте звук по своему вкусу.",
        "Your settings are saved automatically" => "Настройки сохраняются автоматически",
        "Drag the curve or its points to shape the sound. Double-click a point to reset it." => {
            "Перетаскивайте кривую или её точки. Двойной щелчок сбрасывает точку."
        }
        "Customize Spoteq to your preferences." => "Настройте Spoteq под себя.",
        "Choose a theme color for the interface and background." => {
            "Выберите цвет интерфейса и фона."
        }
        "Motion · smooth screens and interactive controls" => {
            "Плавные анимации экранов и элементов"
        }
        "3D depth · lit surfaces, raised buttons and shadows" => {
            "3D-объём: подсветка, выпуклые кнопки и тени"
        }
        "Liquid Glass · translucent surfaces and reflections" => {
            "Liquid Glass · стеклянные панели, блики и отражения"
        }
        "Depth effects · ambient glow and panel shadows" => "Свечение и тени панелей",
        "Control how music continues when your queue ends." => {
            "Настройте воспроизведение после окончания очереди."
        }
        "Autoplay similar tracks" => "Автовоспроизведение похожих треков",
        "Keep 5–10 real recommendations ready from Spotify and SoundCloud." => {
            "Подготавливать 5–10 рекомендаций из Spotify и SoundCloud."
        }
        "Shuffle future queue" => "Перемешивать очередь",
        "Keeps the current track fixed and leaves Autoplay separate." => {
            "Текущий трек не меняется. Автовоспроизведение остаётся отдельным."
        }
        "Repeat mode" => "Повтор",
        "Track transitions" => "Переходы между треками",
        "Crossfade between tracks" => "Плавный переход между треками",
        "Smoothly fade the current track out while the next track fades in." => {
            "Плавно уменьшать громкость текущего трека и увеличивать громкость следующего."
        }
        "Crossfade duration" => "Длительность перехода",
        "Crossfade is disabled. Tracks switch without overlap." => {
            "Плавный переход выключен. Треки не перекрываются."
        }
        "Gapless transitions" => "Воспроизведение без пауз",
        "Preload the next track so natural track boundaries switch with minimal silence." => {
            "Заранее загружать следующий трек, сокращая тишину между треками."
        }
        "Pause / Resume fade" => "Плавная пауза и возобновление",
        "Pause / Resume fade duration" => "Длительность затухания",
        "Smooth volume ramp when pausing or resuming playback." => {
            "Плавно менять громкость при паузе и продолжении воспроизведения."
        }
        "Configure audio and playback settings." => "Настройки звука и воспроизведения.",
        "Manage equalizer behavior." => "Настройки эквалайзера.",
        "Open full Equalizer" => "Открыть эквалайзер",
        "Enable EQ on startup" => "Включать эквалайзер при запуске",
        "Save EQ settings automatically" => "Автоматически сохранять эквалайзер",
        "Reset EQ to default" => "Сбросить эквалайзер",
        "Applied instantly and saved automatically." => {
            "Применяется сразу и сохраняется автоматически."
        }
        "A unified music experience with a real-time equalizer." => {
            "Музыка из разных сервисов и эквалайзер в реальном времени."
        }
        "Native playback and DSP" => "Встроенное воспроизведение и обработка звука",
        "Data" => "Данные",
        "Local settings" => "Локальные настройки",
        "Default" => "Стандартный",
        "Green" => "Зелёный",
        "Lime" => "Лайм",
        "Cyan" => "Бирюзовый",
        "Blue" => "Синий",
        "Violet" => "Фиолетовый",
        "Pink" => "Розовый",
        "Red" => "Красный",
        "Orange" => "Оранжевый",
        "Gold" => "Золотой",
        "Connect your music services and enjoy everything in one place." => {
            "Подключите музыкальные сервисы и слушайте всё в одном месте."
        }
        "Connect both services to get the most out of Spoteq." => {
            "Подключите оба сервиса, чтобы использовать все возможности Spoteq."
        }
        "Search, liked songs and playback stay available from both Spotify and SoundCloud." => {
            "Поиск, любимые треки и воспроизведение из Spotify и SoundCloud."
        }
        "Existing Web API and direct local playback" => {
            "Подключение через API и встроенное воспроизведение"
        }
        "Connected" => "Подключено",
        "Not connected" => "Не подключено",
        "Connecting" => "Подключение",
        "Restoring" => "Восстановление",
        "Authorizing" => "Авторизация",
        "Available" => "Доступно",
        "Unavailable" => "Недоступно",
        "Checking token" => "Проверка доступа",
        "Waiting for browser" => "Ожидание браузера",
        "Needs attention" => "Требуется внимание",
        "Authentication error" => "Ошибка входа",
        "Authentication failed" => "Не удалось войти",
        "Authorization required" => "Необходимо войти",
        "Connect Spotify" => "Подключить Spotify",
        "Connect SoundCloud" => "Подключить SoundCloud",
        "Disconnect" => "Отключить",
        "Reconnect" => "Подключить заново",
        "Playing locally" => "Воспроизводится",
        "Paused" => "На паузе",
        "Playback error" => "Ошибка воспроизведения",
        "API error" => "Ошибка API",
        "Ready" => "Готово",
        "Waiting" => "Ожидание",
        "Loading" => "Загрузка",
        "Not configured" => "Не настроено",
        "Token present" => "Доступ сохранён",
        "Complete login in Edge/Chrome" => "Завершите вход в браузере",
        "CONNECTED ACCOUNT" => "ПОДКЛЮЧЁННЫЙ АККАУНТ",
        "Copy" => "Копировать",
        "Client ID" => "ID приложения",
        "Finish authorization in your browser" => "Завершите вход в браузере",
        "Log out from this app" => "Выйти из аккаунта",
        "Redirect URI to register" => "Адрес перенаправления для регистрации",
        "Listening History" => "История прослушивания",
        "No listening history yet" => "История пока пуста",
        "Played tracks will appear here automatically." => {
            "Прослушанные треки появятся здесь автоматически."
        }
        "Today" => "Сегодня",
        "Yesterday" => "Вчера",
        "Earlier" => "Раньше",
        "Play this track again" => "Послушать снова",
        "Resume" => "Продолжить",
        "Resume session" => "Продолжить прослушивание",
        "Close Mini Player" => "Закрыть мини-плеер",
        "Now Playing" => "Сейчас играет",
        "Next Up" => "Далее",
        "No user tracks queued" => "Очередь пуста",
        "Autoplay" => "Автовоспроизведение",
        "Radio" => "Радио",
        "Start Radio" => "Включить радио",
        "Remove from queue" => "Убрать из очереди",
        "Confirm clear" => "Подтвердить очистку",
        "Name" => "Название",
        "Save current Vibe" => "Сохранить текущую подборку",
        "Save Vibe" => "Сохранить подборку",
        "Play Vibe restores this queue and starts its first track." => {
            "Восстанавливает очередь и запускает первый трек."
        }
        "Radio recommendations are loading" => "Загружаем рекомендации радио",
        "Recommendations will appear near queue end" => {
            "Рекомендации появятся ближе к концу очереди"
        }
        "Library" => "Медиатека",
        "Everything you return to." => "Всё, к чему вы возвращаетесь.",
        "Smart Playlists" => "Умные плейлисты",
        "Saved Vibes" => "Сохранённые подборки",
        "Made from your listening" => "На основе ваших прослушиваний",
        "Not enough listening data yet" => "Пока недостаточно прослушиваний",
        "Play and like more tracks; this playlist updates automatically." => {
            "Слушайте музыку и добавляйте треки в избранное. Плейлист обновится сам."
        }
        "Preparing Smart Library" => "Подготовка медиатеки",
        "Recently played" => "Недавно прослушано",
        "Artist" => "Исполнитель",
        "Collection" => "Альбом",
        "Rename" => "Переименовать",
        "Rename Vibe" => "Переименовать подборку",
        "Delete" => "Удалить",
        "Restore this queue and play its first track" => {
            "Восстановить очередь и включить первый трек"
        }
        "Start Radio from Vibe" => "Радио по подборке",
        " ms" => " мс",
        " s" => " с",
        " Hz" => " Гц",
        " dB" => " дБ",
        _ => return dynamic(text),
    };
    Cow::Borrowed(translated)
}

fn dynamic(text: &str) -> Cow<'_, str> {
    if let Some(count) = text
        .strip_prefix("About ")
        .and_then(|v| v.strip_suffix(" results"))
    {
        return Cow::Owned(format!("Примерно {count} результатов"));
    }
    // Translate the UI framing, never names returned by a music provider.
    for (prefix, russian) in [
        ("Connected as ", "Вы вошли как "),
        ("Before limiter: ", "До лимитера: "),
        ("DSP output: ", "После обработки: "),
        ("About ", "Примерно "),
        ("Use ", "Выбрать: "),
        (
            "No playable tracks match ",
            "Нет доступных треков по запросу ",
        ),
    ] {
        if let Some(value) = text.strip_prefix(prefix) {
            let value = value.strip_suffix(" accent").unwrap_or(value);
            return Cow::Owned(format!("{russian}{value}"));
        }
    }
    for (suffix, russian) in [
        (" results", "результатов"),
        (" tracks", "треков"),
        (" dB", "дБ"),
        (" Hz", "Гц"),
        (" ms", "мс"),
    ] {
        if let Some(value) = text.strip_suffix(suffix) {
            return Cow::Owned(format!("{value} {russian}"));
        }
    }
    Cow::Borrowed(text)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn language_switches_immediately_and_keeps_provider_names_and_unknown_text() {
        set_language(Language::Russian);
        assert_eq!(tr("Settings"), "Настройки");
        assert_eq!(tr("Deep bass"), "Глубокий бас");
        assert_eq!(tr("Spotify"), "Spotify");
        assert_eq!(tr("An unknown track title"), "An unknown track title");
        set_language(Language::English);
        assert_eq!(tr("Settings"), "Settings");
        assert_eq!(tr("Deep bass"), "Deep bass");
        set_language(Language::Russian);
    }

    #[test]
    fn language_is_restored_from_disk_and_old_settings_default_to_russian() {
        use crate::settings::{AppSettings, SettingsStore};
        let mut previous = AppSettings::default();
        previous.audio.bass_studio.tone.depth_db = 4.5;
        let mut json = serde_json::to_value(&previous).unwrap();
        json["appearance"]
            .as_object_mut()
            .unwrap()
            .remove("language");
        let migrated: AppSettings = serde_json::from_value(json).unwrap();
        assert_eq!(migrated.appearance.language, Language::Russian);
        assert_eq!(migrated.audio, previous.audio);
        let directory = tempfile::tempdir().unwrap();
        let store = SettingsStore::from_path(directory.path().join("settings.json"));
        for language in [Language::English, Language::Russian] {
            previous.appearance.language = language;
            store.save_now(&previous).unwrap();
            assert_eq!(store.load().unwrap(), previous);
        }
    }
}
