//! A single draggable glass capsule shared by a group of destinations.
//! Selection follows the visible capsule, including while it is being dragged.
use super::{glass, motion, theme::colors};
use eframe::egui::{self, Color32, Pos2, Rect, Response, Sense, Shape, Stroke, Ui, Vec2};

#[derive(Clone, Copy)]
struct Body {
    center: Vec2,
    velocity: Vec2,
    size: Vec2,
    size_velocity: Vec2,
    last_time: f64,
    dragging: bool,
    grab: Vec2,
    origin: usize,
    destination: usize,
    published: usize,
    keyboard_focus: bool,
    layout_width: f32,
}

fn spring(position: &mut Vec2, velocity: &mut Vec2, target: Vec2, dt: f32, held: bool) {
    let steps = (dt / (1.0 / 240.0)).ceil().max(1.0) as usize;
    let h = dt / steps as f32;
    let (stiffness, damping) = if held { (1050.0, 53.0) } else { (520.0, 31.0) };
    for _ in 0..steps {
        *velocity += ((target - *position) * stiffness - *velocity * damping) * h;
        *position += *velocity * h;
    }
    if (*position - target).length() < 0.025 && velocity.length() < 0.1 {
        *position = target;
        *velocity = Vec2::ZERO;
    }
}

fn rubber(value: f32, min: f32, max: f32) -> f32 {
    let clamped = value.clamp(min, max);
    let overflow = value - clamped;
    clamped + overflow * 0.22 / (1.0 + overflow.abs() / 110.0)
}

pub fn text(
    ui: &mut Ui,
    salt: &str,
    selected: &mut usize,
    labels: &[String],
    min_width: f32,
    height: f32,
) -> Response {
    let font = egui::TextStyle::Button.resolve(ui.style());
    let widths: Vec<f32> = labels
        .iter()
        .map(|label| {
            (ui.painter()
                .layout_no_wrap(label.clone(), font.clone(), colors::text())
                .size()
                .x
                + 28.0)
                .max(min_width)
        })
        .collect();
    show(
        ui,
        salt,
        selected,
        labels,
        &widths,
        height,
        |ui, index, rect, active| {
            ui.painter().text(
                rect.center(),
                egui::Align2::CENTER_CENTER,
                &labels[index],
                font.clone(),
                if active {
                    colors::text()
                } else {
                    colors::text_muted()
                },
            );
        },
    )
}

pub fn show(
    ui: &mut Ui,
    salt: &str,
    selected: &mut usize,
    labels: &[String],
    widths: &[f32],
    height: f32,
    mut paint_label: impl FnMut(&Ui, usize, Rect, bool),
) -> Response {
    assert!(!widths.is_empty() && widths.len() == labels.len());
    let id = ui.make_persistent_id(salt);
    let previous = (*selected).min(widths.len() - 1);
    *selected = previous;
    let gap = 4.0;
    let available = ui.available_width().max(1.0);
    let mut positions = Vec::with_capacity(widths.len());
    let (mut x, mut y, mut right) = (0.0_f32, 0.0_f32, 0.0_f32);
    for width in widths {
        let width = width.min(available);
        if x > 0.0 && x + width > available + 0.1 {
            x = 0.0;
            y += height + gap;
        }
        positions.push(Rect::from_min_size(
            Pos2::new(x, y),
            Vec2::new(width, height),
        ));
        right = right.max(x + width);
        x += width + gap;
    }
    let (area, mut response) = ui.allocate_exact_size(Vec2::new(right, y + height), Sense::hover());
    let rects: Vec<Rect> = positions
        .iter()
        .map(|r| r.translate(area.min.to_vec2()))
        .collect();
    let now = ui.input(|i| i.time);
    let mut body = ui.ctx().data(|d| d.get_temp::<Body>(id)).unwrap_or(Body {
        center: positions[previous].center().to_vec2(),
        velocity: Vec2::ZERO,
        size: positions[previous].size(),
        size_velocity: Vec2::ZERO,
        last_time: now,
        dragging: false,
        grab: Vec2::ZERO,
        origin: previous,
        destination: previous,
        published: previous,
        keyboard_focus: false,
        layout_width: right,
    });
    // External navigation is authoritative; our own live updates keep the spring's target.
    if previous != body.published {
        body.destination = previous;
        body.center = positions[previous].center().to_vec2();
        body.velocity = Vec2::ZERO;
    }
    if (right - body.layout_width).abs() > 1.0 {
        body.center = positions[previous].center().to_vec2();
        body.velocity = Vec2::ZERO;
        body.size = positions[previous].size();
        body.size_velocity = Vec2::ZERO;
        body.dragging = false;
        body.layout_width = right;
        body.destination = previous;
    }
    let background = ui.painter().add(Shape::Noop);
    let items: Vec<Response> = rects
        .iter()
        .enumerate()
        .map(|(index, rect)| {
            let item = ui.interact(*rect, id.with(index), Sense::click_and_drag());
            item.widget_info(|| {
                egui::WidgetInfo::selected(
                    egui::WidgetType::SelectableLabel,
                    ui.is_enabled(),
                    index == previous,
                    labels[index].clone(),
                )
            });
            item
        })
        .collect();
    let pointer = ui.input(|i| i.pointer.interact_pos());
    let down = ui.input(|i| i.pointer.primary_down());
    let held = items.iter().position(|r| r.is_pointer_button_down_on());
    if !body.dragging && down {
        if let Some(index) = held {
            if ui.input(|i| i.pointer.any_pressed()) {
                body.grab = pointer.unwrap_or(rects[index].center()) - rects[index].center();
                body.origin = previous;
                body.keyboard_focus = false;
            }
            if items[index].drag_started() {
                body.dragging = true;
            }
        }
    }
    let was_dragging = body.dragging;
    let cancel = !ui.is_enabled()
        || !ui.input(|i| i.focused)
        || (body.dragging
            && ui.input_mut(|i| i.consume_key(egui::Modifiers::NONE, egui::Key::Escape)));
    if cancel {
        if body.dragging {
            body.destination = body.origin;
        }
        body.dragging = false;
    } else if body.dragging && !down {
        if let Some(p) = pointer.filter(|p| area.expand(16.0).contains(*p)) {
            body.destination = rects
                .iter()
                .enumerate()
                .min_by(|(_, a), (_, b)| {
                    a.distance_sq_to_pos(p).total_cmp(&b.distance_sq_to_pos(p))
                })
                .unwrap()
                .0;
            items[body.destination].request_focus();
        } else {
            body.destination = body.origin;
        }
        body.dragging = false;
    } else if !was_dragging {
        if let Some(index) = items.iter().position(|r| r.clicked()) {
            body.destination = index;
            items[index].request_focus();
        }
    }
    if let Some(focused) = items.iter().position(|r| ui.is_enabled() && r.has_focus()) {
        let key = ui.input_mut(|i| {
            [
                egui::Key::ArrowLeft,
                egui::Key::ArrowRight,
                egui::Key::Home,
                egui::Key::End,
                egui::Key::Enter,
                egui::Key::Space,
            ]
            .into_iter()
            .find(|key| i.consume_key(egui::Modifiers::NONE, *key))
        });
        if let Some(key) = key {
            body.destination = match key {
                egui::Key::ArrowLeft => focused.saturating_sub(1),
                egui::Key::ArrowRight => (focused + 1).min(items.len() - 1),
                egui::Key::Home => 0,
                egui::Key::End => items.len() - 1,
                _ => focused,
            };
            items[body.destination].request_focus();
            body.keyboard_focus = true;
            body.dragging = false;
        }
    }
    let mut target = positions[body.destination].center().to_vec2();
    let mut target_size = positions[body.destination].size();
    if body.dragging {
        if let Some(p) = pointer {
            let local = p - area.min - body.grab;
            let min = positions
                .iter()
                .map(|r| r.center().to_vec2())
                .fold(Vec2::splat(f32::INFINITY), Vec2::min);
            let max = positions
                .iter()
                .map(|r| r.center().to_vec2())
                .fold(Vec2::splat(f32::NEG_INFINITY), Vec2::max);
            target.x = rubber(local.x, min.x, max.x);
            target.y = rubber(local.y, min.y, max.y);
            target_size = positions[body.origin].size();
        }
    }
    let dt = ((now - body.last_time) as f32).clamp(0.0, 0.05);
    body.last_time = now;
    let animate = motion::enabled(ui.ctx());
    if animate {
        spring(
            &mut body.center,
            &mut body.velocity,
            target,
            dt,
            body.dragging,
        );
        let stretch = (body.velocity.x.abs() / 1600.0).min(0.20);
        let press = if body.dragging { 0.045 } else { 0.0 };
        target_size.x *= 1.0 + stretch + press;
        target_size.y *= 1.0 - stretch * 0.42 + press;
        spring(
            &mut body.size,
            &mut body.size_velocity,
            target_size,
            dt,
            body.dragging,
        );
    } else {
        body.center = target;
        body.size = target_size;
        body.velocity = Vec2::ZERO;
        body.size_velocity = Vec2::ZERO;
    }
    let capsule_center = area.min + body.center;
    *selected = rects
        .iter()
        .enumerate()
        .min_by(|(_, a), (_, b)| {
            a.distance_sq_to_pos(capsule_center)
                .total_cmp(&b.distance_sq_to_pos(capsule_center))
        })
        .unwrap()
        .0;
    body.published = *selected;
    let capsule = Rect::from_center_size(capsule_center, body.size.max(Vec2::splat(2.0)));
    let hot = if body.dragging {
        1.0
    } else if items.iter().any(|r| r.hovered()) {
        0.4
    } else {
        0.0
    };
    let radius = capsule.height() * 0.5;
    let mut shapes = vec![glass::outer_shadow(capsule, radius, 16)];
    if motion::glass_enabled(ui.ctx()) {
        shapes.push(glass::thumb(ui, capsule, hot));
    }
    shapes.push(Shape::rect_filled(
        capsule,
        radius,
        Color32::from_white_alpha(45),
    ));
    shapes.push(Shape::rect_stroke(
        capsule.shrink(0.5),
        radius,
        Stroke::new(0.8, colors::border()),
        egui::StrokeKind::Inside,
    ));
    ui.painter().set(background, Shape::Vec(shapes));
    // Labels and hit boxes stay fixed while the glass stretches underneath them.
    for (index, rect) in rects.iter().enumerate() {
        paint_label(ui, index, *rect, index == *selected);
        if body.keyboard_focus && items[index].has_focus() && index == *selected {
            ui.painter().rect_stroke(
                rect.shrink(1.0),
                height * 0.5,
                Stroke::new(1.2, colors::accent()),
                egui::StrokeKind::Inside,
            );
        }
    }
    if *selected != previous {
        response.mark_changed();
    }
    if animate
        && (body.dragging
            || body.velocity.length() > 0.1
            || body.size_velocity.length() > 0.1
            || (body.center - target).length() > 0.025
            || (body.size - target_size).length() > 0.025)
    {
        ui.ctx()
            .request_repaint_after(std::time::Duration::from_millis(8));
    }
    ui.ctx().data_mut(|d| d.insert_temp(id, body));
    #[cfg(test)]
    ui.ctx().data_mut(|d| {
        d.insert_temp(
            egui::Id::new(format!("segment-layout/{salt}")),
            (rects.clone(), capsule_center),
        );
        d.insert_temp(id.with("geometry"), rects);
    });
    response
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::settings::AppearanceSettings;

    struct Snapshot {
        body: Body,
        rects: Vec<Rect>,
        changed: bool,
    }
    fn frame(
        ctx: &egui::Context,
        time: f64,
        selected: &mut usize,
        events: Vec<egui::Event>,
    ) -> Snapshot {
        let mut result = None;
        let mut output = ctx.run_ui(
            egui::RawInput {
                screen_rect: Some(Rect::from_min_size(Pos2::ZERO, Vec2::new(800.0, 300.0))),
                time: Some(time),
                events,
                ..Default::default()
            },
            |ui| {
                let labels = vec!["All".into(), "Spotify".into(), "SoundCloud".into()];
                let id = ui.make_persistent_id("test-segments");
                let response = show(
                    ui,
                    "test-segments",
                    selected,
                    &labels,
                    &[100.0, 140.0, 160.0],
                    40.0,
                    |_, _, _, _| {},
                );
                result = Some(Snapshot {
                    body: ui.ctx().data(|d| d.get_temp::<Body>(id)).unwrap(),
                    rects: ui
                        .ctx()
                        .data(|d| d.get_temp::<Vec<Rect>>(id.with("geometry")))
                        .unwrap(),
                    changed: response.changed(),
                });
            },
        );
        output.textures_delta.clear();
        result.unwrap()
    }
    fn pointer(p: Pos2, pressed: bool) -> Vec<egui::Event> {
        vec![
            egui::Event::PointerMoved(p),
            egui::Event::PointerButton {
                pos: p,
                button: egui::PointerButton::Primary,
                pressed,
                modifiers: Default::default(),
            },
        ]
    }
    fn key(key: egui::Key) -> egui::Event {
        egui::Event::Key {
            key,
            physical_key: None,
            pressed: true,
            repeat: false,
            modifiers: Default::default(),
        }
    }
    fn context(motion_enabled: bool) -> egui::Context {
        let ctx = egui::Context::default();
        motion::configure(
            &ctx,
            &AppearanceSettings {
                motion_enabled,
                ..Default::default()
            },
        );
        ctx
    }

    #[test]
    fn selection_tracks_the_visible_capsule_during_drag_and_spring_return() {
        let ctx = context(true);
        let mut selected = 0;
        let idle = frame(&ctx, 0.0, &mut selected, vec![]);
        let start = idle.rects[0].center();
        let end = idle.rects[2].center();
        frame(&ctx, 0.016, &mut selected, pointer(start, true));
        let dragged = frame(
            &ctx,
            0.032,
            &mut selected,
            vec![egui::Event::PointerMoved(end)],
        );
        assert!(dragged.body.dragging);
        assert!(dragged.body.size.x > idle.body.size.x);
        assert_eq!(selected, 0, "capsule is still over the first segment");
        assert!(!dragged.changed);
        assert_eq!(dragged.rects, idle.rects, "hit boxes must not stretch");
        for index in 1..=5 {
            let held = frame(&ctx, 0.032 + index as f64 * 0.016, &mut selected, vec![]);
            let closest = held
                .rects
                .iter()
                .enumerate()
                .min_by(|(_, a), (_, b)| {
                    let p = idle.rects[0].min + held.body.center;
                    a.distance_sq_to_pos(p).total_cmp(&b.distance_sq_to_pos(p))
                })
                .unwrap()
                .0;
            assert_eq!(selected, closest);
            assert!(held.body.dragging);
        }
        assert_eq!(
            selected, 2,
            "content must update before the pointer is released"
        );
        let release = frame(&ctx, 0.128, &mut selected, pointer(end, false));
        assert_eq!(selected, 2);
        assert!(!release.changed && !release.body.dragging);
        let target = end - idle.rects[0].left_top();
        let mut overshoot = false;
        let mut last = release;
        for index in 1..=180 {
            last = frame(&ctx, 0.128 + index as f64 / 120.0, &mut selected, vec![]);
            overshoot |= last.body.center.x > target.x + 0.1;
            assert!(!last.changed);
        }
        assert!(overshoot, "release must have a small elastic rebound");
        assert!((last.body.center - target).length() < 0.05);
        assert!((last.body.size - idle.rects[2].size()).length() < 0.05);
        assert_eq!(last.body.velocity, Vec2::ZERO);
    }

    #[test]
    fn click_does_not_switch_content_ahead_of_the_glass() {
        let ctx = context(true);
        let mut selected = 0;
        let idle = frame(&ctx, 0.0, &mut selected, vec![]);
        let end = idle.rects[2].center();
        frame(&ctx, 0.016, &mut selected, pointer(end, true));
        let clicked = frame(&ctx, 0.032, &mut selected, pointer(end, false));
        assert_eq!(clicked.body.destination, 2);
        assert_eq!(
            selected, 0,
            "click target must not outrun the visible capsule"
        );
        for index in 1..=90 {
            let shown = frame(&ctx, 0.032 + index as f64 / 60.0, &mut selected, vec![]);
            let p = idle.rects[0].min + shown.body.center;
            let closest = shown
                .rects
                .iter()
                .enumerate()
                .min_by(|(_, a), (_, b)| {
                    a.distance_sq_to_pos(p).total_cmp(&b.distance_sq_to_pos(p))
                })
                .unwrap()
                .0;
            assert_eq!(selected, closest);
        }
        assert_eq!(selected, 2);
    }

    #[test]
    fn outside_release_and_escape_return_to_the_original_section() {
        for escape in [false, true] {
            let ctx = context(true);
            let mut selected = 0;
            let idle = frame(&ctx, 0.0, &mut selected, vec![]);
            frame(
                &ctx,
                0.016,
                &mut selected,
                pointer(idle.rects[0].center(), true),
            );
            let end = idle.rects[2].center();
            frame(
                &ctx,
                0.032,
                &mut selected,
                vec![egui::Event::PointerMoved(end)],
            );
            for index in 1..=5 {
                frame(&ctx, 0.032 + index as f64 * 0.016, &mut selected, vec![]);
            }
            assert_eq!(selected, 2);
            let cancelled = if escape {
                frame(&ctx, 0.128, &mut selected, vec![key(egui::Key::Escape)])
            } else {
                frame(
                    &ctx,
                    0.128,
                    &mut selected,
                    pointer(end + Vec2::new(0.0, 120.0), false),
                )
            };
            assert!(!cancelled.body.dragging);
            for index in 1..=90 {
                frame(&ctx, 0.128 + index as f64 / 60.0, &mut selected, vec![]);
            }
            assert_eq!(selected, 0);
        }
    }

    #[test]
    fn click_and_keyboard_work_with_motion_disabled() {
        let ctx = context(false);
        let mut selected = 0;
        let idle = frame(&ctx, 0.0, &mut selected, vec![]);
        let at = idle.rects[1].center();
        frame(&ctx, 0.016, &mut selected, pointer(at, true));
        let clicked = frame(&ctx, 0.032, &mut selected, pointer(at, false));
        assert!(clicked.changed);
        assert_eq!(selected, 1);
        assert_eq!(clicked.body.velocity, Vec2::ZERO);
        let keyboard = frame(&ctx, 0.048, &mut selected, vec![key(egui::Key::ArrowRight)]);
        assert!(keyboard.changed);
        assert_eq!(selected, 2);
        assert_eq!(keyboard.body.velocity, Vec2::ZERO);
        assert_eq!(
            keyboard.body.center,
            idle.rects[2].center() - idle.rects[0].left_top()
        );
    }
}

#[cfg(all(test, target_os = "windows"))]
#[path = "segments_preview.rs"]
mod native_preview;
