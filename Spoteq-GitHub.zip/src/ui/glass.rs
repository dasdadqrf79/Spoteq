//! Liquid-glass material with a shared soft backdrop and a rounded, refracted light field.
//! Decoration only: no hit targets, layout changes or changes to playback state.
use crate::ui::{motion, theme::colors};
mod gpu;

#[cfg(test)]
pub(crate) fn validate_renderer(ctx: &egui::Context) -> Result<(), String> {
    gpu::validate(ctx)
}
use eframe::egui::{self, Color32, Pos2, Rect, Shape, Stroke, Ui, Vec2};

fn time(ui: &Ui) -> f32 {
    if motion::enabled(ui.ctx()) {
        ui.input(|i| i.time) as f32
    } else {
        0.0
    }
}

/// A quiet canvas gives transparent surfaces a visible backdrop without tinting every control.
fn field(p: Pos2, viewport: Rect, time: f32) -> Color32 {
    let x = (p.x - viewport.left()) / viewport.width().max(1.0);
    let y = (p.y - viewport.top()) / viewport.height().max(1.0);
    let drift = (time * 0.12).sin() * 0.035;
    if super::theme::is_dark() {
        let spots = [
            (0.0 + drift, 0.2, 0.48, 0.72, [12.0, 36.0, 43.0]),
            (1.0, 0.0 + drift, 0.46, 0.6, [39.0, 22.0, 55.0]),
            (0.65 - drift, 1.08, 0.65, 0.38, [14.0, 27.0, 40.0]),
        ];
        let mut rgb = [12.0, 14.0, 20.0];
        for (cx, cy, sx, sy, color) in spots {
            let weight = (-2.0 * (((x - cx) / sx).powi(2) + ((y - cy) / sy).powi(2))).exp();
            for i in 0..3 {
                rgb[i] += color[i] * weight;
            }
        }
        return Color32::from_rgb(rgb[0] as u8, rgb[1] as u8, rgb[2] as u8);
    }
    let spots = [
        (0.00 + drift, 0.20, 0.48, 0.72, [49.0, 22.0, 4.0]),
        (1.00, 0.00 + drift, 0.46, 0.60, [7.0, 37.0, 4.0]),
        (0.65 - drift, 1.08, 0.65, 0.38, [27.0, 5.0, 15.0]),
    ];
    let mut rgb = [248.0, 249.0, 252.0];
    for (cx, cy, sx, sy, color) in spots {
        let weight = (-2.0 * (((x - cx) / sx).powi(2) + ((y - cy) / sy).powi(2))).exp();
        for i in 0..3 {
            rgb[i] -= color[i] * weight;
        }
    }
    let accent = colors::accent();
    let tint = (-3.0 * ((x - 0.72).powi(2) + (y - 0.6).powi(2))).exp() * 0.025;
    for (value, accent) in rgb.iter_mut().zip([accent.r(), accent.g(), accent.b()]) {
        *value = (*value - (255.0 - f32::from(accent)) * tint).clamp(0.0, 255.0);
    }
    Color32::from_rgb(rgb[0] as u8, rgb[1] as u8, rgb[2] as u8)
}

pub fn background(ui: &Ui) {
    let rect = ui.ctx().content_rect();
    if !rect.is_positive() {
        return;
    }
    let time = time(ui);
    let mut mesh = egui::epaint::Mesh::default();
    for y in 0..=16 {
        for x in 0..=24 {
            let p = Pos2::new(
                egui::lerp(rect.x_range(), x as f32 / 24.0),
                egui::lerp(rect.y_range(), y as f32 / 16.0),
            );
            mesh.colored_vertex(p, field(p, rect, time));
            if x < 24 && y < 16 {
                let i = y * 25 + x;
                mesh.add_triangle(i, i + 1, i + 25);
                mesh.add_triangle(i + 1, i + 26, i + 25);
            }
        }
    }
    ui.painter().add(Shape::mesh(mesh));
}

#[test]
fn both_themes_keep_body_and_secondary_text_readable() {
    let ctx = egui::Context::default();
    let viewport = Rect::from_min_size(Pos2::ZERO, Vec2::new(1600.0, 900.0));
    for mode in [
        crate::settings::ThemeMode::Light,
        crate::settings::ThemeMode::Dark,
    ] {
        super::theme::sync_mode(&ctx, mode);
        for time in [0.0, 13.0, 40.0] {
            for y in 0..=16 {
                for x in 0..=24 {
                    let backdrop = field(
                        Pos2::new(x as f32 / 24.0 * 1600.0, y as f32 / 16.0 * 900.0),
                        viewport,
                        time,
                    );
                    for ink in [colors::text(), colors::text_muted()] {
                        let a = super::theme::luminance(backdrop);
                        let b = super::theme::luminance(ink);
                        let contrast = (a.max(b) + 0.05) / (a.min(b) + 0.05);
                        assert!(contrast >= 4.5, "text contrast {contrast} at {x}/{y}");
                    }
                }
            }
        }
    }
}

/// Rounded grid mesh: frosted backdrop, lens-like displacement at the edge, and a
/// bright upper reflection. The fill is behind content, including text and icons.
pub fn panel(ui: &Ui, rect: Rect, radius: f32, hot: f32, _light_x: f32) -> Shape {
    gpu::surface(ui, rect, radius, hot, false)
}

pub fn thumb(ui: &Ui, rect: Rect, hot: f32) -> Shape {
    gpu::surface(ui, rect, rect.height() * 0.5, hot, true)
}

/// A hollow shadow leaves the scene inside transparent glass completely untouched.
pub fn outer_shadow(rect: Rect, radius: f32, opacity: u8) -> Shape {
    if !rect.is_positive() || !rect.is_finite() {
        return Shape::Noop;
    }
    let mut mesh = egui::epaint::Mesh::default();
    const COUNT: u32 = 36;
    for (ring, (distance, offset, alpha)) in [
        (0.0, 0.0, 1.0),
        (3.0, 1.0, 0.5),
        (8.0, 2.0, 0.14),
        (16.0, 3.0, 0.0),
    ]
    .into_iter()
    .enumerate()
    {
        let rect = rect.expand(distance).translate(Vec2::new(0.0, offset));
        let radius = (radius + distance)
            .min(rect.width() * 0.5)
            .min(rect.height() * 0.5);
        for (center, angle) in [
            (rect.left_top() + Vec2::splat(radius), std::f32::consts::PI),
            (
                rect.right_top() + Vec2::new(-radius, radius),
                std::f32::consts::PI * 1.5,
            ),
            (rect.right_bottom() - Vec2::splat(radius), 0.0),
            (
                rect.left_bottom() + Vec2::new(radius, -radius),
                std::f32::consts::FRAC_PI_2,
            ),
        ] {
            for i in 0..=8 {
                let p = center
                    + Vec2::angled(angle + std::f32::consts::FRAC_PI_2 * i as f32 / 8.0) * radius;
                mesh.colored_vertex(
                    p,
                    Color32::from_black_alpha((f32::from(opacity) * alpha) as u8),
                );
            }
        }
        if ring > 0 {
            let a = (ring as u32 - 1) * COUNT;
            let b = ring as u32 * COUNT;
            for i in 0..COUNT {
                let n = (i + 1) % COUNT;
                mesh.add_triangle(a + i, b + i, a + n);
                mesh.add_triangle(a + n, b + i, b + n);
            }
        }
    }
    Shape::mesh(mesh)
}

#[cfg(test)]
pub(crate) fn optical_preview(ui: &mut Ui) -> (Pos2, Pos2) {
    background(ui);
    ui.heading("Clear glass · real backdrop and draggable lens");
    ui.label("The stripes underneath must remain visible through the center of the glass.");
    let size = Vec2::new(
        ui.available_width().min(1100.0),
        (ui.available_height() - 140.0).clamp(220.0, 500.0),
    );
    let (board, _) = ui.allocate_exact_size(size, egui::Sense::hover());
    for i in 0..20 {
        let top = board.top() + i as f32 * board.height() / 20.0;
        let bottom = board.top() + (i + 1) as f32 * board.height() / 20.0;
        let color = if i % 2 == 0 {
            Color32::from_rgb(224, 181, 108)
        } else {
            Color32::from_rgb(34, 77, 108)
        };
        ui.painter().rect_filled(
            Rect::from_min_max(
                Pos2::new(board.left(), top),
                Pos2::new(board.right(), bottom),
            ),
            0,
            color,
        );
    }
    let lens = Rect::from_center_size(
        board.center(),
        Vec2::new(board.width() * 0.55, board.height() * 0.8),
    );
    ui.painter().add(outer_shadow(lens, 30.0, 30));
    ui.painter()
        .add(panel(ui, lens, 30.0, 0.0, lens.center().x));
    rim(ui, lens, 30.0, 0.0);
    let y = board.top() + board.height() * 0.525;
    let probes = (
        Pos2::new(board.left() + 20.0, y),
        Pos2::new(board.center().x, y),
    );
    ui.add_space(18.0);
    let id = egui::Id::new("optical-preview-slider");
    let mut value = ui.ctx().data(|d| d.get_temp::<f32>(id)).unwrap_or(50.0);
    ui.spacing_mut().slider_width = size.x;
    ui.add(super::motion::control(
        egui::Slider::new(&mut value, 0.0..=100.0)
            .show_value(false)
            .handle_shape(egui::style::HandleShape::Circle),
        super::motion::Kind::Slider,
    ));
    ui.ctx().data_mut(|d| d.insert_temp(id, value));
    probes
}

/// Thin clear reflection over native colored controls; intentionally does not hide their labels.
pub fn sheen(rect: Rect, radius: f32, hot: f32, light: f32) -> Shape {
    if !rect.is_positive() || !rect.is_finite() {
        return Shape::Noop;
    }
    let radius = radius
        .min(rect.width() * 0.5)
        .min(rect.height() * 0.5)
        .max(0.0);
    let mut mesh = egui::epaint::Mesh::default();
    let shade = |p: Pos2| {
        let y = ((p.y - rect.top()) / rect.height()).clamp(0.0, 1.0);
        let x = (1.0 - ((p.x - light) / rect.width()).abs()).clamp(0.0, 1.0);
        let highlight = (1.0 - y).powi(2) * (6.0 + 10.0 * hot) * x;
        let lower_glint = y.powi(6) * 2.0;
        Color32::from_white_alpha((highlight + lower_glint) as u8)
    };
    mesh.colored_vertex(rect.center(), shade(rect.center()));
    for (c, a) in [
        (rect.left_top() + Vec2::splat(radius), std::f32::consts::PI),
        (
            rect.right_top() + Vec2::new(-radius, radius),
            std::f32::consts::PI * 1.5,
        ),
        (rect.right_bottom() - Vec2::splat(radius), 0.0),
        (
            rect.left_bottom() + Vec2::new(radius, -radius),
            std::f32::consts::FRAC_PI_2,
        ),
    ] {
        for i in 0..=8 {
            let p = c + Vec2::angled(a + i as f32 / 8.0 * std::f32::consts::FRAC_PI_2) * radius;
            mesh.colored_vertex(p, shade(p));
        }
    }
    let n = mesh.vertices.len() as u32 - 1;
    for i in 1..=n {
        mesh.add_triangle(0, i, if i == n { 1 } else { i + 1 });
    }
    Shape::mesh(mesh)
}

pub fn rim(ui: &Ui, rect: Rect, radius: f32, hot: f32) {
    let painter = ui.painter();
    painter.rect_stroke(
        rect.shrink(0.5),
        radius,
        Stroke::new(
            1.0,
            if super::theme::is_dark() {
                Color32::from_white_alpha((18.0 + 30.0 * hot) as u8)
            } else {
                Color32::from_rgba_unmultiplied(62, 79, 104, (18.0 + 25.0 * hot) as u8)
            },
        ),
        egui::StrokeKind::Inside,
    );
    let inset = radius.min(rect.width() * 0.3);
    painter.line_segment(
        [
            Pos2::new(rect.left() + inset, rect.top() + 1.0),
            Pos2::new(rect.right() - inset, rect.top() + 1.0),
        ],
        Stroke::new(
            1.0,
            Color32::from_white_alpha(if super::theme::is_dark() {
                (22.0 + 30.0 * hot) as u8
            } else {
                (130.0 + 70.0 * hot) as u8
            }),
        ),
    );
}

pub fn window_fill() -> Color32 {
    if super::theme::is_dark() {
        Color32::from_rgba_unmultiplied(15, 22, 34, 12)
    } else {
        Color32::from_rgba_unmultiplied(255, 255, 255, 22)
    }
}

/// Frost content hosted in existing popup builders.
pub fn window_contents<R>(ui: &mut Ui, content: impl FnOnce(&mut Ui) -> R) -> R {
    if !motion::glass_enabled(ui.ctx()) {
        return content(ui);
    }
    let background = ui.painter().add(Shape::Noop);
    let result = content(ui);
    ui.painter().set(
        background,
        gpu::frosted(ui.ctx(), ui.min_rect().expand(12.0), 10.0),
    );
    result
}

/// Frost the entire floating window before its title and contents are painted.
pub fn show_window<R>(
    ctx: &egui::Context,
    id: egui::Id,
    window: egui::Window<'_>,
    content: impl FnOnce(&mut Ui) -> R,
) {
    let painter = ctx.layer_painter(egui::LayerId::new(egui::Order::Middle, id));
    let background = painter.add(Shape::Noop);
    if let Some(result) = window.id(id).show(ctx, content) {
        if motion::glass_enabled(ctx) {
            painter.set(background, gpu::frosted(ctx, result.response.rect, 20.0));
        }
    }
}
