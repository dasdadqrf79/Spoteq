//! Frameless native-window controls integrated into the dark application shell.

use eframe::egui::{
    self, Color32, CursorIcon, Layout, PointerButton, Pos2, Rect, Response, Sense, Stroke, Ui,
    Vec2, ViewportCommand,
};

use crate::ui::theme::{colors, layout};

/// Draws the draggable title area and native window commands.
pub fn show(ui: &mut Ui) {
    egui::Panel::top("spoteq-title-bar")
        .exact_size(layout::TITLE_BAR)
        .frame(
            egui::Frame::new()
                .fill(Color32::TRANSPARENT)
                .inner_margin(egui::Margin::ZERO),
        )
        .show(ui, |ui| {
            let bar = ui.max_rect();
            let controls_width = 3.0 * 48.0;
            let drag_rect = Rect::from_min_max(
                bar.min,
                Pos2::new((bar.right() - controls_width).max(bar.left()), bar.bottom()),
            );
            let drag = ui.interact(
                drag_rect,
                ui.make_persistent_id("native-window-drag-area"),
                Sense::click_and_drag(),
            );

            if drag.double_clicked_by(PointerButton::Primary) {
                toggle_maximized(ui.ctx());
            } else if drag.drag_started_by(PointerButton::Primary) {
                ui.ctx().send_viewport_cmd(ViewportCommand::StartDrag);
            }

            ui.with_layout(Layout::right_to_left(egui::Align::Center), |ui| {
                if window_button(ui, WindowButton::Close).clicked() {
                    ui.ctx().send_viewport_cmd(ViewportCommand::Close);
                }
                let maximized = is_maximized(ui.ctx());
                if window_button(ui, WindowButton::Maximize(maximized)).clicked() {
                    ui.ctx()
                        .send_viewport_cmd(ViewportCommand::Maximized(!maximized));
                }
                if window_button(ui, WindowButton::Minimize).clicked() {
                    ui.ctx().send_viewport_cmd(ViewportCommand::Minimized(true));
                }
            });
        });

    let viewport = ui.ctx().content_rect().shrink(0.5);
    ui.ctx()
        .layer_painter(egui::LayerId::new(
            egui::Order::Foreground,
            egui::Id::new("spoteq-window-outline"),
        ))
        .rect_stroke(
            viewport,
            10,
            Stroke::new(0.7, colors::border()),
            egui::StrokeKind::Inside,
        );
}

fn is_maximized(context: &egui::Context) -> bool {
    context.input(|input| input.viewport().maximized.unwrap_or(false))
}

fn toggle_maximized(context: &egui::Context) {
    context.send_viewport_cmd(ViewportCommand::Maximized(!is_maximized(context)));
}

#[derive(Clone, Copy)]
enum WindowButton {
    Minimize,
    Maximize(bool),
    Close,
}

fn window_button(ui: &mut Ui, button: WindowButton) -> Response {
    let (rect, response) =
        ui.allocate_exact_size(Vec2::new(48.0, layout::TITLE_BAR), Sense::click());
    let hovered = response.hovered();
    let fill = match button {
        WindowButton::Close if hovered => Color32::from_rgb(196, 43, 28),
        _ if hovered => colors::surface_hover(),
        _ => Color32::TRANSPARENT,
    };
    ui.painter().rect_filled(rect, 0, fill);

    let color = if matches!(button, WindowButton::Close) && hovered {
        Color32::WHITE
    } else if response.is_pointer_button_down_on() {
        colors::text_muted()
    } else {
        colors::text()
    };
    paint_window_icon(ui.painter(), rect, button, color);
    response.on_hover_cursor(CursorIcon::PointingHand)
}

fn paint_window_icon(painter: &egui::Painter, rect: Rect, button: WindowButton, color: Color32) {
    let center = rect.center();
    let stroke = Stroke::new(1.25, color);
    match button {
        WindowButton::Minimize => {
            painter.line_segment(
                [
                    Pos2::new(center.x - 5.0, center.y + 3.0),
                    Pos2::new(center.x + 5.0, center.y + 3.0),
                ],
                stroke,
            );
        }
        WindowButton::Maximize(false) => {
            painter.rect_stroke(
                Rect::from_center_size(center, Vec2::splat(10.0)),
                0,
                stroke,
                egui::StrokeKind::Inside,
            );
        }
        WindowButton::Maximize(true) => {
            painter.rect_stroke(
                Rect::from_min_size(center - Vec2::new(3.0, 5.0), Vec2::splat(9.0)),
                0,
                stroke,
                egui::StrokeKind::Inside,
            );
            painter.rect_stroke(
                Rect::from_min_size(center - Vec2::new(6.0, 2.0), Vec2::splat(9.0)),
                0,
                stroke,
                egui::StrokeKind::Inside,
            );
        }
        WindowButton::Close => {
            painter.line_segment(
                [center - Vec2::splat(5.0), center + Vec2::splat(5.0)],
                stroke,
            );
            painter.line_segment(
                [center + Vec2::new(-5.0, 5.0), center + Vec2::new(5.0, -5.0)],
                stroke,
            );
        }
    }
}
