//! One-frame requests used by History and the Mini Player.

use crate::settings::ResumeSession;

const RESUME_ID: &str = "spoteq-resume-session-request";

/// Requests an explicit resume. Merely loading persisted data never starts audio.
pub fn request(context: &eframe::egui::Context, session: ResumeSession) {
    context.data_mut(|data| {
        data.insert_temp(eframe::egui::Id::new(RESUME_ID), session);
    });
}

/// Takes the latest resume request, if a UI surface produced one this frame.
pub fn take(context: &eframe::egui::Context) -> Option<ResumeSession> {
    context.data_mut(|data| {
        let id = eframe::egui::Id::new(RESUME_ID);
        let request = data.get_temp::<ResumeSession>(id);
        data.remove::<ResumeSession>(id);
        request
    })
}
