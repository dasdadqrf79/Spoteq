//! Responsive controls for the real parametric low-frequency processing chain.
use crate::ui::i18n::tr;
use crate::{
    audio::dsp::DspControls,
    settings::{AudioSettings, BassBand, BassFilterKind, BassStudioSettings, BassToneSettings},
    ui::{
        theme::{self, colors},
        widgets,
    },
};
use eframe::egui::{self, Align2, FontId, Pos2, RichText, Sense, Stroke, Ui, Vec2};

const NAMES: [&str; 5] = ["Infra", "Sub", "Punch", "Body", "Warmth"];
const RANGES: [&str; 5] = [
    "20–35 Hz · vibration",
    "35–60 Hz · foundation",
    "60–100 Hz · impact",
    "100–160 Hz · density",
    "160–250 Hz · warmth",
];

pub fn show(ui: &mut Ui, audio: &mut AudioSettings, controls: &DspControls, changed: &mut bool) {
    ui.horizontal_wrapped(|ui| {
        ui.label(
            RichText::new(tr("Bass Studio"))
                .size(28.0)
                .strong()
                .color(colors::text()),
        );
        *changed |= crate::ui::motion::checkbox(ui, &mut audio.bass_studio.enabled, tr("Enabled"))
            .changed();
        *changed |= crate::ui::motion::selectable_value(
            ui,
            &mut audio.bass_studio.bypass,
            false,
            tr("A · Processed"),
        )
        .changed();
        *changed |= crate::ui::motion::selectable_value(
            ui,
            &mut audio.bass_studio.bypass,
            true,
            tr("B · Bypass"),
        )
        .changed();
    });
    ui.label(
        RichText::new(tr("Precision low-frequency control · 20–250 Hz"))
            .color(colors::text_muted()),
    );
    if !audio.eq_enabled {
        ui.horizontal_wrapped(|ui| {
            ui.label(
                RichText::new(tr(
                    &("Global EQ is bypassed. Enable it to hear Bass Studio."),
                ))
                .color(colors::text_muted()),
            );
            if crate::ui::motion::button(ui, tr("Enable global EQ")).clicked() {
                audio.eq_enabled = true;
                *changed = true;
            }
        });
    }
    ui.add_space(14.0);
    sound_character(ui, &mut audio.bass_studio.tone, changed);
    ui.add_space(14.0);
    ui.label(
        RichText::new(tr("Frequency bands"))
            .strong()
            .color(colors::text()),
    );
    ui.add_space(6.0);
    let available = ui.available_width();
    let columns = (((available + 10.0) / 242.0).floor() as usize).clamp(1, 5);
    let width = (available - 10.0 * (columns - 1) as f32) / columns as f32;
    egui::Grid::new("bass-studio-bands")
        .num_columns(columns)
        .spacing(Vec2::splat(10.0))
        .show(ui, |ui| {
            for (index, band) in audio.bass_studio.bands.iter_mut().enumerate() {
                ui.push_id(("bass-band", index), |ui| {
                    theme::elevated_frame(colors::surface(), 16)
                        .inner_margin(16)
                        .show(ui, |ui| {
                            ui.vertical(|ui| {
                                ui.set_width((width - 34.0).max(1.0));
                                ui.horizontal(|ui| {
                                    ui.label(
                                        RichText::new(tr(&(NAMES[index])))
                                            .strong()
                                            .color(colors::text()),
                                    );
                                    *changed |= crate::ui::motion::checkbox(
                                        ui,
                                        &mut band.enabled,
                                        tr("On"),
                                    )
                                    .changed();
                                });
                                ui.label(
                                    RichText::new(tr(&(RANGES[index])))
                                        .size(11.0)
                                        .color(colors::text_muted()),
                                );
                                ui.add_space(12.0);
                                ui.add_enabled_ui(band.enabled, |ui| {
                                    *changed |= gain_slider(ui, &mut band.gain_db).changed();
                                });
                                ui.add_space(8.0);
                                if crate::ui::motion::small_button(ui, tr("Reset band")).clicked() {
                                    *band = default_band(index);
                                    *changed = true;
                                }
                                ui.add_space(4.0);
                                ui.collapsing(tr("Advanced"), |ui| {
                                    ui.add_enabled_ui(band.enabled, |ui| {
                                        ui.horizontal(|ui| {
                                            ui.label(tr("Type"));
                                            egui::ComboBox::from_id_salt("filter-type")
                                                .selected_text(tr(&(match band.kind {
                                                    BassFilterKind::Bell => "Bell",
                                                    BassFilterKind::LowShelf => "Low Shelf",
                                                })))
                                                .width(110.0)
                                                .show_ui(ui, |ui| {
                                                    *changed |=
                                                        crate::ui::motion::selectable_value(
                                                            ui,
                                                            &mut band.kind,
                                                            BassFilterKind::Bell,
                                                            tr("Bell"),
                                                        )
                                                        .changed();
                                                    *changed |=
                                                        crate::ui::motion::selectable_value(
                                                            ui,
                                                            &mut band.kind,
                                                            BassFilterKind::LowShelf,
                                                            tr("Low Shelf"),
                                                        )
                                                        .changed();
                                                });
                                        });
                                        precision_value(
                                            ui,
                                            "Frequency",
                                            &mut band.frequency_hz,
                                            20.0..=250.0,
                                            " Hz",
                                            0.1,
                                            changed,
                                        );
                                        precision_value(
                                            ui,
                                            "Width (Q)",
                                            &mut band.q,
                                            0.3..=6.0,
                                            "",
                                            0.01,
                                            changed,
                                        );
                                    });
                                });
                            });
                        });
                });
                if index % columns == columns - 1 {
                    ui.end_row();
                }
            }
        });
    ui.add_space(14.0);
    theme::elevated_frame(colors::surface(), 16).inner_margin(16).show(ui, |ui| {
        ui.set_width(ui.available_width());
        ui.label(RichText::new(tr("Headroom / clipping")).strong().color(colors::text()));
        meter(ui, controls);
        *changed |= widgets::labeled_slider(ui, "Preamp (shared with EQ)", &mut audio.preamp_db, -24.0..=6.0, " dB", 0.5).changed();
        ui.label(RichText::new(tr("A/B switches Bass Studio only. Global EQ, legacy bass controls and preamp remain active.")).size(11.0).color(colors::text_muted()));
        if crate::ui::motion::button(ui, tr("Reset Bass Studio")).clicked() { audio.bass_studio = BassStudioSettings::default(); *changed = true; }
    });
    ui.add_space(18.0);
}

fn sound_character(ui: &mut Ui, tone: &mut BassToneSettings, changed: &mut bool) {
    theme::elevated_frame(colors::surface(), 16).inner_margin(16).show(ui, |ui| {
        ui.set_width(ui.available_width());
        ui.spacing_mut().item_spacing = Vec2::new(28.0, 5.0);
        ui.horizontal_wrapped(|ui| {
            ui.label(RichText::new(tr("Sound character")).strong().color(colors::text()));
            if crate::ui::motion::small_button(ui, tr("Reset character")).clicked() {
                *tone = BassToneSettings::default();
                *changed = true;
            }
        });
        ui.label(RichText::new(tr("Start with Deep bass for more weight. Add Punch for a sharper kick.")).size(12.0).color(colors::text_muted()));
        ui.add_space(10.0);
        let count = if ui.available_width() >= 1450.0 { 4 } else if ui.available_width() >= 1100.0 { 3 } else if ui.available_width() >= 640.0 { 2 } else { 1 };
        ui.columns(count, |columns| {
            for (index, (label, value, range, suffix, description)) in [
                ("Deep bass", &mut tone.depth_db, 0.0..=9.0, " dB", "More depth and weight below 40 Hz. 0 dB = original."),
                ("Punch / attack", &mut tone.punch, -100.0..=100.0, "%", "Left: softer kick. Right: stronger attack. 0% = original."),
                ("Saturation", &mut tone.saturation, 0.0..=100.0, "%", "Adds bass harmonics, from clean to gritty. 0% = off."),
                ("Density", &mut tone.density, 0.0..=100.0, "%", "Brings quiet bass forward and controls louder notes. 0% = off."),
                ("Rumble cut", &mut tone.rumble_hz, 0.0..=45.0, " Hz", "Removes rumble below the selected frequency. Off, or 15–45 Hz."),
                ("Dynamic bass", &mut tone.dynamic, 0.0..=100.0, "%", "Reduces bass during loud peaks to leave more headroom. 0% = off."),
                ("Stereo width", &mut tone.width, 0.0..=150.0, "%", "0% = mono, 100% = original, 150% = wider stereo."),
            ].into_iter().enumerate() {
                let column = &mut columns[index % count];
                column.push_id(label, |ui| {
                    *changed |= character_slider(ui, label, value, range, suffix, description);
                    ui.add_space(14.0);
                });
            }
        });
        *changed |= crate::ui::motion::checkbox(ui, &mut tone.mono_bass, tr("Keep low bass centered")).on_hover_text(tr("Centers the low band with a gradual crossover around 180 Hz; higher frequencies remain stereo.")).changed();
    });
}

fn character_slider(
    ui: &mut Ui,
    label: &str,
    value: &mut f32,
    range: std::ops::RangeInclusive<f32>,
    suffix: &str,
    description: &str,
) -> bool {
    ui.horizontal(|ui| {
        ui.label(RichText::new(tr(label)).color(colors::text()))
            .on_hover_text(tr(description));
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            let readout = if suffix == " Hz" && *value == 0.0 {
                "Off".to_owned()
            } else if suffix == " dB" {
                format!("{value:+.1} dB")
            } else {
                format!("{value:.0}{suffix}")
            };
            ui.label(
                RichText::new(tr(&(readout)))
                    .monospace()
                    .color(colors::accent_bright()),
            );
        });
    });
    ui.scope(|ui| {
        ui.spacing_mut().slider_width = ui.available_width();
        ui.spacing_mut().slider_rail_height = 5.0;
        let visuals = &mut ui.visuals_mut().widgets;
        visuals.inactive.bg_fill = colors::border_strong();
        visuals.inactive.fg_stroke = Stroke::new(2.0, colors::accent_bright());
        visuals.hovered.bg_fill = colors::accent();
        visuals.active.bg_fill = colors::accent_bright();
        let slider = egui::Slider::new(value, range)
            .show_value(false)
            .trailing_fill(true)
            .handle_shape(egui::style::HandleShape::Circle)
            .step_by(if suffix == " dB" { 0.1 } else { 1.0 });
        let slider = if suffix == " Hz" {
            slider.logarithmic(true).smallest_positive(15.0)
        } else {
            slider
        };
        ui.add_sized(
            [ui.available_width(), 24.0],
            crate::ui::motion::control(slider, crate::ui::motion::Kind::Slider),
        )
        .changed()
    })
    .inner
}

fn default_band(index: usize) -> BassBand {
    BassStudioSettings::default().bands[index]
}

fn precision_value(
    ui: &mut Ui,
    label: &str,
    value: &mut f32,
    range: std::ops::RangeInclusive<f32>,
    suffix: &str,
    speed: f64,
    changed: &mut bool,
) {
    ui.horizontal(|ui| {
        ui.label(RichText::new(tr(label)).color(colors::text_muted()));
        let fine = ui.input(|i| i.modifiers.shift);
        let response = ui.add(crate::ui::motion::control(
            egui::DragValue::new(value)
                .range(range.clone())
                .speed(if fine { speed * 0.1 } else { speed })
                .suffix(tr(suffix))
                .max_decimals(2),
            crate::ui::motion::Kind::Input,
        ));
        *changed |= response.changed();
        if response.hovered() {
            let wheel = ui.input_mut(|i| {
                let delta = i.smooth_scroll_delta.y;
                i.smooth_scroll_delta.y = 0.0;
                delta
            });
            if wheel != 0.0 {
                let next = (*value + wheel.signum() * speed as f32 * if fine { 0.1 } else { 1.0 })
                    .clamp(*range.start(), *range.end());
                *changed |= *value != next;
                *value = next;
            }
        }
    });
}

fn gain_slider(ui: &mut Ui, gain: &mut f32) -> egui::Response {
    ui.horizontal(|ui| {
        ui.label(RichText::new(tr("Gain")).color(colors::text_muted()));
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            ui.add(crate::ui::motion::control(
                egui::DragValue::new(gain)
                    .range(-12.0..=12.0)
                    .speed(0.1)
                    .fixed_decimals(1)
                    .suffix(tr(" dB")),
                crate::ui::motion::Kind::Input,
            ))
        })
        .inner
    })
    .inner
    .union({
        let width = ui.available_width();
        ui.spacing_mut().slider_width = width;
        let response = ui
            .scope(|ui| {
                ui.spacing_mut().slider_rail_height = 5.0;
                let visuals = &mut ui.visuals_mut().widgets;
                visuals.inactive.bg_fill = colors::border_strong();
                visuals.inactive.fg_stroke = Stroke::new(2.0, colors::accent_bright());
                visuals.hovered.bg_fill = colors::accent();
                visuals.active.bg_fill = colors::accent_bright();
                ui.add_sized(
                    [width, 28.0],
                    crate::ui::motion::control(
                        egui::Slider::new(gain, -12.0..=12.0)
                            .show_value(false)
                            .step_by(0.1)
                            .trailing_fill(false)
                            .handle_shape(egui::style::HandleShape::Circle),
                        crate::ui::motion::Kind::Slider,
                    ),
                )
            })
            .inner;
        let center = response.rect.center();
        ui.painter().line_segment(
            [
                Pos2::new(center.x, response.rect.bottom() - 3.0),
                Pos2::new(center.x, response.rect.bottom()),
            ],
            Stroke::new(1.0, colors::text_muted()),
        );
        let (labels, _) = ui.allocate_exact_size(Vec2::new(width, 14.0), Sense::hover());
        for (position, align, label) in [
            (labels.left_center(), Align2::LEFT_CENTER, "−12 dB"),
            (labels.center(), Align2::CENTER_CENTER, "0"),
            (labels.right_center(), Align2::RIGHT_CENTER, "+12 dB"),
        ] {
            ui.painter().text(
                position,
                align,
                tr(label),
                FontId::proportional(10.0),
                colors::text_muted(),
            );
        }
        response
    })
}
fn meter(ui: &mut Ui, controls: &DspControls) {
    let (pre, post) = controls.take_meter_peaks();
    let id = ui.make_persistent_id("bass-meter");
    let now = ui.input(|i| i.time);
    let (previous, previous_time) = ui
        .ctx()
        .data(|d| d.get_temp::<((f32, f32), f64)>(id))
        .unwrap_or(((0.0, 0.0), now));
    let decay = (-((now - previous_time).max(0.0)) as f32 * 3.0).exp();
    let peaks = (pre.max(previous.0 * decay), post.max(previous.1 * decay));
    ui.ctx().data_mut(|d| d.insert_temp(id, (peaks, now)));
    let db = |value: f32| {
        if value > 1e-6 {
            format!("{:+.1} dBFS", 20.0 * value.log10())
        } else {
            "— dBFS".to_owned()
        }
    };
    ui.horizontal_wrapped(|ui| {
        ui.label(tr(&(format!("Before limiter: {}", db(peaks.0)))));
        ui.label(tr(&(format!("DSP output: {}", db(peaks.1)))));
        if peaks.0 >= 0.98 {
            ui.colored_label(colors::error(), "Limiter active / reduce Preamp");
        }
    });
    ui.label(RichText::new(tr("Sample peaks before master volume; this is not a true-peak meter or spectrum analyzer.")).size(11.0).color(colors::text_muted()));
    ui.ctx()
        .request_repaint_after(std::time::Duration::from_millis(50));
}
