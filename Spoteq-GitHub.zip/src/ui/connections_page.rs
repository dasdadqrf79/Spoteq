//! Accounts and API connection status without changing music or playback pages.
use crate::ui::i18n::tr;

use eframe::egui::{self, Align, Layout, RichText, Ui, Vec2};

use crate::{
    soundcloud::{
        CLIENT_ID_ENV, CLIENT_SECRET_ENV, REDIRECT_URI_ENV, SoundCloudAuthView, SoundCloudAvatar,
        SoundCloudRuntime, SoundCloudViewState,
    },
    spotify::{PlaybackStatus, SpotifyCommand, SpotifyRuntime},
    state::{AuthView, SpotifyViewState},
    ui::theme::{self, colors},
};

/// Draws independent Spotify and SoundCloud connection cards.
pub fn show(
    ui: &mut Ui,
    spotify: &mut SpotifyViewState,
    spotify_runtime: &SpotifyRuntime,
    soundcloud: &mut SoundCloudViewState,
    soundcloud_runtime: &SoundCloudRuntime,
    soundcloud_avatar: &SoundCloudAvatar,
) {
    crate::ui::widgets::page_header(
        ui,
        "Accounts",
        "Connect your music services and enjoy everything in one place.",
    );

    egui::ScrollArea::vertical()
        .id_salt("connections-page")
        .auto_shrink([false, false])
        .show(ui, |ui| {
            if ui.available_width() >= 760.0 { ui.columns(2, |columns| {
                spotify_card(&mut columns[0], spotify, spotify_runtime);
                soundcloud_card(
                    &mut columns[1],
                    soundcloud,
                    soundcloud_runtime,
                    soundcloud_avatar,
                );
            }); } else {
                spotify_card(ui, spotify, spotify_runtime);
                ui.add_space(14.0);
                soundcloud_card(ui, soundcloud, soundcloud_runtime, soundcloud_avatar);
            }
            ui.add_space(18.0);
            theme::elevated_frame(colors::surface(), 12)
                .inner_margin(egui::Margin::symmetric(20, 18))
                .show(ui, |ui| {
                    ui.set_min_width(ui.available_width());
                    ui.label(
                        RichText::new(tr("Connect both services to get the most out of Spoteq."))
                            .size(15.0)
                            .strong()
                            .color(colors::text()),
                    );
                    ui.label(
                        RichText::new(tr("Search, liked songs and playback stay available from both Spotify and SoundCloud."))
                            .size(13.0)
                            .color(colors::text_muted()),
                    );
                });
            ui.add_space(24.0);
        });
}

fn spotify_card(ui: &mut Ui, state: &mut SpotifyViewState, runtime: &SpotifyRuntime) {
    service_card(ui, |ui| {
        ui.horizontal(|ui| {
            service_mark(ui, "S", colors::accent());
            ui.vertical(|ui| {
                ui.label(
                    RichText::new(tr("Spotify"))
                        .size(19.0)
                        .strong()
                        .color(colors::text()),
                );
                ui.label(
                    RichText::new(tr("Existing Web API and direct local playback"))
                        .small()
                        .color(colors::text_muted()),
                );
            });
        });
        ui.add_space(14.0);

        let (connection, username, _web_api) = match &state.auth {
            AuthView::LoggedIn(profile) => ("Connected", profile.label(), "Available"),
            AuthView::Restoring => ("Restoring", "—", "Checking token"),
            AuthView::Authorizing => ("Authorizing", "—", "Waiting for browser"),
            AuthView::LoggedOut => ("Not connected", "—", "Unavailable"),
            AuthView::Error(_) => ("Needs attention", "—", "Authentication error"),
        };
        ui.label(
            RichText::new(tr(&(if matches!(&state.auth, AuthView::LoggedIn(_)) {
                format!("Connected as {username}")
            } else {
                connection.to_owned()
            })))
            .color(spotify_status_color(&state.auth)),
        );
        ui.label(
            RichText::new(tr(&(format!(
                "Web API · Playback {}",
                spotify_playback_label(&state.playback.status)
            ))))
            .size(12.0)
            .color(colors::text_muted()),
        );

        if let AuthView::Error(error) = &state.auth {
            error_box(ui, error);
        }

        ui.add_space(12.0);
        ui.horizontal(|ui| {
            if matches!(&state.auth, AuthView::LoggedIn(_)) {
                if crate::ui::motion::button(ui, tr("Reconnect")).clicked() {
                    state.login_open = true;
                    if let Err(error) = runtime.send(SpotifyCommand::Logout) {
                        state.toast_error(error.to_string());
                    }
                }
                if crate::ui::motion::button(ui, tr("Disconnect")).clicked() {
                    if let Err(error) = runtime.send(SpotifyCommand::Logout) {
                        state.toast_error(error.to_string());
                    }
                }
            } else if ui
                .add_enabled(
                    !matches!(&state.auth, AuthView::Restoring | AuthView::Authorizing),
                    crate::ui::motion::control(
                        egui::Button::new(tr("Connect Spotify")),
                        crate::ui::motion::Kind::Button,
                    ),
                )
                .clicked()
            {
                state.login_open = true;
            }
        });
    });
}

fn soundcloud_card(
    ui: &mut Ui,
    state: &mut SoundCloudViewState,
    runtime: &SoundCloudRuntime,
    avatar: &SoundCloudAvatar,
) {
    service_card(ui, |ui| {
        ui.horizontal(|ui| {
            let avatar_url = match &state.auth {
                SoundCloudAuthView::LoggedIn(profile) => profile.avatar_url.as_deref(),
                _ => None,
            };
            let _ = avatar.show(ui, avatar_url, Vec2::splat(44.0));
            ui.vertical(|ui| {
                ui.label(
                    RichText::new(tr("SoundCloud"))
                        .size(19.0)
                        .strong()
                        .color(colors::text()),
                );
                ui.label(
                    RichText::new(tr(
                        &("OAuth 2.1 + PKCE · Search, Library and native playback"),
                    ))
                    .small()
                    .color(colors::text_muted()),
                );
            });
        });
        ui.add_space(14.0);

        let (connection, username, _api_status, color) = match &state.auth {
            SoundCloudAuthView::Restoring => {
                ("Restoring", "—", "Checking token", colors::warning())
            }
            SoundCloudAuthView::LoggedOut => {
                ("Not connected", "—", "Unavailable", colors::text_muted())
            }
            SoundCloudAuthView::Authorizing => (
                "Authorizing",
                "Complete login in Edge/Chrome",
                "Waiting",
                colors::warning(),
            ),
            SoundCloudAuthView::LoggedIn(profile) => (
                "Connected",
                profile.username.as_str(),
                "GET /me OK",
                colors::accent(),
            ),
            SoundCloudAuthView::ConfigurationError => {
                ("Not configured", "—", "Unavailable", colors::error())
            }
            SoundCloudAuthView::AuthError => {
                ("Authentication failed", "—", "Unavailable", colors::error())
            }
            SoundCloudAuthView::ApiError => ("Token present", "—", "API error", colors::error()),
        };
        ui.label(
            RichText::new(tr(&(if state.is_authenticated() {
                format!("Connected as {username}")
            } else {
                connection.to_owned()
            })))
            .color(color),
        );
        ui.label(
            RichText::new(tr(&(if state.is_authenticated() {
                "OAuth · Playback ready"
            } else {
                "OAuth · Playback unavailable"
            })))
            .size(12.0)
            .color(colors::text_muted()),
        );

        if let Some(error) = state.auth_error.as_deref().or(state.api_error.as_deref()) {
            error_box(ui, error);
        }
        if matches!(&state.auth, SoundCloudAuthView::ConfigurationError) {
            ui.add_space(8.0);
            ui.label(
                RichText::new(tr(&(format!(
                    "Set {CLIENT_ID_ENV} and {CLIENT_SECRET_ENV} before starting Spoteq. {REDIRECT_URI_ENV} defaults to eqspot://soundcloud/callback."
                ))))
                .small()
                .color(colors::text_muted()),
            );
        }

        ui.add_space(12.0);
        ui.horizontal(|ui| {
            let configured = state.config.is_some();
            let busy = state.busy();
            let logged_in = state.is_authenticated();
            let retry = matches!(
                &state.auth,
                SoundCloudAuthView::AuthError | SoundCloudAuthView::ApiError
            );
            if logged_in {
                if ui
                    .add_enabled(
                        !busy,
                        crate::ui::motion::control(
                            egui::Button::new(tr("Reconnect")),
                            crate::ui::motion::Kind::Button,
                        ),
                    )
                    .clicked()
                {
                    state.reconnect(runtime);
                }
                if ui
                    .add_enabled(
                        !busy,
                        crate::ui::motion::control(
                            egui::Button::new(tr("Disconnect")),
                            crate::ui::motion::Kind::Button,
                        ),
                    )
                    .clicked()
                {
                    state.logout(runtime);
                }
            } else if ui
                .add_enabled(
                    configured && !busy,
                    crate::ui::motion::control(
                        egui::Button::new(tr(&(if retry {
                            "Reconnect SoundCloud"
                        } else {
                            "Connect SoundCloud"
                        }))),
                        crate::ui::motion::Kind::Button,
                    ),
                )
                .clicked()
            {
                if retry {
                    state.reconnect(runtime);
                } else {
                    state.connect(runtime);
                }
            }
        });
    });
}

fn service_card(ui: &mut Ui, content: impl FnOnce(&mut Ui)) {
    theme::elevated_frame(colors::surface_low(), 12)
        .inner_margin(24)
        .show(ui, |ui| {
            ui.set_min_width(ui.available_width());
            ui.set_min_height(if ui.ctx().content_rect().height() < 800.0 {
                220.0
            } else {
                320.0
            });
            content(ui);
        });
}

fn service_mark(ui: &mut Ui, label: &str, _color: egui::Color32) {
    let (rect, _) = ui.allocate_exact_size(Vec2::splat(44.0), egui::Sense::hover());
    ui.painter()
        .circle_filled(rect.center(), 22.0, colors::text());
    ui.painter().text(
        rect.center(),
        egui::Align2::CENTER_CENTER,
        tr(label),
        egui::FontId::proportional(18.0),
        colors::background(),
    );
}

fn status_row(ui: &mut Ui, label: &str, value: &str, color: egui::Color32) {
    ui.horizontal(|ui| {
        ui.label(RichText::new(tr(label)).color(colors::text_muted()));
        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
            ui.add(egui::Label::new(RichText::new(value).strong().color(color)).truncate());
        });
    });
}

fn error_box(ui: &mut Ui, error: &str) {
    ui.add_space(10.0);
    crate::ui::motion::frame(
        egui::Frame::new()
            .fill(colors::error().gamma_multiply(0.10))
            .stroke(egui::Stroke::new(1.0, colors::error().gamma_multiply(0.35)))
            .corner_radius(7)
            .inner_margin(10),
    )
    .show(ui, |ui| {
        ui.label(RichText::new(error).small().color(colors::text()));
    });
}

fn spotify_status_color(auth: &AuthView) -> egui::Color32 {
    match auth {
        AuthView::LoggedIn(_) => colors::accent(),
        AuthView::Error(_) => colors::error(),
        AuthView::Restoring | AuthView::Authorizing => colors::warning(),
        AuthView::LoggedOut => colors::text_muted(),
    }
}

fn spotify_playback_label(status: &PlaybackStatus) -> &str {
    match status {
        PlaybackStatus::Idle => "Ready",
        PlaybackStatus::Connecting => "Connecting",
        PlaybackStatus::Authorizing => "Authorization required",
        PlaybackStatus::Loading => "Loading",
        PlaybackStatus::Playing => "Playing locally",
        PlaybackStatus::Paused => "Paused",
        PlaybackStatus::Error(_) => "Playback error",
    }
}

fn spotify_playback_color(status: &PlaybackStatus) -> egui::Color32 {
    match status {
        PlaybackStatus::Playing => colors::accent(),
        PlaybackStatus::Error(_) => colors::error(),
        PlaybackStatus::Connecting | PlaybackStatus::Authorizing | PlaybackStatus::Loading => {
            colors::warning()
        }
        PlaybackStatus::Idle | PlaybackStatus::Paused => colors::text_muted(),
    }
}
