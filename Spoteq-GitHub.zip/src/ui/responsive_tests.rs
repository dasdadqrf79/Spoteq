//! Offline UI fixtures: no credentials, network, audio devices, or settings files.
use crate::{
    catalog::TrackRow,
    image_cache::CoverCache,
    settings::{AppSettings, ResumeSession},
    soundcloud::{SoundCloudAvatar, SoundCloudRuntime},
    spotify::{PlaybackStatus, SpotifyRuntime, Track, UserProfile},
    state::{AppState, AuthView, MusicPage, SettingsSection},
};
use eframe::egui::{self, Rect, Vec2};

struct Fixture {
    state: AppState,
    settings: AppSettings,
    spotify: SpotifyRuntime,
    soundcloud: SoundCloudRuntime,
    covers: CoverCache,
    avatar: SoundCloudAvatar,
}

impl Fixture {
    fn new(context: &egui::Context) -> Self {
        super::theme::install(context, Default::default());
        let mut state = AppState::default();
        state.spotify.auth = AuthView::LoggedIn(UserProfile {
            id: "offline-preview".into(),
            display_name: Some("Layout preview".into()),
            country: None,
            product: None,
            image_url: None,
        });
        let tracks: Vec<_> = (0..36).map(|i| Track {
            id: format!("test{i}"), uri: format!("spotify:track:test{i}"),
            name: format!("Track {i} — a deliberately very long title to verify ellipsis and control spacing"),
            artists: "Artist with a very long name and several collaborators".into(),
            album: "Layout fixture".into(), duration_ms: 240_000, image_url: None, saved: true,
        }).collect();
        state.spotify.playback.track = Some(tracks[0].clone());
        state.spotify.playback.status = PlaybackStatus::Paused;
        state.spotify.playback.position_ms = 65_000;
        state.spotify.liked.tracks = tracks.clone();
        state.spotify.liked.loaded_once = true;
        state.spotify.liked.total = tracks.len();
        state.spotify.audio_devices =
            vec!["An exceptionally long audio output device name (High Definition Audio)".into()];
        let mut settings = AppSettings::default();
        settings.audio.output_device = Some(state.spotify.audio_devices[0].clone());
        for (index, track) in tracks.iter().enumerate() {
            let row = TrackRow::from_spotify(track);
            state.autoplay.enqueue_manual(row.clone());
            settings
                .session
                .history
                .push(crate::settings::ListeningHistoryEntry {
                    track: row,
                    started_at_ms: 1_790_000_000_000 - index as i64 * 300_000,
                    played_ms: 200_000,
                    completed: true,
                    skipped: false,
                    finished: true,
                });
        }
        for index in 0..8 {
            settings.session.save_vibe(
                format!("Saved Vibe {index} with a long session name"),
                ResumeSession {
                    current: Some(TrackRow::from_spotify(&tracks[0])),
                    next_up: tracks[1..8].iter().map(TrackRow::from_spotify).collect(),
                    radio_title: Some("Radio preview".into()),
                    ..Default::default()
                },
                1_790_000_000_000 + index,
            );
        }
        state.smart_library_cache.refresh(
            state.smart_playlist,
            &settings.session,
            &state.spotify,
            &state.soundcloud,
        );
        Self {
            state,
            settings,
            spotify: SpotifyRuntime::for_ui_test(),
            soundcloud: SoundCloudRuntime::for_ui_test(),
            covers: Default::default(),
            avatar: Default::default(),
        }
    }

    fn show(&mut self, ui: &mut egui::Ui) {
        let mut toggle = false;
        super::root::show(
            ui,
            &mut self.state,
            &mut self.settings,
            std::path::Path::new("offline-preview/settings.json"),
            None,
            &mut self.covers,
            &self.spotify,
            &self.soundcloud,
            &self.avatar,
            &mut toggle,
        );
    }
}

#[test]
fn both_languages_render_settings_and_bass_without_changing_audio() {
    let context = egui::Context::default();
    let mut fixture = Fixture::new(&context);
    let original_audio = fixture.settings.audio.clone();
    for language in [
        crate::settings::Language::Russian,
        crate::settings::Language::English,
    ] {
        fixture.settings.appearance.language = language;
        fixture.state.page = MusicPage::Settings;
        for section in [
            SettingsSection::General,
            SettingsSection::Audio,
            SettingsSection::BassStudio,
            SettingsSection::Playback,
            SettingsSection::Appearance,
            SettingsSection::Integrations,
            SettingsSection::About,
        ] {
            fixture.state.settings_section = section;
            for size in [Vec2::new(900.0, 650.0), Vec2::new(1600.0, 900.0)] {
                let mut output = context.run_ui(
                    egui::RawInput {
                        screen_rect: Some(Rect::from_min_size(egui::Pos2::ZERO, size)),
                        ..Default::default()
                    },
                    |ui| fixture.show(ui),
                );
                output.textures_delta.clear();
                assert!(!output.shapes.is_empty());
                assert_eq!(fixture.settings.audio, original_audio);
            }
        }
    }
}

#[test]
fn render_pages_through_resize_and_dpi_matrix_without_changing_playback_or_library() {
    let context = egui::Context::default();
    let mut fixture = Fixture::new(&context);
    let original_settings = serde_json::to_value(&fixture.settings).unwrap();
    for (w, h) in [
        (900., 650.),
        (1024., 768.),
        (1280., 720.),
        (1366., 768.),
        (1600., 900.),
        (1920., 1080.),
        (2560., 1440.),
    ] {
        for dpi in [1.0_f32, 1.25, 1.5, 1.75] {
            for page in [
                MusicPage::Search,
                MusicPage::LikedSongs,
                MusicPage::SmartLibrary,
                MusicPage::History,
                MusicPage::Connections,
                MusicPage::Settings,
            ] {
                fixture.state.page = page;
                for section in [
                    SettingsSection::General,
                    SettingsSection::Audio,
                    SettingsSection::BassStudio,
                ] {
                    fixture.state.settings_section = section;
                    fixture.state.queue_open = section == SettingsSection::General;
                    fixture.state.audio_popup_open = section == SettingsSection::Audio;
                    // Native window minimum is expressed in logical points. DPI remains native.
                    let size = Vec2::new((w / dpi).max(900.0), (h / dpi).max(650.0));
                    let mut input = egui::RawInput {
                        screen_rect: Some(Rect::from_min_size(egui::Pos2::ZERO, size)),
                        ..Default::default()
                    };
                    input
                        .viewports
                        .get_mut(&egui::ViewportId::ROOT)
                        .unwrap()
                        .native_pixels_per_point = Some(dpi);
                    let mut output = context.run_ui(input, |ui| fixture.show(ui));
                    output.textures_delta.clear();
                    assert!(!output.shapes.is_empty());
                    for shape in output.shapes {
                        assert!(
                            shape.clip_rect.is_finite(),
                            "invalid clip at {w}x{h} / {dpi} / {page:?}"
                        );
                    }
                    assert_eq!(
                        fixture.state.spotify.playback.status,
                        PlaybackStatus::Paused
                    );
                    assert_eq!(fixture.state.spotify.playback.position_ms, 65_000);
                    assert_eq!(fixture.state.spotify.liked.tracks.len(), 36);
                }
            }
        }
    }
    assert_eq!(
        serde_json::to_value(&fixture.settings).unwrap(),
        original_settings
    );
}

#[test]
fn real_pages_follow_the_capsule_and_settings_tabs_do_not_move_during_drag() {
    fn draw(
        ctx: &egui::Context,
        fixture: &mut Fixture,
        time: f64,
        events: Vec<egui::Event>,
        salt: &str,
    ) -> (Vec<Rect>, egui::Pos2) {
        let mut output = ctx.run_ui(
            egui::RawInput {
                screen_rect: Some(Rect::from_min_size(
                    egui::Pos2::ZERO,
                    Vec2::new(1600.0, 900.0),
                )),
                time: Some(time),
                events,
                ..Default::default()
            },
            |ui| fixture.show(ui),
        );
        output.textures_delta.clear();
        ctx.data(|d| d.get_temp(egui::Id::new(format!("segment-layout/{salt}"))))
            .unwrap()
    }
    fn button(pos: egui::Pos2, pressed: bool) -> Vec<egui::Event> {
        vec![
            egui::Event::PointerMoved(pos),
            egui::Event::PointerButton {
                pos,
                button: egui::PointerButton::Primary,
                pressed,
                modifiers: Default::default(),
            },
        ]
    }
    for settings in [false, true] {
        let ctx = egui::Context::default();
        let mut fixture = Fixture::new(&ctx);
        fixture.state.page = if settings {
            MusicPage::Settings
        } else {
            MusicPage::Search
        };
        fixture.state.settings_section = SettingsSection::Audio;
        let salt = if settings {
            "settings-navigation"
        } else {
            "primary-navigation"
        };
        let (rects, _) = draw(&ctx, &mut fixture, 0.0, vec![], salt);
        let start = rects[if settings { 2 } else { 0 }].center();
        let end = rects[if settings { 4 } else { 1 }].center();
        draw(&ctx, &mut fixture, 0.016, button(start, true), salt);
        let mut changed_while_held = false;
        for index in 1..=30 {
            let p = start.lerp(end, (index as f32 / 20.0).min(1.0));
            let (shown, center) = draw(
                &ctx,
                &mut fixture,
                0.016 + index as f64 / 60.0,
                vec![egui::Event::PointerMoved(p)],
                salt,
            );
            assert_eq!(shown, rects, "navigation moved underneath the gesture");
            let active = shown
                .iter()
                .enumerate()
                .min_by(|(_, a), (_, b)| {
                    a.distance_sq_to_pos(center)
                        .total_cmp(&b.distance_sq_to_pos(center))
                })
                .unwrap()
                .0;
            if settings {
                let sections = [
                    SettingsSection::General,
                    SettingsSection::Playback,
                    SettingsSection::Audio,
                    SettingsSection::BassStudio,
                    SettingsSection::Appearance,
                    SettingsSection::Integrations,
                    SettingsSection::About,
                ];
                assert_eq!(fixture.state.settings_section, sections[active]);
                changed_while_held |= active == 4;
            } else {
                assert_eq!(
                    fixture.state.page,
                    [
                        MusicPage::Search,
                        MusicPage::LikedSongs,
                        MusicPage::Settings
                    ][active]
                );
                changed_while_held |= active == 1;
            }
        }
        assert!(changed_while_held, "page did not switch while dragging");
        draw(&ctx, &mut fixture, 0.55, button(end, false), salt);
    }
}

#[test]
fn appearance_control_switches_the_whole_theme_without_changing_audio() {
    let ctx = egui::Context::default();
    let mut fixture = Fixture::new(&ctx);
    fixture.state.page = MusicPage::Settings;
    fixture.state.settings_section = SettingsSection::Appearance;
    let audio = fixture.settings.audio.clone();
    let mut time = 0.0;
    let draw = |fixture: &mut Fixture, time, events| {
        let mut output = ctx.run_ui(
            egui::RawInput {
                screen_rect: Some(Rect::from_min_size(
                    egui::Pos2::ZERO,
                    Vec2::new(1600.0, 900.0),
                )),
                time: Some(time),
                events,
                ..Default::default()
            },
            |ui| fixture.show(ui),
        );
        output.textures_delta.clear();
        ctx.data(|d| {
            d.get_temp::<(Vec<Rect>, egui::Pos2)>(egui::Id::new("segment-layout/theme-mode"))
        })
        .unwrap()
        .0
    };
    let rects = draw(&mut fixture, time, vec![]);
    assert!(ctx.global_style().visuals.dark_mode);
    for (index, mode) in [
        (0, crate::settings::ThemeMode::Light),
        (1, crate::settings::ThemeMode::Dark),
    ] {
        let pos = rects[index].center();
        for pressed in [true, false] {
            time += 0.02;
            draw(
                &mut fixture,
                time,
                vec![
                    egui::Event::PointerMoved(pos),
                    egui::Event::PointerButton {
                        pos,
                        button: egui::PointerButton::Primary,
                        pressed,
                        modifiers: Default::default(),
                    },
                ],
            );
        }
        for _ in 0..40 {
            time += 0.02;
            draw(&mut fixture, time, vec![]);
        }
        assert_eq!(fixture.settings.appearance.theme, mode);
        assert_eq!(
            ctx.global_style().visuals.dark_mode,
            mode == crate::settings::ThemeMode::Dark
        );
        assert_eq!(fixture.settings.audio, audio);
    }
}

/// Run with cargo test native_resize_preview -- --ignored --nocapture.
/// This is a separate offline test window; the shipping app has no preview controls.
#[test]
#[cfg(target_os = "windows")]
#[ignore = "interactive native window for manual resize verification"]
fn native_resize_preview() {
    use winit::platform::windows::EventLoopBuilderExtWindows;
    const SIZES: [[f32; 2]; 7] = [
        [900., 650.],
        [1024., 768.],
        [1280., 720.],
        [1366., 768.],
        [1600., 900.],
        [1920., 1080.],
        [2560., 1440.],
    ];
    const NAMES: [&str; 12] = [
        "search",
        "likes",
        "library",
        "history",
        "accounts",
        "settings",
        "equalizer",
        "queue",
        "audio-popup",
        "bass-studio",
        "clear-optics",
        "appearance",
    ];
    struct Preview {
        fixture: Fixture,
        capture: Option<std::path::PathBuf>,
        scene: usize,
        frames: usize,
        scene_only: bool,
        bottom: bool,
        optical_probe: Option<(egui::Pos2, egui::Pos2, f32)>,
    }
    impl eframe::App for Preview {
        fn logic(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
            if let Some(directory) = &self.capture {
                for event in ctx.input(|i| i.events.clone()) {
                    if let egui::Event::Screenshot { image, .. } = event {
                        if self.scene % NAMES.len() == 10 {
                            let (outside, inside, scale) = self.optical_probe.unwrap();
                            let sample = |p: egui::Pos2| {
                                image.pixels[(p.y * scale) as usize * image.size[0]
                                    + (p.x * scale) as usize]
                            };
                            let a = sample(outside).to_array();
                            let b = sample(inside).to_array();
                            let difference = (0..3).map(|i| a[i].abs_diff(b[i])).max().unwrap();
                            assert!(
                                difference <= 35,
                                "glass obscures the backdrop: {a:?} -> {b:?}"
                            );
                            println!("Clear center pixel difference: {difference}/255");
                        }
                        let size = SIZES[self.scene / NAMES.len()];
                        let name = format!(
                            "{}x{}-{}.png",
                            size[0],
                            size[1],
                            NAMES[self.scene % NAMES.len()]
                        );
                        let bytes: Vec<u8> =
                            image.pixels.iter().flat_map(|p| p.to_array()).collect();
                        image::save_buffer(
                            directory.join(&name),
                            &bytes,
                            image.size[0] as u32,
                            image.size[1] as u32,
                            image::ColorType::Rgba8,
                        )
                        .unwrap();
                        println!("Captured {name}: {}x{}", image.size[0], image.size[1]);
                        self.scene += if self.scene_only { NAMES.len() } else { 1 };
                        self.frames = 0;
                        if self.scene >= SIZES.len() * NAMES.len() {
                            ctx.send_viewport_cmd(egui::ViewportCommand::Close);
                        }
                    }
                }
            }
        }
        fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
            if self.capture.is_some() && self.scene < SIZES.len() * NAMES.len() {
                if self.frames == 0 {
                    let size = SIZES[self.scene / NAMES.len()];
                    ui.ctx()
                        .send_viewport_cmd(egui::ViewportCommand::InnerSize(size.into()));
                    let mode = self.scene % NAMES.len();
                    self.fixture.state.page = match mode {
                        0 => MusicPage::Search,
                        1 => MusicPage::LikedSongs,
                        2 => MusicPage::SmartLibrary,
                        3 => MusicPage::History,
                        4 => MusicPage::Connections,
                        _ => MusicPage::Settings,
                    };
                    self.fixture.state.settings_section = if mode == 11 {
                        SettingsSection::Appearance
                    } else if mode == 9 {
                        SettingsSection::BassStudio
                    } else if mode == 6 {
                        SettingsSection::Audio
                    } else {
                        SettingsSection::General
                    };
                    if self.scene_only {
                        ui.ctx().data_mut(|d| {
                            d.insert_temp(
                                egui::Id::new("preview-settings-scroll"),
                                if self.bottom { 100000.0_f32 } else { 0.0_f32 },
                            )
                        });
                    }
                    if mode == 9 {
                        self.fixture.settings.audio.bass_studio.enabled = true;
                        self.fixture.settings.audio.bass_studio.bands[1].gain_db = 4.0;
                        self.fixture.settings.audio.bass_studio.bands[2].gain_db = 3.0;
                        self.fixture.settings.audio.bass_studio.bands[3].gain_db = -1.0;
                    }
                    self.fixture.state.queue_open = mode == 7;
                    self.fixture.state.audio_popup_open = mode == 8;
                }
                self.frames += 1;
                if self.frames == 8 {
                    if std::env::var_os("SPOTEQ_EXPECT_GLASS_GPU").is_some() {
                        super::glass::validate_renderer(ui.ctx())
                            .expect("real framebuffer glass must render successfully");
                    }
                    ui.ctx()
                        .send_viewport_cmd(egui::ViewportCommand::Screenshot(Default::default()));
                }
                ui.ctx()
                    .request_repaint_after(std::time::Duration::from_millis(16));
            }
            if self.capture.is_some() && self.scene % NAMES.len() == 10 {
                super::motion::configure(ui.ctx(), &self.fixture.settings.appearance);
                let (outside, inside) = super::glass::optical_preview(ui);
                self.optical_probe = Some((outside, inside, ui.ctx().pixels_per_point()));
            } else {
                self.fixture.show(ui);
            }
        }
    }
    eframe::run_native(
        "Spoteq — offline resize preview",
        eframe::NativeOptions {
            viewport: egui::ViewportBuilder::default()
                .with_title("Spoteq — offline resize preview")
                .with_inner_size([900.0, 650.0])
                .with_min_inner_size([900.0, 650.0])
                .with_decorations(false)
                .with_clamp_size_to_monitor_size(false),
            event_loop_builder: Some(Box::new(|builder| {
                builder.with_any_thread(true);
            })),
            ..Default::default()
        },
        Box::new(|cc| {
            let capture = std::env::var_os("SPOTEQ_CAPTURE_DIR").map(std::path::PathBuf::from);
            if let Some(directory) = &capture {
                std::fs::create_dir_all(directory).unwrap();
            }
            let only_scene = std::env::var("SPOTEQ_CAPTURE_SCENE")
                .ok()
                .and_then(|name| NAMES.iter().position(|candidate| *candidate == name))
                .or_else(|| {
                    std::env::var_os("SPOTEQ_CAPTURE_BASS_ONLY")
                        .is_some()
                        .then_some(9)
                });
            Ok(Box::new(Preview {
                fixture: {
                    let mut fixture = Fixture::new(&cc.egui_ctx);
                    if std::env::var("SPOTEQ_PREVIEW_THEME").as_deref() == Ok("light") {
                        fixture.settings.appearance.theme = crate::settings::ThemeMode::Light;
                    }
                    fixture
                },
                capture,
                scene: only_scene.unwrap_or(0),
                scene_only: only_scene.is_some(),
                bottom: std::env::var_os("SPOTEQ_CAPTURE_BOTTOM").is_some(),
                frames: 0,
                optical_probe: None,
            }))
        }),
    )
    .unwrap();
}
