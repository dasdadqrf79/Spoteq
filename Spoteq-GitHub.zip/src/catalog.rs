//! Provider-neutral track metadata shared by Search and Library UI.

use crate::spotify::Track;
use serde::{Deserialize, Serialize};

/// Music service that owns a catalog item.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TrackProvider {
    /// Spotify Web API and local librespot playback.
    Spotify,
    /// SoundCloud API and the native SoundCloud playback backend.
    SoundCloud,
}

/// Provider-specific identity retained for future playback integrations.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum ProviderTrackId {
    /// Spotify catalog ID and librespot URI.
    Spotify {
        /// Spotify track ID.
        id: String,
        /// Full `spotify:track:...` URI.
        uri: String,
    },
    /// SoundCloud numeric ID, URN and public URL.
    SoundCloud {
        /// SoundCloud track ID preserved as returned by the API.
        id: String,
        /// Stable SoundCloud URN when returned by the API.
        urn: Option<String>,
        /// Public SoundCloud track URL when returned by the API.
        permalink_url: Option<String>,
    },
}

/// Common row rendered by both Search and Liked Songs.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TrackRow {
    /// Owning service.
    pub provider: TrackProvider,
    /// Identity required by the owning service.
    pub provider_id: ProviderTrackId,
    /// Display title.
    pub title: String,
    /// Artist, uploader or publisher name.
    pub artist: String,
    /// Album or provider context shown below the title.
    pub collection: String,
    /// Duration in milliseconds.
    pub duration_ms: u64,
    /// Best available artwork URL.
    pub artwork_url: Option<String>,
    /// Provider-backed saved/liked state when known from an API response.
    pub liked: Option<bool>,
    /// Whether the provider currently reports this track as playable.
    pub playable: bool,
}

impl TrackRow {
    /// Creates a UI row without changing the existing Spotify track model.
    pub fn from_spotify(track: &Track) -> Self {
        Self {
            provider: TrackProvider::Spotify,
            provider_id: ProviderTrackId::Spotify {
                id: track.id.clone(),
                uri: track.uri.clone(),
            },
            title: track.name.clone(),
            artist: track.artists.clone(),
            collection: track.album.clone(),
            duration_ms: track.duration_ms,
            artwork_url: track.image_url.clone(),
            liked: Some(track.saved),
            playable: true,
        }
    }

    /// Stable provider-qualified key used by row animations and selections.
    pub fn stable_key(&self) -> String {
        match &self.provider_id {
            ProviderTrackId::Spotify { uri, .. } => format!("spotify:{uri}"),
            ProviderTrackId::SoundCloud { id, urn, .. } => urn
                .as_ref()
                .map(|urn| format!("soundcloud:{urn}"))
                .unwrap_or_else(|| format!("soundcloud:{id}")),
        }
    }

    /// Returns the Spotify URI only for Spotify-owned rows.
    pub fn spotify_uri(&self) -> Option<&str> {
        match &self.provider_id {
            ProviderTrackId::Spotify { uri, .. } => Some(uri),
            ProviderTrackId::SoundCloud { .. } => None,
        }
    }

    /// Reconstructs an existing Spotify queue item; SoundCloud never enters librespot.
    pub fn to_spotify_track(&self) -> Option<Track> {
        let ProviderTrackId::Spotify { id, uri } = &self.provider_id else {
            return None;
        };
        Some(Track {
            id: id.clone(),
            uri: uri.clone(),
            name: self.title.clone(),
            artists: self.artist.clone(),
            album: self.collection.clone(),
            duration_ms: self.duration_ms,
            image_url: self.artwork_url.clone(),
            saved: self.liked.unwrap_or(false),
        })
    }
}

/// Cursor-based page returned by SoundCloud collection endpoints.
#[derive(Debug, Clone)]
pub struct TrackPage {
    /// Tracks returned in provider order.
    pub items: Vec<TrackRow>,
    /// Opaque absolute continuation URL supplied by SoundCloud.
    pub next_href: Option<String>,
}

/// Provider selection shared by Search and Liked Songs.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ProviderFilter {
    /// Query and show both connected services.
    All,
    /// Show Spotify only.
    Spotify,
    /// Show SoundCloud only.
    SoundCloud,
}

/// Catalog context used by the Search tabs. Every scope still resolves to
/// playable tracks, so selecting an artist, album or playlist never creates a
/// second, incompatible result model.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SearchScope {
    /// Match track titles and general catalog relevance.
    Tracks,
    /// Find tracks by matching artist names.
    Artists,
    /// Find tracks belonging to matching albums.
    Albums,
    /// Find tracks contained in matching playlists.
    Playlists,
}

impl SearchScope {
    /// Stable UI label for the scope selector.
    pub const fn label(self) -> &'static str {
        match self {
            Self::Tracks => "Tracks",
            Self::Artists => "Artists",
            Self::Albums => "Albums",
            Self::Playlists => "Playlists",
        }
    }

    /// All user-selectable scopes in display order.
    pub const ALL: [Self; 4] = [Self::Tracks, Self::Artists, Self::Albums, Self::Playlists];
}

impl ProviderFilter {
    /// Whether Spotify belongs to this selection.
    pub fn includes_spotify(self) -> bool {
        matches!(self, Self::All | Self::Spotify)
    }

    /// Whether SoundCloud belongs to this selection.
    pub fn includes_soundcloud(self) -> bool {
        matches!(self, Self::All | Self::SoundCloud)
    }
}
