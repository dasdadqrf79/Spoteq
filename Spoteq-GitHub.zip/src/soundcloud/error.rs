//! Recoverable SoundCloud configuration, OAuth and API failures.

use thiserror::Error;

/// Error returned by the independent SoundCloud integration.
#[derive(Debug, Error)]
pub enum SoundCloudError {
    /// A required environment variable is missing.
    #[error("missing SoundCloud configuration: {0}")]
    MissingConfiguration(&'static str),
    /// The configured redirect URI cannot be used by the local callback listener.
    #[error("invalid SoundCloud redirect URI: {0}")]
    InvalidRedirect(String),
    /// Windows could not register Spoteq as the owner of the custom URI scheme.
    #[error("could not register the eqspot:// URL protocol: {0}")]
    ProtocolRegistration(String),
    /// The custom-protocol callback could not reach the authorizing Spoteq process.
    #[error("SoundCloud protocol callback failed: {0}")]
    ProtocolCallback(String),
    /// A local token file operation failed.
    #[error("SoundCloud token storage failed: {0}")]
    Io(#[from] std::io::Error),
    /// A local token file is malformed.
    #[error("SoundCloud token data is invalid: {0}")]
    Json(#[from] serde_json::Error),
    /// An HTTP request failed before a response was received.
    #[error("SoundCloud request failed: {0}")]
    Http(#[from] reqwest::Error),
    /// A URL could not be parsed.
    #[error("SoundCloud URL is invalid: {0}")]
    Url(#[from] url::ParseError),
    /// A pagination URL did not point back to the official SoundCloud API.
    #[error("SoundCloud returned an unsafe pagination URL")]
    InvalidApiUrl,
    /// The system browser could not be opened.
    #[error("could not open SoundCloud authorization: {0}")]
    Browser(String),
    /// The callback did not contain the expected state or authorization code.
    #[error("SoundCloud returned an invalid OAuth callback")]
    InvalidCallback,
    /// The user or authorization server rejected the request.
    #[error("SoundCloud authorization was denied: {0}")]
    AuthorizationDenied(String),
    /// The local callback did not arrive within the allowed time.
    #[error("SoundCloud authorization timed out")]
    AuthorizationTimeout,
    /// SoundCloud rejected an OAuth or API request.
    #[error("SoundCloud API returned HTTP {status}: {message}")]
    Api {
        /// HTTP status code.
        status: u16,
        /// Response body or normalized error text.
        message: String,
    },
    /// The API rate limit was exceeded.
    #[error("SoundCloud rate limit reached{retry_after}")]
    RateLimited {
        /// Human-readable retry hint derived from the `Retry-After` header.
        retry_after: String,
    },
    /// A playable track had no supported full-track SoundCloud stream.
    #[error("SoundCloud did not provide a supported full-track stream")]
    NoPlayableStream,
    /// HLS manifest or media data could not be decoded.
    #[error("SoundCloud playback failed: {0}")]
    Playback(String),
    /// No stored user token is available.
    #[error("SoundCloud is not connected")]
    NotAuthenticated,
    /// Secure random generation failed.
    #[error("could not generate SoundCloud PKCE data: {0}")]
    Random(String),
    /// The background service stopped.
    #[error("SoundCloud service stopped unexpectedly")]
    RuntimeStopped,
    /// The operating system did not provide a per-user data directory.
    #[error("SoundCloud token directory is unavailable")]
    DataDirectoryUnavailable,
}
