//! Private per-user persistence for SoundCloud OAuth tokens.

use std::{
    fs::{self, File},
    io::{BufReader, BufWriter, Write},
    path::{Path, PathBuf},
};

use crate::{
    soundcloud::{SoundCloudError, auth::StoredSoundCloudToken},
    storage::{DirectoryKind, app_directory},
};

#[derive(Debug, Clone)]
pub(crate) struct SoundCloudTokenStore {
    path: PathBuf,
}

impl SoundCloudTokenStore {
    pub fn discover() -> Result<Self, SoundCloudError> {
        let path = app_directory(DirectoryKind::DataLocal)
            .map(|directory| directory.join("soundcloud-token.json"))
            .ok_or(SoundCloudError::DataDirectoryUnavailable)?;
        Ok(Self { path })
    }

    pub fn load(&self) -> Result<Option<StoredSoundCloudToken>, SoundCloudError> {
        let temporary = self.path.with_extension("json.tmp");
        if temporary.exists() {
            // A refresh token is single-use. If a process stopped during the
            // atomic swap, the temporary file is the newest valid generation.
            let token = read_token(&temporary)?;
            self.install_recovered_temporary(&temporary)?;
            return Ok(Some(token));
        }
        match File::open(&self.path) {
            Ok(file) => Ok(Some(serde_json::from_reader(BufReader::new(file))?)),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(None),
            Err(error) => Err(error.into()),
        }
    }

    pub fn save(&self, token: &StoredSoundCloudToken) -> Result<(), SoundCloudError> {
        if let Some(parent) = self.path.parent() {
            fs::create_dir_all(parent)?;
        }
        let temporary = self.path.with_extension("json.tmp");
        {
            let file = create_private_file(&temporary)?;
            let mut writer = BufWriter::new(file);
            serde_json::to_writer_pretty(&mut writer, token)?;
            writer.write_all(b"\n")?;
            writer.flush()?;
            writer.get_ref().sync_all()?;
        }
        if !self.path.exists() {
            fs::rename(temporary, &self.path)?;
            return Ok(());
        }

        // Windows cannot replace an existing file with rename. Keep a rollback
        // copy until the newly rotated, single-use refresh token is in place.
        let backup = self.path.with_extension("json.bak");
        remove_if_present(&backup)?;
        fs::rename(&self.path, &backup)?;
        if let Err(error) = fs::rename(&temporary, &self.path) {
            let _ = fs::rename(&backup, &self.path);
            return Err(error.into());
        }
        if let Err(error) = remove_if_present(&backup) {
            tracing::warn!(%error, "stale SoundCloud token backup could not be removed");
        }
        Ok(())
    }

    fn install_recovered_temporary(&self, temporary: &Path) -> Result<(), SoundCloudError> {
        let backup = self.path.with_extension("json.bak");
        remove_if_present(&backup)?;
        if self.path.exists() {
            fs::rename(&self.path, &backup)?;
        }
        if let Err(error) = fs::rename(temporary, &self.path) {
            let _ = fs::rename(&backup, &self.path);
            return Err(error.into());
        }
        if let Err(error) = remove_if_present(&backup) {
            tracing::warn!(%error, "stale SoundCloud token backup could not be removed");
        }
        Ok(())
    }

    pub fn clear(&self) -> Result<(), SoundCloudError> {
        remove_if_present(&self.path)?;
        remove_if_present(&self.path.with_extension("json.tmp"))?;
        remove_if_present(&self.path.with_extension("json.bak"))?;
        Ok(())
    }
}

fn read_token(path: &Path) -> Result<StoredSoundCloudToken, SoundCloudError> {
    let file = File::open(path)?;
    Ok(serde_json::from_reader(BufReader::new(file))?)
}

fn remove_if_present(path: &Path) -> Result<(), std::io::Error> {
    match fs::remove_file(path) {
        Ok(()) => Ok(()),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(()),
        Err(error) => Err(error),
    }
}

#[cfg(unix)]
fn create_private_file(path: &Path) -> Result<File, std::io::Error> {
    use std::os::unix::fs::OpenOptionsExt;
    fs::OpenOptions::new()
        .create(true)
        .truncate(true)
        .write(true)
        .mode(0o600)
        .open(path)
}

#[cfg(not(unix))]
fn create_private_file(path: &Path) -> Result<File, std::io::Error> {
    File::create(path)
}
