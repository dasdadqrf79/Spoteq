//! Reusable authenticated SoundCloud API client.

use reqwest::{Client, Method, Response, StatusCode};
use serde::de::DeserializeOwned;
use url::Url;

use crate::catalog::TrackPage;
use crate::soundcloud::{
    SoundCloudError, SoundCloudProfile,
    auth::SharedSoundCloudAuth,
    model::{RawTrackPage, SoundCloudStreams},
};

const API_ROOT: &str = "https://api.soundcloud.com";

#[derive(Debug)]
pub(crate) struct SoundCloudMedia {
    pub bytes: Vec<u8>,
    pub final_url: Url,
}

/// Stateless facade for current and future user-scoped SoundCloud endpoints.
#[derive(Clone)]
pub(crate) struct SoundCloudApi {
    client: Client,
    auth: SharedSoundCloudAuth,
}

impl SoundCloudApi {
    pub fn new(client: Client, auth: SharedSoundCloudAuth) -> Self {
        Self { client, auth }
    }

    /// Returns the account associated with the authorization-code token.
    pub async fn me(&self) -> Result<SoundCloudProfile, SoundCloudError> {
        self.get_json("/me", &[]).await
    }

    /// Searches only tracks SoundCloud reports as playable.
    pub async fn search_tracks(
        &self,
        query: &str,
        next_href: Option<&str>,
    ) -> Result<TrackPage, SoundCloudError> {
        let raw: RawTrackPage = if let Some(next_href) = next_href {
            self.get_json_url(next_href).await?
        } else {
            self.get_json(
                "/tracks",
                &[
                    ("q", query),
                    ("access", "playable"),
                    ("linked_partitioning", "true"),
                    ("limit", "50"),
                ],
            )
            .await?
        };
        Ok(raw.into_page())
    }

    /// Returns the authenticated account's real liked tracks.
    pub async fn liked_tracks(
        &self,
        next_href: Option<&str>,
    ) -> Result<TrackPage, SoundCloudError> {
        let raw: RawTrackPage = if let Some(next_href) = next_href {
            self.get_json_url(next_href).await?
        } else {
            self.get_json(
                "/me/likes/tracks",
                &[("linked_partitioning", "true"), ("limit", "50")],
            )
            .await?
        };
        let mut page = raw.into_page();
        for track in &mut page.items {
            track.liked = Some(true);
        }
        Ok(page)
    }

    /// Reads provider-native like state for one SoundCloud track URN.
    pub async fn is_track_liked(&self, track_urn: &str) -> Result<bool, SoundCloudError> {
        let path = format!("/likes/tracks/{track_urn}");
        let response = self.request(Method::GET, &path, &[]).await?;
        if response.status() == StatusCode::NOT_FOUND {
            return Ok(false);
        }
        checked(response).await?;
        Ok(true)
    }

    /// Mutates the real SoundCloud account likes collection.
    pub async fn set_track_liked(
        &self,
        track_urn: &str,
        liked: bool,
    ) -> Result<(), SoundCloudError> {
        let path = format!("/likes/tracks/{track_urn}");
        let method = if liked { Method::POST } else { Method::DELETE };
        let response = self.request(method, &path, &[]).await?;
        checked(response).await?;
        Ok(())
    }

    /// Returns SoundCloud's real related-track station for one catalog URN.
    pub async fn related_tracks(
        &self,
        track_urn: &str,
        limit: usize,
    ) -> Result<TrackPage, SoundCloudError> {
        let path = format!("/tracks/{track_urn}/related");
        let limit = limit.clamp(1, 50).to_string();
        let raw: RawTrackPage = self
            .get_json(
                &path,
                &[
                    ("access", "playable"),
                    ("linked_partitioning", "true"),
                    ("limit", &limit),
                ],
            )
            .await?;
        Ok(raw.into_page())
    }

    /// Resolves the current authenticated AAC HLS URLs for one playable track.
    pub async fn streams(&self, track_urn: &str) -> Result<SoundCloudStreams, SoundCloudError> {
        let path = format!("/tracks/{track_urn}/streams");
        self.get_json(&path, &[]).await
    }

    /// Downloads an HLS manifest or media segment and preserves the final URL
    /// after redirects so relative HLS segment URLs resolve against the CDN, not
    /// the SoundCloud API resolver URL. SoundCloud API resolver URLs are
    /// authenticated; CDN URLs are intentionally fetched without the OAuth token.
    pub async fn media_resource(&self, url: &str) -> Result<SoundCloudMedia, SoundCloudError> {
        let parsed = Url::parse(url)?;
        if parsed.scheme() != "https" {
            return Err(SoundCloudError::InvalidApiUrl);
        }

        let is_api = parsed.host_str() == Some("api.soundcloud.com");
        let mut response = if is_api {
            let access_token = self.auth.access_token(&self.client).await?;
            self.client
                .get(parsed.clone())
                .header(reqwest::header::ACCEPT, "*/*")
                .header(
                    reqwest::header::AUTHORIZATION,
                    format!("OAuth {access_token}"),
                )
                .send()
                .await?
        } else {
            self.client
                .get(parsed.clone())
                .header(reqwest::header::ACCEPT, "*/*")
                .send()
                .await?
        };

        tracing::info!(
            status = response.status().as_u16(),
            host = parsed.host_str().unwrap_or("unknown"),
            path = parsed.path(),
            authenticated = is_api,
            "SoundCloud media response status"
        );

        if is_api && response.status() == StatusCode::UNAUTHORIZED {
            let refreshed = self.auth.force_refresh(&self.client).await?;
            response = self
                .client
                .get(parsed.clone())
                .header(reqwest::header::ACCEPT, "*/*")
                .header(reqwest::header::AUTHORIZATION, format!("OAuth {refreshed}"))
                .send()
                .await?;
            tracing::info!(
                status = response.status().as_u16(),
                host = parsed.host_str().unwrap_or("unknown"),
                path = parsed.path(),
                "SoundCloud media retry status after token refresh"
            );
        }

        let response = checked(response).await?;
        let final_url = response.url().clone();
        let bytes = response.bytes().await?.to_vec();
        Ok(SoundCloudMedia { bytes, final_url })
    }

    /// Generic authenticated GET used as the base for future Search and Likes clients.
    pub async fn get_json<T: DeserializeOwned>(
        &self,
        path: &str,
        query: &[(&str, &str)],
    ) -> Result<T, SoundCloudError> {
        let response = self.request(Method::GET, path, query).await?;
        parse_json(response).await
    }

    async fn get_json_url<T: DeserializeOwned>(
        &self,
        next_href: &str,
    ) -> Result<T, SoundCloudError> {
        let url = Url::parse(next_href)?;
        if url.scheme() != "https" || url.host_str() != Some("api.soundcloud.com") {
            return Err(SoundCloudError::InvalidApiUrl);
        }
        let response = self.request_url(Method::GET, url.as_str(), &[]).await?;
        parse_json(response).await
    }

    async fn request(
        &self,
        method: Method,
        path: &str,
        query: &[(&str, &str)],
    ) -> Result<Response, SoundCloudError> {
        let url = format!("{API_ROOT}{path}");
        self.request_url(method, &url, query).await
    }

    async fn request_url(
        &self,
        method: Method,
        url: &str,
        query: &[(&str, &str)],
    ) -> Result<Response, SoundCloudError> {
        let mut access_token = self.auth.access_token(&self.client).await?;
        let mut response = match self.send(&method, url, query, &access_token).await {
            Ok(response) => response,
            Err(SoundCloudError::Http(error))
                if method == Method::GET && (error.is_timeout() || error.is_connect()) =>
            {
                tracing::warn!(url, "Retrying transient SoundCloud network failure");
                tokio::time::sleep(std::time::Duration::from_millis(350)).await;
                self.send(&method, url, query, &access_token).await?
            }
            Err(error) => return Err(error),
        };

        tracing::info!(
            status = response.status().as_u16(),
            url,
            "SoundCloud response status"
        );

        if response.status() == StatusCode::UNAUTHORIZED {
            access_token = self.auth.force_refresh(&self.client).await?;
            response = self.send(&method, url, query, &access_token).await?;
            tracing::info!(
                status = response.status().as_u16(),
                url,
                "SoundCloud response status after token refresh"
            );
        }

        if let Some(delay) = short_retry_delay(&response) {
            tracing::warn!(
                status = response.status().as_u16(),
                delay_ms = delay.as_millis(),
                url,
                "Retrying transient SoundCloud API response"
            );
            tokio::time::sleep(delay).await;
            response = self.send(&method, url, query, &access_token).await?;
        }
        Ok(response)
    }

    async fn send(
        &self,
        method: &Method,
        url: &str,
        query: &[(&str, &str)],
        access_token: &str,
    ) -> Result<Response, SoundCloudError> {
        Ok(self
            .client
            .request(method.clone(), url)
            .header(reqwest::header::ACCEPT, "application/json; charset=utf-8")
            .header(
                reqwest::header::AUTHORIZATION,
                format!("OAuth {access_token}"),
            )
            .query(query)
            .send()
            .await?)
    }
}

fn short_retry_delay(response: &Response) -> Option<std::time::Duration> {
    let status = response.status();
    if status == StatusCode::TOO_MANY_REQUESTS {
        let seconds = response
            .headers()
            .get(reqwest::header::RETRY_AFTER)?
            .to_str()
            .ok()?
            .parse::<u64>()
            .ok()?;
        return (seconds <= 5).then(|| std::time::Duration::from_secs(seconds.max(1)));
    }
    status
        .is_server_error()
        .then(|| std::time::Duration::from_millis(500))
}

async fn parse_json<T: DeserializeOwned>(response: Response) -> Result<T, SoundCloudError> {
    let response = checked(response).await?;
    Ok(response.json().await?)
}

async fn checked(response: Response) -> Result<Response, SoundCloudError> {
    let status = response.status();
    if status.is_success() {
        return Ok(response);
    }
    if status == StatusCode::TOO_MANY_REQUESTS {
        let retry_after = response
            .headers()
            .get(reqwest::header::RETRY_AFTER)
            .and_then(|value| value.to_str().ok())
            .map(|value| format!("; retry after {value}"))
            .unwrap_or_else(|| "; try again shortly".to_owned());
        return Err(SoundCloudError::RateLimited { retry_after });
    }
    let message = response
        .text()
        .await
        .unwrap_or_else(|_| "unknown SoundCloud API error".to_owned());
    Err(SoundCloudError::Api {
        status: status.as_u16(),
        message: compact_error_message(status, &message),
    })
}

fn compact_error_message(status: StatusCode, body: &str) -> String {
    if let Ok(value) = serde_json::from_str::<serde_json::Value>(body)
        && let Some(message) = value
            .get("message")
            .or_else(|| value.get("error").and_then(|error| error.get("message")))
            .and_then(|message| message.as_str())
    {
        return message.to_owned();
    }
    let trimmed = body.trim();
    if trimmed.starts_with('<') || trimmed.len() > 320 {
        return status
            .canonical_reason()
            .unwrap_or("SoundCloud API request failed")
            .to_owned();
    }
    trimmed.to_owned()
}
#[cfg(test)]
mod tests {
    use super::compact_error_message;
    use reqwest::StatusCode;

    #[test]
    fn soundcloud_error_bodies_are_bounded_for_toasts() {
        assert_eq!(
            compact_error_message(StatusCode::FORBIDDEN, r#"{"message":"Access denied"}"#),
            "Access denied"
        );
        assert_eq!(
            compact_error_message(StatusCode::BAD_GATEWAY, "<html>proxy failure</html>"),
            "Bad Gateway"
        );
    }
}
