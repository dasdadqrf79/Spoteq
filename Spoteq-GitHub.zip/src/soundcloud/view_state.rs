//! UI-owned SoundCloud connection, Search and Library snapshots.

use std::{
    sync::atomic::{AtomicU64, Ordering},
    time::{Duration, Instant},
};

use crate::catalog::TrackRow;
use crate::soundcloud::{
    PublicSoundCloudConfig, SoundCloudCommand, SoundCloudEvent, SoundCloudProfile,
    SoundCloudRuntime,
};
use crate::spotify::PlaybackStatus;

const SEARCH_DEBOUNCE: Duration = Duration::from_millis(300);

/// Current SoundCloud authorization state displayed on Connections.
#[derive(Debug, Clone)]
pub enum SoundCloudAuthView {
    /// Configuration and stored credentials are being inspected.
    Restoring,
    /// Configuration is valid but no user token is stored.
    LoggedOut,
    /// Browser authorization is in progress.
    Authorizing,
    /// A real account was verified through `GET /me`.
    LoggedIn(SoundCloudProfile),
    /// Required process configuration is missing or invalid.
    ConfigurationError,
    /// OAuth failed while the rest of the application remains usable.
    AuthError,
    /// `GET /me` or another authenticated API request failed.
    ApiError,
}

/// Loading state for a SoundCloud Search request.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SoundCloudSearchStatus {
    /// Query is empty.
    Idle,
    /// Waiting for the shared 300 ms debounce.
    Debouncing,
    /// First page is loading.
    Loading,
    /// At least one row is available.
    Ready,
    /// The provider returned no playable rows.
    Empty,
    /// The first page failed.
    Error,
}

/// Cursor-paginated SoundCloud Search state.
#[derive(Debug)]
pub struct SoundCloudSearchView {
    /// Current first-page state.
    pub status: SoundCloudSearchStatus,
    /// Provider-neutral rows returned by `/tracks`.
    pub tracks: Vec<TrackRow>,
    /// Opaque URL returned by SoundCloud for the next page.
    pub next_href: Option<String>,
    /// Whether a continuation request is running.
    pub loading_more: bool,
    /// Most recent first-page or pagination error.
    pub error: Option<String>,
    generation: u64,
    edit_time: Option<Instant>,
}

impl Default for SoundCloudSearchView {
    fn default() -> Self {
        Self {
            status: SoundCloudSearchStatus::Idle,
            tracks: Vec::new(),
            next_href: None,
            loading_more: false,
            error: None,
            generation: 0,
            edit_time: None,
        }
    }
}

static NEXT_LIKES_REVISION: AtomicU64 = AtomicU64::new(1);

/// Cursor-paginated SoundCloud liked-track state.
#[derive(Debug)]
pub struct SoundCloudLikesView {
    /// Provider-neutral rows returned by `/me/likes/tracks`.
    pub tracks: Vec<TrackRow>,
    /// Opaque URL returned by SoundCloud for the next page.
    pub next_href: Option<String>,
    /// Whether the first or next page is loading.
    pub loading: bool,
    /// Whether the first request has completed.
    pub loaded_once: bool,
    /// Most recent first-page or pagination error.
    pub error: Option<String>,
    /// Changes only when the loaded provider library changes.
    pub revision: u64,
    generation: u64,
}

impl Default for SoundCloudLikesView {
    fn default() -> Self {
        Self {
            tracks: Vec::new(),
            next_href: None,
            loading: false,
            loaded_once: false,
            error: None,
            revision: NEXT_LIKES_REVISION.fetch_add(1, Ordering::Relaxed),
            generation: 0,
        }
    }
}

/// UI snapshot of the independent native SoundCloud player.
#[derive(Debug)]
pub struct SoundCloudPlaybackView {
    pub track: Option<TrackRow>,
    pub status: PlaybackStatus,
    pub position_ms: u32,
    pub queue_index: Option<usize>,
    pub queue_len: usize,
    pub seek_preview_ms: Option<u32>,
    position_updated_at: Instant,
}

impl Default for SoundCloudPlaybackView {
    fn default() -> Self {
        Self {
            track: None,
            status: PlaybackStatus::Idle,
            position_ms: 0,
            queue_index: None,
            queue_len: 0,
            seek_preview_ms: None,
            position_updated_at: Instant::now(),
        }
    }
}

impl SoundCloudPlaybackView {
    pub fn displayed_position_ms(&self) -> u32 {
        if let Some(preview) = self.seek_preview_ms {
            return preview;
        }
        let elapsed = if self.status == PlaybackStatus::Playing {
            self.position_updated_at.elapsed().as_millis() as u64
        } else {
            0
        };
        let duration = self
            .track
            .as_ref()
            .map(|track| track.duration_ms)
            .unwrap_or(0);
        u64::from(self.position_ms)
            .saturating_add(elapsed)
            .min(duration)
            .min(u64::from(u32::MAX)) as u32
    }
    pub fn has_next(&self) -> bool {
        self.queue_index
            .is_some_and(|index| index + 1 < self.queue_len)
    }
}

/// SoundCloud state owned exclusively by the egui thread.
#[derive(Debug)]
pub struct SoundCloudViewState {
    /// Current connection lifecycle.
    pub auth: SoundCloudAuthView,
    /// Safe configured values; never contains the client secret.
    pub config: Option<PublicSoundCloudConfig>,
    /// Most recent OAuth/configuration failure.
    pub auth_error: Option<String>,
    /// Most recent authenticated API failure.
    pub api_error: Option<String>,
    /// SoundCloud half of unified Search.
    pub search: SoundCloudSearchView,
    /// SoundCloud half of unified Liked Songs.
    pub likes: SoundCloudLikesView,
    /// Native SoundCloud playback state.
    pub playback: SoundCloudPlaybackView,
}

impl Default for SoundCloudViewState {
    fn default() -> Self {
        Self {
            auth: SoundCloudAuthView::Restoring,
            config: None,
            auth_error: None,
            api_error: None,
            search: SoundCloudSearchView::default(),
            likes: SoundCloudLikesView::default(),
            playback: SoundCloudPlaybackView::default(),
        }
    }
}

impl SoundCloudViewState {
    /// True only after `/me` has verified the restored or new token.
    pub fn is_authenticated(&self) -> bool {
        matches!(
            &self.auth,
            SoundCloudAuthView::LoggedIn(_) | SoundCloudAuthView::ApiError
        )
    }

    /// Restarts SoundCloud's non-blocking 300 ms Search debounce.
    pub fn search_edited(&mut self, query: &str) {
        self.search.generation = self.search.generation.wrapping_add(1);
        self.search.error = None;
        self.search.next_href = None;
        self.search.loading_more = false;
        self.search.edit_time = Some(Instant::now());
        if query.trim().is_empty() {
            self.search.status = SoundCloudSearchStatus::Idle;
            self.search.tracks.clear();
            self.search.edit_time = None;
        } else {
            self.search.status = SoundCloudSearchStatus::Debouncing;
        }
    }

    /// Dispatches a matured SoundCloud Search without blocking egui.
    pub fn dispatch_search(&mut self, query: &str, runtime: &SoundCloudRuntime) {
        if self.search.status != SoundCloudSearchStatus::Debouncing || !self.is_authenticated() {
            return;
        }
        let Some(edit_time) = self.search.edit_time else {
            return;
        };
        if edit_time.elapsed() < SEARCH_DEBOUNCE {
            return;
        }
        let command = SoundCloudCommand::Search {
            query: query.trim().to_owned(),
            generation: self.search.generation,
        };
        match runtime.send(command) {
            Ok(()) => {
                self.search.status = SoundCloudSearchStatus::Loading;
                self.search.edit_time = None;
            }
            Err(error) => {
                self.search.status = SoundCloudSearchStatus::Error;
                self.search.error = Some(error.to_string());
            }
        }
    }

    /// Requests the opaque next Search page once.
    pub fn load_more_search(&mut self, query: &str, runtime: &SoundCloudRuntime) {
        if self.search.loading_more || !self.is_authenticated() {
            return;
        }
        let Some(next_href) = self.search.next_href.clone() else {
            return;
        };
        self.search.loading_more = true;
        self.search.error = None;
        if let Err(error) = runtime.send(SoundCloudCommand::SearchNext {
            query: query.trim().to_owned(),
            next_href,
            generation: self.search.generation,
        }) {
            self.search.loading_more = false;
            self.search.error = Some(error.to_string());
        }
    }

    /// Loads the first SoundCloud Likes page once per authenticated session.
    pub fn ensure_likes_loaded(&mut self, runtime: &SoundCloudRuntime) {
        if self.is_authenticated() && !self.likes.loaded_once && !self.likes.loading {
            self.load_likes(runtime, false);
        }
    }

    /// Refreshes the first page or follows SoundCloud's opaque continuation URL.
    pub fn load_likes(&mut self, runtime: &SoundCloudRuntime, append: bool) {
        if self.likes.loading || !self.is_authenticated() {
            return;
        }
        let next_href = if append {
            let Some(next_href) = self.likes.next_href.clone() else {
                return;
            };
            Some(next_href)
        } else {
            self.likes.generation = self.likes.generation.wrapping_add(1);
            None
        };
        self.likes.loading = true;
        self.likes.error = None;
        if let Err(error) = runtime.send(SoundCloudCommand::LoadLikes {
            next_href,
            generation: self.likes.generation,
        }) {
            self.likes.loading = false;
            self.likes.error = Some(error.to_string());
        }
    }

    /// Begins authorization and clears stale errors first.
    pub fn connect(&mut self, runtime: &SoundCloudRuntime) {
        self.clear_errors();
        self.auth = SoundCloudAuthView::Authorizing;
        if let Err(error) = runtime.send(SoundCloudCommand::Connect) {
            self.auth = SoundCloudAuthView::AuthError;
            self.auth_error = Some(error.to_string());
        }
    }

    /// Replaces the current SoundCloud authorization.
    pub fn reconnect(&mut self, runtime: &SoundCloudRuntime) {
        self.clear_errors();
        self.auth = SoundCloudAuthView::Authorizing;
        if let Err(error) = runtime.send(SoundCloudCommand::Reconnect) {
            self.auth = SoundCloudAuthView::AuthError;
            self.auth_error = Some(error.to_string());
        }
    }

    /// Clears both local and remote connection state when possible.
    pub fn logout(&mut self, runtime: &SoundCloudRuntime) {
        self.clear_errors();
        self.auth = SoundCloudAuthView::Restoring;
        if let Err(error) = runtime.send(SoundCloudCommand::Logout) {
            self.auth = SoundCloudAuthView::AuthError;
            self.auth_error = Some(error.to_string());
        }
    }

    /// Applies one service event and returns avatar bytes for GPU upload.
    pub fn handle_event(&mut self, event: SoundCloudEvent) -> Option<SoundCloudEvent> {
        match event {
            SoundCloudEvent::Configured(Ok(config)) => {
                self.config = Some(config);
                self.auth_error = None;
            }
            SoundCloudEvent::Configured(Err(error)) => {
                self.config = None;
                self.auth = SoundCloudAuthView::ConfigurationError;
                self.auth_error = Some(error);
                self.api_error = None;
            }
            SoundCloudEvent::Restoring => {
                tracing::info!("[AUTH] SoundCloud auth view = Restoring");
                self.auth = SoundCloudAuthView::Restoring;
                self.clear_errors();
            }
            SoundCloudEvent::LoggedOut => {
                tracing::info!("[AUTH] SoundCloud auth view = LoggedOut");
                self.auth = SoundCloudAuthView::LoggedOut;
                self.clear_errors();
                self.clear_catalog_data();
            }
            SoundCloudEvent::Authorizing => {
                tracing::info!("[AUTH] SoundCloud auth view = Authorizing");
                self.auth = SoundCloudAuthView::Authorizing;
                self.clear_errors();
            }
            SoundCloudEvent::LoggedIn(profile) => {
                tracing::info!("[AUTH] SoundCloud auth view = LoggedIn");
                self.auth = SoundCloudAuthView::LoggedIn(profile);
                self.clear_errors();
                self.clear_catalog_data();
            }
            SoundCloudEvent::AuthFailed(error) => {
                self.auth = if self.config.is_some() {
                    SoundCloudAuthView::AuthError
                } else {
                    SoundCloudAuthView::ConfigurationError
                };
                self.auth_error = Some(error);
                self.api_error = None;
            }
            SoundCloudEvent::ApiFailed(error) => {
                // Keep an already verified account usable. Catalog failures are
                // recoverable and must not silently log the user out.
                if !matches!(self.auth, SoundCloudAuthView::LoggedIn(_)) {
                    self.auth = SoundCloudAuthView::ApiError;
                }
                self.api_error = Some(error);
                self.auth_error = None;
            }
            SoundCloudEvent::SearchFinished {
                generation,
                append,
                result,
            } => {
                if generation != self.search.generation || !self.is_authenticated() {
                    return None;
                }
                self.search.loading_more = false;
                match result {
                    Ok(page) => {
                        if append {
                            self.search.tracks.extend(page.items);
                        } else {
                            self.search.tracks = page.items;
                        }
                        self.search.next_href = page.next_href;
                        self.search.error = None;
                        self.search.status = if self.search.tracks.is_empty() {
                            SoundCloudSearchStatus::Empty
                        } else {
                            SoundCloudSearchStatus::Ready
                        };
                    }
                    Err(error) => {
                        self.search.error = Some(error);
                        if !append {
                            self.search.status = SoundCloudSearchStatus::Error;
                        }
                    }
                }
            }
            SoundCloudEvent::LikesFinished {
                generation,
                append,
                result,
            } => {
                if generation != self.likes.generation || !self.is_authenticated() {
                    return None;
                }
                self.likes.loading = false;
                self.likes.loaded_once = true;
                match result {
                    Ok(page) => {
                        if append {
                            self.likes.tracks.extend(page.items);
                        } else {
                            self.likes.tracks = page.items;
                        }
                        self.likes.next_href = page.next_href;
                        self.likes.error = None;
                        self.likes.revision = NEXT_LIKES_REVISION.fetch_add(1, Ordering::Relaxed);
                    }
                    Err(error) => self.likes.error = Some(error),
                }
            }
            library @ (SoundCloudEvent::LikedStateLoaded { .. }
            | SoundCloudEvent::LikedChanged { .. }) => return Some(library),
            recommendation @ SoundCloudEvent::RecommendationsFinished { .. } => {
                return Some(recommendation);
            }
            image @ (SoundCloudEvent::AvatarFinished { .. }
            | SoundCloudEvent::ArtworkFinished { .. }) => return Some(image),
            SoundCloudEvent::PlaybackChanged(update) => {
                self.playback.track = update.track;
                self.playback.status = update.status;
                self.playback.position_ms = update.position_ms;
                self.playback.queue_index = update.queue_index;
                self.playback.queue_len = update.queue_len;
                self.playback.position_updated_at = Instant::now();
            }
        }
        None
    }

    /// True while buttons must not start a competing OAuth operation.
    pub fn busy(&self) -> bool {
        matches!(
            &self.auth,
            SoundCloudAuthView::Restoring | SoundCloudAuthView::Authorizing
        )
    }

    pub fn play_queue(&mut self, runtime: &SoundCloudRuntime, tracks: Vec<TrackRow>, index: usize) {
        self.api_error = None;
        let Some(selected) = tracks.get(index).cloned() else {
            self.api_error =
                Some("The selected SoundCloud track is outside the local queue".to_owned());
            return;
        };
        self.playback.track = Some(selected);
        self.playback.status = PlaybackStatus::Loading;
        self.playback.position_ms = 0;
        self.playback.queue_index = Some(index);
        self.playback.queue_len = tracks.len();
        self.playback.seek_preview_ms = None;
        self.playback.position_updated_at = Instant::now();
        if let Err(error) = runtime.send(SoundCloudCommand::PlayQueue { tracks, index }) {
            self.api_error = Some(error.to_string());
            self.playback = SoundCloudPlaybackView::default();
        }
    }
    pub fn toggle_playback(&mut self, runtime: &SoundCloudRuntime) {
        let _ = runtime.send(SoundCloudCommand::TogglePlayback);
    }
    pub fn previous(&mut self, runtime: &SoundCloudRuntime) {
        let _ = runtime.send(SoundCloudCommand::Previous);
    }
    pub fn next(&mut self, runtime: &SoundCloudRuntime) {
        let _ = runtime.send(SoundCloudCommand::Next);
    }
    pub fn seek(&mut self, runtime: &SoundCloudRuntime, position_ms: u32) {
        self.playback.position_ms = position_ms;
        self.playback.seek_preview_ms = None;
        self.playback.position_updated_at = Instant::now();
        let _ = runtime.send(SoundCloudCommand::Seek { position_ms });
    }
    pub fn set_volume(&mut self, runtime: &SoundCloudRuntime, volume: f32) {
        let _ = runtime.send(SoundCloudCommand::SetVolume { volume });
    }
    pub fn set_output_device(&mut self, runtime: &SoundCloudRuntime, device: Option<String>) {
        let _ = runtime.send(SoundCloudCommand::SetOutputDevice { device });
    }
    pub fn stop_playback(&mut self, runtime: &SoundCloudRuntime) {
        self.playback = SoundCloudPlaybackView::default();
        let _ = runtime.send(SoundCloudCommand::StopPlayback);
    }

    fn clear_errors(&mut self) {
        self.auth_error = None;
        self.api_error = None;
    }

    fn clear_catalog_data(&mut self) {
        let search_generation = self.search.generation.wrapping_add(1);
        let likes_generation = self.likes.generation.wrapping_add(1);
        self.search = SoundCloudSearchView::default();
        self.search.generation = search_generation;
        self.likes = SoundCloudLikesView::default();
        self.likes.generation = likes_generation;
    }
}
