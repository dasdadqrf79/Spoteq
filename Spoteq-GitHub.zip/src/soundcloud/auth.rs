//! SoundCloud OAuth 2.1 Authorization Code flow with PKCE and token rotation.

use std::{
    sync::Arc,
    time::{Duration, SystemTime, UNIX_EPOCH},
};

use base64::{Engine as _, engine::general_purpose::URL_SAFE_NO_PAD};
use reqwest::Client;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use tokio::{sync::Mutex, time::timeout};
use url::Url;

use crate::soundcloud::{
    SoundCloudError, config::SoundCloudConfig, protocol::ProtocolCallbackReceiver,
    token_store::SoundCloudTokenStore,
};

const AUTHORIZE_URL: &str = "https://secure.soundcloud.com/authorize";
const TOKEN_URL: &str = "https://secure.soundcloud.com/oauth/token";
const SIGN_OUT_URL: &str = "https://secure.soundcloud.com/sign-out";
const CALLBACK_TIMEOUT: Duration = Duration::from_secs(180);

/// OAuth token snapshot stored in the current user's local application data.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub(crate) struct StoredSoundCloudToken {
    pub client_id: String,
    pub access_token: String,
    pub refresh_token: String,
    pub expires_at: u64,
    pub scope: String,
}

#[derive(Debug, Deserialize)]
struct TokenResponse {
    access_token: String,
    expires_in: u64,
    refresh_token: Option<String>,
    #[serde(default)]
    scope: String,
}

/// Serializes access-token refreshes and atomically rotates single-use refresh tokens.
pub(crate) struct SoundCloudAuth {
    config: SoundCloudConfig,
    store: SoundCloudTokenStore,
    token: Mutex<Option<StoredSoundCloudToken>>,
}

impl SoundCloudAuth {
    pub fn new(config: SoundCloudConfig, store: SoundCloudTokenStore) -> Self {
        Self {
            config,
            store,
            token: Mutex::new(None),
        }
    }

    pub async fn restore(&self, client: &Client) -> Result<bool, SoundCloudError> {
        let loaded = self.store.load()?;
        if loaded
            .as_ref()
            .is_some_and(|token| token.client_id != self.config.client_id)
        {
            self.store.clear()?;
            *self.token.lock().await = None;
            return Ok(false);
        }
        *self.token.lock().await = loaded;
        if self.token.lock().await.is_none() {
            return Ok(false);
        }
        self.access_token(client).await?;
        Ok(true)
    }

    pub async fn login(&self, client: &Client) -> Result<(), SoundCloudError> {
        let token = authorize(client, &self.config).await?;
        self.store.save(&token)?;
        *self.token.lock().await = Some(token);
        Ok(())
    }

    pub async fn logout(&self, client: &Client) -> Result<(), SoundCloudError> {
        let previous = self.token.lock().await.clone();
        self.store.clear()?;
        *self.token.lock().await = None;
        if let Some(token) = previous {
            let response = client
                .post(SIGN_OUT_URL)
                .json(&serde_json::json!({ "access_token": token.access_token }))
                .send()
                .await;
            if let Err(error) = response {
                tracing::warn!(%error, "SoundCloud remote sign-out failed after local logout");
            }
        }
        Ok(())
    }

    pub async fn access_token(&self, client: &Client) -> Result<String, SoundCloudError> {
        let mut guard = self.token.lock().await;
        let token = guard.as_ref().ok_or(SoundCloudError::NotAuthenticated)?;
        if token.expires_at > unix_time().saturating_add(60) {
            return Ok(token.access_token.clone());
        }

        let refreshed = refresh(client, &self.config, token).await?;
        self.store.save(&refreshed)?;
        let access_token = refreshed.access_token.clone();
        *guard = Some(refreshed);
        Ok(access_token)
    }

    pub async fn force_refresh(&self, client: &Client) -> Result<String, SoundCloudError> {
        let mut guard = self.token.lock().await;
        let token = guard.as_ref().ok_or(SoundCloudError::NotAuthenticated)?;
        let refreshed = refresh(client, &self.config, token).await?;
        self.store.save(&refreshed)?;
        let access_token = refreshed.access_token.clone();
        *guard = Some(refreshed);
        Ok(access_token)
    }
}

async fn authorize(
    client: &Client,
    config: &SoundCloudConfig,
) -> Result<StoredSoundCloudToken, SoundCloudError> {
    let callback_receiver = ProtocolCallbackReceiver::bind().await?;
    let verifier = random_urlsafe(64)?;
    let state = random_urlsafe(24)?;
    let challenge = URL_SAFE_NO_PAD.encode(Sha256::digest(verifier.as_bytes()));

    let mut authorization_url = Url::parse(AUTHORIZE_URL)?;
    authorization_url
        .query_pairs_mut()
        .append_pair("client_id", &config.client_id)
        .append_pair("redirect_uri", &config.redirect_uri)
        .append_pair("response_type", "code")
        .append_pair("code_challenge", &challenge)
        .append_pair("code_challenge_method", "S256")
        .append_pair("state", &state);

    let browser_url = authorization_url.to_string();
    let opened_browser =
        tokio::task::spawn_blocking(move || open_authorization_browser(&browser_url))
            .await
            .map_err(|error| SoundCloudError::Browser(error.to_string()))??;
    tracing::info!(browser = opened_browser, "SoundCloud OAuth browser opened");

    let code = timeout(CALLBACK_TIMEOUT, callback_receiver.receive(&state))
        .await
        .map_err(|_| SoundCloudError::AuthorizationTimeout)??;

    let response = client
        .post(TOKEN_URL)
        .header(reqwest::header::ACCEPT, "application/json; charset=utf-8")
        .form(&[
            ("grant_type", "authorization_code"),
            ("client_id", config.client_id.as_str()),
            ("client_secret", config.client_secret.as_str()),
            ("redirect_uri", config.redirect_uri.as_str()),
            ("code_verifier", verifier.as_str()),
            ("code", code.as_str()),
        ])
        .send()
        .await?;
    let token = parse_token_response(response).await?;
    let refresh_token = token.refresh_token.ok_or_else(|| SoundCloudError::Api {
        status: 200,
        message: "authorization response did not contain a refresh token".to_owned(),
    })?;
    Ok(StoredSoundCloudToken {
        client_id: config.client_id.clone(),
        access_token: token.access_token,
        refresh_token,
        expires_at: unix_time().saturating_add(token.expires_in),
        scope: token.scope,
    })
}

#[cfg(target_os = "windows")]
fn open_authorization_browser(url: &str) -> Result<&'static str, SoundCloudError> {
    use std::{path::PathBuf, process::Command};

    fn candidate(env_name: &str, relative: &str) -> Option<PathBuf> {
        std::env::var_os(env_name)
            .map(PathBuf::from)
            .map(|base| base.join(relative))
    }

    // Prefer a Chromium browser on Windows because SoundCloud's authorization page has had
    // blank-page regressions in some browsers. Use a normal profile rather than private mode:
    // SoundCloud's login/consent page may depend on regular cookie/storage behavior.
    let edge_paths = [
        candidate(
            "PROGRAMFILES(X86)",
            r"Microsoft\Edge\Application\msedge.exe",
        ),
        candidate("PROGRAMFILES", r"Microsoft\Edge\Application\msedge.exe"),
        candidate("LOCALAPPDATA", r"Microsoft\Edge\Application\msedge.exe"),
    ];
    for path in edge_paths.into_iter().flatten() {
        if path.is_file() {
            Command::new(&path)
                .arg("--new-window")
                .arg(url)
                .spawn()
                .map_err(|error| {
                    SoundCloudError::Browser(format!(
                        "failed to open Microsoft Edge for SoundCloud authorization: {error}"
                    ))
                })?;
            return Ok("Microsoft Edge");
        }
    }

    let chrome_paths = [
        candidate("LOCALAPPDATA", r"Google\Chrome\Application\chrome.exe"),
        candidate("PROGRAMFILES", r"Google\Chrome\Application\chrome.exe"),
        candidate("PROGRAMFILES(X86)", r"Google\Chrome\Application\chrome.exe"),
    ];
    for path in chrome_paths.into_iter().flatten() {
        if path.is_file() {
            Command::new(&path)
                .arg("--new-window")
                .arg(url)
                .spawn()
                .map_err(|error| {
                    SoundCloudError::Browser(format!(
                        "failed to open Google Chrome for SoundCloud authorization: {error}"
                    ))
                })?;
            return Ok("Google Chrome");
        }
    }

    // Last resort: preserve the old behavior when neither browser can be located.
    webbrowser::open(url).map_err(|error| SoundCloudError::Browser(error.to_string()))?;
    Ok("system default browser")
}

#[cfg(not(target_os = "windows"))]
fn open_authorization_browser(url: &str) -> Result<&'static str, SoundCloudError> {
    webbrowser::open(url).map_err(|error| SoundCloudError::Browser(error.to_string()))?;
    Ok("system default browser")
}

async fn refresh(
    client: &Client,
    config: &SoundCloudConfig,
    current: &StoredSoundCloudToken,
) -> Result<StoredSoundCloudToken, SoundCloudError> {
    let response = client
        .post(TOKEN_URL)
        .header(reqwest::header::ACCEPT, "application/json; charset=utf-8")
        .form(&[
            ("grant_type", "refresh_token"),
            ("client_id", config.client_id.as_str()),
            ("client_secret", config.client_secret.as_str()),
            ("refresh_token", current.refresh_token.as_str()),
        ])
        .send()
        .await?;
    let token = parse_token_response(response).await?;
    let refresh_token = token.refresh_token.ok_or_else(|| SoundCloudError::Api {
        status: 200,
        message: "refresh response did not contain the required rotated refresh token".to_owned(),
    })?;
    Ok(StoredSoundCloudToken {
        client_id: config.client_id.clone(),
        access_token: token.access_token,
        refresh_token,
        expires_at: unix_time().saturating_add(token.expires_in),
        scope: if token.scope.is_empty() {
            current.scope.clone()
        } else {
            token.scope
        },
    })
}

async fn parse_token_response(
    response: reqwest::Response,
) -> Result<TokenResponse, SoundCloudError> {
    let status = response.status();
    if status.is_success() {
        return Ok(response.json().await?);
    }
    let message = response
        .text()
        .await
        .unwrap_or_else(|_| "unknown SoundCloud OAuth error".to_owned());
    Err(SoundCloudError::Api {
        status: status.as_u16(),
        message,
    })
}

fn random_urlsafe(length: usize) -> Result<String, SoundCloudError> {
    let mut bytes = vec![0_u8; length];
    getrandom::fill(&mut bytes).map_err(|error| SoundCloudError::Random(error.to_string()))?;
    Ok(URL_SAFE_NO_PAD.encode(bytes))
}

fn unix_time() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

pub(crate) type SharedSoundCloudAuth = Arc<SoundCloudAuth>;
