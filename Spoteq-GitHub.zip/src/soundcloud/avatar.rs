//! One-entry egui texture cache for the connected SoundCloud avatar.

use eframe::egui::{self, Color32, Response, TextureHandle, Ui, Vec2};

use crate::{soundcloud::DecodedAvatar, ui::theme::colors};

/// GPU-side avatar owned only by the egui thread.
#[derive(Default)]
pub struct SoundCloudAvatar {
    url: Option<String>,
    texture: Option<TextureHandle>,
}

impl SoundCloudAvatar {
    /// Uploads decoded pixels and replaces the previous account avatar.
    pub fn insert(&mut self, context: &egui::Context, url: String, image: DecodedAvatar) {
        let color = egui::ColorImage::from_rgba_unmultiplied(image.size, &image.rgba);
        self.texture = Some(context.load_texture(
            format!("soundcloud-avatar:{url}"),
            color,
            egui::TextureOptions::LINEAR,
        ));
        self.url = Some(url);
    }

    /// Marks an avatar request as failed while keeping the profile usable.
    pub fn fail(&mut self, url: String) {
        if self.url.as_deref() == Some(url.as_str()) {
            self.url = None;
            self.texture = None;
        }
    }

    /// Draws the matching avatar or a neutral account placeholder.
    pub fn show(&self, ui: &mut Ui, url: Option<&str>, size: Vec2) -> Response {
        if url.is_some() && self.url.as_deref() == url {
            if let Some(texture) = &self.texture {
                return ui.add(egui::Image::new((texture.id(), size)).corner_radius(size.x / 2.0));
            }
        }
        let (rect, response) = ui.allocate_exact_size(size, egui::Sense::hover());
        ui.painter()
            .circle_filled(rect.center(), size.x / 2.0, colors::surface_raised());
        ui.painter().circle_filled(
            egui::Pos2::new(rect.center().x, rect.center().y - size.y * 0.12),
            size.x * 0.13,
            Color32::from_gray(135),
        );
        ui.painter().circle_filled(
            egui::Pos2::new(rect.center().x, rect.center().y + size.y * 0.20),
            size.x * 0.22,
            Color32::from_gray(135),
        );
        response
    }
}
