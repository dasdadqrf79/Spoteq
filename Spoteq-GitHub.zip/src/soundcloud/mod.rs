//! Independent SoundCloud OAuth, catalog API and native playback.

mod api;
mod auth;
mod avatar;
mod config;
mod error;
mod model;
mod playback;
mod protocol;
mod runtime;
mod token_store;
mod view_state;

pub use avatar::SoundCloudAvatar;
pub use config::{CLIENT_ID_ENV, CLIENT_SECRET_ENV, PublicSoundCloudConfig, REDIRECT_URI_ENV};
pub use error::SoundCloudError;
pub use model::{DecodedArtwork, DecodedAvatar, SoundCloudProfile};
pub use playback::SoundCloudPlaybackUpdate;
pub use protocol::{handle_protocol_invocation, register_protocol_handler};
pub use runtime::{SoundCloudCommand, SoundCloudEvent, SoundCloudRuntime};
pub use view_state::{
    SoundCloudAuthView, SoundCloudLikesView, SoundCloudPlaybackView, SoundCloudSearchStatus,
    SoundCloudSearchView, SoundCloudViewState,
};
