//! SoundCloud application configuration.
//! Credentials are supplied through environment variables.

use crate::soundcloud::{SoundCloudError, protocol::CUSTOM_REDIRECT_URI};

/// Environment variable overriding the registered SoundCloud application ID.
pub const CLIENT_ID_ENV: &str = "SOUNDCLOUD_CLIENT_ID";
/// Environment variable overriding the registered SoundCloud application secret.
pub const CLIENT_SECRET_ENV: &str = "SOUNDCLOUD_CLIENT_SECRET";
/// Environment variable overriding the exact registered desktop callback URI.
pub const REDIRECT_URI_ENV: &str = "SOUNDCLOUD_REDIRECT_URI";

/// Confidential SoundCloud application configuration.
#[derive(Clone)]
pub(crate) struct SoundCloudConfig {
    pub client_id: String,
    pub client_secret: String,
    pub redirect_uri: String,
}

/// Non-secret configuration details safe to display in the UI.
#[derive(Debug, Clone)]
pub struct PublicSoundCloudConfig {
    /// Exact redirect URI used for both authorization and code exchange.
    pub redirect_uri: String,
}

impl SoundCloudConfig {
    pub fn from_environment() -> Result<Self, SoundCloudError> {
        let client_id = required_env(CLIENT_ID_ENV)?;
        let client_secret = required_env(CLIENT_SECRET_ENV)?;
        let redirect_uri = env_or_default(REDIRECT_URI_ENV, CUSTOM_REDIRECT_URI);
        validate_custom_protocol_redirect(&redirect_uri)?;

        Ok(Self {
            client_id,
            client_secret,
            redirect_uri,
        })
    }

    pub fn public(&self) -> PublicSoundCloudConfig {
        PublicSoundCloudConfig {
            redirect_uri: self.redirect_uri.clone(),
        }
    }
}

fn required_env(name: &'static str) -> Result<String, SoundCloudError> {
    let value = env_or_default(name, "");
    if value.is_empty() {
        Err(SoundCloudError::MissingConfiguration(name))
    } else {
        Ok(value)
    }
}

fn env_or_default(name: &'static str, default: &'static str) -> String {
    std::env::var(name)
        .ok()
        .map(|value| value.trim().to_owned())
        .filter(|value| !value.is_empty())
        .unwrap_or_else(|| default.to_owned())
}

fn validate_custom_protocol_redirect(value: &str) -> Result<(), SoundCloudError> {
    if value == CUSTOM_REDIRECT_URI {
        Ok(())
    } else {
        Err(SoundCloudError::InvalidRedirect(format!(
            "this desktop build requires exactly {CUSTOM_REDIRECT_URI}"
        )))
    }
}
