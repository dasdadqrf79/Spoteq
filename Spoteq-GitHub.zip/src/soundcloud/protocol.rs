//! Windows custom-protocol registration and local OAuth callback handoff.

use std::{
    io::Write,
    net::{IpAddr, Ipv4Addr, SocketAddr, TcpStream},
    time::Duration,
};

use tokio::{io::AsyncReadExt, net::TcpListener};
use url::Url;

use crate::soundcloud::SoundCloudError;

/// Exact redirect URI registered for the Spoteq desktop application.
pub const CUSTOM_REDIRECT_URI: &str = "eqspot://soundcloud/callback";

const CALLBACK_RELAY_PORT: u16 = 47_983;
const MAX_CALLBACK_BYTES: u64 = 16 * 1024;

/// Receives a custom-protocol URI relayed by the short-lived Windows process.
pub(crate) struct ProtocolCallbackReceiver {
    listener: TcpListener,
}

impl ProtocolCallbackReceiver {
    /// Registers the URL handler and reserves the private loopback relay before opening a browser.
    pub async fn bind() -> Result<Self, SoundCloudError> {
        register_windows_protocol()?;
        let listener = TcpListener::bind(relay_address()).await.map_err(|error| {
            SoundCloudError::ProtocolCallback(format!(
                "could not start the local callback relay: {error}"
            ))
        })?;
        Ok(Self { listener })
    }

    /// Waits until a callback with the expected OAuth state arrives.
    pub async fn receive(self, expected_state: &str) -> Result<String, SoundCloudError> {
        loop {
            let (stream, peer) = self.listener.accept().await.map_err(|error| {
                SoundCloudError::ProtocolCallback(format!(
                    "could not accept the local callback relay: {error}"
                ))
            })?;
            if !peer.ip().is_loopback() {
                continue;
            }

            let mut bytes = Vec::with_capacity(2048);
            stream
                .take(MAX_CALLBACK_BYTES)
                .read_to_end(&mut bytes)
                .await
                .map_err(|error| {
                    SoundCloudError::ProtocolCallback(format!(
                        "could not read the local callback relay: {error}"
                    ))
                })?;
            let Ok(raw_uri) = std::str::from_utf8(&bytes) else {
                continue;
            };
            match parse_callback(raw_uri.trim(), expected_state)? {
                Some(code) => return Ok(code),
                None => continue,
            }
        }
    }
}

/// Handles an `eqspot://` process launch before the eframe application is created.
///
/// Returns `true` whenever this process was launched only to relay an OAuth callback.
pub fn handle_protocol_invocation() -> bool {
    let callback = std::env::args_os().skip(1).find_map(|argument| {
        let argument = argument.to_string_lossy();
        is_soundcloud_callback(&argument).then(|| argument.into_owned())
    });
    let Some(callback) = callback else {
        return false;
    };

    if let Err(error) = forward_to_running_app(&callback) {
        tracing::error!(%error, "SoundCloud custom-protocol callback could not be relayed");
    }
    true
}

/// Registers the current executable as the per-user `eqspot://` handler.
pub fn register_protocol_handler() -> Result<(), SoundCloudError> {
    register_windows_protocol()
}

fn parse_callback(raw_uri: &str, expected_state: &str) -> Result<Option<String>, SoundCloudError> {
    let Ok(callback) = Url::parse(raw_uri) else {
        return Ok(None);
    };
    if !is_expected_url(&callback) {
        return Ok(None);
    }

    let mut code = None;
    let mut returned_state = None;
    let mut oauth_error = None;
    for (key, value) in callback.query_pairs() {
        match key.as_ref() {
            "code" => code = Some(value.into_owned()),
            "state" => returned_state = Some(value.into_owned()),
            "error_description" => oauth_error = Some(value.into_owned()),
            "error" if oauth_error.is_none() => oauth_error = Some(value.into_owned()),
            _ => {}
        }
    }

    if returned_state.as_deref() != Some(expected_state) {
        return Ok(None);
    }
    if let Some(error) = oauth_error {
        return Err(SoundCloudError::AuthorizationDenied(error));
    }
    Ok(code)
}

fn is_soundcloud_callback(raw_uri: &str) -> bool {
    Url::parse(raw_uri)
        .ok()
        .is_some_and(|url| is_expected_url(&url))
}

fn is_expected_url(url: &Url) -> bool {
    url.scheme().eq_ignore_ascii_case("eqspot")
        && url
            .host_str()
            .is_some_and(|host| host.eq_ignore_ascii_case("soundcloud"))
        && url.path() == "/callback"
        && url.username().is_empty()
        && url.password().is_none()
        && url.port().is_none()
        && url.fragment().is_none()
}

fn forward_to_running_app(callback: &str) -> Result<(), SoundCloudError> {
    let address = relay_address();
    let mut last_error = None;
    for _ in 0..20 {
        match TcpStream::connect_timeout(&address, Duration::from_millis(150)) {
            Ok(mut stream) => {
                stream
                    .set_write_timeout(Some(Duration::from_secs(2)))
                    .map_err(|error| SoundCloudError::ProtocolCallback(error.to_string()))?;
                stream
                    .write_all(callback.as_bytes())
                    .map_err(|error| SoundCloudError::ProtocolCallback(error.to_string()))?;
                return Ok(());
            }
            Err(error) => {
                last_error = Some(error);
                std::thread::sleep(Duration::from_millis(50));
            }
        }
    }
    Err(SoundCloudError::ProtocolCallback(format!(
        "the running Spoteq instance did not accept the callback: {}",
        last_error
            .map(|error| error.to_string())
            .unwrap_or_else(|| "unknown relay error".to_owned())
    )))
}

fn relay_address() -> SocketAddr {
    SocketAddr::new(IpAddr::V4(Ipv4Addr::LOCALHOST), CALLBACK_RELAY_PORT)
}

#[cfg(target_os = "windows")]
fn register_windows_protocol() -> Result<(), SoundCloudError> {
    let executable = std::env::current_exe().map_err(|error| {
        SoundCloudError::ProtocolRegistration(format!(
            "could not locate the Spoteq executable: {error}"
        ))
    })?;
    let executable = executable.to_string_lossy();
    let command = format!("\"{executable}\" \"%1\"");
    let icon = format!("\"{executable}\",0");
    let root = r"HKCU\Software\Classes\eqspot";

    reg_default(root, "URL:Spoteq Protocol")?;
    reg_named(root, "URL Protocol", "")?;
    reg_default(&format!(r"{root}\DefaultIcon"), &icon)?;
    reg_default(&format!(r"{root}\shell\open\command"), &command)?;
    Ok(())
}

#[cfg(not(target_os = "windows"))]
fn register_windows_protocol() -> Result<(), SoundCloudError> {
    Err(SoundCloudError::ProtocolRegistration(
        "the eqspot:// callback is supported only on Windows".to_owned(),
    ))
}

#[cfg(target_os = "windows")]
fn reg_default(key: &str, value: &str) -> Result<(), SoundCloudError> {
    run_reg(&["add", key, "/ve", "/d", value, "/f"])
}

#[cfg(target_os = "windows")]
fn reg_named(key: &str, name: &str, value: &str) -> Result<(), SoundCloudError> {
    run_reg(&["add", key, "/v", name, "/d", value, "/f"])
}

#[cfg(target_os = "windows")]
fn run_reg(arguments: &[&str]) -> Result<(), SoundCloudError> {
    use std::{os::windows::process::CommandExt, process::Command};

    const CREATE_NO_WINDOW: u32 = 0x0800_0000;

    let status = Command::new("reg.exe")
        .args(arguments)
        .creation_flags(CREATE_NO_WINDOW)
        .status()
        .map_err(|error| SoundCloudError::ProtocolRegistration(error.to_string()))?;
    if status.success() {
        Ok(())
    } else {
        Err(SoundCloudError::ProtocolRegistration(format!(
            "reg.exe exited with status {status}"
        )))
    }
}

#[cfg(test)]
mod tests {
    use super::parse_callback;
    use crate::soundcloud::SoundCloudError;

    #[test]
    fn accepts_matching_state_and_decodes_code() {
        let code = parse_callback(
            "eqspot://soundcloud/callback?code=a%2Fb&state=expected",
            "expected",
        )
        .expect("callback must parse");
        assert_eq!(code.as_deref(), Some("a/b"));
    }

    #[test]
    fn ignores_wrong_state() {
        let code = parse_callback(
            "eqspot://soundcloud/callback?code=secret&state=unexpected",
            "expected",
        )
        .expect("callback must parse");
        assert!(code.is_none());
    }

    #[test]
    fn propagates_oauth_denial_only_for_matching_state() {
        let error = parse_callback(
            "eqspot://soundcloud/callback?error=access_denied&state=expected",
            "expected",
        )
        .expect_err("matching OAuth denial must be reported");
        assert!(matches!(error, SoundCloudError::AuthorizationDenied(_)));
    }
}
