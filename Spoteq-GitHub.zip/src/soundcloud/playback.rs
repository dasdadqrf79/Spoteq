//! Native SoundCloud AAC/HLS playback actor.

use std::{
    io::{self, Cursor},
    sync::Arc,
    time::{Duration, Instant},
};

use cpal::traits::{DeviceTrait, HostTrait};
use eframe::egui;

use symphonia::core::{
    audio::SampleBuffer,
    codecs::DecoderOptions,
    errors::Error as SymphoniaError,
    formats::{FormatOptions, SeekMode, SeekTo},
    io::{MediaSourceStream, MediaSourceStreamOptions},
    meta::MetadataOptions,
    probe::Hint,
};
use tokio::sync::mpsc;

use crate::{
    audio::dsp::{DspControls, DspPlaybackProcessor},
    catalog::{ProviderTrackId, TrackRow},
    soundcloud::{SoundCloudError, api::SoundCloudApi, model::SoundCloudStreamFormat},
    spotify::{PlaybackError, PlaybackErrorKind, PlaybackStatus},
};

const SAMPLE_RATE: u32 = librespot_playback::SAMPLE_RATE;
const CHANNELS: u16 = librespot_playback::NUM_CHANNELS as u16;

#[derive(Debug)]
pub(crate) enum SoundCloudPlaybackCommand {
    PlayQueue {
        tracks: Vec<TrackRow>,
        index: usize,
    },
    /// Preloads encoded media for a likely next/hovered track without starting it.
    Preload(TrackRow),
    Toggle,
    Previous,
    Next,
    Seek(u32),
    SetVolume(f32),
    SetOutputDevice(Option<String>),
    Stop,
    Shutdown,
}

#[derive(Debug, Clone)]
pub struct SoundCloudPlaybackUpdate {
    pub track: Option<TrackRow>,
    pub status: PlaybackStatus,
    pub position_ms: u32,
    pub queue_index: Option<usize>,
    pub queue_len: usize,
    /// True only when the final item in this backend queue completed naturally.
    pub ended: bool,
}

enum LoaderEvent {
    Selected { generation: u64, name: &'static str },
    Samples { generation: u64, samples: Vec<f64> },
    Finished { generation: u64 },
    Failed { generation: u64, error: String },
}

struct PreparedMedia {
    media: Vec<u8>,
    format: SoundCloudStreamFormat,
    name: &'static str,
}

#[derive(Default)]
struct FastStartCacheState {
    requested_key: Option<String>,
    ready: Option<(String, PreparedMedia)>,
}

type FastStartCache = Arc<std::sync::Mutex<FastStartCacheState>>;

struct NativeOutput {
    dsp: Arc<DspPlaybackProcessor>,
    volume: Arc<rodio::Sink>,
    _stream: rodio::OutputStream,
}

pub(crate) fn spawn(
    api: SoundCloudApi,
    event_tx: flume::Sender<crate::soundcloud::SoundCloudEvent>,
    context: egui::Context,
    initial_volume: f32,
    initial_output_device: Option<String>,
    dsp_controls: Arc<DspControls>,
) -> mpsc::UnboundedSender<SoundCloudPlaybackCommand> {
    let (tx, rx) = mpsc::unbounded_channel();
    tokio::spawn(run(
        rx,
        api,
        event_tx,
        context,
        initial_volume,
        initial_output_device,
        dsp_controls,
    ));
    tx
}

async fn run(
    mut commands: mpsc::UnboundedReceiver<SoundCloudPlaybackCommand>,
    api: SoundCloudApi,
    event_tx: flume::Sender<crate::soundcloud::SoundCloudEvent>,
    context: egui::Context,
    initial_volume: f32,
    initial_output_device: Option<String>,
    dsp_controls: Arc<DspControls>,
) {
    let (loader_tx, mut loader_rx) = mpsc::channel(8);
    let mut loader_task: Option<tokio::task::JoinHandle<()>> = None;
    let mut output: Option<NativeOutput> = None;
    let mut queue = Vec::new();
    let mut index = None;
    let mut status = PlaybackStatus::Idle;
    let mut position_ms = 0_u32;
    let mut position_anchor = Instant::now();
    let mut generation = 0_u64;
    let mut volume = initial_volume.clamp(0.0, 1.0);
    let mut output_device = initial_output_device;
    let mut ticker = tokio::time::interval(Duration::from_millis(200));
    ticker.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
    let fast_start_cache: FastStartCache =
        Arc::new(std::sync::Mutex::new(FastStartCacheState::default()));

    loop {
        tokio::select! {
            command = commands.recv() => {
                let Some(command) = command else { break };
                match command {
                    SoundCloudPlaybackCommand::PlayQueue { tracks, index: requested } => {
                        if requested >= tracks.len() {
                            fail(&event_tx, &context, &queue, index, position_ms, "The selected SoundCloud track is outside the local queue");
                            continue;
                        }
                        queue = tracks;
                        index = Some(requested);
                        position_ms = 0;
                        generation = generation.wrapping_add(1);
                        cancel_loader(&mut loader_task);
                        tracing::info!(track = %queue[requested].title, "SoundCloud playback requested");
                        status = PlaybackStatus::Loading;
                        emit(&event_tx, &context, &queue, index, &status, position_ms);
                        let output_ready = if let Some(active) = output.as_ref() {
                            active.volume.clear();
                            active.volume.pause();
                            active.volume.set_volume(volume);
                            true
                        } else {
                            match create_output(output_device.clone(), volume, dsp_controls.clone()) {
                                Ok(created) => {
                                    output = Some(created);
                                    true
                                }
                                Err(error) => {
                                    status = PlaybackStatus::Error(playback_error(error));
                                    emit(&event_tx, &context, &queue, index, &status, position_ms);
                                    false
                                }
                            }
                        };
                        if output_ready {
                            loader_task = Some(spawn_loader(
                                api.clone(),
                                queue[requested].clone(),
                                0,
                                generation,
                                loader_tx.clone(),
                                fast_start_cache.clone(),
                            ));
                        }
                    }
                    SoundCloudPlaybackCommand::Preload(track) => {
                        let key = track.stable_key();
                        let should_start = fast_start_cache
                            .lock()
                            .ok()
                            .map(|mut cache| {
                                let already_requested =
                                    cache.requested_key.as_deref() == Some(key.as_str());
                                let already_ready = cache
                                    .ready
                                    .as_ref()
                                    .is_some_and(|(cached, _)| cached == &key);
                                if already_requested || already_ready {
                                    false
                                } else {
                                    cache.requested_key = Some(key.clone());
                                    true
                                }
                            })
                            .unwrap_or(false);
                        if should_start {
                            let api = api.clone();
                            let cache = fast_start_cache.clone();
                            tokio::spawn(async move {
                                match prepare_media(api, &track).await {
                                    Ok(prepared) => {
                                        if let Ok(mut cache) = cache.lock() {
                                            if cache.requested_key.as_deref() == Some(key.as_str()) {
                                                cache.ready = Some((key.clone(), prepared));
                                            }
                                        }
                                        tracing::debug!(track_key = %key, "SoundCloud fast-start preload ready");
                                    }
                                    Err(error) => {
                                        if let Ok(mut cache) = cache.lock() {
                                            if cache.requested_key.as_deref() == Some(key.as_str()) {
                                                cache.requested_key = None;
                                            }
                                        }
                                        tracing::debug!(track_key = %key, reason = %error, "SoundCloud fast-start preload skipped");
                                    }
                                }
                            });
                        }
                    }
                    SoundCloudPlaybackCommand::Toggle => {
                        if status == PlaybackStatus::Playing {
                            if let Some(active) = &output { active.volume.pause(); }
                            position_ms = displayed_position(position_ms, position_anchor, &status, current_duration(&queue, index));
                            status = PlaybackStatus::Paused;
                            tracing::info!("SoundCloud playback stopped");
                            emit(&event_tx, &context, &queue, index, &status, position_ms);
                        } else if status == PlaybackStatus::Paused {
                            if let Some(active) = &output { active.volume.play(); }
                            position_anchor = Instant::now();
                            status = PlaybackStatus::Playing;
                            tracing::info!("SoundCloud playback started");
                            emit(&event_tx, &context, &queue, index, &status, position_ms);
                        }
                    }
                    SoundCloudPlaybackCommand::Previous => {
                        let target = if position_ms > 5_000 { index } else { index.and_then(|i| i.checked_sub(1)).or(index) };
                        restart(&api, &mut loader_task, &loader_tx, &mut output, &queue, target, 0, &mut index, &mut position_ms, &mut status, &mut generation, output_device.clone(), volume, dsp_controls.clone(), fast_start_cache.clone(), &event_tx, &context);
                    }
                    SoundCloudPlaybackCommand::Next => {
                        let target = index.and_then(|i| (i + 1 < queue.len()).then_some(i + 1));
                        if target.is_some() {
                            restart(&api, &mut loader_task, &loader_tx, &mut output, &queue, target, 0, &mut index, &mut position_ms, &mut status, &mut generation, output_device.clone(), volume, dsp_controls.clone(), fast_start_cache.clone(), &event_tx, &context);
                        }
                    }
                    SoundCloudPlaybackCommand::Seek(target) => {
                        if index.is_some() {
                            let target = target.min(current_duration(&queue, index) as u32);
                            restart(&api, &mut loader_task, &loader_tx, &mut output, &queue, index, target, &mut index, &mut position_ms, &mut status, &mut generation, output_device.clone(), volume, dsp_controls.clone(), fast_start_cache.clone(), &event_tx, &context);
                        }
                    }
                    SoundCloudPlaybackCommand::SetVolume(value) => {
                        volume = value.clamp(0.0, 1.0);
                        if let Some(active) = &output { active.volume.set_volume(volume); }
                    }
                    SoundCloudPlaybackCommand::SetOutputDevice(device) => {
                        output_device = device;
                        output = None;
                        if index.is_some() {
                            let resume_at = displayed_position(position_ms, position_anchor, &status, current_duration(&queue, index));
                            restart(&api, &mut loader_task, &loader_tx, &mut output, &queue, index, resume_at, &mut index, &mut position_ms, &mut status, &mut generation, output_device.clone(), volume, dsp_controls.clone(), fast_start_cache.clone(), &event_tx, &context);
                        }
                    }
                    SoundCloudPlaybackCommand::Stop => {
                        generation = generation.wrapping_add(1);
                        cancel_loader(&mut loader_task);
                        output = None;
                        queue.clear(); index = None; position_ms = 0; status = PlaybackStatus::Idle;
                        tracing::info!("SoundCloud playback stopped");
                        emit(&event_tx, &context, &queue, index, &status, position_ms);
                    }
                    SoundCloudPlaybackCommand::Shutdown => break,
                }
            }
            event = loader_rx.recv(), if output.as_ref().is_none_or(|active| active.volume.len() < 12) => {
                let Some(event) = event else { continue };
                match event {
                    LoaderEvent::Selected { generation: event_generation, name } if event_generation == generation => {
                        tracing::info!(transcoding = name, "SoundCloud stream/transcoding selected");
                    }
                    LoaderEvent::Samples { generation: event_generation, samples } if event_generation == generation => {
                        if let Some(active) = output.as_mut() {
                            append_samples(active, samples);
                            if status == PlaybackStatus::Loading {
                                active.volume.play();
                                position_anchor = Instant::now();
                                status = PlaybackStatus::Playing;
                                tracing::info!("SoundCloud playback started");
                                emit(&event_tx, &context, &queue, index, &status, position_ms);
                            }
                        }
                    }
                    LoaderEvent::Finished { generation: event_generation } if event_generation == generation => {}
                    LoaderEvent::Failed { generation: event_generation, error } if event_generation == generation => {
                        tracing::error!(reason = %error, "SoundCloud API/playback error reason");
                        status = PlaybackStatus::Error(playback_error(error));
                        output = None;
                        emit(&event_tx, &context, &queue, index, &status, position_ms);
                    }
                    _ => {}
                }
            }
            _ = ticker.tick() => {
                if status == PlaybackStatus::Playing {
                    let duration = current_duration(&queue, index);
                    let displayed = displayed_position(position_ms, position_anchor, &status, duration);
                    if displayed != position_ms {
                        position_ms = displayed;
                        position_anchor = Instant::now();
                        emit(&event_tx, &context, &queue, index, &status, position_ms);
                    }
                    if duration > 0 && u64::from(position_ms) >= duration {
                        let target = index.and_then(|i| (i + 1 < queue.len()).then_some(i + 1));
                        if target.is_some() {
                            restart(&api, &mut loader_task, &loader_tx, &mut output, &queue, target, 0, &mut index, &mut position_ms, &mut status, &mut generation, output_device.clone(), volume, dsp_controls.clone(), fast_start_cache.clone(), &event_tx, &context);
                        } else {
                            status = PlaybackStatus::Paused;
                            emit_with_end(
                                &event_tx,
                                &context,
                                &queue,
                                index,
                                &status,
                                position_ms,
                                true,
                            );
                        }
                    }
                }
            }
        }
    }
    cancel_loader(&mut loader_task);
}

#[allow(clippy::too_many_arguments)]
fn restart(
    api: &SoundCloudApi,
    loader_task: &mut Option<tokio::task::JoinHandle<()>>,
    loader_tx: &mpsc::Sender<LoaderEvent>,
    output: &mut Option<NativeOutput>,
    queue: &[TrackRow],
    target_index: Option<usize>,
    target_ms: u32,
    index: &mut Option<usize>,
    position_ms: &mut u32,
    status: &mut PlaybackStatus,
    generation: &mut u64,
    output_device: Option<String>,
    volume: f32,
    dsp_controls: Arc<DspControls>,
    fast_start_cache: FastStartCache,
    event_tx: &flume::Sender<crate::soundcloud::SoundCloudEvent>,
    context: &egui::Context,
) {
    let Some(target_index) = target_index else {
        return;
    };
    *generation = (*generation).wrapping_add(1);
    cancel_loader(loader_task);
    *index = Some(target_index);
    *position_ms = target_ms;
    *status = PlaybackStatus::Loading;
    emit(event_tx, context, queue, *index, status, *position_ms);

    let output_ready = if let Some(active) = output.as_ref() {
        active.volume.clear();
        active.volume.pause();
        active.volume.set_volume(volume);
        true
    } else {
        match create_output(output_device, volume, dsp_controls) {
            Ok(created) => {
                *output = Some(created);
                true
            }
            Err(error) => {
                *status = PlaybackStatus::Error(playback_error(error));
                emit(event_tx, context, queue, *index, status, *position_ms);
                false
            }
        }
    };
    if output_ready {
        *loader_task = Some(spawn_loader(
            api.clone(),
            queue[target_index].clone(),
            target_ms,
            *generation,
            loader_tx.clone(),
            fast_start_cache,
        ));
    }
}

fn spawn_loader(
    api: SoundCloudApi,
    track: TrackRow,
    seek_ms: u32,
    generation: u64,
    tx: mpsc::Sender<LoaderEvent>,
    fast_start_cache: FastStartCache,
) -> tokio::task::JoinHandle<()> {
    tokio::spawn(async move {
        let result = load_audio(
            api,
            &track,
            seek_ms,
            generation,
            tx.clone(),
            fast_start_cache,
        )
        .await;
        if let Err(error) = result {
            let _ = tx
                .send(LoaderEvent::Failed {
                    generation,
                    error: error.to_string(),
                })
                .await;
        }
    })
}

async fn load_audio(
    api: SoundCloudApi,
    track: &TrackRow,
    seek_ms: u32,
    generation: u64,
    tx: mpsc::Sender<LoaderEvent>,
    fast_start_cache: FastStartCache,
) -> Result<(), SoundCloudError> {
    let ProviderTrackId::SoundCloud { id, urn, .. } = &track.provider_id else {
        return Err(SoundCloudError::NoPlayableStream);
    };
    let resource = urn.as_deref().unwrap_or(id);
    let stable_key = track.stable_key();
    let cached = fast_start_cache.lock().ok().and_then(|mut cache| {
        if cache
            .ready
            .as_ref()
            .is_some_and(|(key, _)| key == &stable_key)
        {
            cache.requested_key = None;
            cache.ready.take().map(|(_, prepared)| prepared)
        } else {
            None
        }
    });
    if let Some(prepared) = cached {
        let PreparedMedia {
            media,
            format,
            name,
        } = prepared;
        tracing::info!(track_key = %stable_key, transcoding = name, "SoundCloud fast-start cache hit");
        let attempt_tx = tx.clone();
        let attempt = tokio::task::spawn_blocking(move || {
            decode_and_send(media, format, seek_ms, generation, name, attempt_tx)
        })
        .await
        .map_err(|error| SoundCloudError::Playback(error.to_string()))?;
        match attempt {
            Ok(()) => return Ok(()),
            Err(DecodeAttemptError::BeforeOutput(error)) => {
                tracing::warn!(track_key = %stable_key, reason = %error, "SoundCloud cached preload was not decodable; falling back to network");
            }
            Err(DecodeAttemptError::AfterOutput(error)) => {
                return Err(SoundCloudError::Playback(format!(
                    "{} failed after playback started: {error}",
                    name
                )));
            }
            Err(DecodeAttemptError::RuntimeStopped) => return Err(SoundCloudError::RuntimeStopped),
        }
    }

    let streams = api.streams(resource).await?;
    let available = streams.available_variants();
    let candidates = streams.playback_candidates();

    tracing::info!(
        track_urn = resource,
        variants = ?available,
        candidates = candidates.len(),
        "SoundCloud /streams variants available"
    );

    if candidates.is_empty() {
        tracing::warn!(
            track_urn = resource,
            variants = ?available,
            "SoundCloud did not return a supported full-track stream"
        );
        return Err(SoundCloudError::NoPlayableStream);
    }

    let mut failures = Vec::new();

    for (name, stream_url, format) in candidates {
        tracing::info!(
            track_urn = resource,
            transcoding = name,
            ?format,
            "SoundCloud trying stream/transcoding"
        );

        if seek_ms == 0
            && matches!(
                format,
                SoundCloudStreamFormat::AacHls | SoundCloudStreamFormat::Mp3Hls
            )
        {
            match stream_hls_audio(&api, &stream_url, format, generation, name, tx.clone(), 0).await
            {
                Ok(()) => return Ok(()),
                Err(DecodeAttemptError::BeforeOutput(error)) => {
                    tracing::debug!(
                        track_urn = resource,
                        transcoding = name,
                        reason = %error,
                        "SoundCloud progressive HLS start unavailable; falling back to full download"
                    );
                }
                Err(DecodeAttemptError::AfterOutput(error)) => {
                    return Err(SoundCloudError::Playback(format!(
                        "{name} failed after progressive playback started: {error}"
                    )));
                }
                Err(DecodeAttemptError::RuntimeStopped) => {
                    return Err(SoundCloudError::RuntimeStopped);
                }
            }
        }

        let media_result = match format {
            SoundCloudStreamFormat::AacHls | SoundCloudStreamFormat::Mp3Hls => {
                download_hls(&api, &stream_url, 0).await
            }
            SoundCloudStreamFormat::Mp3Http => api
                .media_resource(&stream_url)
                .await
                .map(|resource| resource.bytes),
        };

        let media = match media_result {
            Ok(media) => media,
            Err(error) => {
                tracing::warn!(
                    track_urn = resource,
                    transcoding = name,
                    reason = %error,
                    "SoundCloud stream download failed"
                );

                if !may_try_another_stream(&error) {
                    return Err(error);
                }

                failures.push(format!("{name}: {error}"));
                continue;
            }
        };

        tracing::info!(
            track_urn = resource,
            transcoding = name,
            bytes = media.len(),
            "SoundCloud stream downloaded"
        );

        let attempt_tx = tx.clone();
        let attempt = tokio::task::spawn_blocking(move || {
            decode_and_send(media, format, seek_ms, generation, name, attempt_tx)
        })
        .await
        .map_err(|error| SoundCloudError::Playback(error.to_string()))?;

        match attempt {
            Ok(()) => return Ok(()),
            Err(DecodeAttemptError::BeforeOutput(error)) => {
                tracing::warn!(
                    track_urn = resource,
                    transcoding = name,
                    reason = %error,
                    "SoundCloud decoder rejected stream; trying fallback"
                );
                failures.push(format!("{name}: {error}"));
            }
            Err(DecodeAttemptError::AfterOutput(error)) => {
                return Err(SoundCloudError::Playback(format!(
                    "{name} failed after playback started: {error}"
                )));
            }
            Err(DecodeAttemptError::RuntimeStopped) => {
                return Err(SoundCloudError::RuntimeStopped);
            }
        }
    }

    let details = if failures.is_empty() {
        "no compatible full-track stream was available".to_owned()
    } else {
        failures.join(" | ")
    };

    Err(SoundCloudError::Playback(format!(
        "all SoundCloud full-track streams failed: {details}"
    )))
}

async fn prepare_media(
    api: SoundCloudApi,
    track: &TrackRow,
) -> Result<PreparedMedia, SoundCloudError> {
    let ProviderTrackId::SoundCloud { id, urn, .. } = &track.provider_id else {
        return Err(SoundCloudError::NoPlayableStream);
    };
    let resource = urn.as_deref().unwrap_or(id);
    let streams = api.streams(resource).await?;
    let mut failures = Vec::new();
    for (name, stream_url, format) in streams.playback_candidates() {
        let result = match format {
            SoundCloudStreamFormat::AacHls | SoundCloudStreamFormat::Mp3Hls => {
                download_hls(&api, &stream_url, 0).await
            }
            SoundCloudStreamFormat::Mp3Http => api
                .media_resource(&stream_url)
                .await
                .map(|resource| resource.bytes),
        };
        match result {
            Ok(media) if !media.is_empty() => {
                return Ok(PreparedMedia {
                    media,
                    format,
                    name,
                });
            }
            Ok(_) => failures.push(format!("{name}: empty media")),
            Err(error) => {
                if !may_try_another_stream(&error) {
                    return Err(error);
                }
                failures.push(format!("{name}: {error}"));
            }
        }
    }
    Err(SoundCloudError::Playback(format!(
        "SoundCloud preload failed: {}",
        failures.join(" | ")
    )))
}

fn may_try_another_stream(error: &SoundCloudError) -> bool {
    !matches!(
        error,
        SoundCloudError::NotAuthenticated
            | SoundCloudError::RateLimited { .. }
            | SoundCloudError::RuntimeStopped
            | SoundCloudError::Api { status: 401, .. }
    )
}

fn stream_hls_audio<'a>(
    api: &'a SoundCloudApi,
    manifest_url: &'a str,
    format: SoundCloudStreamFormat,
    generation: u64,
    name: &'static str,
    tx: mpsc::Sender<LoaderEvent>,
    depth: u8,
) -> std::pin::Pin<Box<dyn std::future::Future<Output = Result<(), DecodeAttemptError>> + Send + 'a>>
{
    Box::pin(async move {
        if depth > 3 {
            return Err(DecodeAttemptError::BeforeOutput(
                "too many nested HLS manifests".to_owned(),
            ));
        }

        let resource = api
            .media_resource(manifest_url)
            .await
            .map_err(|error| DecodeAttemptError::BeforeOutput(error.to_string()))?;
        let text = String::from_utf8(resource.bytes)
            .map_err(|error| DecodeAttemptError::BeforeOutput(error.to_string()))?;
        if !text.trim_start().starts_with("#EXTM3U") {
            return Err(DecodeAttemptError::BeforeOutput(
                "SoundCloud HLS URL did not return an M3U8 playlist".to_owned(),
            ));
        }

        let base = resource.final_url;
        let lines: Vec<_> = text.lines().map(str::trim).collect();
        if lines
            .iter()
            .any(|line| line.starts_with("#EXT-X-STREAM-INF"))
        {
            let variant = select_master_variant(&lines).ok_or_else(|| {
                DecodeAttemptError::BeforeOutput("HLS master playlist has no variant".to_owned())
            })?;
            let url = base
                .join(variant)
                .map_err(|error| DecodeAttemptError::BeforeOutput(error.to_string()))?;
            return stream_hls_audio(api, url.as_str(), format, generation, name, tx, depth + 1)
                .await;
        }

        if lines
            .iter()
            .any(|line| line.starts_with("#EXT-X-BYTERANGE:"))
            || lines
                .iter()
                .any(|line| line.starts_with("#EXT-X-MAP:") && line.contains("BYTERANGE="))
        {
            return Err(DecodeAttemptError::BeforeOutput(
                "HLS byte-range playlists require full-download fallback".to_owned(),
            ));
        }

        let mut init_segment: Option<Vec<u8>> = None;
        for line in &lines {
            if line.starts_with("#EXT-X-MAP:") {
                let uri = attribute(line, "URI").ok_or_else(|| {
                    DecodeAttemptError::BeforeOutput(
                        "HLS initialization map is missing its URI".to_owned(),
                    )
                })?;
                let url = base
                    .join(&uri)
                    .map_err(|error| DecodeAttemptError::BeforeOutput(error.to_string()))?;
                let init = api
                    .media_resource(url.as_str())
                    .await
                    .map_err(|error| DecodeAttemptError::BeforeOutput(error.to_string()))?
                    .bytes;
                if init.is_empty() {
                    return Err(DecodeAttemptError::BeforeOutput(
                        "HLS initialization segment is empty".to_owned(),
                    ));
                }
                init_segment = Some(init);
                break;
            }
        }

        let segment_urls = lines
            .iter()
            .copied()
            .filter(|line| !line.is_empty() && !line.starts_with('#'))
            .map(|line| {
                base.join(line)
                    .map_err(|error| DecodeAttemptError::BeforeOutput(error.to_string()))
            })
            .collect::<Result<Vec<_>, _>>()?;
        if segment_urls.is_empty() {
            return Err(DecodeAttemptError::BeforeOutput(
                "HLS playlist contains no media".to_owned(),
            ));
        }

        let mut committed = false;
        for (segment_index, url) in segment_urls.into_iter().enumerate() {
            let segment = api
                .media_resource(url.as_str())
                .await
                .map_err(|error| {
                    if committed {
                        DecodeAttemptError::AfterOutput(error.to_string())
                    } else {
                        DecodeAttemptError::BeforeOutput(error.to_string())
                    }
                })?
                .bytes;
            if segment.is_empty() {
                return Err(if committed {
                    DecodeAttemptError::AfterOutput(format!(
                        "HLS media segment {segment_index} is empty"
                    ))
                } else {
                    DecodeAttemptError::BeforeOutput(format!(
                        "HLS media segment {segment_index} is empty"
                    ))
                });
            }

            let media = if let Some(init) = init_segment.as_ref() {
                let mut combined = Vec::with_capacity(init.len() + segment.len());
                combined.extend_from_slice(init);
                combined.extend_from_slice(&segment);
                combined
            } else {
                segment
            };
            let attempt_tx = tx.clone();
            let attempt = tokio::task::spawn_blocking(move || {
                decode_and_send(media, format, 0, generation, name, attempt_tx)
            })
            .await
            .map_err(|error| {
                if committed {
                    DecodeAttemptError::AfterOutput(error.to_string())
                } else {
                    DecodeAttemptError::BeforeOutput(error.to_string())
                }
            })?;

            match attempt {
                Ok(()) => committed = true,
                Err(DecodeAttemptError::BeforeOutput(error)) if !committed => {
                    return Err(DecodeAttemptError::BeforeOutput(error));
                }
                Err(DecodeAttemptError::BeforeOutput(error))
                | Err(DecodeAttemptError::AfterOutput(error)) => {
                    return Err(DecodeAttemptError::AfterOutput(error));
                }
                Err(DecodeAttemptError::RuntimeStopped) => {
                    return Err(DecodeAttemptError::RuntimeStopped);
                }
            }
        }

        Ok(())
    })
}

fn download_hls<'a>(
    api: &'a SoundCloudApi,
    manifest_url: &'a str,
    depth: u8,
) -> std::pin::Pin<
    Box<dyn std::future::Future<Output = Result<Vec<u8>, SoundCloudError>> + Send + 'a>,
> {
    Box::pin(async move {
        if depth > 3 {
            return Err(SoundCloudError::Playback(
                "too many nested HLS manifests".to_owned(),
            ));
        }

        let resource = api.media_resource(manifest_url).await?;
        let text = String::from_utf8(resource.bytes)
            .map_err(|error| SoundCloudError::Playback(error.to_string()))?;

        if !text.trim_start().starts_with("#EXTM3U") {
            return Err(SoundCloudError::Playback(
                "SoundCloud HLS URL did not return an M3U8 playlist".to_owned(),
            ));
        }

        // Use the final URL after redirects so relative segment URLs resolve
        // against the SoundCloud CDN rather than api.soundcloud.com.
        let base = resource.final_url;
        let lines: Vec<_> = text.lines().map(str::trim).collect();

        if lines
            .iter()
            .any(|line| line.starts_with("#EXT-X-STREAM-INF"))
        {
            let variant = select_master_variant(&lines).ok_or_else(|| {
                SoundCloudError::Playback("HLS master playlist has no variant".to_owned())
            })?;
            let url = base.join(variant)?;
            return download_hls(api, url.as_str(), depth + 1).await;
        }

        // Downloading a complete object for every byte-range entry corrupts the
        // reconstructed media. Reject this candidate cleanly so another
        // SoundCloud transcoding can be tried instead.
        if lines
            .iter()
            .any(|line| line.starts_with("#EXT-X-BYTERANGE:"))
            || lines
                .iter()
                .any(|line| line.starts_with("#EXT-X-MAP:") && line.contains("BYTERANGE="))
        {
            return Err(SoundCloudError::Playback(
                "HLS byte-range playlists are not supported by the native loader".to_owned(),
            ));
        }

        let mut media = Vec::new();
        let mut last_map_url: Option<String> = None;
        let mut media_segments = 0_usize;

        for line in lines {
            if line.is_empty() {
                continue;
            }

            if line.starts_with("#EXT-X-MAP:") {
                let Some(uri) = attribute(line, "URI") else {
                    return Err(SoundCloudError::Playback(
                        "HLS initialization map is missing its URI".to_owned(),
                    ));
                };
                let url = base.join(&uri)?;
                let absolute = url.to_string();

                // Repeated identical EXT-X-MAP lines must not duplicate init.mp4.
                if last_map_url.as_deref() != Some(absolute.as_str()) {
                    let init = api.media_resource(url.as_str()).await?.bytes;
                    if init.is_empty() {
                        return Err(SoundCloudError::Playback(
                            "HLS initialization segment is empty".to_owned(),
                        ));
                    }
                    media.extend(init);
                    last_map_url = Some(absolute);
                }
                continue;
            }

            if line.starts_with('#') {
                continue;
            }

            let url = base.join(line)?;
            let segment = api.media_resource(url.as_str()).await?.bytes;
            if segment.is_empty() {
                return Err(SoundCloudError::Playback(format!(
                    "HLS media segment {media_segments} is empty"
                )));
            }
            media.extend(segment);
            media_segments += 1;
        }

        if media_segments == 0 || media.is_empty() {
            return Err(SoundCloudError::Playback(
                "HLS playlist contains no media".to_owned(),
            ));
        }

        tracing::info!(
            segments = media_segments,
            bytes = media.len(),
            "SoundCloud HLS media assembled"
        );

        Ok(media)
    })
}

fn select_master_variant<'a>(lines: &'a [&'a str]) -> Option<&'a str> {
    let mut best: Option<(u64, &'a str)> = None;

    let mut index = 0;
    while index < lines.len() {
        let line = lines[index];
        if !line.starts_with("#EXT-X-STREAM-INF:") {
            index += 1;
            continue;
        }

        let bandwidth = unquoted_attribute(line, "BANDWIDTH")
            .and_then(|value| value.parse::<u64>().ok())
            .unwrap_or(0);

        let uri = lines[index + 1..]
            .iter()
            .copied()
            .find(|candidate| !candidate.is_empty() && !candidate.starts_with('#'));

        if let Some(uri) = uri {
            if best.is_none_or(|(current, _)| bandwidth >= current) {
                best = Some((bandwidth, uri));
            }
        }

        index += 1;
    }

    best.map(|(_, uri)| uri)
}

fn attribute(line: &str, name: &str) -> Option<String> {
    let marker = format!("{name}=\"");
    let value = line.split(&marker).nth(1)?;
    Some(value.split('"').next()?.to_owned())
}

fn unquoted_attribute<'a>(line: &'a str, name: &str) -> Option<&'a str> {
    let marker = format!("{name}=");
    let value = line.split(&marker).nth(1)?;
    Some(value.split(',').next()?.trim())
}

#[derive(Debug, Clone, Copy)]
enum ElementaryAudioFormat {
    Aac,
    Mp3,
}

enum DecodeAttemptError {
    /// Decoder rejected the stream before any samples were committed. The
    /// caller may safely try another SoundCloud transcoding.
    BeforeOutput(String),
    /// Playback already emitted samples, so switching streams would duplicate
    /// audio and reset the timeline. Surface the failure instead.
    AfterOutput(String),
    RuntimeStopped,
}

fn decode_and_send(
    media: Vec<u8>,
    stream_format: SoundCloudStreamFormat,
    seek_ms: u32,
    generation: u64,
    name: &'static str,
    tx: mpsc::Sender<LoaderEvent>,
) -> Result<(), DecodeAttemptError> {
    let is_transport_stream =
        media.len() >= 188 && media[0] == 0x47 && media.get(188) == Some(&0x47);

    let (media, extension, mime_type) = if is_transport_stream {
        let (elementary, elementary_format) = extract_audio_from_mpeg_ts(&media)
            .map_err(|error| DecodeAttemptError::BeforeOutput(error.to_string()))?;
        match elementary_format {
            ElementaryAudioFormat::Aac => (elementary, "aac", "audio/aac"),
            ElementaryAudioFormat::Mp3 => (elementary, "mp3", "audio/mpeg"),
        }
    } else if looks_like_adts(&media) {
        (media, "aac", "audio/aac")
    } else {
        match stream_format {
            SoundCloudStreamFormat::AacHls => (media, "m4a", "audio/mp4"),
            SoundCloudStreamFormat::Mp3Hls | SoundCloudStreamFormat::Mp3Http => {
                (media, "mp3", "audio/mpeg")
            }
        }
    };

    tracing::info!(
        transcoding = name,
        bytes = media.len(),
        extension,
        mime_type,
        "SoundCloud preparing decoder"
    );

    let mut hint = Hint::new();
    hint.with_extension(extension);
    hint.mime_type(mime_type);

    // librespot's SymphoniaDecoder checks codec_params.channels immediately
    // after creating the codec. SoundCloud's modern fragmented MP4/AAC stream
    // can leave that field unset until the first AAC frame is decoded. Probe
    // and decode directly with Symphonia so the actual decoded SignalSpec is
    // authoritative instead of failing early with
    // "Could not retrieve channel configuration".
    let mss = MediaSourceStream::new(
        Box::new(Cursor::new(media)),
        MediaSourceStreamOptions::default(),
    );
    let format_opts = FormatOptions {
        enable_gapless: true,
        ..Default::default()
    };
    let metadata_opts = MetadataOptions::default();
    let mut probe = symphonia::default::get_probe()
        .format(&hint, mss, &format_opts, &metadata_opts)
        .map_err(|error| DecodeAttemptError::BeforeOutput(error.to_string()))?;

    let track = probe.format.default_track().ok_or_else(|| {
        DecodeAttemptError::BeforeOutput("could not retrieve default audio track".to_owned())
    })?;
    let track_id = track.id;

    let decoder_opts = DecoderOptions::default();
    let mut decoder = symphonia::default::get_codecs()
        .make(&track.codec_params, &decoder_opts)
        .map_err(|error| DecodeAttemptError::BeforeOutput(error.to_string()))?;

    if seek_ms > 0 {
        let target = Duration::from_millis(u64::from(seek_ms));
        probe
            .format
            .seek(
                SeekMode::Accurate,
                SeekTo::Time {
                    time: target.into(),
                    track_id: Some(track_id),
                },
            )
            .map_err(|error| DecodeAttemptError::BeforeOutput(error.to_string()))?;
        decoder.reset();
    }

    // Fast-start: commit after roughly 180 ms instead of waiting a full second.
    // This preserves a small decoder safety buffer while making perceived start
    // latency much closer to an instant response once encoded media is ready.
    let chunk_target = ((SAMPLE_RATE as usize * CHANNELS as usize) * 180 / 1_000).max(1);
    let mut chunk = Vec::with_capacity(chunk_target);
    let mut output_started = false;
    let mut sample_buffer: Option<SampleBuffer<f64>> = None;
    let mut decoded_rate: Option<u32> = None;
    let mut decoded_channels: Option<usize> = None;

    loop {
        let packet = match probe.format.next_packet() {
            Ok(packet) => packet,
            Err(SymphoniaError::IoError(error)) if error.kind() == io::ErrorKind::UnexpectedEof => {
                break;
            }
            Err(error) => {
                return Err(if output_started {
                    DecodeAttemptError::AfterOutput(error.to_string())
                } else {
                    DecodeAttemptError::BeforeOutput(error.to_string())
                });
            }
        };

        if packet.track_id() != track_id {
            continue;
        }

        let decoded = match decoder.decode(&packet) {
            Ok(decoded) => decoded,
            Err(SymphoniaError::DecodeError(error)) => {
                tracing::warn!(
                    transcoding = name,
                    reason = error,
                    "SoundCloud skipping malformed audio packet"
                );
                continue;
            }
            Err(error) => {
                return Err(if output_started {
                    DecodeAttemptError::AfterOutput(error.to_string())
                } else {
                    DecodeAttemptError::BeforeOutput(error.to_string())
                });
            }
        };

        let spec = *decoded.spec();
        let rate = spec.rate;
        let channels = spec.channels.count();

        if let Some(previous) = decoded_rate {
            if previous != rate {
                let error =
                    format!("audio sample rate changed mid-stream from {previous} Hz to {rate} Hz");
                return Err(if output_started {
                    DecodeAttemptError::AfterOutput(error)
                } else {
                    DecodeAttemptError::BeforeOutput(error)
                });
            }
        } else {
            decoded_rate = Some(rate);
        }

        if let Some(previous) = decoded_channels {
            if previous != channels {
                let error =
                    format!("audio channel count changed mid-stream from {previous} to {channels}");
                return Err(if output_started {
                    DecodeAttemptError::AfterOutput(error)
                } else {
                    DecodeAttemptError::BeforeOutput(error)
                });
            }
        } else {
            decoded_channels = Some(channels);
            tracing::info!(
                transcoding = name,
                sample_rate = rate,
                channels,
                "SoundCloud decoded audio format"
            );
        }

        if rate != SAMPLE_RATE {
            let error = format!(
                "unsupported SoundCloud sample rate: {rate} Hz (player output is {SAMPLE_RATE} Hz)"
            );
            return Err(if output_started {
                DecodeAttemptError::AfterOutput(error)
            } else {
                DecodeAttemptError::BeforeOutput(error)
            });
        }

        if channels != 1 && channels != CHANNELS as usize {
            let error = format!(
                "unsupported SoundCloud channel count: {channels} (expected mono or stereo)"
            );
            return Err(if output_started {
                DecodeAttemptError::AfterOutput(error)
            } else {
                DecodeAttemptError::BeforeOutput(error)
            });
        }

        let buffer = match sample_buffer.as_mut() {
            Some(buffer) => buffer,
            None => sample_buffer.insert(SampleBuffer::new(decoded.capacity() as u64, spec)),
        };
        buffer.copy_interleaved_ref(decoded);
        let samples = buffer.samples();

        if channels == 1 {
            chunk.reserve(samples.len());
            for &sample in samples {
                chunk.push(sample);
                chunk.push(sample);
            }
        } else {
            chunk.extend_from_slice(samples);
        }

        if !output_started && chunk.len() >= chunk_target {
            tx.blocking_send(LoaderEvent::Selected { generation, name })
                .map_err(|_| DecodeAttemptError::RuntimeStopped)?;
            tx.blocking_send(LoaderEvent::Samples {
                generation,
                samples: std::mem::take(&mut chunk),
            })
            .map_err(|_| DecodeAttemptError::RuntimeStopped)?;
            output_started = true;
            continue;
        }

        if output_started && chunk.len() >= chunk_target {
            tx.blocking_send(LoaderEvent::Samples {
                generation,
                samples: std::mem::take(&mut chunk),
            })
            .map_err(|_| DecodeAttemptError::RuntimeStopped)?;
        }
    }

    if !output_started {
        if chunk.is_empty() {
            return Err(DecodeAttemptError::BeforeOutput(
                "stream contained no decodable audio samples".to_owned(),
            ));
        }

        tx.blocking_send(LoaderEvent::Selected { generation, name })
            .map_err(|_| DecodeAttemptError::RuntimeStopped)?;
    }

    if !chunk.is_empty() {
        tx.blocking_send(LoaderEvent::Samples {
            generation,
            samples: chunk,
        })
        .map_err(|_| DecodeAttemptError::RuntimeStopped)?;
    }

    tx.blocking_send(LoaderEvent::Finished { generation })
        .map_err(|_| DecodeAttemptError::RuntimeStopped)?;
    Ok(())
}

fn looks_like_adts(input: &[u8]) -> bool {
    input.len() >= 2 && input[0] == 0xff && (input[1] & 0xf0) == 0xf0
}

fn extract_audio_from_mpeg_ts(
    input: &[u8],
) -> Result<(Vec<u8>, ElementaryAudioFormat), SoundCloudError> {
    let mut pmt_pid = None;
    let mut audio: Option<(u16, ElementaryAudioFormat)> = None;

    for packet in input.chunks_exact(188) {
        let Some((pid, start, payload)) = ts_payload(packet) else {
            continue;
        };
        if pid == 0 && start {
            let section = psi_section(payload);
            if section.first() == Some(&0x00) && section.len() >= 12 {
                let section_len = ((usize::from(section[1] & 0x0f)) << 8) | usize::from(section[2]);
                let end = (3 + section_len).saturating_sub(4).min(section.len());
                let mut pos = 8;
                while pos + 4 <= end {
                    let program = u16::from_be_bytes([section[pos], section[pos + 1]]);
                    if program != 0 {
                        pmt_pid = Some(
                            ((u16::from(section[pos + 2] & 0x1f)) << 8)
                                | u16::from(section[pos + 3]),
                        );
                        break;
                    }
                    pos += 4;
                }
            }
        } else if Some(pid) == pmt_pid && start {
            let section = psi_section(payload);
            if section.first() == Some(&0x02) && section.len() >= 12 {
                let section_len = ((usize::from(section[1] & 0x0f)) << 8) | usize::from(section[2]);
                let end = (3 + section_len).saturating_sub(4).min(section.len());
                let program_info_len =
                    ((usize::from(section[10] & 0x0f)) << 8) | usize::from(section[11]);
                let mut pos = 12 + program_info_len;
                while pos + 5 <= end {
                    let stream_type = section[pos];
                    let pid =
                        ((u16::from(section[pos + 1] & 0x1f)) << 8) | u16::from(section[pos + 2]);
                    let info_len = ((usize::from(section[pos + 3] & 0x0f)) << 8)
                        | usize::from(section[pos + 4]);
                    let format = match stream_type {
                        0x0f | 0x11 => Some(ElementaryAudioFormat::Aac),
                        0x03 | 0x04 => Some(ElementaryAudioFormat::Mp3),
                        _ => None,
                    };
                    if let Some(format) = format {
                        audio = Some((pid, format));
                        break;
                    }
                    pos += 5 + info_len;
                }
            }
        }
        if audio.is_some() {
            break;
        }
    }

    let (audio_pid, format) = audio.ok_or_else(|| {
        SoundCloudError::Playback(
            "supported audio stream was not found in HLS transport data".to_owned(),
        )
    })?;

    let mut elementary = Vec::new();
    for packet in input.chunks_exact(188) {
        let Some((pid, start, payload)) = ts_payload(packet) else {
            continue;
        };
        if pid != audio_pid {
            continue;
        }
        if start {
            if payload.len() < 9 || !payload.starts_with(&[0, 0, 1]) {
                continue;
            }
            let header_len = 9 + usize::from(payload[8]);
            if header_len < payload.len() {
                elementary.extend_from_slice(&payload[header_len..]);
            }
        } else {
            elementary.extend_from_slice(payload);
        }
    }

    if elementary.is_empty() {
        return Err(SoundCloudError::Playback(
            "SoundCloud HLS audio payload is empty".to_owned(),
        ));
    }
    Ok((elementary, format))
}

fn ts_payload(packet: &[u8]) -> Option<(u16, bool, &[u8])> {
    if packet.len() != 188 || packet[0] != 0x47 || packet[1] & 0x80 != 0 {
        return None;
    }
    let start = packet[1] & 0x40 != 0;
    let pid = ((u16::from(packet[1] & 0x1f)) << 8) | u16::from(packet[2]);
    let control = (packet[3] >> 4) & 0x03;
    if control == 0 || control == 2 {
        return None;
    }
    let mut offset = 4;
    if control == 3 {
        offset += 1 + usize::from(*packet.get(4)?);
    }
    (offset < packet.len()).then(|| (pid, start, &packet[offset..]))
}

fn psi_section(payload: &[u8]) -> &[u8] {
    let Some(pointer) = payload.first().copied().map(usize::from) else {
        return &[];
    };
    payload.get(1 + pointer..).unwrap_or(&[])
}

struct SoundCloudDspSource {
    samples: Vec<f64>,
    cursor: usize,
    processed: Vec<f32>,
    processed_cursor: usize,
    dsp: Arc<DspPlaybackProcessor>,
}

impl SoundCloudDspSource {
    fn new(samples: Vec<f64>, dsp: Arc<DspPlaybackProcessor>) -> Self {
        Self {
            samples,
            cursor: 0,
            processed: Vec::new(),
            processed_cursor: 0,
            dsp,
        }
    }

    fn refill(&mut self) -> bool {
        if self.cursor >= self.samples.len() {
            return false;
        }

        const DSP_BLOCK_FRAMES: usize = 512;
        const DSP_BLOCK_SAMPLES: usize = DSP_BLOCK_FRAMES * CHANNELS as usize;

        let end = (self.cursor + DSP_BLOCK_SAMPLES).min(self.samples.len());
        let mut block = self.samples[self.cursor..end].to_vec();
        self.cursor = end;

        self.dsp.process_f64(&mut block);

        self.processed.clear();
        self.processed.reserve(block.len());
        self.processed.extend(
            block
                .into_iter()
                .map(|sample| sample.clamp(-1.0, 1.0) as f32),
        );
        self.processed_cursor = 0;
        !self.processed.is_empty()
    }

    fn remaining_samples(&self) -> usize {
        self.processed.len().saturating_sub(self.processed_cursor)
            + self.samples.len().saturating_sub(self.cursor)
    }
}

impl Iterator for SoundCloudDspSource {
    type Item = f32;

    fn next(&mut self) -> Option<Self::Item> {
        if self.processed_cursor >= self.processed.len() && !self.refill() {
            return None;
        }

        let sample = self.processed[self.processed_cursor];
        self.processed_cursor += 1;
        Some(sample)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let remaining = self.remaining_samples();
        (remaining, Some(remaining))
    }
}

impl ExactSizeIterator for SoundCloudDspSource {}

impl rodio::Source for SoundCloudDspSource {
    fn current_span_len(&self) -> Option<usize> {
        Some(self.remaining_samples())
    }

    fn channels(&self) -> u16 {
        CHANNELS
    }

    fn sample_rate(&self) -> u32 {
        SAMPLE_RATE
    }

    fn total_duration(&self) -> Option<Duration> {
        let frames = self.samples.len() as f64 / f64::from(CHANNELS);
        Some(Duration::from_secs_f64(frames / f64::from(SAMPLE_RATE)))
    }
}

fn append_samples(output: &NativeOutput, samples: Vec<f64>) {
    if samples.is_empty() {
        return;
    }

    output
        .volume
        .append(SoundCloudDspSource::new(samples, output.dsp.clone()));
}

fn create_output(
    device_name: Option<String>,
    volume: f32,
    controls: Arc<DspControls>,
) -> Result<NativeOutput, String> {
    fn assert_send<T: Send>() {}
    assert_send::<NativeOutput>();

    let host = cpal::default_host();
    let device = if let Some(name) = device_name.as_deref() {
        let selected = host
            .output_devices()
            .map_err(|error| error.to_string())?
            .find(|device| device.name().ok().as_deref() == Some(name));
        if let Some(device) = selected {
            device
        } else {
            tracing::warn!(
                requested = name,
                "Selected SoundCloud output disappeared; using Windows default"
            );
            host.default_output_device()
                .ok_or_else(|| "Windows default audio output is unavailable".to_owned())?
        }
    } else {
        host.default_output_device()
            .ok_or_else(|| "Windows default audio output is unavailable".to_owned())?
    };
    let selected = device.name().unwrap_or_else(|_| "unknown".to_owned());
    tracing::info!(device = %selected, "SoundCloud opening local audio output");
    let mut stream = rodio::OutputStreamBuilder::from_device(device)
        .map_err(|error| error.to_string())?
        .open_stream_or_fallback()
        .map_err(|error| error.to_string())?;
    stream.log_on_drop(false);
    let sink = Arc::new(rodio::Sink::connect_new(stream.mixer()));
    sink.set_volume(volume);
    sink.pause();
    Ok(NativeOutput {
        dsp: DspPlaybackProcessor::new(controls),
        volume: sink,
        _stream: stream,
    })
}

fn cancel_loader(task: &mut Option<tokio::task::JoinHandle<()>>) {
    if let Some(task) = task.take() {
        task.abort();
    }
}
fn current_duration(queue: &[TrackRow], index: Option<usize>) -> u64 {
    index
        .and_then(|i| queue.get(i))
        .map(|track| track.duration_ms)
        .unwrap_or(0)
}
fn displayed_position(base: u32, anchor: Instant, status: &PlaybackStatus, duration: u64) -> u32 {
    let elapsed = if *status == PlaybackStatus::Playing {
        anchor.elapsed().as_millis() as u64
    } else {
        0
    };
    u64::from(base)
        .saturating_add(elapsed)
        .min(duration)
        .min(u64::from(u32::MAX)) as u32
}
fn playback_error(error: impl Into<String>) -> PlaybackError {
    PlaybackError::new(
        PlaybackErrorKind::AudioBackend,
        format!("SoundCloud playback failed: {}", error.into()),
    )
}
fn fail(
    tx: &flume::Sender<crate::soundcloud::SoundCloudEvent>,
    ctx: &egui::Context,
    queue: &[TrackRow],
    index: Option<usize>,
    position: u32,
    error: &str,
) {
    emit(
        tx,
        ctx,
        queue,
        index,
        &PlaybackStatus::Error(playback_error(error)),
        position,
    );
}
fn emit(
    tx: &flume::Sender<crate::soundcloud::SoundCloudEvent>,
    ctx: &egui::Context,
    queue: &[TrackRow],
    index: Option<usize>,
    status: &PlaybackStatus,
    position_ms: u32,
) {
    emit_with_end(tx, ctx, queue, index, status, position_ms, false);
}

fn emit_with_end(
    tx: &flume::Sender<crate::soundcloud::SoundCloudEvent>,
    ctx: &egui::Context,
    queue: &[TrackRow],
    index: Option<usize>,
    status: &PlaybackStatus,
    position_ms: u32,
    ended: bool,
) {
    let update = SoundCloudPlaybackUpdate {
        track: index.and_then(|i| queue.get(i)).cloned(),
        status: status.clone(),
        position_ms,
        queue_index: index,
        queue_len: queue.len(),
        ended,
    };
    let _ = tx.send(crate::soundcloud::SoundCloudEvent::PlaybackChanged(update));
    ctx.request_repaint();
}
