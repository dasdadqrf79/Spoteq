//! SoundCloud response models needed by authentication and future API features.

use serde::Deserialize;

use crate::catalog::{ProviderTrackId, TrackPage, TrackProvider, TrackRow};

/// Authenticated SoundCloud account returned by `GET /me`.
#[derive(Debug, Clone, Deserialize)]
pub struct SoundCloudProfile {
    /// Stable numeric SoundCloud user identifier.
    pub id: u64,
    /// Public username.
    pub username: String,
    /// Public profile URL, when supplied by the API.
    pub permalink_url: Option<String>,
    /// Profile image URL, when supplied by the API.
    pub avatar_url: Option<String>,
}

/// Decoded avatar pixels transferred to the egui thread.
#[derive(Debug, Clone)]
pub struct DecodedAvatar {
    /// Pixel width and height.
    pub size: [usize; 2],
    /// Unmultiplied RGBA8 pixels.
    pub rgba: Vec<u8>,
}

/// Decoded SoundCloud artwork transferred to the egui thread.
#[derive(Debug, Clone)]
pub struct DecodedArtwork {
    /// Pixel width and height.
    pub size: [usize; 2],
    /// Unmultiplied RGBA8 pixels.
    pub rgba: Vec<u8>,
}

/// Current stream URLs returned by `/tracks/{track_urn}/streams`.
#[derive(Debug, Clone, Deserialize)]
pub(crate) struct SoundCloudStreams {
    /// Preferred modern 160 kbit/s AAC HLS stream.
    pub hls_aac_160_url: Option<String>,
    /// Modern 96 kbit/s AAC HLS fallback.
    pub hls_aac_96_url: Option<String>,
    /// Legacy HLS MP3 fallback. Some older catalog entries may still expose it.
    pub hls_mp3_128_url: Option<String>,
    /// Legacy progressive MP3 fallback. Some older catalog entries may still expose it.
    pub http_mp3_128_url: Option<String>,
    /// Preview is deliberately not used for full-track playback.
    pub preview_mp3_128_url: Option<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum SoundCloudStreamFormat {
    AacHls,
    Mp3Hls,
    Mp3Http,
}

impl SoundCloudStreams {
    /// Returns every full-track stream in the order the player should try it.
    /// Modern AAC HLS is preferred, while legacy MP3 variants remain useful as
    /// compatibility fallbacks when SoundCloud still exposes them.
    pub fn playback_candidates(&self) -> Vec<(&'static str, String, SoundCloudStreamFormat)> {
        let mut candidates = Vec::with_capacity(4);

        if let Some(url) = self.hls_aac_160_url.clone() {
            candidates.push(("hls_aac_160", url, SoundCloudStreamFormat::AacHls));
        }
        if let Some(url) = self.hls_aac_96_url.clone() {
            candidates.push(("hls_aac_96", url, SoundCloudStreamFormat::AacHls));
        }
        if let Some(url) = self.hls_mp3_128_url.clone() {
            candidates.push(("hls_mp3_128", url, SoundCloudStreamFormat::Mp3Hls));
        }
        if let Some(url) = self.http_mp3_128_url.clone() {
            candidates.push(("http_mp3_128", url, SoundCloudStreamFormat::Mp3Http));
        }

        candidates
    }

    pub fn available_variants(&self) -> Vec<&'static str> {
        let mut variants = Vec::new();
        if self.hls_aac_160_url.is_some() {
            variants.push("hls_aac_160_url");
        }
        if self.hls_aac_96_url.is_some() {
            variants.push("hls_aac_96_url");
        }
        if self.hls_mp3_128_url.is_some() {
            variants.push("hls_mp3_128_url");
        }
        if self.http_mp3_128_url.is_some() {
            variants.push("http_mp3_128_url");
        }
        if self.preview_mp3_128_url.is_some() {
            variants.push("preview_mp3_128_url");
        }
        variants
    }
}

#[derive(Debug, Deserialize)]
pub(crate) struct RawTrackPage {
    #[serde(default)]
    collection: Vec<RawSoundCloudTrack>,
    next_href: Option<String>,
}

impl RawTrackPage {
    pub fn into_page(self) -> TrackPage {
        TrackPage {
            items: self
                .collection
                .into_iter()
                .map(RawSoundCloudTrack::into_track_row)
                .collect(),
            next_href: self.next_href.filter(|href| !href.trim().is_empty()),
        }
    }
}

#[derive(Debug, Deserialize)]
struct RawSoundCloudTrack {
    id: RawSoundCloudId,
    urn: Option<String>,
    title: String,
    #[serde(default)]
    duration: u64,
    artwork_url: Option<String>,
    permalink_url: Option<String>,
    access: Option<String>,
    streamable: Option<bool>,
    metadata_artist: Option<String>,
    user: Option<RawSoundCloudUser>,
    publisher_metadata: Option<RawPublisherMetadata>,
}

impl RawSoundCloudTrack {
    fn into_track_row(self) -> TrackRow {
        let metadata_artist = self
            .metadata_artist
            .as_deref()
            .filter(|artist| !artist.trim().is_empty());
        let publisher_artist = self
            .publisher_metadata
            .as_ref()
            .and_then(|metadata| metadata.artist.as_deref())
            .filter(|artist| !artist.trim().is_empty());
        let uploader = self
            .user
            .as_ref()
            .map(|user| user.username.as_str())
            .filter(|username| !username.trim().is_empty());
        let artist = metadata_artist
            .or(publisher_artist)
            .or(uploader)
            .unwrap_or("Unknown artist");
        let collection = self
            .publisher_metadata
            .as_ref()
            .and_then(|metadata| metadata.album_title.as_deref())
            .filter(|album| !album.trim().is_empty())
            .unwrap_or("SoundCloud");
        let playable = self.streamable.unwrap_or(true)
            && self
                .access
                .as_deref()
                .is_none_or(|access| access.eq_ignore_ascii_case("playable"));

        TrackRow {
            provider: TrackProvider::SoundCloud,
            provider_id: ProviderTrackId::SoundCloud {
                id: self.id.into_string(),
                urn: self.urn,
                permalink_url: self.permalink_url,
            },
            title: self.title,
            artist: artist.to_owned(),
            collection: collection.to_owned(),
            duration_ms: self.duration,
            artwork_url: self.artwork_url,
            liked: None,
            playable,
        }
    }
}

#[derive(Debug, Deserialize)]
#[serde(untagged)]
enum RawSoundCloudId {
    Number(u64),
    Text(String),
}

impl RawSoundCloudId {
    fn into_string(self) -> String {
        match self {
            Self::Number(id) => id.to_string(),
            Self::Text(id) => id,
        }
    }
}

#[derive(Debug, Deserialize)]
struct RawSoundCloudUser {
    username: String,
}

#[derive(Debug, Deserialize)]
struct RawPublisherMetadata {
    artist: Option<String>,
    album_title: Option<String>,
}

#[cfg(test)]
mod tests {
    use super::RawTrackPage;
    use crate::catalog::{ProviderTrackId, TrackProvider};

    #[test]
    fn linked_track_page_preserves_provider_identity_and_cursor() {
        let raw: RawTrackPage = serde_json::from_str(
            r#"{
                "collection": [{
                    "id": 123456,
                    "urn": "soundcloud:tracks:123456",
                    "title": "Example",
                    "duration": 185000,
                    "artwork_url": "https://i1.sndcdn.com/artworks-example-large.jpg",
                    "permalink_url": "https://soundcloud.com/example/track",
                    "access": "playable",
                    "streamable": true,
                    "user": { "username": "Uploader" },
                    "publisher_metadata": {
                        "artist": "Artist",
                        "album_title": "Album"
                    }
                }],
                "next_href": "https://api.soundcloud.com/tracks?cursor=opaque"
            }"#,
        )
        .expect("fixture must deserialize");

        let page = raw.into_page();
        assert_eq!(
            page.next_href.as_deref(),
            Some("https://api.soundcloud.com/tracks?cursor=opaque")
        );
        assert_eq!(page.items.len(), 1);
        let track = &page.items[0];
        assert_eq!(track.provider, TrackProvider::SoundCloud);
        assert_eq!(track.artist, "Artist");
        assert_eq!(track.collection, "Album");
        assert!(track.playable);
        assert!(matches!(
            &track.provider_id,
            ProviderTrackId::SoundCloud { id, urn: Some(urn), .. }
                if id == "123456" && urn == "soundcloud:tracks:123456"
        ));
    }

    #[test]
    fn string_ids_and_empty_cursors_are_accepted() {
        let raw: RawTrackPage = serde_json::from_str(
            r#"{
                "collection": [{
                    "id": "future-id",
                    "title": "Example",
                    "duration": 1000,
                    "access": "blocked",
                    "streamable": true
                }],
                "next_href": ""
            }"#,
        )
        .expect("fixture must deserialize");

        let page = raw.into_page();
        assert!(page.next_href.is_none());
        assert!(!page.items[0].playable);
        assert!(matches!(
            &page.items[0].provider_id,
            ProviderTrackId::SoundCloud { id, .. } if id == "future-id"
        ));
    }
}
