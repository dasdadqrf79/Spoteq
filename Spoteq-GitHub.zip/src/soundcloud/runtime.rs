//! Independent non-blocking coordinator for SoundCloud authentication and API state.

use std::{thread, thread::JoinHandle, time::Duration};

use eframe::egui;
use flume::{Receiver, Sender};
use reqwest::Client;
use tokio::sync::mpsc;

use crate::soundcloud::{
    DecodedArtwork, DecodedAvatar, PublicSoundCloudConfig, SoundCloudError, SoundCloudProfile,
    api::SoundCloudApi,
    auth::{SharedSoundCloudAuth, SoundCloudAuth},
    config::SoundCloudConfig,
    playback::{self, SoundCloudPlaybackCommand, SoundCloudPlaybackUpdate},
    token_store::SoundCloudTokenStore,
};
use crate::{
    audio::dsp::DspControls,
    catalog::{TrackPage, TrackRow},
};

/// Commands accepted by the SoundCloud background service.
#[derive(Debug, Clone)]
pub enum SoundCloudCommand {
    /// Start first-time browser authorization.
    Connect,
    /// Discard the current token and authorize again.
    Reconnect,
    /// Revoke the remote session when possible and always clear the local token.
    Logout,
    /// Search the first playable SoundCloud track page.
    Search {
        /// User-entered query.
        query: String,
        /// UI generation used to reject stale responses.
        generation: u64,
    },
    /// Follow an opaque SoundCloud Search continuation URL.
    SearchNext {
        /// Original query retained for diagnostics and future retries.
        query: String,
        /// Absolute `next_href` returned by SoundCloud.
        next_href: String,
        /// UI generation used to reject stale responses.
        generation: u64,
    },
    /// Load the first or next page of the authenticated user's likes.
    LoadLikes {
        /// `None` for the first page, otherwise SoundCloud's opaque continuation URL.
        next_href: Option<String>,
        /// UI generation used to reject stale responses.
        generation: u64,
    },
    /// Query one track against the real SoundCloud likes collection.
    LoadLikedState {
        urn: String,
        stable_key: String,
        request_id: u64,
    },
    /// Like or unlike one track in the real SoundCloud account.
    SetLiked {
        urn: String,
        stable_key: String,
        liked: bool,
        request_id: u64,
    },
    /// Generate a related-track batch from current/recent real track seeds.
    Recommend {
        seeds: Vec<TrackRow>,
        generation: u64,
        limit: usize,
    },
    /// Download one SoundCloud artwork image outside the UI thread.
    LoadArtwork {
        /// Exact artwork URL returned by the API.
        url: String,
    },
    /// Replaces the local SoundCloud queue and starts the selected row.
    PlayQueue { tracks: Vec<TrackRow>, index: usize },
    /// Preloads one likely next/hovered SoundCloud track into the fast-start cache.
    PreloadTrack { track: TrackRow },
    /// Toggles native SoundCloud playback.
    TogglePlayback,
    /// Moves within the local SoundCloud queue.
    Previous,
    /// Moves within the local SoundCloud queue.
    Next,
    /// Seeks the active SoundCloud stream.
    Seek { position_ms: u32 },
    /// Applies local SoundCloud output volume immediately.
    SetVolume { volume: f32 },
    /// Recreates SoundCloud output on the selected device.
    SetOutputDevice { device: Option<String> },
    /// Stops SoundCloud without changing OAuth state.
    StopPlayback,
    /// Stop the background service.
    Shutdown,
}

/// Immutable SoundCloud events delivered to the egui thread.
#[derive(Debug)]
pub enum SoundCloudEvent {
    /// Configuration was loaded without exposing the client secret.
    Configured(Result<PublicSoundCloudConfig, String>),
    /// A stored user session is being restored.
    Restoring,
    /// No stored SoundCloud session exists.
    LoggedOut,
    /// Browser authorization is in progress.
    Authorizing,
    /// `GET /me` succeeded for the connected account.
    LoggedIn(SoundCloudProfile),
    /// OAuth or token persistence failed.
    AuthFailed(String),
    /// An authenticated SoundCloud API call failed.
    ApiFailed(String),
    /// One SoundCloud Search page completed.
    SearchFinished {
        /// Query generation supplied by the UI.
        generation: u64,
        /// Whether this result follows a previous page.
        append: bool,
        /// Provider rows or a recoverable API error.
        result: Result<TrackPage, String>,
    },
    /// One SoundCloud Likes page completed.
    LikesFinished {
        /// Library generation supplied by the UI.
        generation: u64,
        /// Whether this result follows a previous page.
        append: bool,
        /// Provider rows or a recoverable API error.
        result: Result<TrackPage, String>,
    },
    /// Provider source-of-truth state for one Heart.
    LikedStateLoaded {
        stable_key: String,
        request_id: u64,
        result: Result<bool, String>,
    },
    /// Result of a provider-native SoundCloud Like/Unlike mutation.
    LikedChanged {
        stable_key: String,
        liked: bool,
        request_id: u64,
        result: Result<(), String>,
    },
    /// Autoplay recommendation batch completed.
    RecommendationsFinished {
        generation: u64,
        result: Result<Vec<TrackRow>, String>,
    },
    /// The profile avatar was decoded away from the UI thread.
    AvatarFinished {
        /// Original avatar URL.
        url: String,
        /// Decoded pixels or a recoverable error.
        result: Result<DecodedAvatar, String>,
    },
    /// Track artwork was decoded away from the UI thread.
    ArtworkFinished {
        /// Original artwork URL.
        url: String,
        /// Decoded pixels or a recoverable error.
        result: Result<DecodedArtwork, String>,
    },
    /// Native SoundCloud player state changed.
    PlaybackChanged(SoundCloudPlaybackUpdate),
}

/// UI-safe handle for the dedicated SoundCloud runtime.
pub struct SoundCloudRuntime {
    command_tx: Sender<SoundCloudCommand>,
    event_rx: Receiver<SoundCloudEvent>,
    thread: Option<JoinHandle<()>>,
}

impl SoundCloudRuntime {
    /// Disconnected, in-memory handle for UI tests; starts no workers or authentication.
    #[cfg(test)]
    pub(crate) fn for_ui_test() -> Self {
        let (command_tx, _) = flume::unbounded();
        let (_, event_rx) = flume::unbounded();
        Self {
            command_tx,
            event_rx,
            thread: None,
        }
    }

    /// Starts SoundCloud without delaying or sharing the Spotify runtime.
    pub fn start(
        context: egui::Context,
        initial_volume: f32,
        initial_output_device: Option<String>,
        dsp_controls: std::sync::Arc<DspControls>,
    ) -> Result<Self, std::io::Error> {
        let (command_tx, command_rx) = flume::unbounded();
        let (event_tx, event_rx) = flume::unbounded();
        let thread = thread::Builder::new()
            .name("soundcloud-runtime".to_owned())
            .spawn(move || {
                runtime_thread(
                    command_rx,
                    event_tx,
                    context,
                    initial_volume,
                    initial_output_device,
                    dsp_controls,
                )
            })?;
        Ok(Self {
            command_tx,
            event_rx,
            thread: Some(thread),
        })
    }

    /// Queues an operation without blocking egui.
    pub fn send(&self, command: SoundCloudCommand) -> Result<(), SoundCloudError> {
        self.command_tx
            .send(command)
            .map_err(|_| SoundCloudError::RuntimeStopped)
    }

    /// Drains currently available UI events.
    pub fn drain(&self) -> flume::TryIter<'_, SoundCloudEvent> {
        self.event_rx.try_iter()
    }
}

impl Drop for SoundCloudRuntime {
    fn drop(&mut self) {
        let _ = self.command_tx.send(SoundCloudCommand::Shutdown);
        if let Some(thread) = self.thread.take() {
            let _ = thread.join();
        }
    }
}

#[derive(Clone, Copy)]
enum AuthTaskKind {
    Restore,
    Connect,
    Reconnect,
    Logout,
}

enum AuthTaskResult {
    LoggedOut,
    LoggedIn(SoundCloudProfile),
    AuthFailed(String),
    ApiFailed(String),
}

struct AuthTaskCompletion {
    generation: u64,
    result: AuthTaskResult,
}

fn runtime_thread(
    command_rx: Receiver<SoundCloudCommand>,
    event_tx: Sender<SoundCloudEvent>,
    context: egui::Context,
    initial_volume: f32,
    initial_output_device: Option<String>,
    dsp_controls: std::sync::Arc<DspControls>,
) {
    let runtime = match tokio::runtime::Builder::new_multi_thread()
        .worker_threads(2)
        .enable_all()
        .build()
    {
        Ok(runtime) => runtime,
        Err(error) => {
            emit(
                &event_tx,
                &context,
                SoundCloudEvent::AuthFailed(error.to_string()),
            );
            return;
        }
    };

    runtime.block_on(async move {
        let client = match Client::builder()
            .user_agent(format!("Spoteq/{}", env!("CARGO_PKG_VERSION")))
            .connect_timeout(Duration::from_secs(8))
            .timeout(Duration::from_secs(25))
            .build()
        {
            Ok(client) => client,
            Err(error) => {
                emit(
                    &event_tx,
                    &context,
                    SoundCloudEvent::AuthFailed(error.to_string()),
                );
                return;
            }
        };

        let config = SoundCloudConfig::from_environment();
        emit(
            &event_tx,
            &context,
            SoundCloudEvent::Configured(
                config
                    .as_ref()
                    .map(SoundCloudConfig::public)
                    .map_err(ToString::to_string),
            ),
        );
        let services = match config {
            Ok(config) => SoundCloudTokenStore::discover().map(|store| {
                let auth = std::sync::Arc::new(SoundCloudAuth::new(config, store));
                let api = SoundCloudApi::new(client.clone(), auth.clone());
                (auth, api)
            }),
            Err(error) => Err(error),
        };

        let playback_tx = services.as_ref().ok().map(|(_, api)| playback::spawn(
            api.clone(), event_tx.clone(), context.clone(), initial_volume,
            initial_output_device, dsp_controls,
        ));
        let (result_tx, mut result_rx) = mpsc::unbounded_channel::<AuthTaskCompletion>();
        let mut generation = 0_u64;
        let mut active_task = None;

        if let Ok((auth, api)) = &services {
            emit(&event_tx, &context, SoundCloudEvent::Restoring);
            active_task = Some(spawn_auth_task(
                generation,
                AuthTaskKind::Restore,
                client.clone(),
                auth.clone(),
                api.clone(),
                result_tx.clone(),
            ));
        } else if let Err(error) = &services {
            emit(
                &event_tx,
                &context,
                SoundCloudEvent::AuthFailed(error.to_string()),
            );
        }

        loop {
            tokio::select! {
                command = command_rx.recv_async() => {
                    let Ok(command) = command else { break };
                    if matches!(&command, SoundCloudCommand::Shutdown) {
                        if let Some(task) = active_task.take() {
                            task.abort();
                        }
                        if let Some(tx) = &playback_tx { let _ = tx.send(SoundCloudPlaybackCommand::Shutdown); }
                        break;
                    }
                    match command {
                        auth_command @ (SoundCloudCommand::Connect
                        | SoundCloudCommand::Reconnect
                        | SoundCloudCommand::Logout) => {
                            let Ok((auth, api)) = &services else {
                                let message = service_error(&services);
                                emit(&event_tx, &context, SoundCloudEvent::AuthFailed(message));
                                continue;
                            };
                            if let Some(task) = active_task.take() {
                                task.abort();
                            }
                            generation = generation.wrapping_add(1);
                            let kind = match auth_command {
                                SoundCloudCommand::Connect => AuthTaskKind::Connect,
                                SoundCloudCommand::Reconnect => AuthTaskKind::Reconnect,
                                SoundCloudCommand::Logout => AuthTaskKind::Logout,
                                _ => unreachable!(),
                            };
                            if matches!(kind, AuthTaskKind::Logout) {
                                if let Some(tx) = &playback_tx { let _ = tx.send(SoundCloudPlaybackCommand::Stop); }
                            }
                            emit(
                                &event_tx,
                                &context,
                                if matches!(kind, AuthTaskKind::Logout) {
                                    SoundCloudEvent::Restoring
                                } else {
                                    SoundCloudEvent::Authorizing
                                },
                            );
                            active_task = Some(spawn_auth_task(
                                generation,
                                kind,
                                client.clone(),
                                auth.clone(),
                                api.clone(),
                                result_tx.clone(),
                            ));
                        }
                        SoundCloudCommand::Search { query, generation } => {
                            let Ok((_, api)) = &services else {
                                emit_search_error(&event_tx, &context, generation, false, service_error(&services));
                                continue;
                            };
                            tracing::info!(query = %query, "SoundCloud search dispatched");
                            spawn_search(api.clone(), query, None, generation, event_tx.clone(), context.clone());
                        }
                        SoundCloudCommand::SearchNext { query, next_href, generation } => {
                            let Ok((_, api)) = &services else {
                                emit_search_error(&event_tx, &context, generation, true, service_error(&services));
                                continue;
                            };
                            tracing::info!(query = %query, "SoundCloud search dispatched");
                            spawn_search(
                                api.clone(),
                                query,
                                Some(next_href),
                                generation,
                                event_tx.clone(),
                                context.clone(),
                            );
                        }
                        SoundCloudCommand::LoadLikes { next_href, generation } => {
                            let append = next_href.is_some();
                            let Ok((_, api)) = &services else {
                                emit(
                                    &event_tx,
                                    &context,
                                    SoundCloudEvent::LikesFinished {
                                        generation,
                                        append,
                                        result: Err(service_error(&services)),
                                    },
                                );
                                continue;
                            };
                            tracing::info!("SoundCloud likes dispatched");
                            spawn_likes(api.clone(), next_href, generation, event_tx.clone(), context.clone());
                        }
                        SoundCloudCommand::LoadLikedState { urn, stable_key, request_id } => {
                            let Ok((_, api)) = &services else {
                                emit(&event_tx, &context, SoundCloudEvent::LikedStateLoaded { stable_key, request_id, result: Err(service_error(&services)) });
                                continue;
                            };
                            let api = api.clone();
                            let tx = event_tx.clone();
                            let ctx = context.clone();
                            tokio::spawn(async move {
                                let result = api.is_track_liked(&urn).await.map_err(|error| error.to_string());
                                emit(&tx, &ctx, SoundCloudEvent::LikedStateLoaded { stable_key, request_id, result });
                            });
                        }
                        SoundCloudCommand::SetLiked { urn, stable_key, liked, request_id } => {
                            let Ok((_, api)) = &services else {
                                emit(&event_tx, &context, SoundCloudEvent::LikedChanged { stable_key, liked, request_id, result: Err(service_error(&services)) });
                                continue;
                            };
                            let api = api.clone();
                            let tx = event_tx.clone();
                            let ctx = context.clone();
                            tokio::spawn(async move {
                                let result = api.set_track_liked(&urn, liked).await.map_err(|error| error.to_string());
                                emit(&tx, &ctx, SoundCloudEvent::LikedChanged { stable_key, liked, request_id, result });
                            });
                        }
                        SoundCloudCommand::Recommend { seeds, generation, limit } => {
                            let Ok((_, api)) = &services else {
                                emit(
                                    &event_tx,
                                    &context,
                                    SoundCloudEvent::RecommendationsFinished {
                                        generation,
                                        result: Err(service_error(&services)),
                                    },
                                );
                                continue;
                            };
                            let api = api.clone();
                            let tx = event_tx.clone();
                            let ctx = context.clone();
                            tokio::spawn(async move {
                                let mut urn = seeds.first().and_then(|track| match &track.provider_id {
                                    crate::catalog::ProviderTrackId::SoundCloud { urn, .. } => urn.clone(),
                                    crate::catalog::ProviderTrackId::Spotify { .. } => None,
                                });

                                // Map a Spotify-only seed to an actual SoundCloud track,
                                // then use SoundCloud's related station rather than random search rows.
                                if urn.is_none() {
                                    if let Some(seed) = seeds.first() {
                                        let query = format!("{} {}", seed.artist, seed.title);
                                        if let Ok(page) = api.search_tracks(&query, None).await {
                                            urn = page.items.into_iter().find_map(|track| match track.provider_id {
                                                crate::catalog::ProviderTrackId::SoundCloud { urn, .. } => urn,
                                                crate::catalog::ProviderTrackId::Spotify { .. } => None,
                                            });
                                        }
                                    }
                                }

                                let result = match urn {
                                    Some(urn) => api
                                        .related_tracks(&urn, limit)
                                        .await
                                        .map(|page| page.items)
                                        .map_err(|error| error.to_string()),
                                    None => Ok(Vec::new()),
                                };
                                emit(
                                    &tx,
                                    &ctx,
                                    SoundCloudEvent::RecommendationsFinished { generation, result },
                                );
                            });
                        }
                        SoundCloudCommand::LoadArtwork { url } => {
                            spawn_artwork(client.clone(), url, event_tx.clone(), context.clone());
                        }
                        SoundCloudCommand::PlayQueue { tracks, index } => if let Some(tx) = &playback_tx { let _ = tx.send(SoundCloudPlaybackCommand::PlayQueue { tracks, index }); },
                        SoundCloudCommand::PreloadTrack { track } => if let Some(tx) = &playback_tx { let _ = tx.send(SoundCloudPlaybackCommand::Preload(track)); },
                        SoundCloudCommand::TogglePlayback => if let Some(tx) = &playback_tx { let _ = tx.send(SoundCloudPlaybackCommand::Toggle); },
                        SoundCloudCommand::Previous => if let Some(tx) = &playback_tx { let _ = tx.send(SoundCloudPlaybackCommand::Previous); },
                        SoundCloudCommand::Next => if let Some(tx) = &playback_tx { let _ = tx.send(SoundCloudPlaybackCommand::Next); },
                        SoundCloudCommand::Seek { position_ms } => if let Some(tx) = &playback_tx { let _ = tx.send(SoundCloudPlaybackCommand::Seek(position_ms)); },
                        SoundCloudCommand::SetVolume { volume } => if let Some(tx) = &playback_tx { let _ = tx.send(SoundCloudPlaybackCommand::SetVolume(volume)); },
                        SoundCloudCommand::SetOutputDevice { device } => if let Some(tx) = &playback_tx { let _ = tx.send(SoundCloudPlaybackCommand::SetOutputDevice(device)); },
                        SoundCloudCommand::StopPlayback => if let Some(tx) = &playback_tx { let _ = tx.send(SoundCloudPlaybackCommand::Stop); },
                        SoundCloudCommand::Shutdown => unreachable!(),
                    }
                }
                completion = result_rx.recv() => {
                    let Some(completion) = completion else { break };
                    if completion.generation != generation {
                        continue;
                    }
                    active_task = None;
                    match completion.result {
                        AuthTaskResult::LoggedOut => {
                            emit(&event_tx, &context, SoundCloudEvent::LoggedOut);
                        }
                        AuthTaskResult::LoggedIn(profile) => {
                            let avatar_url = profile.avatar_url.clone();
                            emit(&event_tx, &context, SoundCloudEvent::LoggedIn(profile));
                            if let Some(url) = avatar_url {
                                spawn_avatar(client.clone(), url, event_tx.clone(), context.clone());
                            }
                        }
                        AuthTaskResult::AuthFailed(error) => {
                            emit(&event_tx, &context, SoundCloudEvent::AuthFailed(error));
                        }
                        AuthTaskResult::ApiFailed(error) => {
                            emit(&event_tx, &context, SoundCloudEvent::ApiFailed(error));
                        }
                    }
                }
            }
        }
    });
}

fn service_error(
    services: &Result<(SharedSoundCloudAuth, SoundCloudApi), SoundCloudError>,
) -> String {
    services
        .as_ref()
        .err()
        .map(ToString::to_string)
        .unwrap_or_else(|| "SoundCloud configuration is unavailable".to_owned())
}

fn emit_search_error(
    event_tx: &Sender<SoundCloudEvent>,
    context: &egui::Context,
    generation: u64,
    append: bool,
    error: String,
) {
    emit(
        event_tx,
        context,
        SoundCloudEvent::SearchFinished {
            generation,
            append,
            result: Err(error),
        },
    );
}

fn spawn_search(
    api: SoundCloudApi,
    query: String,
    next_href: Option<String>,
    generation: u64,
    event_tx: Sender<SoundCloudEvent>,
    context: egui::Context,
) {
    tokio::spawn(async move {
        let append = next_href.is_some();
        let result = api
            .search_tracks(&query, next_href.as_deref())
            .await
            .map_err(|error| error.to_string());
        match &result {
            Ok(page) => {
                tracing::info!(query = %query, count = page.items.len(), "SoundCloud search result count")
            }
            Err(error) => {
                tracing::error!(query = %query, reason = %error, "SoundCloud API/playback error reason")
            }
        }
        emit(
            &event_tx,
            &context,
            SoundCloudEvent::SearchFinished {
                generation,
                append,
                result,
            },
        );
    });
}

fn spawn_likes(
    api: SoundCloudApi,
    next_href: Option<String>,
    generation: u64,
    event_tx: Sender<SoundCloudEvent>,
    context: egui::Context,
) {
    tokio::spawn(async move {
        let append = next_href.is_some();
        let result = api
            .liked_tracks(next_href.as_deref())
            .await
            .map_err(|error| error.to_string());
        match &result {
            Ok(page) => tracing::info!(count = page.items.len(), "SoundCloud likes result count"),
            Err(error) => tracing::error!(reason = %error, "SoundCloud API/playback error reason"),
        }
        emit(
            &event_tx,
            &context,
            SoundCloudEvent::LikesFinished {
                generation,
                append,
                result,
            },
        );
    });
}

fn spawn_auth_task(
    generation: u64,
    kind: AuthTaskKind,
    client: Client,
    auth: SharedSoundCloudAuth,
    api: SoundCloudApi,
    result_tx: mpsc::UnboundedSender<AuthTaskCompletion>,
) -> tokio::task::JoinHandle<()> {
    tokio::spawn(async move {
        let result = run_auth_task(kind, &client, &auth, &api).await;
        let _ = result_tx.send(AuthTaskCompletion { generation, result });
    })
}

async fn run_auth_task(
    kind: AuthTaskKind,
    client: &Client,
    auth: &SharedSoundCloudAuth,
    api: &SoundCloudApi,
) -> AuthTaskResult {
    match kind {
        AuthTaskKind::Restore => match auth.restore(client).await {
            Ok(false) => AuthTaskResult::LoggedOut,
            Ok(true) => profile_result(api).await,
            Err(error) => AuthTaskResult::AuthFailed(error.to_string()),
        },
        AuthTaskKind::Connect => match auth.login(client).await {
            Ok(()) => profile_result(api).await,
            Err(error) => AuthTaskResult::AuthFailed(error.to_string()),
        },
        AuthTaskKind::Reconnect => {
            if let Err(error) = auth.logout(client).await {
                return AuthTaskResult::AuthFailed(error.to_string());
            }
            match auth.login(client).await {
                Ok(()) => profile_result(api).await,
                Err(error) => AuthTaskResult::AuthFailed(error.to_string()),
            }
        }
        AuthTaskKind::Logout => match auth.logout(client).await {
            Ok(()) => AuthTaskResult::LoggedOut,
            Err(error) => AuthTaskResult::AuthFailed(error.to_string()),
        },
    }
}

async fn profile_result(api: &SoundCloudApi) -> AuthTaskResult {
    match api.me().await {
        Ok(profile) => AuthTaskResult::LoggedIn(profile),
        Err(error) => AuthTaskResult::ApiFailed(error.to_string()),
    }
}

fn spawn_avatar(
    client: Client,
    url: String,
    event_tx: Sender<SoundCloudEvent>,
    context: egui::Context,
) {
    tokio::spawn(async move {
        let result = load_avatar(&client, &url).await;
        emit(
            &event_tx,
            &context,
            SoundCloudEvent::AvatarFinished { url, result },
        );
    });
}

fn spawn_artwork(
    client: Client,
    url: String,
    event_tx: Sender<SoundCloudEvent>,
    context: egui::Context,
) {
    tokio::spawn(async move {
        let result = load_artwork(&client, &url).await;
        emit(
            &event_tx,
            &context,
            SoundCloudEvent::ArtworkFinished { url, result },
        );
    });
}

async fn load_avatar(client: &Client, url: &str) -> Result<DecodedAvatar, String> {
    let response = client
        .get(url)
        .send()
        .await
        .map_err(|error| error.to_string())?;
    let status = response.status();
    if !status.is_success() {
        return Err(format!(
            "SoundCloud avatar returned HTTP {}",
            status.as_u16()
        ));
    }
    let bytes = response.bytes().await.map_err(|error| error.to_string())?;
    let image = image::load_from_memory(&bytes)
        .map_err(|error| error.to_string())?
        .thumbnail(160, 160)
        .to_rgba8();
    Ok(DecodedAvatar {
        size: [image.width() as usize, image.height() as usize],
        rgba: image.into_raw(),
    })
}

async fn load_artwork(client: &Client, url: &str) -> Result<DecodedArtwork, String> {
    let response = client
        .get(url)
        .send()
        .await
        .map_err(|error| error.to_string())?;
    let status = response.status();
    if !status.is_success() {
        return Err(format!(
            "SoundCloud artwork returned HTTP {}",
            status.as_u16()
        ));
    }
    let bytes = response.bytes().await.map_err(|error| error.to_string())?;
    let image = image::load_from_memory(&bytes)
        .map_err(|error| error.to_string())?
        .thumbnail(600, 600)
        .to_rgba8();
    Ok(DecodedArtwork {
        size: [image.width() as usize, image.height() as usize],
        rgba: image.into_raw(),
    })
}

fn emit(event_tx: &Sender<SoundCloudEvent>, context: &egui::Context, event: SoundCloudEvent) {
    if event_tx.send(event).is_ok() {
        context.request_repaint();
    }
}
