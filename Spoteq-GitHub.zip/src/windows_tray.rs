//! Windows notification-area icon and compact transport menu.

use tray_icon::{
    Icon, MouseButton, TrayIcon, TrayIconBuilder, TrayIconEvent,
    menu::{Menu, MenuEvent, MenuItem, PredefinedMenuItem},
};

use crate::windows_taskbar::TaskbarAction;

const TRAY_ID: &str = "spoteq-main-tray";
const OPEN_ID: &str = "spoteq-tray-open";
const TOGGLE_ID: &str = "spoteq-tray-toggle";
const PREVIOUS_ID: &str = "spoteq-tray-previous";
const NEXT_ID: &str = "spoteq-tray-next";
const EXIT_ID: &str = "spoteq-tray-exit";
const LOGO: &[u8] = include_bytes!("../assets/branding/spoteq-logo.png");

#[derive(Debug, Clone, Copy)]
pub enum TrayAction {
    Open,
    Transport(TaskbarAction),
    Exit,
}

pub struct WindowsTray {
    _tray: TrayIcon,
    toggle: MenuItem,
    last_playing: Option<bool>,
}

impl WindowsTray {
    pub fn install() -> Result<Self, String> {
        let open = MenuItem::with_id(OPEN_ID, "Open Spoteq", true, None);
        let previous = MenuItem::with_id(PREVIOUS_ID, "Previous", true, None);
        let toggle = MenuItem::with_id(TOGGLE_ID, "Play", true, None);
        let next = MenuItem::with_id(NEXT_ID, "Next", true, None);
        let exit = MenuItem::with_id(EXIT_ID, "Exit", true, None);
        let separator_one = PredefinedMenuItem::separator();
        let separator_two = PredefinedMenuItem::separator();
        let menu = Menu::new();
        menu.append_items(&[
            &open,
            &separator_one,
            &previous,
            &toggle,
            &next,
            &separator_two,
            &exit,
        ])
        .map_err(|error| format!("Could not create tray menu: {error}"))?;

        let decoded = image::load_from_memory(LOGO)
            .map_err(|error| format!("Could not decode tray icon: {error}"))?
            .into_rgba8();
        let (width, height) = decoded.dimensions();
        let icon = Icon::from_rgba(decoded.into_raw(), width, height)
            .map_err(|error| format!("Could not create tray icon: {error}"))?;
        let tray = TrayIconBuilder::new()
            .with_id(TRAY_ID)
            .with_menu(Box::new(menu))
            .with_menu_on_left_click(false)
            .with_tooltip("Spoteq")
            .with_icon(icon)
            .build()
            .map_err(|error| format!("Could not install system tray icon: {error}"))?;

        tracing::info!("Windows system tray initialized");
        Ok(Self {
            _tray: tray,
            toggle,
            last_playing: None,
        })
    }

    pub fn poll(&self) -> Vec<TrayAction> {
        let mut actions = Vec::new();
        while let Ok(event) = MenuEvent::receiver().try_recv() {
            let action = match event.id.0.as_str() {
                OPEN_ID => Some(TrayAction::Open),
                TOGGLE_ID => Some(TrayAction::Transport(TaskbarAction::Toggle)),
                PREVIOUS_ID => Some(TrayAction::Transport(TaskbarAction::Previous)),
                NEXT_ID => Some(TrayAction::Transport(TaskbarAction::Next)),
                EXIT_ID => Some(TrayAction::Exit),
                _ => None,
            };
            if let Some(action) = action {
                actions.push(action);
            }
        }
        while let Ok(event) = TrayIconEvent::receiver().try_recv() {
            if event.id().0.as_str() == TRAY_ID
                && matches!(
                    event,
                    TrayIconEvent::DoubleClick {
                        button: MouseButton::Left,
                        ..
                    }
                )
            {
                actions.push(TrayAction::Open);
            }
        }
        actions
    }

    pub fn sync(&mut self, playing: bool) {
        if self.last_playing != Some(playing) {
            self.toggle.set_text(if playing { "Pause" } else { "Play" });
            self.last_playing = Some(playing);
        }
    }
}
