//! UI-owned snapshots for Spotify data, notifications and direct playback.

use std::{
    sync::atomic::{AtomicU64, Ordering},
    time::{Duration, Instant},
};

use crate::soundcloud::SoundCloudViewState;
use crate::spotify::{
    Page, PlaybackError, PlaybackErrorKind, PlaybackStatus, PlaybackUpdate, SpotifyCommand,
    SpotifyEvent, SpotifyRuntime, Track, UserProfile,
};
use crate::{
    autoplay::AutoplayQueue,
    catalog::{ProviderFilter, SearchScope},
};

/// Primary destinations available in the application.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MusicPage {
    /// Spotify catalog search.
    Search,
    /// The authenticated user's saved tracks.
    LikedSongs,
    /// In-app audio, equalizer and about settings page.
    Settings,
    /// Spotify and SoundCloud account connections.
    Connections,
    /// Local playback history and resumable session.
    History,
    /// Computed playlists built from provider libraries and local play history.
    SmartLibrary,
}

/// Computed Smart Playlist selected on the Smart Library page.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SmartPlaylistKind {
    RecentlyLiked,
    MostPlayed,
    NeverSkipped,
    Night,
    Discovery,
    ProviderMix,
}

impl SmartPlaylistKind {
    /// All playlists in their stable UI order.
    pub const ALL: [Self; 6] = [
        Self::RecentlyLiked,
        Self::MostPlayed,
        Self::NeverSkipped,
        Self::Night,
        Self::Discovery,
        Self::ProviderMix,
    ];

    /// User-facing name.
    pub const fn label(self) -> &'static str {
        match self {
            Self::RecentlyLiked => "Recently liked",
            Self::MostPlayed => "Most played",
            Self::NeverSkipped => "Never skipped",
            Self::Night => "Night",
            Self::Discovery => "Discovery",
            Self::ProviderMix => "Spotify + SoundCloud mix",
        }
    }
}

/// A settings section available from the settings surface.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SettingsSection {
    /// Precision parametric low-frequency equalizer.
    BassStudio,
    /// Quick settings overview.
    General,
    /// Queue and track transition preferences.
    Playback,
    /// Manual audio and equalizer controls.
    Audio,
    /// Accent and visual preferences.
    Appearance,
    /// Account connection information.
    Integrations,
    /// Version and local storage information.
    About,
}

/// UI state owned exclusively by the eframe thread.
#[derive(Debug)]
pub struct AppState {
    /// Currently visible music page.
    pub page: MusicPage,
    /// Text entered in the search field.
    pub search_query: String,
    /// Provider selection on the shared Search page.
    pub search_filter: ProviderFilter,
    /// Selected catalog context for the unified Search page.
    pub search_scope: SearchScope,
    /// Provider selection on the shared Liked Songs page.
    pub library_filter: ProviderFilter,
    /// Local text filter applied to the already loaded unified library.
    pub library_query: String,
    /// Currently selected settings section.
    pub settings_section: SettingsSection,
    /// Selected computed playlist.
    pub smart_playlist: SmartPlaylistKind,
    /// Ordered Smart Library rows cached outside the egui render pass.
    pub smart_library_cache: crate::ui::smart_library_page::SmartLibraryCache,
    /// Whether the auto-hide library sidebar is currently expanded by pointer hover.
    pub sidebar_open: bool,
    /// Whether the provider-neutral queue overlay is visible.
    pub queue_open: bool,
    /// Whether the compact Audio & Equalizer popup is visible above the player.
    pub audio_popup_open: bool,
    /// Whether the native always-on-top compact player viewport is visible.
    pub mini_player_open: bool,
    /// Two-step confirmation guard for clearing future queue items.
    pub queue_clear_armed: bool,
    /// Pending user-confirmed Vibe snapshot; no tracks are saved before confirmation.
    pub vibe_draft: Option<crate::settings::ResumeSession>,
    /// Editable name shown by the Save Vibe dialog.
    pub vibe_name: String,
    /// Vibe currently being renamed in the Library dialog.
    pub vibe_rename: Option<(usize, String)>,
    /// Spotify account, Search and Liked Songs view state.
    pub spotify: SpotifyViewState,
    /// Independent SoundCloud account and API state.
    pub soundcloud: SoundCloudViewState,
    /// Provider-neutral queue and similar-track Autoplay session state.
    pub autoplay: AutoplayQueue,
    /// Transient provider-native Like/Unlike state shared by every visible row.
    pub provider_library: crate::provider_library::ProviderLibraryState,
}

impl Default for AppState {
    fn default() -> Self {
        Self {
            page: MusicPage::Search,
            search_query: String::new(),
            search_filter: ProviderFilter::All,
            search_scope: SearchScope::Tracks,
            library_filter: ProviderFilter::All,
            library_query: String::new(),
            settings_section: SettingsSection::General,
            smart_playlist: SmartPlaylistKind::RecentlyLiked,
            smart_library_cache: crate::ui::smart_library_page::SmartLibraryCache::default(),
            sidebar_open: false,
            queue_open: false,
            audio_popup_open: false,
            mini_player_open: false,
            queue_clear_armed: false,
            vibe_draft: None,
            vibe_name: String::new(),
            vibe_rename: None,
            spotify: SpotifyViewState::default(),
            soundcloud: SoundCloudViewState::default(),
            autoplay: AutoplayQueue::default(),
            provider_library: crate::provider_library::ProviderLibraryState::default(),
        }
    }
}

/// Current account state shown without blocking the UI.
#[derive(Debug, Clone)]
pub enum AuthView {
    /// A persisted token is being checked.
    Restoring,
    /// No Spotify account is connected.
    LoggedOut,
    /// Browser authorization is in progress.
    Authorizing,
    /// Spotify account metadata is available.
    LoggedIn(UserProfile),
    /// Authorization failed and can be retried.
    Error(String),
}

/// Search loading state.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SearchStatus {
    /// No non-empty search query has been entered.
    Idle,
    /// The query is waiting for the 300 ms debounce window.
    Debouncing,
    /// A Spotify request is in flight.
    Loading,
    /// Search results are available.
    Ready,
    /// Spotify returned no matching tracks.
    Empty,
    /// The last search request failed.
    Error(String),
}

/// Spotify Search view model.
#[derive(Debug)]
pub struct SearchView {
    /// Current request and presentation state.
    pub status: SearchStatus,
    /// Tracks returned by the latest accepted query generation.
    pub tracks: Vec<Track>,
    generation: u64,
    edit_time: Option<Instant>,
}

impl Default for SearchView {
    fn default() -> Self {
        Self {
            status: SearchStatus::Idle,
            tracks: Vec::new(),
            generation: 0,
            edit_time: None,
        }
    }
}

static NEXT_LIKED_REVISION: AtomicU64 = AtomicU64::new(1);

/// Paginated Spotify Liked Songs view model.
#[derive(Debug)]
pub struct LikedView {
    /// Loaded pages in Spotify library order.
    pub tracks: Vec<Track>,
    /// Total item count reported by Spotify.
    pub total: usize,
    /// Whether Spotify supplied another page URL.
    pub has_more: bool,
    /// Whether a Liked Songs request is currently in flight.
    pub loading: bool,
    /// Whether the first page has completed at least once.
    pub loaded_once: bool,
    /// Last recoverable pagination error shown in the UI.
    pub error: Option<String>,
    /// Offset to request when the user loads another page.
    pub next_offset: usize,
    /// Changes only when the loaded provider library changes.
    pub revision: u64,
    generation: u64,
}

impl Default for LikedView {
    fn default() -> Self {
        Self {
            tracks: Vec::new(),
            total: 0,
            has_more: false,
            loading: false,
            loaded_once: false,
            error: None,
            next_offset: 0,
            revision: NEXT_LIKED_REVISION.fetch_add(1, Ordering::Relaxed),
            generation: 0,
        }
    }
}

/// Visual severity and lifetime policy for one notification.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ToastKind {
    /// Successful action, automatically hidden after three seconds.
    Success,
    /// Recoverable failure, kept visible for eight seconds.
    Error,
}

/// One bounded overlay notification. A new toast replaces the previous one.
#[derive(Debug)]
pub struct Toast {
    /// Text shown to the user.
    pub message: String,
    /// Color and lifetime category.
    pub kind: ToastKind,
    expires_at: Instant,
}

/// UI-side snapshot of the single playback actor.
#[derive(Debug)]
pub struct PlaybackView {
    /// Selected queue item.
    pub track: Option<Track>,
    /// Current direct Player state.
    pub status: PlaybackStatus,
    /// Last position received from librespot.
    pub position_ms: u32,
    /// Current position in the local queue.
    pub queue_index: Option<usize>,
    /// Number of tracks in the local queue.
    pub queue_len: usize,
    /// Position controlled by an active progress-bar drag.
    pub seek_preview_ms: Option<u32>,
    position_updated_at: Instant,
}

impl Default for PlaybackView {
    fn default() -> Self {
        Self {
            track: None,
            status: PlaybackStatus::Idle,
            position_ms: 0,
            queue_index: None,
            queue_len: 0,
            seek_preview_ms: None,
            position_updated_at: Instant::now(),
        }
    }
}

impl PlaybackView {
    /// Smooth position estimate between 200 ms Player updates.
    pub fn displayed_position_ms(&self) -> u32 {
        if let Some(preview) = self.seek_preview_ms {
            return preview;
        }
        let base = u64::from(self.position_ms);
        let elapsed = if self.status == PlaybackStatus::Playing {
            self.position_updated_at.elapsed().as_millis() as u64
        } else {
            0
        };
        let duration = self
            .track
            .as_ref()
            .map(|track| track.duration_ms)
            .unwrap_or(0);
        base.saturating_add(elapsed).min(duration) as u32
    }

    /// Whether playback can move to a later queue item.
    pub fn has_next(&self) -> bool {
        self.queue_index
            .is_some_and(|index| index.saturating_add(1) < self.queue_len)
    }

    fn apply(&mut self, update: PlaybackUpdate) {
        self.track = update.track;
        self.status = update.status;
        self.position_ms = update.position_ms;
        self.queue_index = update.queue_index;
        self.queue_len = update.queue_len;
        self.position_updated_at = Instant::now();
    }
}

/// All Spotify-owned state retained by the UI thread.
#[derive(Debug)]
pub struct SpotifyViewState {
    /// Current account authorization state.
    pub auth: AuthView,
    /// Whether the account window is visible.
    pub login_open: bool,
    /// Spotify application Client ID entered by the user.
    pub client_id_input: String,
    /// Search request and result state.
    pub search: SearchView,
    /// Paginated Liked Songs state.
    pub liked: LikedView,
    /// State of the direct local librespot Player.
    pub playback: PlaybackView,
    /// Output device names currently reported by CPAL/WASAPI.
    pub audio_devices: Vec<String>,
    /// Name of the current Windows default output, when available.
    pub default_audio_device: Option<String>,
    /// Single overlay notification; new notifications replace old ones.
    pub toast: Option<Toast>,
}

impl Default for SpotifyViewState {
    fn default() -> Self {
        Self {
            auth: AuthView::Restoring,
            login_open: false,
            client_id_input: std::env::var("SPOTIFY_CLIENT_ID").unwrap_or_default(),
            search: SearchView::default(),
            liked: LikedView::default(),
            playback: PlaybackView::default(),
            audio_devices: Vec::new(),
            default_audio_device: None,
            toast: None,
        }
    }
}

impl SpotifyViewState {
    /// True only after profile loading succeeds.
    pub fn is_authenticated(&self) -> bool {
        matches!(self.auth, AuthView::LoggedIn(_))
    }

    /// Restarts the 300 ms search debounce.
    pub fn search_edited(&mut self, query: &str) {
        self.search.generation = self.search.generation.wrapping_add(1);
        self.search.edit_time = Some(Instant::now());
        if query.trim().is_empty() {
            self.search.status = SearchStatus::Idle;
            self.search.tracks.clear();
            self.search.edit_time = None;
        } else {
            self.search.status = SearchStatus::Debouncing;
        }
    }

    /// Dispatches a matured search without sleeping on the UI thread.
    pub fn dispatch_search(&mut self, query: &str, scope: SearchScope, runtime: &SpotifyRuntime) {
        if self.search.status != SearchStatus::Debouncing || !self.is_authenticated() {
            return;
        }
        let Some(edit_time) = self.search.edit_time else {
            return;
        };
        if edit_time.elapsed().as_millis() < 300 {
            return;
        }

        let command = SpotifyCommand::Search {
            query: query.trim().to_owned(),
            scope,
            generation: self.search.generation,
        };
        match runtime.send(command) {
            Ok(()) => {
                self.search.status = SearchStatus::Loading;
                self.search.edit_time = None;
            }
            Err(error) => self.search.status = SearchStatus::Error(error.to_string()),
        }
    }

    /// Requests the first Liked Songs page once per authenticated session.
    pub fn ensure_liked_loaded(&mut self, runtime: &SpotifyRuntime) {
        if self.is_authenticated() && !self.liked.loaded_once && !self.liked.loading {
            self.load_liked(runtime, 0);
        }
    }

    /// Requests one offset page.
    pub fn load_liked(&mut self, runtime: &SpotifyRuntime, offset: usize) {
        if offset == 0 {
            self.liked.generation = self.liked.generation.wrapping_add(1);
        }
        self.liked.loading = true;
        self.liked.error = None;
        if let Err(error) = runtime.send(SpotifyCommand::LoadLiked {
            offset,
            generation: self.liked.generation,
        }) {
            self.liked.loading = false;
            self.liked.error = Some(error.to_string());
        }
    }

    /// Replaces the local queue and immediately selects one track in the UI.
    pub fn play_queue(&mut self, runtime: &SpotifyRuntime, tracks: Vec<Track>, index: usize) {
        self.toast = None;
        let selected = tracks.get(index).cloned();
        if selected.is_none() {
            self.toast_error("The selected track is outside the local queue");
            return;
        }
        self.playback.track = selected;
        self.playback.status = PlaybackStatus::Connecting;
        self.playback.position_ms = 0;
        self.playback.queue_index = Some(index);
        self.playback.queue_len = tracks.len();
        self.playback.seek_preview_ms = None;
        self.playback.position_updated_at = Instant::now();
        if let Some(track) = self.playback.track.as_ref() {
            let _ = runtime.send(SpotifyCommand::PreloadTrack {
                uri: track.uri.clone(),
            });
        }
        if let Err(error) = runtime.send(SpotifyCommand::PlayQueue { tracks, index }) {
            self.playback.status = PlaybackStatus::Error(PlaybackError::new(
                PlaybackErrorKind::AudioBackend,
                error.to_string(),
            ));
            self.toast_error(error.to_string());
        }
    }

    /// Toggles the only local Player.
    pub fn toggle_playback(&mut self, runtime: &SpotifyRuntime) {
        self.toast = None;
        if let Err(error) = runtime.send(SpotifyCommand::TogglePlayback) {
            self.toast_error(error.to_string());
        }
    }

    /// Requests the previous local queue position.
    pub fn previous(&mut self, runtime: &SpotifyRuntime) {
        self.toast = None;
        if let Err(error) = runtime.send(SpotifyCommand::Previous) {
            self.toast_error(error.to_string());
        }
    }

    /// Requests the next local queue position.
    pub fn next(&mut self, runtime: &SpotifyRuntime) {
        self.toast = None;
        if let Err(error) = runtime.send(SpotifyCommand::Next) {
            self.toast_error(error.to_string());
        }
    }

    /// Seeks through the local Player without a Web API request.
    pub fn seek(&mut self, runtime: &SpotifyRuntime, position_ms: u32) {
        self.playback.position_ms = position_ms;
        self.playback.position_updated_at = Instant::now();
        self.playback.seek_preview_ms = None;
        if let Err(error) = runtime.send(SpotifyCommand::Seek { position_ms }) {
            self.toast_error(error.to_string());
        }
    }

    /// Updates the atomic librespot soft-volume control.
    pub fn set_volume(&mut self, runtime: &SpotifyRuntime, volume: f32) {
        if let Err(error) = runtime.send(SpotifyCommand::SetVolume { volume }) {
            self.toast_error(error.to_string());
        }
    }

    /// Stops Spotify audio when another provider becomes active without logging out playback.
    pub fn stop_playback(&mut self, runtime: &SpotifyRuntime) {
        self.playback = PlaybackView::default();
        if let Err(error) = runtime.send(SpotifyCommand::StopPlayback) {
            self.toast_error(error.to_string());
        }
    }

    /// Selects a named output, or follows the current Windows default with `None`.
    pub fn set_output_device(&mut self, runtime: &SpotifyRuntime, device: Option<String>) {
        self.toast = None;
        if let Err(error) = runtime.send(SpotifyCommand::SetOutputDevice { device }) {
            self.toast_error(error.to_string());
        }
    }

    /// Refreshes output names and the Windows default without blocking the UI.
    pub fn refresh_audio_devices(&mut self, runtime: &SpotifyRuntime) {
        if let Err(error) = runtime.send(SpotifyCommand::RefreshAudioDevices) {
            self.toast_error(error.to_string());
        }
    }

    /// Shows a short successful operation notification.
    pub fn toast_success(&mut self, message: impl Into<String>) {
        self.toast = Some(Toast {
            message: message.into(),
            kind: ToastKind::Success,
            expires_at: Instant::now() + Duration::from_secs(3),
        });
    }

    /// Shows a longer recoverable-error notification.
    pub fn toast_error(&mut self, message: impl Into<String>) {
        self.toast = Some(Toast {
            message: message.into(),
            kind: ToastKind::Error,
            expires_at: Instant::now() + Duration::from_secs(8),
        });
    }

    /// Clears the current transient notification before a new user action.
    pub fn clear_toast(&mut self) {
        self.toast = None;
    }

    /// Removes an expired toast and returns its remaining lifetime.
    pub fn update_toast(&mut self) -> Option<Duration> {
        let remaining = self
            .toast
            .as_ref()
            .and_then(|toast| toast.expires_at.checked_duration_since(Instant::now()));
        if remaining.is_none() {
            self.toast = None;
        }
        remaining
    }

    /// Applies one background event. Image events are returned to the caller.
    pub fn handle_event(
        &mut self,
        event: SpotifyEvent,
        runtime: &SpotifyRuntime,
    ) -> Option<SpotifyEvent> {
        match event {
            SpotifyEvent::Restoring => {
                tracing::info!("[AUTH] Spotify auth view = Restoring");
                self.auth = AuthView::Restoring;
            }
            SpotifyEvent::LoggedOut => {
                tracing::info!("[AUTH] Spotify auth view = LoggedOut");
                self.auth = AuthView::LoggedOut;
                self.clear_account_data();
            }
            SpotifyEvent::Authorizing => {
                tracing::info!("[AUTH] Spotify auth view = Authorizing");
                self.auth = AuthView::Authorizing;
            }
            SpotifyEvent::LoggedIn(profile) => {
                tracing::info!("[AUTH] Spotify auth view = LoggedIn");
                self.auth = AuthView::LoggedIn(profile);
                self.login_open = false;
                self.toast = None;
                self.liked.loaded_once = false;
                self.ensure_liked_loaded(runtime);
            }
            SpotifyEvent::LibraryPermissionMissing => {
                self.toast_error("Reconnect Spotify to grant permission to change Liked Songs.")
            }
            SpotifyEvent::AuthFailed(error) | SpotifyEvent::RuntimeFailed(error) => {
                tracing::warn!(reason = %error, "[AUTH] Spotify auth view = Error");
                self.auth = AuthView::Error(error);
                self.login_open = true;
            }
            SpotifyEvent::SearchFinished { generation, result } => {
                if self.is_authenticated() && generation == self.search.generation {
                    match result {
                        Ok(tracks) if tracks.is_empty() => {
                            self.search.tracks.clear();
                            self.search.status = SearchStatus::Empty;
                        }
                        Ok(tracks) => {
                            self.search.tracks = tracks;
                            self.search.status = SearchStatus::Ready;
                        }
                        Err(error) => self.search.status = SearchStatus::Error(error),
                    }
                }
            }
            recommendation @ SpotifyEvent::RecommendationsFinished { .. } => {
                return Some(recommendation);
            }
            SpotifyEvent::LikedFinished {
                offset,
                generation,
                result,
            } => {
                if !self.is_authenticated() || generation != self.liked.generation {
                    return None;
                }
                self.liked.loading = false;
                match result {
                    Ok(page) => self.apply_liked_page(offset, page),
                    Err(error) => {
                        self.liked.loaded_once = true;
                        self.liked.error = Some(error);
                    }
                }
            }
            library @ (SpotifyEvent::SavedChanged { .. }
            | SpotifyEvent::SavedStateLoaded { .. }) => return Some(library),
            SpotifyEvent::PlaybackChanged(update) => {
                if self.is_authenticated() {
                    let error = match &update.status {
                        PlaybackStatus::Error(error) => Some(error.message.clone()),
                        _ => None,
                    };
                    self.playback.apply(update);
                    if let Some(error) = error {
                        let already_visible = self.toast.as_ref().is_some_and(|toast| {
                            toast.kind == ToastKind::Error && toast.message == error
                        });
                        if !already_visible {
                            self.toast_error(error);
                        }
                    }
                }
            }
            SpotifyEvent::AudioDevicesChanged {
                devices,
                default_device,
            } => {
                self.audio_devices = devices;
                self.default_audio_device = default_device;
            }
            image @ SpotifyEvent::ImageFinished { .. } => return Some(image),
        }
        None
    }

    fn apply_liked_page(&mut self, requested_offset: usize, page: Page<Track>) {
        if requested_offset == 0 {
            self.liked.tracks = page.items;
        } else if requested_offset == self.liked.next_offset {
            self.liked.tracks.extend(page.items);
        } else {
            return;
        }
        self.liked.total = page.total;
        self.liked.has_more = page.has_more;
        self.liked.next_offset = page.offset.saturating_add(page.limit);
        self.liked.loaded_once = true;
        self.liked.error = None;
        self.liked.revision = NEXT_LIKED_REVISION.fetch_add(1, Ordering::Relaxed);
    }

    fn clear_account_data(&mut self) {
        self.search = SearchView::default();
        self.liked = LikedView::default();
        self.playback = PlaybackView::default();
        self.toast = None;
    }
}

#[cfg(test)]
mod tests {
    use std::time::{Duration, Instant};

    use super::SpotifyViewState;

    #[test]
    fn a_new_toast_replaces_the_previous_message() {
        let mut state = SpotifyViewState::default();
        state.toast_success("first");
        state.toast_success("second");

        assert_eq!(
            state.toast.as_ref().map(|toast| toast.message.as_str()),
            Some("second")
        );
    }

    #[test]
    fn expired_toast_is_removed() {
        let mut state = SpotifyViewState::default();
        state.toast_success("saved");
        if let Some(toast) = state.toast.as_mut() {
            toast.expires_at = Instant::now() - Duration::from_millis(1);
        }

        assert!(state.update_toast().is_none());
        assert!(state.toast.is_none());
    }
}
