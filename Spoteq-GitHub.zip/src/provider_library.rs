//! Provider-native Like/Unlike coordination for the egui thread.
//!
//! This is deliberately an in-memory UI cache, not a Spoteq favorites store.
//! Spotify and SoundCloud remain the only sources of truth.

use std::collections::HashMap;

use crate::{
    catalog::{ProviderTrackId, TrackProvider, TrackRow},
    soundcloud::{SoundCloudCommand, SoundCloudRuntime},
    spotify::{SpotifyCommand, SpotifyRuntime},
};

/// Provider-qualified target for a library operation.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LikeTarget {
    /// Key shared by every visible copy of the same provider resource.
    pub stable_key: String,
    /// Owning music service.
    pub provider: TrackProvider,
    /// Spotify URI or SoundCloud track URN used by the provider API.
    pub provider_key: String,
}

impl LikeTarget {
    /// Extracts the provider identity required for Like/Unlike.
    pub fn from_track(track: &TrackRow) -> Result<Self, &'static str> {
        let provider_key = match &track.provider_id {
            ProviderTrackId::Spotify { uri, .. } if !uri.trim().is_empty() => uri.clone(),
            ProviderTrackId::SoundCloud { urn: Some(urn), .. } if !urn.trim().is_empty() => {
                urn.clone()
            }
            ProviderTrackId::Spotify { .. } => return Err("Spotify track has no valid URI"),
            ProviderTrackId::SoundCloud { .. } => {
                return Err("SoundCloud track has no valid URN");
            }
        };
        Ok(Self {
            stable_key: track.stable_key(),
            provider: track.provider,
            provider_key,
        })
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum ProviderLikeRoute {
    Spotify { uri: String, liked: bool },
    SoundCloud { urn: String, liked: bool },
}

fn mutation_route(target: &LikeTarget, liked: bool) -> ProviderLikeRoute {
    match target.provider {
        TrackProvider::Spotify => ProviderLikeRoute::Spotify {
            uri: target.provider_key.clone(),
            liked,
        },
        TrackProvider::SoundCloud => ProviderLikeRoute::SoundCloud {
            urn: target.provider_key.clone(),
            liked,
        },
    }
}

/// Current presentation state of one provider-native Heart.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct LikeVisualState {
    pub liked: bool,
    pub known: bool,
    pub pending: bool,
}

#[derive(Debug, Clone)]
struct PendingMutation {
    request_id: u64,
    previous: Option<bool>,
    desired: bool,
}

#[derive(Debug, Clone, Default)]
struct Entry {
    confirmed: Option<bool>,
    query_id: Option<u64>,
    mutation: Option<PendingMutation>,
}

/// Transient synchronized Heart state. Nothing in this type is persisted.
#[derive(Debug, Default)]
pub struct ProviderLibraryState {
    entries: HashMap<String, Entry>,
    next_request_id: u64,
    current_key: Option<String>,
}

impl ProviderLibraryState {
    /// Seeds the cache from provider-backed list/search responses.
    pub fn observe(&mut self, track: &TrackRow) {
        let Some(liked) = track.liked else { return };
        let entry = self.entries.entry(track.stable_key()).or_default();
        if entry.mutation.is_none() && entry.confirmed.is_none() {
            entry.confirmed = Some(liked);
        }
    }

    /// Returns one synchronized state for all visible copies of a track.
    pub fn visual(&self, track: &TrackRow) -> LikeVisualState {
        let entry = self.entries.get(&track.stable_key());
        let optimistic = entry.and_then(|entry| entry.mutation.as_ref().map(|m| m.desired));
        let confirmed = entry.and_then(|entry| entry.confirmed).or(track.liked);
        LikeVisualState {
            liked: optimistic.or(confirmed).unwrap_or(false),
            known: optimistic.is_some() || confirmed.is_some(),
            pending: entry
                .is_some_and(|entry| entry.mutation.is_some() || entry.query_id.is_some()),
        }
    }

    /// Ensures provider state is loaded for a visible row without blocking UI.
    pub fn ensure_loaded(
        &mut self,
        track: &TrackRow,
        spotify: &SpotifyRuntime,
        soundcloud: &SoundCloudRuntime,
    ) {
        self.observe(track);
        // SoundCloud has no batch "contains" endpoint. Querying one endpoint
        // per visible Search/Queue row quickly triggers HTTP 429. SoundCloud
        // Likes pages seed this cache with `liked = true`; an individual check
        // is reserved for the current track in `ensure_current`.
        if track.provider == TrackProvider::SoundCloud {
            return;
        }
        let Ok(target) = LikeTarget::from_track(track) else {
            return;
        };
        let needs_query = match self.entries.get(&target.stable_key) {
            None => true,
            Some(entry) => {
                entry.confirmed.is_none() && entry.query_id.is_none() && entry.mutation.is_none()
            }
        };
        if needs_query {
            self.dispatch_query(target, spotify, soundcloud);
        }
    }

    /// Forces a source-of-truth check whenever the active provider track changes.
    pub fn ensure_current(
        &mut self,
        track: Option<&TrackRow>,
        spotify: &SpotifyRuntime,
        soundcloud: &SoundCloudRuntime,
    ) {
        if !self.select_current(track) {
            return;
        }
        let Some(track) = track else { return };
        self.observe(track);
        if let Ok(target) = LikeTarget::from_track(track) {
            if self
                .entries
                .get(&target.stable_key)
                .map_or(true, |entry| entry.mutation.is_none())
            {
                self.dispatch_query(target, spotify, soundcloud);
            }
        }
    }

    /// Applies an optimistic toggle and dispatches it to the owning provider.
    pub fn toggle(
        &mut self,
        track: &TrackRow,
        spotify: &SpotifyRuntime,
        soundcloud: &SoundCloudRuntime,
    ) -> Result<(), String> {
        let target = LikeTarget::from_track(track).map_err(str::to_owned)?;
        self.observe(track);
        let current = self.visual(track).liked;
        let request_id = self.allocate_id();
        let entry = self.entries.entry(target.stable_key.clone()).or_default();
        if entry.mutation.is_some() {
            return Ok(());
        }
        entry.mutation = Some(PendingMutation {
            request_id,
            previous: entry.confirmed.or(track.liked),
            desired: !current,
        });
        let result: Result<(), String> = match mutation_route(&target, !current) {
            ProviderLikeRoute::Spotify { uri, liked } => spotify
                .send(SpotifyCommand::SetSaved {
                    uri,
                    saved: liked,
                    request_id,
                })
                .map_err(|error| error.to_string()),
            ProviderLikeRoute::SoundCloud { urn, liked } => soundcloud
                .send(SoundCloudCommand::SetLiked {
                    urn,
                    stable_key: target.stable_key.clone(),
                    liked,
                    request_id,
                })
                .map_err(|error| error.to_string()),
        };
        if let Err(error) = result {
            self.rollback_dispatch(&target.stable_key, request_id);
            return Err(error);
        }
        Ok(())
    }

    pub fn accept_loaded(
        &mut self,
        stable_key: &str,
        request_id: u64,
        result: Result<bool, String>,
    ) -> Result<bool, String> {
        let entry = self.entries.entry(stable_key.to_owned()).or_default();
        if entry.query_id != Some(request_id) {
            return result;
        }
        entry.query_id = None;
        match result {
            Ok(liked) => {
                if entry.mutation.is_none() {
                    entry.confirmed = Some(liked);
                }
                tracing::info!(track = stable_key, liked, "Liked state loaded");
                Ok(liked)
            }
            Err(error) => Err(error),
        }
    }

    pub fn accept_changed(
        &mut self,
        stable_key: &str,
        request_id: u64,
        result: Result<(), String>,
    ) -> Result<bool, String> {
        let entry = self.entries.entry(stable_key.to_owned()).or_default();
        let Some(pending) = entry.mutation.take() else {
            return result.map(|_| false);
        };
        if pending.request_id != request_id {
            entry.mutation = Some(pending);
            return result.map(|_| false);
        }
        match result {
            Ok(()) => {
                entry.confirmed = Some(pending.desired);
                Ok(pending.desired)
            }
            Err(error) => {
                entry.confirmed = pending.previous;
                tracing::warn!(track = stable_key, reason = %error, "Like request failed");
                Err(error)
            }
        }
    }

    /// Clears transient values after login/reconnect/logout/manual provider reload.
    pub fn invalidate_provider(&mut self, provider: TrackProvider) {
        let prefix = match provider {
            TrackProvider::Spotify => "spotify:",
            TrackProvider::SoundCloud => "soundcloud:",
        };
        self.entries.retain(|key, _| !key.starts_with(prefix));
        if self
            .current_key
            .as_deref()
            .is_some_and(|key| key.starts_with(prefix))
        {
            self.current_key = None;
        }
    }

    fn dispatch_query(
        &mut self,
        target: LikeTarget,
        spotify: &SpotifyRuntime,
        soundcloud: &SoundCloudRuntime,
    ) {
        let request_id = self.allocate_id();
        self.entries
            .entry(target.stable_key.clone())
            .or_default()
            .query_id = Some(request_id);
        let result: Result<(), String> = match target.provider {
            TrackProvider::Spotify => spotify
                .send(SpotifyCommand::LoadSavedState {
                    uri: target.provider_key,
                    stable_key: target.stable_key.clone(),
                    request_id,
                })
                .map_err(|error| error.to_string()),
            TrackProvider::SoundCloud => soundcloud
                .send(SoundCloudCommand::LoadLikedState {
                    urn: target.provider_key,
                    stable_key: target.stable_key.clone(),
                    request_id,
                })
                .map_err(|error| error.to_string()),
        };
        if result.is_err() {
            if let Some(entry) = self.entries.get_mut(&target.stable_key) {
                entry.query_id = None;
            }
        }
    }

    fn allocate_id(&mut self) -> u64 {
        self.next_request_id = self.next_request_id.wrapping_add(1).max(1);
        self.next_request_id
    }

    fn select_current(&mut self, track: Option<&TrackRow>) -> bool {
        let next = track.map(TrackRow::stable_key);
        if self.current_key == next {
            return false;
        }
        self.current_key = next;
        track.is_some()
    }

    fn rollback_dispatch(&mut self, stable_key: &str, request_id: u64) {
        if let Some(entry) = self.entries.get_mut(stable_key)
            && entry
                .mutation
                .as_ref()
                .is_some_and(|pending| pending.request_id == request_id)
        {
            let previous = entry.mutation.take().and_then(|pending| pending.previous);
            entry.confirmed = previous;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn spotify() -> TrackRow {
        TrackRow {
            provider: TrackProvider::Spotify,
            provider_id: ProviderTrackId::Spotify {
                id: "s".into(),
                uri: "spotify:track:s".into(),
            },
            title: "Song".into(),
            artist: "A".into(),
            collection: String::new(),
            duration_ms: 1,
            artwork_url: None,
            liked: Some(false),
            playable: true,
        }
    }
    fn soundcloud() -> TrackRow {
        TrackRow {
            provider: TrackProvider::SoundCloud,
            provider_id: ProviderTrackId::SoundCloud {
                id: "7".into(),
                urn: Some("soundcloud:tracks:7".into()),
                permalink_url: None,
            },
            title: "Song".into(),
            artist: "A".into(),
            collection: String::new(),
            duration_ms: 1,
            artwork_url: None,
            liked: None,
            playable: true,
        }
    }

    #[test]
    fn tracks_route_only_to_their_provider() {
        let spotify = LikeTarget::from_track(&spotify()).unwrap();
        let soundcloud = LikeTarget::from_track(&soundcloud()).unwrap();
        assert_eq!(spotify.provider, TrackProvider::Spotify);
        assert_eq!(spotify.provider_key, "spotify:track:s");
        assert_eq!(soundcloud.provider, TrackProvider::SoundCloud);
        assert_eq!(soundcloud.provider_key, "soundcloud:tracks:7");
        assert_ne!(spotify.stable_key, soundcloud.stable_key);
    }

    #[test]
    fn spotify_like_and_unlike_route_to_spotify_only() {
        let target = LikeTarget::from_track(&spotify()).unwrap();
        assert_eq!(
            mutation_route(&target, true),
            ProviderLikeRoute::Spotify {
                uri: "spotify:track:s".into(),
                liked: true
            }
        );
        assert_eq!(
            mutation_route(&target, false),
            ProviderLikeRoute::Spotify {
                uri: "spotify:track:s".into(),
                liked: false
            }
        );
    }

    #[test]
    fn soundcloud_like_and_unlike_route_to_soundcloud_only() {
        let target = LikeTarget::from_track(&soundcloud()).unwrap();
        assert_eq!(
            mutation_route(&target, true),
            ProviderLikeRoute::SoundCloud {
                urn: "soundcloud:tracks:7".into(),
                liked: true
            }
        );
        assert_eq!(
            mutation_route(&target, false),
            ProviderLikeRoute::SoundCloud {
                urn: "soundcloud:tracks:7".into(),
                liked: false
            }
        );
    }

    #[test]
    fn optimistic_state_rolls_back_on_error() {
        let track = spotify();
        let mut state = ProviderLibraryState::default();
        state.observe(&track);
        let key = track.stable_key();
        state.entries.get_mut(&key).unwrap().mutation = Some(PendingMutation {
            request_id: 9,
            previous: Some(false),
            desired: true,
        });
        assert!(state.visual(&track).liked);
        assert!(state.accept_changed(&key, 9, Err("no".into())).is_err());
        assert!(!state.visual(&track).liked);
    }

    #[test]
    fn provider_switch_refreshes_liked_state() {
        let mut state = ProviderLibraryState::default();
        state.observe(&spotify());
        assert!(state.select_current(Some(&spotify())));
        assert!(!state.select_current(Some(&spotify())));
        assert!(state.select_current(Some(&soundcloud())));
        assert!(!state.visual(&soundcloud()).known);
    }

    #[test]
    fn multiple_visible_track_rows_synchronize_liked_state() {
        let track = spotify();
        let copy = track.clone();
        let key = track.stable_key();
        let mut state = ProviderLibraryState::default();
        state.observe(&track);
        state.entries.get_mut(&key).unwrap().mutation = Some(PendingMutation {
            request_id: 10,
            previous: Some(false),
            desired: true,
        });
        assert!(state.visual(&track).liked);
        assert!(state.visual(&copy).liked);
    }

    #[test]
    fn spotify_like_does_not_affect_soundcloud_and_vice_versa() {
        let spotify = spotify();
        let soundcloud = soundcloud();
        let mut state = ProviderLibraryState::default();
        state.observe(&spotify);
        state
            .entries
            .get_mut(&spotify.stable_key())
            .unwrap()
            .confirmed = Some(true);
        assert!(state.visual(&spotify).liked);
        assert!(!state.visual(&soundcloud).known);

        state
            .entries
            .entry(soundcloud.stable_key())
            .or_default()
            .confirmed = Some(true);
        assert!(state.visual(&soundcloud).liked);
        assert!(state.visual(&spotify).liked);
    }
}
