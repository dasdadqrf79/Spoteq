use serde::{Deserialize, Serialize};

use crate::catalog::TrackRow;

/// Number of bands in the graphic equalizer.
pub const EQ_BAND_COUNT: usize = 10;

/// Standard octave-spaced frequencies of the fixed ten-band equalizer.
pub const EQ_FREQUENCIES_HZ: [f32; EQ_BAND_COUNT] = [
    31.0, 62.0, 125.0, 250.0, 500.0, 1_000.0, 2_000.0, 4_000.0, 8_000.0, 16_000.0,
];

const SETTINGS_SCHEMA_VERSION: u32 = 16;

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Default)]
pub enum Language {
    English,
    #[default]
    Russian,
}

const RECENT_SEARCH_LIMIT: usize = 8;
const RECENT_TRACK_LIMIT: usize = 8;
const LISTENING_HISTORY_LIMIT: usize = 500;
const VIBE_HISTORY_LIMIT: usize = 20;

/// User-selectable accent palettes for the dark Spoteq interface.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
pub enum AccentColor {
    Neutral,
    Green,
    Lime,
    Cyan,
    Blue,
    Violet,
    Pink,
    Red,
    Orange,
    Gold,
}

impl AccentColor {
    /// All accent choices in the order shown in Settings.
    pub const ALL: [Self; 10] = [
        Self::Neutral,
        Self::Green,
        Self::Lime,
        Self::Cyan,
        Self::Blue,
        Self::Violet,
        Self::Pink,
        Self::Red,
        Self::Orange,
        Self::Gold,
    ];

    /// Short display name used by the appearance picker.
    pub const fn label(self) -> &'static str {
        match self {
            Self::Neutral => "Default",
            Self::Green => "Green",
            Self::Lime => "Lime",
            Self::Cyan => "Cyan",
            Self::Blue => "Blue",
            Self::Violet => "Violet",
            Self::Pink => "Pink",
            Self::Red => "Red",
            Self::Orange => "Orange",
            Self::Gold => "Gold",
        }
    }

    /// RGB channels of this accent.
    pub const fn rgb(self) -> [u8; 3] {
        match self {
            Self::Neutral => [238, 239, 239],
            Self::Green => [30, 215, 96],
            Self::Lime => [163, 230, 53],
            Self::Cyan => [34, 211, 238],
            Self::Blue => [59, 130, 246],
            Self::Violet => [139, 92, 246],
            Self::Pink => [236, 72, 153],
            Self::Red => [239, 68, 68],
            Self::Orange => [249, 115, 22],
            Self::Gold => [245, 158, 11],
        }
    }
}

impl Default for AccentColor {
    fn default() -> Self {
        Self::Neutral
    }
}

/// Persistent visual preferences that do not affect playback or DSP.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Default)]
pub enum ThemeMode {
    Light,
    #[default]
    Dark,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(default)]
pub struct AppearanceSettings {
    pub theme: ThemeMode,
    pub language: Language,
    /// Percentage of background detail retained by the glass material.
    pub glass_transparency: u8,
    /// Accent used for selection, active controls and playback indicators.
    pub accent: AccentColor,
    /// Enables lightweight interface transitions.
    pub motion_enabled: bool,
    /// Enables ambient glow and raised panel shadows.
    pub depth_enabled: bool,
}

impl Default for AppearanceSettings {
    fn default() -> Self {
        Self {
            theme: ThemeMode::default(),
            language: Language::default(),
            glass_transparency: 90,
            accent: AccentColor::default(),
            motion_enabled: true,
            depth_enabled: true,
        }
    }
}

/// Complete application settings persisted between launches.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(default)]
pub struct AppSettings {
    /// Schema version used for future migrations.
    pub schema_version: u32,
    /// Audio and equalizer parameters.
    pub audio: AudioSettings,
    /// Visual appearance preferences.
    pub appearance: AppearanceSettings,
    /// Queue and playback behavior that does not alter the DSP chain.
    pub playback: PlaybackSettings,
    /// Small local Search history used only to restore recent UI actions.
    pub search_history: SearchHistorySettings,
    /// Recently played tracks and the last resumable session.
    pub session: SessionSettings,
}

impl AppSettings {
    /// Clamps values loaded from disk to the supported ranges.
    pub fn sanitize(&mut self) {
        self.schema_version = SETTINGS_SCHEMA_VERSION;
        self.appearance.glass_transparency = self.appearance.glass_transparency.min(100);
        self.audio.sanitize();
        self.search_history.sanitize();
        self.playback.sanitize();
        self.session.sanitize();
    }
}

impl Default for AppSettings {
    fn default() -> Self {
        Self {
            schema_version: SETTINGS_SCHEMA_VERSION,
            audio: AudioSettings::default(),
            appearance: AppearanceSettings::default(),
            playback: PlaybackSettings::default(),
            search_history: SearchHistorySettings::default(),
            session: SessionSettings::default(),
        }
    }
}

/// Bounded local history shown when the Search field is empty.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Default)]
#[serde(default)]
pub struct SearchHistorySettings {
    /// Most recently dispatched Search queries, newest first.
    pub queries: Vec<String>,
    /// Tracks explicitly selected from Search, newest first.
    pub tracks: Vec<TrackRow>,
}

impl SearchHistorySettings {
    /// Moves a non-empty query to the front and enforces the storage limit.
    pub fn record_query(&mut self, query: &str) -> bool {
        let query = query.trim();
        if query.is_empty() {
            return false;
        }
        if self
            .queries
            .first()
            .is_some_and(|current| current.eq_ignore_ascii_case(query))
        {
            return false;
        }
        self.queries
            .retain(|saved| !saved.eq_ignore_ascii_case(query));
        self.queries.insert(0, query.to_owned());
        self.queries.truncate(RECENT_SEARCH_LIMIT);
        true
    }

    /// Moves one provider-qualified Search selection to the front.
    pub fn record_track(&mut self, track: &TrackRow) -> bool {
        let key = track.stable_key();
        self.tracks.retain(|saved| saved.stable_key() != key);
        self.tracks.insert(0, track.clone());
        self.tracks.truncate(RECENT_TRACK_LIMIT);
        true
    }

    fn sanitize(&mut self) {
        self.queries.retain(|query| !query.trim().is_empty());
        let mut unique_queries = Vec::new();
        for query in self.queries.drain(..) {
            if !unique_queries
                .iter()
                .any(|saved: &String| saved.eq_ignore_ascii_case(&query))
            {
                unique_queries.push(query);
            }
        }
        unique_queries.truncate(RECENT_SEARCH_LIMIT);
        self.queries = unique_queries;

        let mut keys = std::collections::HashSet::new();
        self.tracks
            .retain(|track| track.playable && keys.insert(track.stable_key()));
        self.tracks.truncate(RECENT_TRACK_LIMIT);
    }
}

/// Persistent session playback preferences.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(default)]
pub struct PlaybackSettings {
    /// Continue an exhausted user queue with real similar-track recommendations.
    pub autoplay_similar: bool,
    /// Randomizes only the unplayed part of the user queue.
    pub shuffle: bool,
    /// Determines what happens when the active track or user queue ends.
    pub repeat: RepeatMode,
    /// Short provider-neutral volume ramp used around Pause and Resume.
    pub pause_fade_ms: u16,
    /// Uses preloaded next-track audio to minimize silence at natural boundaries.
    pub gapless_enabled: bool,
    /// Equal-power cross-provider overlap duration. Zero disables crossfade.
    pub crossfade_seconds: u8,
}

impl Default for PlaybackSettings {
    fn default() -> Self {
        Self {
            autoplay_similar: true,
            shuffle: false,
            repeat: RepeatMode::Off,
            pause_fade_ms: 200,
            gapless_enabled: true,
            crossfade_seconds: 4,
        }
    }
}

impl PlaybackSettings {
    fn sanitize(&mut self) {
        self.pause_fade_ms = self.pause_fade_ms.clamp(100, 300);
        self.crossfade_seconds = self.crossfade_seconds.min(12);
    }
}

/// One real playback start retained in the local listening history.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct ListeningHistoryEntry {
    /// Provider-qualified metadata required to play the item again.
    pub track: TrackRow,
    /// UTC Unix timestamp in milliseconds when playback began.
    pub started_at_ms: i64,
    /// Furthest observed playback position for this play.
    #[serde(default)]
    pub played_ms: u32,
    /// Whether at least 80% of the track was heard.
    #[serde(default)]
    pub completed: bool,
    /// Whether the track was left during its first short listening window.
    #[serde(default)]
    pub skipped: bool,
    /// Prevents a later UI refresh from recording the same outcome twice.
    #[serde(default)]
    pub finished: bool,
}

/// Last active track, position and remaining provider-neutral queue.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Default)]
#[serde(default)]
pub struct ResumeSession {
    /// Track that was active when the snapshot was written.
    pub current: Option<TrackRow>,
    /// Position to seek to after the user explicitly resumes.
    pub position_ms: u32,
    /// User-controlled tracks that followed the active track.
    pub next_up: Vec<TrackRow>,
    /// Automatically recommended tracks kept behind the user queue.
    pub autoplay: Vec<TrackRow>,
    /// Explicit Radio title when the queue originated from Start Radio.
    pub radio_title: Option<String>,
}

/// One explicitly saved Autoplay/Radio session, not a provider favorite.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct VibeSession {
    /// Short UI title derived from the Radio seed.
    pub title: String,
    /// UTC Unix timestamp in milliseconds when the user saved the session.
    pub saved_at_ms: i64,
    /// Temporary provider-qualified queue snapshot.
    pub session: ResumeSession,
}

/// Bounded session data persisted by the existing background settings writer.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(default)]
pub struct SessionSettings {
    /// Newest playback start first.
    pub history: Vec<ListeningHistoryEntry>,
    /// Transient revision of the history data used by Smart Library.
    #[serde(skip)]
    pub history_revision: u64,
    /// Last resumable snapshot. Loading it never starts audio automatically.
    pub resume: Option<ResumeSession>,
    /// Explicitly saved Autoplay/Radio sessions, newest first.
    pub vibes: Vec<VibeSession>,
}

impl PartialEq for SessionSettings {
    fn eq(&self, other: &Self) -> bool {
        self.history == other.history && self.resume == other.resume && self.vibes == other.vibes
    }
}

impl SessionSettings {
    /// Records a real track start without inventing provider library data.
    pub fn record_started(&mut self, track: &TrackRow, started_at_ms: i64) {
        self.history.insert(
            0,
            ListeningHistoryEntry {
                track: track.clone(),
                started_at_ms,
                played_ms: 0,
                completed: false,
                skipped: false,
                finished: false,
            },
        );
        self.history.truncate(LISTENING_HISTORY_LIMIT);
        self.history_revision = self.history_revision.wrapping_add(1);
    }

    /// Finalizes the newest matching play using real observed playback progress.
    pub fn finish_play(&mut self, stable_key: &str, position_ms: u32, duration_ms: u64) {
        let Some(entry) = self
            .history
            .iter_mut()
            .find(|entry| !entry.finished && entry.track.stable_key() == stable_key)
        else {
            return;
        };
        let duration = duration_ms.min(u64::from(u32::MAX)) as u32;
        entry.played_ms = position_ms.min(duration);
        let ratio = if duration == 0 {
            0.0
        } else {
            f64::from(entry.played_ms) / f64::from(duration)
        };
        entry.completed = ratio >= 0.80;
        let short_window = duration.saturating_div(4).min(30_000).max(5_000);
        entry.skipped = !entry.completed && entry.played_ms < short_window;
        entry.finished = true;
        self.history_revision = self.history_revision.wrapping_add(1);
    }

    /// Saves a bounded temporary Radio/Autoplay session.
    pub fn save_vibe(&mut self, title: String, session: ResumeSession, saved_at_ms: i64) {
        self.vibes.insert(
            0,
            VibeSession {
                title,
                saved_at_ms,
                session,
            },
        );
        self.vibes.truncate(VIBE_HISTORY_LIMIT);
    }

    fn sanitize(&mut self) {
        self.history.retain(|entry| entry.track.playable);
        self.history.truncate(LISTENING_HISTORY_LIMIT);
        self.vibes.retain(|vibe| {
            vibe.session
                .current
                .as_ref()
                .is_some_and(|track| track.playable)
        });
        self.vibes.truncate(VIBE_HISTORY_LIMIT);
        if self
            .resume
            .as_ref()
            .is_some_and(|resume| resume.current.as_ref().is_none_or(|track| !track.playable))
        {
            self.resume = None;
        }
        if let Some(resume) = &mut self.resume {
            resume.next_up.retain(|track| track.playable);
            resume.autoplay.retain(|track| track.playable);
            resume.next_up.truncate(100);
            resume.autoplay.truncate(20);
            if let Some(current) = &resume.current {
                resume.position_ms = resume
                    .position_ms
                    .min(current.duration_ms.min(u64::from(u32::MAX)) as u32);
            }
        }
        for vibe in &mut self.vibes {
            vibe.title = vibe.title.trim().chars().take(80).collect();
            vibe.session.next_up.retain(|track| track.playable);
            vibe.session.autoplay.retain(|track| track.playable);
            vibe.session.next_up.truncate(100);
            vibe.session.autoplay.truncate(20);
        }
    }
}

/// Repeat behavior shared by Spotify and SoundCloud playback.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Default)]
pub enum RepeatMode {
    /// Stop (or enter Autoplay) after the user queue ends.
    #[default]
    Off,
    /// Restart the user queue after its last track.
    Queue,
    /// Restart the active track after a natural end.
    Track,
}

impl RepeatMode {
    /// Advances through the three repeat modes used by the player bar.
    pub const fn next(self) -> Self {
        match self {
            Self::Off => Self::Queue,
            Self::Queue => Self::Track,
            Self::Track => Self::Off,
        }
    }

    /// Compact label suitable for a transport control tooltip.
    pub const fn label(self) -> &'static str {
        match self {
            Self::Off => "Repeat off",
            Self::Queue => "Repeat queue",
            Self::Track => "Repeat track",
        }
    }
}

/// Number of freely tunable low-frequency filters.
pub const BASS_BAND_COUNT: usize = 5;

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Default)]
pub enum BassFilterKind {
    #[default]
    Bell,
    LowShelf,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq)]
#[serde(default)]
pub struct BassBand {
    pub enabled: bool,
    pub kind: BassFilterKind,
    pub frequency_hz: f32,
    pub gain_db: f32,
    pub q: f32,
}

impl Default for BassBand {
    fn default() -> Self {
        Self {
            enabled: true,
            kind: BassFilterKind::Bell,
            frequency_hz: 78.0,
            gain_db: 0.0,
            q: 0.8,
        }
    }
}

impl BassBand {
    pub fn sanitize(&mut self) {
        fn bounded(value: f32, fallback: f32, low: f32, high: f32) -> f32 {
            if value.is_finite() {
                value.clamp(low, high)
            } else {
                fallback
            }
        }
        self.frequency_hz = bounded(self.frequency_hz, 78.0, 20.0, 250.0);
        self.gain_db = bounded(self.gain_db, 0.0, -12.0, 12.0);
        self.q = bounded(self.q, 0.8, 0.3, 6.0);
    }
}

/// Neutral by default, so older saved equalizer settings keep their sound.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq)]
#[serde(default)]
pub struct BassToneSettings {
    pub depth_db: f32,
    pub punch: f32,
    pub saturation: f32,
    pub density: f32,
    /// Zero bypasses the subsonic high-pass filter.
    pub rumble_hz: f32,
    pub dynamic: f32,
    /// 100 is the original stereo image; 0 is mono.
    pub width: f32,
    pub mono_bass: bool,
}

impl Default for BassToneSettings {
    fn default() -> Self {
        Self {
            depth_db: 0.0,
            punch: 0.0,
            saturation: 0.0,
            density: 0.0,
            rumble_hz: 0.0,
            dynamic: 0.0,
            width: 100.0,
            mono_bass: false,
        }
    }
}

impl BassToneSettings {
    pub fn sanitize(&mut self) {
        fn bounded(value: &mut f32, fallback: f32, low: f32, high: f32) {
            *value = if value.is_finite() {
                value.clamp(low, high)
            } else {
                fallback
            };
        }
        bounded(&mut self.depth_db, 0.0, 0.0, 9.0);
        bounded(&mut self.punch, 0.0, -100.0, 100.0);
        bounded(&mut self.saturation, 0.0, 0.0, 100.0);
        bounded(&mut self.density, 0.0, 0.0, 100.0);
        bounded(&mut self.rumble_hz, 0.0, 0.0, 45.0);
        if self.rumble_hz > 0.0 {
            self.rumble_hz = self.rumble_hz.max(15.0);
        }
        bounded(&mut self.dynamic, 0.0, 0.0, 100.0);
        bounded(&mut self.width, 100.0, 0.0, 150.0);
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(default)]
pub struct BassStudioSettings {
    pub enabled: bool,
    /// A/B bypass of Bass Studio only; the existing EQ remains independent.
    pub bypass: bool,
    pub bands: [BassBand; BASS_BAND_COUNT],
    pub tone: BassToneSettings,
}

impl Default for BassStudioSettings {
    fn default() -> Self {
        Self {
            enabled: false,
            bypass: false,
            tone: BassToneSettings::default(),
            bands: [28.0, 46.0, 78.0, 128.0, 200.0].map(|frequency_hz| BassBand {
                frequency_hz,
                ..Default::default()
            }),
        }
    }
}

/// Persistent parameters for local output and the real-time DSP engine.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(default)]
pub struct AudioSettings {
    /// `None` follows the current Windows default output; otherwise stores the
    /// exact CPAL/WASAPI device name selected by the user.
    pub output_device: Option<String>,
    /// Enables or bypasses all filters while retaining master volume.
    pub eq_enabled: bool,
    /// Gain applied before all filters, in decibels.
    pub preamp_db: f32,
    /// Low-shelf gain near 45 Hz, in decibels.
    pub sub_bass_db: f32,
    /// Gain of the parametric bass filter, in decibels.
    pub bass_gain_db: f32,
    /// Center frequency of the parametric bass filter.
    pub bass_frequency_hz: f32,
    /// Q factor of the parametric bass filter.
    pub bass_q: f32,
    /// Gain of each fixed equalizer band, in decibels. A vector permits
    /// migration from the fourteen-band v0.3 settings file.
    pub eq_db: Vec<f32>,
    /// Local output volume in the normalized 0.0 to 1.0 range.
    pub master_volume: f32,
    pub bass_studio: BassStudioSettings,
}

impl AudioSettings {
    fn sanitize(&mut self) {
        self.output_device = self
            .output_device
            .take()
            .map(|device| device.trim().to_owned())
            .filter(|device| !device.is_empty());
        for band in &mut self.bass_studio.bands {
            band.sanitize();
        }
        self.bass_studio.tone.sanitize();
        self.preamp_db = self.preamp_db.clamp(-24.0, 6.0);
        self.sub_bass_db = self.sub_bass_db.clamp(-12.0, 12.0);
        self.bass_gain_db = self.bass_gain_db.clamp(-12.0, 12.0);
        self.bass_frequency_hz = self.bass_frequency_hz.clamp(35.0, 180.0);
        self.bass_q = self.bass_q.clamp(0.30, 3.00);
        self.master_volume = self.master_volume.clamp(0.0, 1.0);
        if self.eq_db.len() == 14 {
            self.eq_db = vec![
                (self.eq_db[0] + self.eq_db[1]) * 0.5,
                self.eq_db[2],
                self.eq_db[5],
                self.eq_db[7],
                self.eq_db[8],
                self.eq_db[9],
                self.eq_db[10],
                self.eq_db[11],
                self.eq_db[12],
                self.eq_db[13],
            ];
        } else {
            self.eq_db.resize(EQ_BAND_COUNT, 0.0);
            self.eq_db.truncate(EQ_BAND_COUNT);
        }
        for gain in &mut self.eq_db {
            *gain = gain.clamp(-12.0, 12.0);
        }
    }
}

impl Default for AudioSettings {
    fn default() -> Self {
        Self {
            output_device: None,
            eq_enabled: true,
            preamp_db: -6.0,
            sub_bass_db: 0.0,
            bass_gain_db: 0.0,
            bass_frequency_hz: 70.0,
            bass_q: 0.80,
            eq_db: vec![0.0; EQ_BAND_COUNT],
            master_volume: 0.80,
            bass_studio: BassStudioSettings::default(),
        }
    }
}

#[cfg(test)]
mod tests {
    #[test]
    fn theme_defaults_to_dark_and_light_and_dark_choices_survive_restart() {
        use super::{AppSettings, ThemeMode};
        let mut settings = AppSettings::default();
        let audio = settings.audio.clone();
        let mut old = serde_json::to_value(&settings).unwrap();
        old["appearance"].as_object_mut().unwrap().remove("theme");
        let migrated: AppSettings = serde_json::from_value(old).unwrap();
        assert_eq!(migrated.appearance.theme, ThemeMode::Dark);
        let directory = tempfile::tempdir().unwrap();
        let store =
            crate::settings::SettingsStore::from_path(directory.path().join("settings.json"));
        for mode in [ThemeMode::Light, ThemeMode::Dark] {
            settings.appearance.theme = mode;
            store.save_now(&settings).unwrap();
            let restored = store.load().unwrap();
            assert_eq!(restored.appearance.theme, mode);
            assert_eq!(restored.audio, audio);
        }
    }
    #[test]
    fn clear_glass_setting_migrates_persists_and_clamps() {
        use super::AppSettings;
        let settings = AppSettings::default();
        let mut json = serde_json::to_value(&settings).unwrap();
        json["appearance"]
            .as_object_mut()
            .unwrap()
            .remove("glass_transparency");
        let mut migrated: AppSettings = serde_json::from_value(json).unwrap();
        assert_eq!(migrated.appearance.glass_transparency, 90);
        migrated.appearance.glass_transparency = 97;
        let directory = tempfile::tempdir().unwrap();
        let store =
            crate::settings::SettingsStore::from_path(directory.path().join("settings.json"));
        store.save_now(&migrated).unwrap();
        assert_eq!(store.load().unwrap(), migrated);
        migrated.appearance.glass_transparency = 255;
        migrated.sanitize();
        assert_eq!(migrated.appearance.glass_transparency, 100);
        assert_eq!(migrated.audio, settings.audio);
    }

    #[test]
    fn bass_tone_settings_migrate_save_restore_and_sanitize() {
        use super::{AppSettings, BassToneSettings};
        let mut old = AppSettings::default();
        old.audio.bass_studio.enabled = true;
        old.audio.bass_studio.bands[2].gain_db = 4.5;
        let mut json = serde_json::to_value(&old).unwrap();
        json["audio"]["bass_studio"]
            .as_object_mut()
            .unwrap()
            .remove("tone");
        let restored: AppSettings = serde_json::from_value(json).unwrap();
        assert_eq!(restored, old);
        assert_eq!(restored.audio.bass_studio.tone, BassToneSettings::default());

        let directory = tempfile::tempdir().unwrap();
        let store =
            crate::settings::SettingsStore::from_path(directory.path().join("settings.json"));
        old.audio.bass_studio.tone = BassToneSettings {
            depth_db: 4.5,
            punch: -30.0,
            density: 25.0,
            saturation: 40.0,
            rumble_hz: 24.0,
            dynamic: 50.0,
            width: 125.0,
            mono_bass: true,
        };
        store.save_now(&old).unwrap();
        assert_eq!(store.load().unwrap(), old);
        let mut invalid = BassToneSettings {
            depth_db: f32::NAN,
            punch: -300.0,
            density: f32::INFINITY,
            saturation: 900.0,
            rumble_hz: -10.0,
            dynamic: 300.0,
            width: f32::NAN,
            mono_bass: true,
        };
        invalid.sanitize();
        assert_eq!(
            invalid,
            BassToneSettings {
                depth_db: 0.0,
                punch: -100.0,
                density: 0.0,
                saturation: 100.0,
                rumble_hz: 0.0,
                dynamic: 100.0,
                width: 100.0,
                mono_bass: true
            }
        );
        old.audio.bass_studio.tone = invalid;
        old.audio.bass_studio.tone.width = 999.0;
        old.sanitize();
        assert_eq!(old.audio.bass_studio.tone.width, 150.0);
    }

    use super::{
        AppSettings, LISTENING_HISTORY_LIMIT, RECENT_SEARCH_LIMIT, ResumeSession,
        SearchHistorySettings, SessionSettings, VIBE_HISTORY_LIMIT,
    };
    use crate::catalog::{ProviderTrackId, TrackProvider, TrackRow};

    fn track(id: usize) -> TrackRow {
        TrackRow {
            provider: TrackProvider::Spotify,
            provider_id: ProviderTrackId::Spotify {
                id: id.to_string(),
                uri: format!("spotify:track:{id}"),
            },
            title: format!("Track {id}"),
            artist: "Artist".to_owned(),
            collection: "Album".to_owned(),
            duration_ms: 180_000,
            artwork_url: None,
            liked: None,
            playable: true,
        }
    }

    #[test]
    fn recent_queries_are_bounded_and_moved_to_the_front() {
        let mut history = SearchHistorySettings::default();
        for index in 0..RECENT_SEARCH_LIMIT + 3 {
            history.record_query(&format!("query {index}"));
        }
        assert_eq!(history.queries.len(), RECENT_SEARCH_LIMIT);

        assert!(history.record_query("query 5"));
        assert_eq!(history.queries.first().map(String::as_str), Some("query 5"));
        assert_eq!(
            history
                .queries
                .iter()
                .filter(|query| query.eq_ignore_ascii_case("query 5"))
                .count(),
            1
        );
    }

    #[test]
    fn listening_history_is_bounded_and_keeps_newest_first() {
        let mut session = SessionSettings::default();
        for index in 0..LISTENING_HISTORY_LIMIT + 3 {
            session.record_started(&track(index), index as i64);
        }
        assert_eq!(session.history.len(), LISTENING_HISTORY_LIMIT);
        assert_eq!(session.history[0].track.title, "Track 502");
    }

    #[test]
    fn listening_outcome_distinguishes_completion_from_early_skip() {
        let mut session = SessionSettings::default();
        session.record_started(&track(1), 1);
        session.finish_play(&track(1).stable_key(), 150_000, 180_000);
        assert!(session.history[0].completed);
        assert!(!session.history[0].skipped);
        assert!(session.history[0].finished);

        session.record_started(&track(2), 2);
        session.finish_play(&track(2).stable_key(), 4_000, 180_000);
        assert!(!session.history[0].completed);
        assert!(session.history[0].skipped);
        assert!(session.history[0].finished);
    }

    #[test]
    fn saved_vibes_are_bounded_and_keep_real_provider_tracks() {
        let mut session = SessionSettings::default();
        for index in 0..VIBE_HISTORY_LIMIT + 2 {
            session.save_vibe(
                format!("Vibe {index}"),
                ResumeSession {
                    current: Some(track(index)),
                    position_ms: 0,
                    next_up: Vec::new(),
                    autoplay: Vec::new(),
                    radio_title: Some(format!("Artist {index} Radio")),
                },
                index as i64,
            );
        }
        assert_eq!(session.vibes.len(), VIBE_HISTORY_LIMIT);
        assert_eq!(session.vibes[0].title, "Vibe 21");
        assert_eq!(
            session.vibes[0]
                .session
                .current
                .as_ref()
                .map(TrackRow::stable_key),
            Some(track(21).stable_key())
        );
    }

    #[test]
    fn v016_settings_without_v017_fields_load_with_safe_defaults() {
        let mut legacy = AppSettings::default();
        legacy.schema_version = 8;
        legacy.session.record_started(&track(7), 123);
        legacy.session.resume = Some(ResumeSession {
            current: Some(track(7)),
            position_ms: 12_000,
            next_up: vec![track(8)],
            autoplay: Vec::new(),
            radio_title: None,
        });

        let mut json = serde_json::to_value(&legacy).expect("serialize settings fixture");
        let session = json
            .get_mut("session")
            .and_then(serde_json::Value::as_object_mut)
            .expect("session object");
        session.remove("vibes");
        session
            .get_mut("resume")
            .and_then(serde_json::Value::as_object_mut)
            .expect("resume object")
            .remove("radio_title");
        for entry in session
            .get_mut("history")
            .and_then(serde_json::Value::as_array_mut)
            .expect("history array")
        {
            let entry = entry.as_object_mut().expect("history entry");
            entry.remove("played_ms");
            entry.remove("completed");
            entry.remove("skipped");
            entry.remove("finished");
        }

        let mut restored: AppSettings =
            serde_json::from_value(json).expect("v0.16 settings must deserialize");
        restored.sanitize();
        assert_eq!(restored.session.history.len(), 1);
        assert_eq!(restored.session.history[0].played_ms, 0);
        assert!(!restored.session.history[0].completed);
        assert!(restored.session.vibes.is_empty());
        assert_eq!(
            restored
                .session
                .resume
                .as_ref()
                .and_then(|resume| resume.radio_title.as_deref()),
            None
        );
    }
}
