//! Versioned settings model and non-blocking persistence worker.

mod model;
mod store;

pub use model::{
    AccentColor, AppSettings, AppearanceSettings, AudioSettings, BASS_BAND_COUNT, BassBand,
    BassFilterKind, BassStudioSettings, BassToneSettings, EQ_BAND_COUNT, EQ_FREQUENCIES_HZ,
    ListeningHistoryEntry, PlaybackSettings, RepeatMode, ResumeSession, SearchHistorySettings,
    SessionSettings, VibeSession,
};
pub use model::{Language, ThemeMode};
pub use store::{SettingsStore, SettingsWriter, WriterStatus};
