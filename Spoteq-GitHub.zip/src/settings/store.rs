use std::{
    fs::{self, File},
    io::{BufReader, BufWriter, Write},
    path::{Path, PathBuf},
    thread::{self, JoinHandle},
    time::Duration,
};

use flume::{Receiver, Sender};

use crate::{
    error::AppError,
    settings::AppSettings,
    storage::{DirectoryKind, app_directory},
};

const SAVE_DEBOUNCE: Duration = Duration::from_millis(500);

/// Resolves and reads the application settings file.
#[derive(Debug, Clone)]
pub struct SettingsStore {
    path: PathBuf,
}

impl SettingsStore {
    /// Creates a store in the platform-specific user configuration directory.
    pub fn discover() -> Result<Self, AppError> {
        let path = app_directory(DirectoryKind::Config)
            .map(|directory| directory.join("settings.json"))
            .ok_or(AppError::ConfigDirectoryUnavailable)?;
        Ok(Self { path })
    }

    /// Creates a store at an explicit path, primarily for tests.
    pub fn from_path(path: PathBuf) -> Self {
        Self { path }
    }

    /// Returns the settings file path.
    pub fn path(&self) -> &Path {
        &self.path
    }

    /// Loads and validates settings. A valid backup is used if the main file is damaged.
    pub fn load(&self) -> Result<AppSettings, AppError> {
        tracing::info!(path = %self.path.display(), "[STATE] loading config");
        match read_settings(&self.path) {
            Ok(mut settings) => {
                settings.sanitize();
                tracing::info!("[STATE] primary config loaded");
                Ok(settings)
            }
            Err(AppError::Io(error)) if error.kind() == std::io::ErrorKind::NotFound => {
                let backup = backup_path(&self.path);
                if backup.exists() {
                    let mut settings = read_settings(&backup)?;
                    settings.sanitize();
                    tracing::warn!(path = %backup.display(), "[STATE] primary config missing; backup restored");
                    Ok(settings)
                } else {
                    tracing::info!("[STATE] no persisted config; safe defaults loaded");
                    Ok(AppSettings::default())
                }
            }
            Err(primary_error) => {
                let backup = backup_path(&self.path);
                if backup.exists() {
                    let mut settings = read_settings(&backup)?;
                    settings.sanitize();
                    tracing::warn!(%primary_error, path = %backup.display(), "[STATE] damaged primary config; backup restored");
                    Ok(settings)
                } else {
                    tracing::error!(%primary_error, "[STATE] config deserialization failed");
                    Err(primary_error)
                }
            }
        }
    }

    /// Writes settings immediately using a recoverable temporary-and-backup rotation.
    pub fn save_now(&self, settings: &AppSettings) -> Result<(), AppError> {
        write_settings_safely(&self.path, settings)
    }
}

/// Status messages emitted by the background writer.
#[derive(Debug, Clone)]
pub enum WriterStatus {
    /// The latest snapshot was persisted.
    Saved,
    /// Persistence failed while the application can continue running.
    Failed(String),
}

enum WriterCommand {
    Update(AppSettings),
    FlushAndStop(AppSettings),
}

/// Single-owner background writer that keeps disk I/O off the UI thread.
pub struct SettingsWriter {
    command_tx: Sender<WriterCommand>,
    status_rx: Receiver<WriterStatus>,
    thread: Option<JoinHandle<()>>,
}

impl SettingsWriter {
    /// Starts the writer for the supplied store.
    pub fn start(store: SettingsStore) -> Result<Self, AppError> {
        let (command_tx, command_rx) = flume::unbounded();
        let (status_tx, status_rx) = flume::unbounded();
        let thread = thread::Builder::new()
            .name("settings-writer".to_owned())
            .spawn(move || writer_loop(store, command_rx, status_tx))?;

        Ok(Self {
            command_tx,
            status_rx,
            thread: Some(thread),
        })
    }

    /// Queues a new snapshot without waiting for file I/O.
    pub fn schedule(&self, settings: &AppSettings) -> Result<(), AppError> {
        self.command_tx
            .send(WriterCommand::Update(settings.clone()))
            .map_err(|_| AppError::SettingsWriterStopped)
    }

    /// Returns the most recent writer status, if one is available.
    pub fn try_status(&self) -> Option<WriterStatus> {
        self.status_rx.try_iter().last()
    }

    /// Flushes the final snapshot and joins the writer thread.
    pub fn shutdown(&mut self, settings: &AppSettings) {
        let _ = self
            .command_tx
            .send(WriterCommand::FlushAndStop(settings.clone()));
        if let Some(thread) = self.thread.take() {
            let _ = thread.join();
        }
    }
}

fn writer_loop(
    store: SettingsStore,
    command_rx: Receiver<WriterCommand>,
    status_tx: Sender<WriterStatus>,
) {
    while let Ok(command) = command_rx.recv() {
        let mut latest = match command {
            WriterCommand::Update(settings) => settings,
            WriterCommand::FlushAndStop(settings) => {
                report_save_result(store.save_now(&settings), &status_tx);
                return;
            }
        };

        loop {
            match command_rx.recv_timeout(SAVE_DEBOUNCE) {
                Ok(WriterCommand::Update(settings)) => latest = settings,
                Ok(WriterCommand::FlushAndStop(settings)) => {
                    report_save_result(store.save_now(&settings), &status_tx);
                    return;
                }
                Err(flume::RecvTimeoutError::Timeout) => {
                    report_save_result(store.save_now(&latest), &status_tx);
                    break;
                }
                Err(flume::RecvTimeoutError::Disconnected) => {
                    report_save_result(store.save_now(&latest), &status_tx);
                    return;
                }
            }
        }
    }
}

fn report_save_result(result: Result<(), AppError>, status_tx: &Sender<WriterStatus>) {
    let status = match result {
        Ok(()) => WriterStatus::Saved,
        Err(error) => WriterStatus::Failed(error.to_string()),
    };
    let _ = status_tx.send(status);
}

fn read_settings(path: &Path) -> Result<AppSettings, AppError> {
    let file = File::open(path)?;
    Ok(serde_json::from_reader(BufReader::new(file))?)
}

fn write_settings_safely(path: &Path, settings: &AppSettings) -> Result<(), AppError> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)?;
    }

    let temporary = temporary_path(path);
    let backup = backup_path(path);

    {
        let file = File::create(&temporary)?;
        let mut writer = BufWriter::new(file);
        serde_json::to_writer_pretty(&mut writer, settings)?;
        writer.write_all(b"\n")?;
        writer.flush()?;
        writer.get_ref().sync_all()?;
    }

    if !path.exists() {
        fs::rename(&temporary, path)?;
        return Ok(());
    }

    if backup.exists() {
        fs::remove_file(&backup)?;
    }
    fs::rename(path, &backup)?;

    if let Err(error) = fs::rename(&temporary, path) {
        let _ = fs::rename(&backup, path);
        return Err(error.into());
    }

    Ok(())
}

fn temporary_path(path: &Path) -> PathBuf {
    path.with_extension("json.tmp")
}

fn backup_path(path: &Path) -> PathBuf {
    path.with_extension("json.bak")
}
