//! Core modules for the Spoteq desktop audio application.

pub mod app;
pub mod audio;
pub mod autoplay;
pub mod catalog;
pub mod error;
pub mod image_cache;
pub mod provider_library;
pub mod settings;
pub mod soundcloud;
pub mod spotify;
pub mod state;
mod storage;
pub mod ui;

#[cfg(target_os = "windows")]
pub mod windows_media;
#[cfg(target_os = "windows")]
pub mod windows_taskbar;
#[cfg(target_os = "windows")]
pub mod windows_tray;
