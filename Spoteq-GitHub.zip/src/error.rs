//! Application-level errors that can be shown without crashing the UI.

use thiserror::Error;

/// Recoverable errors produced by local application services.
#[derive(Debug, Error)]
pub enum AppError {
    /// A local file operation failed.
    #[error("file operation failed: {0}")]
    Io(#[from] std::io::Error),

    /// A settings file contained invalid JSON.
    #[error("settings file is invalid: {0}")]
    Json(#[from] serde_json::Error),

    /// The background settings writer is no longer available.
    #[error("settings writer stopped unexpectedly")]
    SettingsWriterStopped,

    /// The operating system did not provide a per-user configuration directory.
    #[error("the user configuration directory is unavailable")]
    ConfigDirectoryUnavailable,
}
