//! Bounded UI texture cache backed by the Spotify worker's disk cache.

use std::{
    collections::{HashMap, HashSet},
    time::{Duration, Instant},
};

use eframe::egui::{self, Color32, Response, TextureHandle, Ui, Vec2};

use crate::{
    soundcloud::{DecodedArtwork, SoundCloudCommand, SoundCloudRuntime},
    spotify::{DecodedImage, SpotifyCommand, SpotifyRuntime},
    ui::theme::{self, colors},
};

const MAX_TEXTURES: usize = 128;
const MAX_FAILURES: usize = 256;
const FAILED_RETRY_AFTER: Duration = Duration::from_secs(60);

struct CachedTexture {
    texture: TextureHandle,
    last_used_frame: u64,
}

/// Owns decoded GPU textures and deduplicates in-flight cover requests.
#[derive(Default)]
pub struct CoverCache {
    textures: HashMap<String, CachedTexture>,
    pending: HashSet<String>,
    failed: HashMap<String, Instant>,
}

impl CoverCache {
    /// Inserts pixels returned by the background decoder.
    pub fn insert(&mut self, context: &egui::Context, url: String, image: DecodedImage) {
        self.insert_pixels(context, url, image.size, &image.rgba);
    }

    /// Inserts artwork decoded by the independent SoundCloud worker.
    pub fn insert_soundcloud(
        &mut self,
        context: &egui::Context,
        url: String,
        image: DecodedArtwork,
    ) {
        self.insert_pixels(context, url, image.size, &image.rgba);
    }

    fn insert_pixels(
        &mut self,
        context: &egui::Context,
        url: String,
        size: [usize; 2],
        rgba: &[u8],
    ) {
        self.pending.remove(&url);
        self.failed.remove(&url);
        let color_image = egui::ColorImage::from_rgba_unmultiplied(size, rgba);
        let texture = context.load_texture(&url, color_image, egui::TextureOptions::LINEAR);
        self.textures.insert(
            url,
            CachedTexture {
                texture,
                last_used_frame: context.cumulative_frame_nr(),
            },
        );
        self.evict_oldest();
    }

    /// Records a failed request to avoid retrying every frame.
    pub fn fail(&mut self, url: String) {
        self.pending.remove(&url);
        self.record_failure(url);
    }

    /// Draws a cover or a stable placeholder and schedules missing work.
    pub fn show(
        &mut self,
        ui: &mut Ui,
        url: Option<&str>,
        runtime: &SpotifyRuntime,
        size: Vec2,
    ) -> Response {
        if let Some(url) = url {
            if let Some(cached) = self.textures.get_mut(url) {
                cached.last_used_frame = ui.ctx().cumulative_frame_nr();
                let image = egui::Image::new((cached.texture.id(), size))
                    .corner_radius((size.x * 0.10).min(10.0));
                return if size.x >= 80.0 {
                    egui::Frame::new()
                        .corner_radius((size.x * 0.10).min(10.0))
                        .shadow(theme::card_shadow())
                        .show(ui, |ui| ui.add(image))
                        .inner
                } else {
                    ui.add(image)
                };
            }
            let recently_failed = self
                .failed
                .get(url)
                .is_some_and(|failed_at| failed_at.elapsed() < FAILED_RETRY_AFTER);
            if !recently_failed {
                self.failed.remove(url);
            }
            if !self.pending.contains(url) && !recently_failed {
                match runtime.send(SpotifyCommand::LoadImage {
                    url: url.to_owned(),
                }) {
                    Ok(()) => {
                        self.pending.insert(url.to_owned());
                    }
                    Err(_) => {
                        self.record_failure(url.to_owned());
                    }
                }
            }
        }
        let (rect, response) = ui.allocate_exact_size(size, egui::Sense::hover());
        ui.painter()
            .rect_filled(rect, (size.x * 0.10).min(10.0), colors::surface_raised());
        let icon = Color32::from_gray(130);
        let center = rect.center();
        let stem_top = center.y - size.y * 0.20;
        let stem_bottom = center.y + size.y * 0.13;
        ui.painter().line_segment(
            [
                egui::Pos2::new(center.x + size.x * 0.09, stem_top),
                egui::Pos2::new(center.x + size.x * 0.09, stem_bottom),
            ],
            egui::Stroke::new(2.0, icon),
        );
        ui.painter().circle_filled(
            egui::Pos2::new(center.x, stem_bottom + size.y * 0.04),
            size.x * 0.075,
            icon,
        );
        response
    }

    /// Draws cached SoundCloud artwork and schedules a provider-local download.
    pub fn show_soundcloud(
        &mut self,
        ui: &mut Ui,
        url: Option<&str>,
        runtime: &SoundCloudRuntime,
        size: Vec2,
    ) -> Response {
        if let Some(url) = url {
            if let Some(cached) = self.textures.get_mut(url) {
                cached.last_used_frame = ui.ctx().cumulative_frame_nr();
                let image = egui::Image::new((cached.texture.id(), size))
                    .corner_radius((size.x * 0.10).min(10.0));
                return if size.x >= 80.0 {
                    egui::Frame::new()
                        .corner_radius((size.x * 0.10).min(10.0))
                        .shadow(theme::card_shadow())
                        .show(ui, |ui| ui.add(image))
                        .inner
                } else {
                    ui.add(image)
                };
            }
            let recently_failed = self
                .failed
                .get(url)
                .is_some_and(|failed_at| failed_at.elapsed() < FAILED_RETRY_AFTER);
            if !recently_failed {
                self.failed.remove(url);
            }
            if !self.pending.contains(url) && !recently_failed {
                match runtime.send(SoundCloudCommand::LoadArtwork {
                    url: url.to_owned(),
                }) {
                    Ok(()) => {
                        self.pending.insert(url.to_owned());
                    }
                    Err(_) => {
                        self.record_failure(url.to_owned());
                    }
                }
            }
        }
        self.placeholder(ui, size)
    }

    fn placeholder(&self, ui: &mut Ui, size: Vec2) -> Response {
        let (rect, response) = ui.allocate_exact_size(size, egui::Sense::hover());
        ui.painter()
            .rect_filled(rect, (size.x * 0.10).min(10.0), colors::surface_raised());
        let icon = Color32::from_gray(130);
        let center = rect.center();
        let stem_top = center.y - size.y * 0.20;
        let stem_bottom = center.y + size.y * 0.13;
        ui.painter().line_segment(
            [
                egui::Pos2::new(center.x + size.x * 0.09, stem_top),
                egui::Pos2::new(center.x + size.x * 0.09, stem_bottom),
            ],
            egui::Stroke::new(2.0, icon),
        );
        ui.painter().circle_filled(
            egui::Pos2::new(center.x, stem_bottom + size.y * 0.04),
            size.x * 0.075,
            icon,
        );
        response
    }

    fn evict_oldest(&mut self) {
        while self.textures.len() > MAX_TEXTURES {
            let oldest = self
                .textures
                .iter()
                .min_by_key(|(_, entry)| entry.last_used_frame)
                .map(|(url, _)| url.clone());
            let Some(url) = oldest else {
                break;
            };
            self.textures.remove(&url);
        }
    }

    fn record_failure(&mut self, url: String) {
        self.failed.insert(url, Instant::now());
        while self.failed.len() > MAX_FAILURES {
            let oldest = self
                .failed
                .iter()
                .min_by_key(|(_, failed_at)| **failed_at)
                .map(|(url, _)| url.clone());
            let Some(url) = oldest else { break };
            self.failed.remove(&url);
        }
    }
}
