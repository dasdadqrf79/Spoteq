#![cfg_attr(target_os = "windows", windows_subsystem = "windows")]

use eframe::egui::{Vec2, ViewportBuilder};
use spoteq::{
    app::{SpoteqApp, StartupFailureApp},
    soundcloud::{handle_protocol_invocation, register_protocol_handler},
    ui::branding,
};
use tracing_subscriber::EnvFilter;

fn main() -> eframe::Result {
    tracing_subscriber::fmt()
        .with_env_filter(
            EnvFilter::try_from_default_env().unwrap_or_else(|_| EnvFilter::new("info")),
        )
        .with_target(false)
        .compact()
        .init();

    tracing::info!("[STARTUP] Spoteq process started");

    if handle_protocol_invocation() {
        return Ok(());
    }
    if let Err(error) = register_protocol_handler() {
        tracing::warn!(%error, "Spoteq URL protocol registration is unavailable");
    }

    let mut viewport = ViewportBuilder::default()
        .with_title("Spoteq")
        .with_decorations(false)
        .with_inner_size(Vec2::new(1440.0, 900.0))
        .with_min_inner_size(Vec2::new(900.0, 650.0));
    if let Some(icon) = branding::app_icon() {
        viewport = viewport.with_icon(icon);
    }

    let options = eframe::NativeOptions {
        renderer: eframe::Renderer::Glow,
        viewport,
        ..Default::default()
    };

    eframe::run_native(
        "Spoteq",
        options,
        Box::new(|creation_context| {
            let app: Box<dyn eframe::App> = match SpoteqApp::new(creation_context) {
                Ok(app) => Box::new(app),
                Err(error) => Box::new(StartupFailureApp::new(
                    &creation_context.egui_ctx,
                    error.to_string(),
                )),
            };
            Ok(app)
        }),
    )
}
