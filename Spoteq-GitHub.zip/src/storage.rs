//! Resolves Spoteq storage folders and migrates the former application folder.

use std::{fs, path::PathBuf};

use directories::ProjectDirs;

/// Platform-specific folder used by an application subsystem.
#[derive(Clone, Copy)]
pub(crate) enum DirectoryKind {
    Config,
    DataLocal,
    Cache,
}

/// Returns the current Spoteq folder, preserving existing user data after the rename.
pub(crate) fn app_directory(kind: DirectoryKind) -> Option<PathBuf> {
    let current = ProjectDirs::from("dev", "Spoteq", "Spoteq")?;
    let target = directory(&current, kind).to_path_buf();

    if !target.exists() && kind_is_persistent(kind) {
        if let Some(legacy) = ProjectDirs::from("dev", "SpotifyEQ", "SpotifyEQ") {
            let source = directory(&legacy, kind);
            if source.exists() {
                migrate_directory(source, &target);
            }
        }
    }

    Some(target)
}

fn directory(dirs: &ProjectDirs, kind: DirectoryKind) -> &std::path::Path {
    match kind {
        DirectoryKind::Config => dirs.config_dir(),
        DirectoryKind::DataLocal => dirs.data_local_dir(),
        DirectoryKind::Cache => dirs.cache_dir(),
    }
}

fn kind_is_persistent(kind: DirectoryKind) -> bool {
    matches!(kind, DirectoryKind::Config | DirectoryKind::DataLocal)
}

fn migrate_directory(source: &std::path::Path, target: &std::path::Path) {
    if let Some(parent) = target.parent() {
        let _ = fs::create_dir_all(parent);
    }
    if fs::rename(source, target).is_ok() {
        return;
    }
    let _ = copy_directory(source, target);
}

fn copy_directory(source: &std::path::Path, target: &std::path::Path) -> std::io::Result<()> {
    fs::create_dir_all(target)?;
    for entry in fs::read_dir(source)? {
        let entry = entry?;
        let source_path = entry.path();
        let target_path = target.join(entry.file_name());
        if entry.file_type()?.is_dir() {
            copy_directory(&source_path, &target_path)?;
        } else if !target_path.exists() {
            fs::copy(source_path, target_path)?;
        }
    }
    Ok(())
}
