//! Unified session queue and non-blocking similar-track autoplay coordinator.

use std::{
    collections::{HashMap, HashSet, VecDeque},
    time::{Duration, Instant},
};

use crate::{
    catalog::{TrackProvider, TrackRow},
    settings::{RepeatMode, ResumeSession},
    soundcloud::{SoundCloudCommand, SoundCloudRuntime, SoundCloudViewState},
    spotify::{SpotifyCommand, SpotifyRuntime},
    state::SpotifyViewState,
};

const AUTOPLAY_TARGET: usize = 8;
const AUTOPLAY_REFILL_AT: usize = 3;
const HISTORY_LIMIT: usize = 24;

/// Explicit seed used to start a provider-neutral Radio queue.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RadioKind {
    /// Recommendations centered on one exact track.
    Track,
    /// Recommendations centered on the selected track's artist context.
    Artist,
}

/// Identifies why a track entered the unified session queue.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum QueueOrigin {
    /// Item selected from the Search or Liked Songs result queue.
    Normal,
    /// Explicit high-priority Play Next item.
    PlayNext,
    /// Explicitly queued user item.
    Manual,
    /// Similar track returned by a provider recommendation endpoint.
    Autoplay,
}

impl QueueOrigin {
    /// Human-readable source displayed in the queue panel.
    pub const fn label(self) -> &'static str {
        match self {
            Self::Normal => "Queue",
            Self::PlayNext => "Play next",
            Self::Manual => "Added manually",
            Self::Autoplay => "Autoplay",
        }
    }
}

/// Address of a future queue item. The provider-qualified track key keeps UI
/// actions stable while unrelated provider events are processed.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct QueueEntryId {
    lane: QueueLane,
    key: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
enum QueueLane {
    PlayNext,
    Manual,
    Normal,
    Autoplay,
}

/// Read-only row consumed by the queue overlay.
#[derive(Debug, Clone)]
pub struct QueueSnapshotItem {
    /// Stable address used by play/remove/reorder actions.
    pub id: QueueEntryId,
    /// Unified Spotify/SoundCloud track metadata.
    pub track: TrackRow,
    /// How this item entered the queue.
    pub origin: QueueOrigin,
}

/// Provider-neutral queue presentation model.
#[derive(Debug, Clone, Default)]
pub struct QueueSnapshot {
    /// Active item, if playback has started.
    pub current: Option<QueueSnapshotItem>,
    /// All future user-controlled items in playback priority order.
    pub next_up: Vec<QueueSnapshotItem>,
    /// Similar-track recommendations kept separate from the user queue.
    pub autoplay: Vec<QueueSnapshotItem>,
}

#[derive(Debug, Clone)]
struct QueueItem {
    track: TrackRow,
    origin: QueueOrigin,
}

#[derive(Debug, Clone)]
struct HistoryItem {
    track: TrackRow,
}

/// Provider-neutral queue state layered above the two native playback actors.
#[derive(Debug, Default)]
pub struct AutoplayQueue {
    normal: Vec<TrackRow>,
    original_normal: Vec<TrackRow>,
    normal_index: Option<usize>,
    play_next: VecDeque<TrackRow>,
    manual: VecDeque<TrackRow>,
    recommended: VecDeque<TrackRow>,
    current: Option<QueueItem>,
    history: VecDeque<HistoryItem>,
    repeat_cycle: Vec<TrackRow>,
    shuffle_enabled: bool,
    artist_skips: HashMap<String, u8>,
    request_generation: u64,
    pending_providers: usize,
    preferred_provider: Option<TrackProvider>,
    spotify_candidates: Vec<TrackRow>,
    soundcloud_candidates: Vec<TrackRow>,
    recommendation_context: Vec<TrackRow>,
    waiting_for_autoplay: bool,
    last_request_at: Option<Instant>,
    radio_title: Option<String>,
    radio_seed_artist: Option<String>,
}

impl AutoplayQueue {
    /// Restores persisted queue metadata and starts only after an explicit user action.
    #[allow(clippy::too_many_arguments)]
    pub fn resume_session(
        &mut self,
        session: &ResumeSession,
        spotify: &mut SpotifyViewState,
        soundcloud: &mut SoundCloudViewState,
        spotify_runtime: &SpotifyRuntime,
        soundcloud_runtime: &SoundCloudRuntime,
    ) -> Option<String> {
        let current = session.current.as_ref()?.clone();
        if !current.playable {
            spotify.toast_error("The saved track is no longer playable");
            return None;
        }

        self.normal.clear();
        self.normal.push(current.clone());
        self.normal.extend(
            session
                .next_up
                .iter()
                .filter(|track| track.playable && track.stable_key() != current.stable_key())
                .cloned(),
        );
        self.original_normal = self.normal.clone();
        self.normal_index = Some(0);
        self.repeat_cycle = self.normal.clone();
        self.play_next.clear();
        self.manual.clear();
        self.recommended = session
            .autoplay
            .iter()
            .filter(|track| track.playable)
            .cloned()
            .collect();
        self.spotify_candidates.clear();
        self.soundcloud_candidates.clear();
        self.recommendation_context.clear();
        self.pending_providers = 0;
        self.waiting_for_autoplay = false;
        self.last_request_at = None;
        self.radio_title = session.radio_title.clone();
        self.radio_seed_artist = None;
        self.launch(
            QueueItem {
                track: current.clone(),
                origin: QueueOrigin::Normal,
            },
            spotify,
            soundcloud,
            spotify_runtime,
            soundcloud_runtime,
        );
        Some(current.stable_key())
    }

    /// Starts a fresh Radio queue around one real provider track or artist.
    #[allow(clippy::too_many_arguments)]
    pub fn start_radio(
        &mut self,
        seed: TrackRow,
        kind: RadioKind,
        spotify: &mut SpotifyViewState,
        soundcloud: &mut SoundCloudViewState,
        spotify_runtime: &SpotifyRuntime,
        soundcloud_runtime: &SoundCloudRuntime,
    ) {
        let key = seed.stable_key();
        self.start(
            std::slice::from_ref(&seed),
            &key,
            spotify,
            soundcloud,
            spotify_runtime,
            soundcloud_runtime,
        );
        self.radio_title = Some(match kind {
            RadioKind::Track => format!("{} Radio", seed.title),
            RadioKind::Artist => format!("{} Radio", seed.artist),
        });
        self.radio_seed_artist = (kind == RadioKind::Artist).then(|| normalize(&seed.artist));
        self.last_request_at = None;
        tracing::info!(kind = ?kind, seed = %seed.title, "Radio started");
    }

    /// Current explicit Radio title, when Radio owns the Autoplay lane.
    pub fn radio_title(&self) -> Option<&str> {
        self.radio_title.as_deref()
    }

    /// Whether the current queue was explicitly created with Start Radio.
    pub fn is_radio(&self) -> bool {
        self.radio_title.is_some()
    }

    /// Starts a provider-neutral queue at the selected row.
    #[allow(clippy::too_many_arguments)]
    pub fn start(
        &mut self,
        rows: &[TrackRow],
        key: &str,
        spotify: &mut SpotifyViewState,
        soundcloud: &mut SoundCloudViewState,
        spotify_runtime: &SpotifyRuntime,
        soundcloud_runtime: &SoundCloudRuntime,
    ) {
        let playable = rows
            .iter()
            .filter(|track| track.playable)
            .cloned()
            .collect::<Vec<_>>();
        let Some(index) = playable.iter().position(|track| track.stable_key() == key) else {
            spotify.toast_error("This track is currently unavailable from its provider");
            return;
        };

        self.normal = playable;
        self.normal_index = Some(index);
        self.original_normal = self.normal.clone();
        self.repeat_cycle = self.normal[index..].to_vec();
        if self.shuffle_enabled {
            self.shuffle_future();
        }
        self.play_next.clear();
        self.manual.clear();
        self.recommended.clear();
        self.spotify_candidates.clear();
        self.soundcloud_candidates.clear();
        self.recommendation_context.clear();
        self.pending_providers = 0;
        self.last_request_at = None;
        self.radio_title = None;
        self.radio_seed_artist = None;
        self.waiting_for_autoplay = false;
        let item = QueueItem {
            track: self.normal[index].clone(),
            origin: QueueOrigin::Normal,
        };
        self.launch(
            item,
            spotify,
            soundcloud,
            spotify_runtime,
            soundcloud_runtime,
        );
    }

    /// Returns the next provider-neutral track without consuming queue state.
    pub fn next_candidate(&self, autoplay_enabled: bool, repeat: RepeatMode) -> Option<TrackRow> {
        if repeat == RepeatMode::Track {
            return self.current.as_ref().map(|item| item.track.clone());
        }
        if let Some(track) = self.play_next.front() {
            return Some(track.clone());
        }
        if let Some(track) = self.manual.front() {
            return Some(track.clone());
        }
        if let Some(next_index) = self
            .normal_index
            .map(|index| index.saturating_add(1))
            .filter(|index| *index < self.normal.len())
        {
            return self.normal.get(next_index).cloned();
        }
        if autoplay_enabled && repeat == RepeatMode::Off {
            if let Some(track) = self.recommended.front() {
                return Some(track.clone());
            }
        }
        if repeat == RepeatMode::Queue {
            return self.repeat_cycle.first().cloned();
        }
        None
    }

    /// Starts a different-provider next item without stopping the current backend.
    /// The application coordinator then applies equal-power gains and stops the old backend.
    #[allow(clippy::too_many_arguments)]
    pub fn start_crossfade_next(
        &mut self,
        position_ms: u32,
        natural_end: bool,
        autoplay_enabled: bool,
        repeat: RepeatMode,
        spotify: &mut SpotifyViewState,
        soundcloud: &mut SoundCloudViewState,
        spotify_runtime: &SpotifyRuntime,
        soundcloud_runtime: &SoundCloudRuntime,
    ) -> Option<(TrackProvider, TrackProvider, String)> {
        if repeat == RepeatMode::Track {
            return None;
        }
        let from = self.current.as_ref()?.track.provider;
        let autoplay_enabled = autoplay_enabled || self.is_radio();
        let item = self.take_next_with_repeat(autoplay_enabled, repeat)?;
        let to = item.track.provider;
        if from == to {
            // This path is intentionally reserved for provider overlap. Same-provider
            // transitions use the preloaded/gapless natural-end path instead.
            return None;
        }
        let target_key = item.track.stable_key();

        match to {
            TrackProvider::Spotify => {
                let Some(track) = item.track.to_spotify_track() else {
                    spotify.toast_error("Spotify track identity is incomplete");
                    return None;
                };
                spotify.set_volume(spotify_runtime, 0.0);
                spotify.play_queue(spotify_runtime, vec![track], 0);
            }
            TrackProvider::SoundCloud => {
                soundcloud.set_volume(soundcloud_runtime, 0.0);
                soundcloud.play_queue(soundcloud_runtime, vec![item.track.clone()], 0);
            }
        }

        self.finish_current(position_ms, natural_end);
        self.preferred_provider = Some(to);
        self.current = Some(item);
        self.waiting_for_autoplay = false;
        tracing::info!(?from, ?to, "Cross-provider transition started");
        Some((from, to, target_key))
    }

    /// True when the shared queue can move beyond the active item.
    pub fn has_next(&self, autoplay_enabled: bool) -> bool {
        let autoplay_enabled = autoplay_enabled || self.is_radio();
        !self.play_next.is_empty()
            || !self.manual.is_empty()
            || self
                .normal_index
                .is_some_and(|index| index.saturating_add(1) < self.normal.len())
            || !self.recommended.is_empty()
            || self.pending_providers > 0
            || (autoplay_enabled && self.current.is_some())
    }

    /// Stable key of the provider-neutral item currently owned by the shared queue.
    pub fn current_key(&self) -> Option<String> {
        self.current.as_ref().map(|item| item.track.stable_key())
    }

    /// Retries the active queue item once after a transient provider playback failure.
    #[allow(clippy::too_many_arguments)]
    pub fn retry_current(
        &mut self,
        spotify: &mut SpotifyViewState,
        soundcloud: &mut SoundCloudViewState,
        spotify_runtime: &SpotifyRuntime,
        soundcloud_runtime: &SoundCloudRuntime,
    ) -> bool {
        let Some(item) = self.current.clone() else {
            return false;
        };
        tracing::warn!(track = %item.track.title, provider = ?item.track.provider, "Retrying failed queue item");
        self.launch(
            item,
            spotify,
            soundcloud,
            spotify_runtime,
            soundcloud_runtime,
        );
        true
    }

    /// Retries the active cross-provider target without stopping the old provider.
    /// Used only while the application crossfade coordinator still owns both backends.
    pub fn retry_current_overlap(
        &mut self,
        spotify: &mut SpotifyViewState,
        soundcloud: &mut SoundCloudViewState,
        spotify_runtime: &SpotifyRuntime,
        soundcloud_runtime: &SoundCloudRuntime,
    ) -> bool {
        let Some(item) = self.current.clone() else {
            return false;
        };
        match item.track.provider {
            TrackProvider::Spotify => {
                let Some(track) = item.track.to_spotify_track() else {
                    return false;
                };
                spotify.set_volume(spotify_runtime, 0.0);
                spotify.play_queue(spotify_runtime, vec![track], 0);
            }
            TrackProvider::SoundCloud => {
                soundcloud.set_volume(soundcloud_runtime, 0.0);
                soundcloud.play_queue(soundcloud_runtime, vec![item.track.clone()], 0);
            }
        }
        tracing::warn!(track = %item.track.title, provider = ?item.track.provider, "Retrying cross-provider target without stopping source");
        true
    }

    /// Whether the player bar's active item came from Autoplay.
    pub fn current_is_recommended(&self) -> bool {
        self.current
            .as_ref()
            .is_some_and(|item| item.origin == QueueOrigin::Autoplay)
    }

    /// Number of already buffered Autoplay items.
    pub fn recommendation_count(&self) -> usize {
        self.recommended.len()
    }

    /// Adds an explicit item ahead of every other future queue source.
    pub fn enqueue_play_next(&mut self, track: TrackRow) -> bool {
        if !track.playable || self.contains_future(&track) {
            return false;
        }
        self.repeat_cycle.push(track.clone());
        self.play_next.push_back(track);
        tracing::info!("Queue item added as Play Next");
        true
    }

    /// Adds an explicit user item after Play Next but before the original queue.
    pub fn enqueue_manual(&mut self, track: TrackRow) -> bool {
        if !track.playable || self.contains_future(&track) {
            return false;
        }
        self.repeat_cycle.push(track.clone());
        self.manual.push_back(track);
        tracing::info!("Queue item added manually");
        true
    }

    /// Applies or removes Shuffle without moving the active track.
    pub fn set_shuffle(&mut self, enabled: bool) {
        if self.shuffle_enabled == enabled {
            return;
        }
        self.shuffle_enabled = enabled;
        if enabled {
            self.shuffle_future();
        } else {
            self.restore_future_order();
        }
        tracing::info!(enabled, "Queue shuffle changed");
    }

    /// Returns a stable presentation snapshot without exposing playback actors.
    pub fn snapshot(&self) -> QueueSnapshot {
        let current = self.current.as_ref().map(|item| QueueSnapshotItem {
            id: QueueEntryId {
                lane: lane_for_origin(item.origin),
                key: item.track.stable_key(),
            },
            track: item.track.clone(),
            origin: item.origin,
        });
        let mut next_up = Vec::new();
        extend_snapshot(
            &mut next_up,
            &self.play_next,
            QueueLane::PlayNext,
            QueueOrigin::PlayNext,
        );
        extend_snapshot(
            &mut next_up,
            &self.manual,
            QueueLane::Manual,
            QueueOrigin::Manual,
        );
        let normal_start = self.normal_index.map_or(0, |index| index.saturating_add(1));
        for track in self.normal.iter().skip(normal_start) {
            next_up.push(snapshot_item(track, QueueLane::Normal, QueueOrigin::Normal));
        }
        let autoplay = self
            .recommended
            .iter()
            .map(|track| snapshot_item(track, QueueLane::Autoplay, QueueOrigin::Autoplay))
            .collect();
        QueueSnapshot {
            current,
            next_up,
            autoplay,
        }
    }

    /// Removes a future item. The active item cannot be removed here.
    pub fn remove(&mut self, id: &QueueEntryId) -> bool {
        let removed = match id.lane {
            QueueLane::PlayNext => remove_key(&mut self.play_next, &id.key),
            QueueLane::Manual => remove_key(&mut self.manual, &id.key),
            QueueLane::Autoplay => remove_key(&mut self.recommended, &id.key),
            QueueLane::Normal => {
                let start = self.normal_index.map_or(0, |index| index.saturating_add(1));
                let remove_index = self
                    .normal
                    .iter()
                    .enumerate()
                    .skip(start)
                    .find(|(_, track)| track.stable_key() == id.key)
                    .map(|(index, _)| index);
                if let Some(index) = remove_index {
                    self.normal.remove(index);
                    true
                } else {
                    false
                }
            }
        };
        if removed {
            self.repeat_cycle
                .retain(|track| track.stable_key() != id.key);
            tracing::info!("Queue item removed");
        }
        removed
    }

    /// Clears all future items while leaving the active track untouched.
    pub fn clear_future(&mut self) {
        self.play_next.clear();
        self.manual.clear();
        self.recommended.clear();
        if let Some(index) = self.normal_index {
            self.normal.truncate(index.saturating_add(1));
        } else {
            self.normal.clear();
        }
        self.waiting_for_autoplay = false;
        self.radio_title = None;
        self.radio_seed_artist = None;
        self.repeat_cycle = self
            .current
            .as_ref()
            .map(|item| vec![item.track.clone()])
            .unwrap_or_default();
        tracing::info!("Future queue cleared");
    }

    /// Reorders two items inside the same priority lane.
    pub fn reorder(&mut self, source: &QueueEntryId, target: &QueueEntryId) -> bool {
        if source.lane != target.lane || source == target {
            return false;
        }
        let changed = match source.lane {
            QueueLane::PlayNext => reorder_deque(&mut self.play_next, &source.key, &target.key),
            QueueLane::Manual => reorder_deque(&mut self.manual, &source.key, &target.key),
            QueueLane::Autoplay => reorder_deque(&mut self.recommended, &source.key, &target.key),
            QueueLane::Normal => {
                let start = self.normal_index.map_or(0, |index| index.saturating_add(1));
                reorder_slice(&mut self.normal, start, &source.key, &target.key)
            }
        };
        if changed {
            tracing::info!("Queue items reordered");
        }
        changed
    }

    /// Promotes an existing future item to the front of the Play Next lane.
    pub fn promote_play_next(&mut self, id: &QueueEntryId) -> bool {
        let Some(track) = self.take_entry(id) else {
            return false;
        };
        self.play_next.push_front(track);
        true
    }

    /// Moves an existing future item to the end of the manual lane.
    pub fn move_to_manual(&mut self, id: &QueueEntryId) -> bool {
        let Some(track) = self.take_entry(id) else {
            return false;
        };
        self.manual.push_back(track);
        true
    }

    /// Advances according to Play Next, manual, normal, then Autoplay priority.
    #[allow(clippy::too_many_arguments)]
    pub fn next(
        &mut self,
        position_ms: u32,
        autoplay_enabled: bool,
        repeat: RepeatMode,
        spotify: &mut SpotifyViewState,
        soundcloud: &mut SoundCloudViewState,
        spotify_runtime: &SpotifyRuntime,
        soundcloud_runtime: &SoundCloudRuntime,
    ) {
        let autoplay_enabled = autoplay_enabled || self.is_radio();
        self.finish_current(position_ms, false);
        if let Some(item) = self.take_next_with_repeat(autoplay_enabled, repeat) {
            self.launch(
                item,
                spotify,
                soundcloud,
                spotify_runtime,
                soundcloud_runtime,
            );
        } else if autoplay_enabled {
            self.waiting_for_autoplay = true;
        } else {
            self.stop_all(spotify, soundcloud, spotify_runtime, soundcloud_runtime);
        }
    }

    /// Handles a natural end without treating it as negative skip feedback.
    #[allow(clippy::too_many_arguments)]
    pub fn track_finished(
        &mut self,
        autoplay_enabled: bool,
        repeat: RepeatMode,
        spotify: &mut SpotifyViewState,
        soundcloud: &mut SoundCloudViewState,
        spotify_runtime: &SpotifyRuntime,
        soundcloud_runtime: &SoundCloudRuntime,
    ) {
        let autoplay_enabled = autoplay_enabled || self.is_radio();
        if repeat == RepeatMode::Track {
            if let Some(current) = self.current.clone() {
                self.launch(
                    current,
                    spotify,
                    soundcloud,
                    spotify_runtime,
                    soundcloud_runtime,
                );
            }
            return;
        }
        let position = self
            .current
            .as_ref()
            .map(|item| item.track.duration_ms.min(u64::from(u32::MAX)) as u32)
            .unwrap_or(0);
        self.finish_current(position, true);
        if let Some(item) = self.take_next_with_repeat(autoplay_enabled, repeat) {
            self.launch(
                item,
                spotify,
                soundcloud,
                spotify_runtime,
                soundcloud_runtime,
            );
        } else if autoplay_enabled {
            self.waiting_for_autoplay = true;
        }
    }

    /// Seeks to zero after five seconds, otherwise returns through shared history.
    #[allow(clippy::too_many_arguments)]
    pub fn previous(
        &mut self,
        position_ms: u32,
        spotify: &mut SpotifyViewState,
        soundcloud: &mut SoundCloudViewState,
        spotify_runtime: &SpotifyRuntime,
        soundcloud_runtime: &SoundCloudRuntime,
    ) {
        if position_ms > 5_000 {
            match self.current.as_ref().map(|item| item.track.provider) {
                Some(TrackProvider::Spotify) => spotify.seek(spotify_runtime, 0),
                Some(TrackProvider::SoundCloud) => soundcloud.seek(soundcloud_runtime, 0),
                None => {}
            }
            return;
        }
        if let Some(previous) = self.take_previous_history() {
            self.launch(
                previous,
                spotify,
                soundcloud,
                spotify_runtime,
                soundcloud_runtime,
            );
        } else {
            match self.current.as_ref().map(|item| item.track.provider) {
                Some(TrackProvider::Spotify) => spotify.seek(spotify_runtime, 0),
                Some(TrackProvider::SoundCloud) => soundcloud.seek(soundcloud_runtime, 0),
                None => {}
            }
        }
    }

    /// Immediately plays one future item and preserves the rest of the queue.
    #[allow(clippy::too_many_arguments)]
    pub fn play_now(
        &mut self,
        id: &QueueEntryId,
        position_ms: u32,
        spotify: &mut SpotifyViewState,
        soundcloud: &mut SoundCloudViewState,
        spotify_runtime: &SpotifyRuntime,
        soundcloud_runtime: &SoundCloudRuntime,
    ) -> bool {
        let Some(track) = self.take_entry(id) else {
            return false;
        };
        self.finish_current(position_ms, false);
        self.launch(
            QueueItem {
                track,
                origin: origin_for_lane(id.lane),
            },
            spotify,
            soundcloud,
            spotify_runtime,
            soundcloud_runtime,
        );
        true
    }

    /// Starts background refilling when the end of the user queue is near.
    pub fn prefetch_if_needed(
        &mut self,
        enabled: bool,
        spotify_authenticated: bool,
        soundcloud_authenticated: bool,
        spotify_runtime: &SpotifyRuntime,
        soundcloud_runtime: &SoundCloudRuntime,
    ) {
        let enabled = enabled || self.is_radio();
        if !enabled
            || (self.current.is_none() && self.history.is_empty())
            || self.pending_providers > 0
        {
            return;
        }
        if self
            .last_request_at
            .is_some_and(|instant| instant.elapsed() < Duration::from_secs(10))
        {
            return;
        }
        let normal_remaining = self
            .normal_index
            .map(|index| self.normal.len().saturating_sub(index.saturating_add(1)))
            .unwrap_or(0);
        if normal_remaining > AUTOPLAY_REFILL_AT || self.recommended.len() > AUTOPLAY_REFILL_AT {
            return;
        }

        let mut seeds = Vec::new();
        if let Some(current) = &self.current {
            seeds.push(current.track.clone());
        }
        for item in self.history.iter().rev() {
            if seeds.len() >= 5 {
                break;
            }
            if !seeds
                .iter()
                .any(|seed: &TrackRow| seed.stable_key() == item.track.stable_key())
            {
                seeds.push(item.track.clone());
            }
        }
        if seeds.is_empty() {
            return;
        }

        self.request_generation = self.request_generation.wrapping_add(1);
        self.last_request_at = Some(Instant::now());
        self.preferred_provider = self
            .current
            .as_ref()
            .map(|item| item.track.provider)
            .or_else(|| self.history.back().map(|item| item.track.provider));
        self.spotify_candidates.clear();
        self.soundcloud_candidates.clear();
        self.recommendation_context = seeds.clone();
        self.pending_providers = 0;
        let wanted = AUTOPLAY_TARGET
            .saturating_sub(self.recommended.len())
            .max(5);

        if spotify_authenticated {
            let command = SpotifyCommand::Recommend {
                seeds: seeds.clone(),
                generation: self.request_generation,
                limit: wanted,
            };
            if spotify_runtime.send(command).is_ok() {
                self.pending_providers += 1;
            }
        }
        if soundcloud_authenticated {
            let command = SoundCloudCommand::Recommend {
                seeds,
                generation: self.request_generation,
                limit: wanted,
            };
            if soundcloud_runtime.send(command).is_ok() {
                self.pending_providers += 1;
            }
        }
        if self.pending_providers > 0 {
            tracing::info!(
                generation = self.request_generation,
                providers = self.pending_providers,
                "Autoplay recommendation request dispatched"
            );
        }
    }

    /// Accepts a provider batch and finalizes it after both providers respond.
    pub fn accept_recommendations(
        &mut self,
        provider: TrackProvider,
        generation: u64,
        result: Result<Vec<TrackRow>, String>,
    ) {
        if generation != self.request_generation || self.pending_providers == 0 {
            return;
        }
        self.pending_providers = self.pending_providers.saturating_sub(1);
        match result {
            Ok(rows) => match provider {
                TrackProvider::Spotify => self.spotify_candidates = rows,
                TrackProvider::SoundCloud => self.soundcloud_candidates = rows,
            },
            Err(error) => tracing::warn!(?provider, %error, "Autoplay provider failed"),
        }
        if self.pending_providers == 0 {
            self.finalize_candidates();
        }
    }

    /// Starts a batch that arrived while the last user track was ending.
    #[allow(clippy::too_many_arguments)]
    pub fn resume_if_ready(
        &mut self,
        spotify: &mut SpotifyViewState,
        soundcloud: &mut SoundCloudViewState,
        spotify_runtime: &SpotifyRuntime,
        soundcloud_runtime: &SoundCloudRuntime,
    ) {
        if !self.waiting_for_autoplay {
            return;
        }
        if let Some(track) = self.recommended.pop_front() {
            self.waiting_for_autoplay = false;
            self.launch(
                QueueItem {
                    track,
                    origin: QueueOrigin::Autoplay,
                },
                spotify,
                soundcloud,
                spotify_runtime,
                soundcloud_runtime,
            );
        }
    }

    fn take_next(&mut self, autoplay_enabled: bool) -> Option<QueueItem> {
        if let Some(track) = self.play_next.pop_front() {
            return Some(QueueItem {
                track,
                origin: QueueOrigin::PlayNext,
            });
        }
        if let Some(track) = self.manual.pop_front() {
            return Some(QueueItem {
                track,
                origin: QueueOrigin::Manual,
            });
        }
        if let Some(next_index) = self
            .normal_index
            .map(|index| index.saturating_add(1))
            .filter(|index| *index < self.normal.len())
        {
            self.normal_index = Some(next_index);
            return Some(QueueItem {
                track: self.normal[next_index].clone(),
                origin: QueueOrigin::Normal,
            });
        }
        if autoplay_enabled {
            self.recommended.pop_front().map(|track| QueueItem {
                track,
                origin: QueueOrigin::Autoplay,
            })
        } else {
            None
        }
    }

    fn take_next_with_repeat(
        &mut self,
        autoplay_enabled: bool,
        repeat: RepeatMode,
    ) -> Option<QueueItem> {
        if let Some(item) = self.take_next(autoplay_enabled && repeat == RepeatMode::Off) {
            return Some(item);
        }
        if repeat != RepeatMode::Queue || self.repeat_cycle.is_empty() {
            return None;
        }
        self.normal = self.repeat_cycle.clone();
        self.original_normal = self.normal.clone();
        self.normal_index = None;
        if self.shuffle_enabled {
            shuffle_tracks(&mut self.normal, 0);
        }
        // A restarted repeat cycle has no active index yet. `take_next`
        // deliberately advances only from an existing index, so select the
        // first item explicitly instead of falling through to Autoplay.
        let track = self.normal.first()?.clone();
        self.normal_index = Some(0);
        Some(QueueItem {
            track,
            origin: QueueOrigin::Normal,
        })
    }

    fn contains_future(&self, candidate: &TrackRow) -> bool {
        let id = candidate.stable_key();
        let metadata = metadata_key(candidate);
        self.current
            .iter()
            .map(|item| &item.track)
            .chain(self.play_next.iter())
            .chain(self.manual.iter())
            .chain(self.recommended.iter())
            .chain(
                self.normal
                    .iter()
                    .skip(self.normal_index.map_or(0, |i| i + 1)),
            )
            .any(|track| track.stable_key() == id || metadata_key(track) == metadata)
    }

    fn take_entry(&mut self, id: &QueueEntryId) -> Option<TrackRow> {
        match id.lane {
            QueueLane::PlayNext => take_key(&mut self.play_next, &id.key),
            QueueLane::Manual => take_key(&mut self.manual, &id.key),
            QueueLane::Autoplay => take_key(&mut self.recommended, &id.key),
            QueueLane::Normal => {
                let start = self.normal_index.map_or(0, |index| index.saturating_add(1));
                let index = self
                    .normal
                    .iter()
                    .enumerate()
                    .skip(start)
                    .find(|(_, track)| track.stable_key() == id.key)
                    .map(|(index, _)| index)?;
                Some(self.normal.remove(index))
            }
        }
    }

    fn take_previous_history(&mut self) -> Option<QueueItem> {
        let previous = self.history.pop_back()?;
        if let Some(current) = self.current.take() {
            self.play_next.push_front(current.track);
        }
        Some(QueueItem {
            track: previous.track,
            origin: QueueOrigin::Manual,
        })
    }

    fn shuffle_future(&mut self) {
        let start = self.normal_index.map_or(0, |index| index.saturating_add(1));
        shuffle_tracks(&mut self.normal, start);
    }

    fn restore_future_order(&mut self) {
        let start = self.normal_index.map_or(0, |index| index.saturating_add(1));
        if start >= self.normal.len() {
            return;
        }
        let remaining = self.normal[start..]
            .iter()
            .map(TrackRow::stable_key)
            .collect::<HashSet<_>>();
        let restored = self
            .original_normal
            .iter()
            .filter(|track| remaining.contains(&track.stable_key()))
            .cloned()
            .collect::<Vec<_>>();
        self.normal.splice(start.., restored);
    }

    fn finish_current(&mut self, position_ms: u32, natural_end: bool) {
        let Some(current) = self.current.take() else {
            return;
        };
        let listened_ratio = if current.track.duration_ms == 0 {
            0.0
        } else {
            f64::from(position_ms) / current.track.duration_ms as f64
        };
        if current.origin == QueueOrigin::Autoplay && !natural_end && position_ms < 15_000 {
            let key = normalize(&current.track.artist);
            let score = self.artist_skips.entry(key).or_default();
            *score = score.saturating_add(1);
        } else if natural_end || listened_ratio >= 0.7 {
            let key = normalize(&current.track.artist);
            if let Some(score) = self.artist_skips.get_mut(&key) {
                *score = score.saturating_sub(1);
            }
        }
        self.history.push_back(HistoryItem {
            track: current.track,
        });
        while self.history.len() > HISTORY_LIMIT {
            self.history.pop_front();
        }
    }

    fn finalize_candidates(&mut self) {
        let mut blocked_ids = HashSet::new();
        let mut blocked_metadata = HashSet::new();
        for track in self
            .normal
            .iter()
            .chain(self.play_next.iter())
            .chain(self.manual.iter())
            .chain(self.recommended.iter())
            .chain(self.history.iter().map(|item| &item.track))
            .chain(self.current.iter().map(|item| &item.track))
        {
            blocked_ids.insert(track.stable_key());
            blocked_metadata.insert(metadata_key(track));
        }

        let preferred = self.preferred_provider;
        let mut ranked = Vec::new();
        for (provider, rows) in [
            (
                TrackProvider::Spotify,
                std::mem::take(&mut self.spotify_candidates),
            ),
            (
                TrackProvider::SoundCloud,
                std::mem::take(&mut self.soundcloud_candidates),
            ),
        ] {
            let total = rows.len();
            for (rank, track) in rows.into_iter().enumerate() {
                // Provider recommendation order is the strongest real signal.
                // Metadata/duration scoring then blends current and recent
                // listening context without inventing genre or audio features.
                let provider_rank = total.saturating_sub(rank).min(50) as i32;
                let score = provider_rank
                    + similarity_score(&track, &self.recommendation_context)
                    + if Some(provider) == preferred { 18 } else { 0 }
                    + if self.radio_seed_artist.as_ref().is_some_and(|artist| {
                        let candidate = normalize(&track.artist);
                        candidate.contains(artist.as_str()) || artist.contains(&candidate)
                    }) {
                        30
                    } else {
                        0
                    }
                    - i32::from(
                        self.artist_skips
                            .get(&normalize(&track.artist))
                            .copied()
                            .unwrap_or(0),
                    ) * 45;
                ranked.push((score, rank, track));
            }
        }
        ranked.sort_by(|left, right| right.0.cmp(&left.0).then_with(|| left.1.cmp(&right.1)));

        for (_, _, track) in ranked {
            if self.recommended.len() >= AUTOPLAY_TARGET {
                break;
            }
            if !track.playable {
                continue;
            }
            let id = track.stable_key();
            let metadata = metadata_key(&track);
            let artist_penalty = self
                .artist_skips
                .get(&normalize(&track.artist))
                .copied()
                .unwrap_or(0);
            if artist_penalty >= 2 || !blocked_ids.insert(id) || !blocked_metadata.insert(metadata)
            {
                continue;
            }
            self.recommended.push_back(track);
        }
        tracing::info!(
            buffered = self.recommended.len(),
            "Autoplay recommendations applied"
        );
    }

    #[allow(clippy::too_many_arguments)]
    fn launch(
        &mut self,
        item: QueueItem,
        spotify: &mut SpotifyViewState,
        soundcloud: &mut SoundCloudViewState,
        spotify_runtime: &SpotifyRuntime,
        soundcloud_runtime: &SoundCloudRuntime,
    ) {
        spotify.toast = None;
        match item.track.provider {
            TrackProvider::Spotify => {
                let Some(track) = item.track.to_spotify_track() else {
                    spotify.toast_error("Spotify track identity is incomplete");
                    return;
                };
                soundcloud.stop_playback(soundcloud_runtime);
                spotify.play_queue(spotify_runtime, vec![track], 0);
            }
            TrackProvider::SoundCloud => {
                spotify.stop_playback(spotify_runtime);
                soundcloud.play_queue(soundcloud_runtime, vec![item.track.clone()], 0);
            }
        }
        self.preferred_provider = Some(item.track.provider);
        self.current = Some(item);
        self.waiting_for_autoplay = false;
    }

    fn stop_all(
        &mut self,
        spotify: &mut SpotifyViewState,
        soundcloud: &mut SoundCloudViewState,
        spotify_runtime: &SpotifyRuntime,
        soundcloud_runtime: &SoundCloudRuntime,
    ) {
        spotify.stop_playback(spotify_runtime);
        soundcloud.stop_playback(soundcloud_runtime);
        self.current = None;
        self.waiting_for_autoplay = false;
    }
}

fn lane_for_origin(origin: QueueOrigin) -> QueueLane {
    match origin {
        QueueOrigin::Normal => QueueLane::Normal,
        QueueOrigin::PlayNext => QueueLane::PlayNext,
        QueueOrigin::Manual => QueueLane::Manual,
        QueueOrigin::Autoplay => QueueLane::Autoplay,
    }
}

fn origin_for_lane(lane: QueueLane) -> QueueOrigin {
    match lane {
        QueueLane::Normal => QueueOrigin::Normal,
        QueueLane::PlayNext => QueueOrigin::PlayNext,
        QueueLane::Manual => QueueOrigin::Manual,
        QueueLane::Autoplay => QueueOrigin::Autoplay,
    }
}

fn snapshot_item(track: &TrackRow, lane: QueueLane, origin: QueueOrigin) -> QueueSnapshotItem {
    QueueSnapshotItem {
        id: QueueEntryId {
            lane,
            key: track.stable_key(),
        },
        track: track.clone(),
        origin,
    }
}

fn extend_snapshot(
    output: &mut Vec<QueueSnapshotItem>,
    tracks: &VecDeque<TrackRow>,
    lane: QueueLane,
    origin: QueueOrigin,
) {
    output.extend(
        tracks
            .iter()
            .map(|track| snapshot_item(track, lane, origin)),
    );
}

fn remove_key(tracks: &mut VecDeque<TrackRow>, key: &str) -> bool {
    take_key(tracks, key).is_some()
}

fn take_key(tracks: &mut VecDeque<TrackRow>, key: &str) -> Option<TrackRow> {
    let index = tracks.iter().position(|track| track.stable_key() == key)?;
    tracks.remove(index)
}

fn reorder_deque(tracks: &mut VecDeque<TrackRow>, source: &str, target: &str) -> bool {
    let Some(source_index) = tracks.iter().position(|track| track.stable_key() == source) else {
        return false;
    };
    let Some(mut target_index) = tracks.iter().position(|track| track.stable_key() == target)
    else {
        return false;
    };
    let Some(track) = tracks.remove(source_index) else {
        return false;
    };
    if source_index < target_index {
        target_index = target_index.saturating_sub(1);
    }
    tracks.insert(target_index, track);
    true
}

fn reorder_slice(tracks: &mut Vec<TrackRow>, start: usize, source: &str, target: &str) -> bool {
    let Some(source_index) = tracks
        .iter()
        .enumerate()
        .skip(start)
        .find(|(_, track)| track.stable_key() == source)
        .map(|(index, _)| index)
    else {
        return false;
    };
    let Some(mut target_index) = tracks
        .iter()
        .enumerate()
        .skip(start)
        .find(|(_, track)| track.stable_key() == target)
        .map(|(index, _)| index)
    else {
        return false;
    };
    let track = tracks.remove(source_index);
    if source_index < target_index {
        target_index = target_index.saturating_sub(1);
    }
    tracks.insert(target_index, track);
    true
}

fn shuffle_tracks(tracks: &mut [TrackRow], start: usize) {
    if tracks.len().saturating_sub(start) < 2 {
        return;
    }
    let mut seed = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|duration| duration.as_nanos() as u64)
        .unwrap_or(0x9e37_79b9_7f4a_7c15);
    for index in ((start + 1)..tracks.len()).rev() {
        seed ^= seed << 13;
        seed ^= seed >> 7;
        seed ^= seed << 17;
        let target = start + (seed as usize % (index - start + 1));
        tracks.swap(index, target);
    }
}

fn similarity_score(candidate: &TrackRow, context: &[TrackRow]) -> i32 {
    context
        .iter()
        .enumerate()
        .map(|(index, seed)| {
            let recency = (5_i32 - index as i32).max(1);
            let candidate_artist = words(&candidate.artist);
            let seed_artist = words(&seed.artist);
            let candidate_collection = words(&candidate.collection);
            let seed_collection = words(&seed.collection);
            let candidate_title = words(&candidate.title);
            let seed_title = words(&seed.title);

            let same_artist = (normalize(&candidate.artist) == normalize(&seed.artist)) as i32;
            let artist_overlap = overlap_count(&candidate_artist, &seed_artist) as i32;
            let collection_overlap = overlap_count(&candidate_collection, &seed_collection) as i32;
            let title_overlap = overlap_count(&candidate_title, &seed_title) as i32;
            let duration_delta = candidate.duration_ms.abs_diff(seed.duration_ms);
            let duration_score = if duration_delta <= 15_000 {
                14
            } else if duration_delta <= 45_000 {
                8
            } else if duration_delta <= 90_000 {
                3
            } else {
                0
            };

            recency
                * (same_artist * 8
                    + artist_overlap * 5
                    + collection_overlap * 7
                    + title_overlap * 2
                    + duration_score)
        })
        .sum()
}

fn words(text: &str) -> HashSet<String> {
    text.split(|character: char| !character.is_alphanumeric())
        .map(str::to_lowercase)
        .filter(|word| word.chars().count() >= 3)
        .collect()
}

fn overlap_count(left: &HashSet<String>, right: &HashSet<String>) -> usize {
    left.intersection(right).count()
}

fn metadata_key(track: &TrackRow) -> String {
    format!("{}|{}", normalize(&track.artist), normalize(&track.title))
}

fn normalize(text: &str) -> String {
    text.chars()
        .flat_map(char::to_lowercase)
        .filter(|character| character.is_alphanumeric())
        .collect()
}

#[cfg(test)]
mod tests {
    use super::{
        AutoplayQueue, HistoryItem, QueueEntryId, QueueItem, QueueLane, QueueOrigin, metadata_key,
        normalize, similarity_score,
    };
    use crate::catalog::{ProviderTrackId, TrackProvider, TrackRow};
    use crate::settings::RepeatMode;

    #[test]
    fn cross_provider_metadata_keys_match() {
        let spotify = TrackRow {
            provider: TrackProvider::Spotify,
            provider_id: ProviderTrackId::Spotify {
                id: "one".into(),
                uri: "spotify:track:one".into(),
            },
            title: "Blinding Lights".into(),
            artist: "The Weeknd".into(),
            collection: String::new(),
            duration_ms: 1,
            artwork_url: None,
            liked: None,
            playable: true,
        };
        let mut soundcloud = spotify.clone();
        soundcloud.provider = TrackProvider::SoundCloud;
        soundcloud.provider_id = ProviderTrackId::SoundCloud {
            id: "two".into(),
            urn: Some("soundcloud:tracks:two".into()),
            permalink_url: None,
        };
        assert_eq!(metadata_key(&spotify), metadata_key(&soundcloud));
        assert_eq!(normalize("The Weeknd"), "theweeknd");
    }

    #[test]
    fn contextual_ranking_prefers_matching_album_and_duration() {
        let seed = sample_track(
            "seed",
            "Blinding Lights",
            "The Weeknd",
            "After Hours",
            200_000,
        );
        let close = sample_track(
            "close",
            "Save Your Tears",
            "The Weeknd",
            "After Hours",
            215_000,
        );
        let distant = sample_track(
            "far",
            "Long Ambient Piece",
            "Other Artist",
            "Field Notes",
            540_000,
        );

        assert!(
            similarity_score(&close, std::slice::from_ref(&seed))
                > similarity_score(&distant, &[seed])
        );
    }

    #[test]
    fn queue_priority_is_play_next_manual_normal_then_autoplay() {
        let mut queue = AutoplayQueue::default();
        queue.normal = vec![
            sample_track("current", "Current", "A", "", 1),
            sample_track("normal", "Normal", "A", "", 1),
        ];
        queue.normal_index = Some(0);
        queue
            .play_next
            .push_back(sample_track("next", "Next", "A", "", 1));
        queue
            .manual
            .push_back(sample_track("manual", "Manual", "A", "", 1));
        queue
            .recommended
            .push_back(sample_track("auto", "Auto", "A", "", 1));

        assert_eq!(
            queue.take_next(true).map(|item| item.origin),
            Some(QueueOrigin::PlayNext)
        );
        assert_eq!(
            queue.take_next(true).map(|item| item.origin),
            Some(QueueOrigin::Manual)
        );
        assert_eq!(
            queue.take_next(true).map(|item| item.origin),
            Some(QueueOrigin::Normal)
        );
        assert_eq!(
            queue.take_next(true).map(|item| item.origin),
            Some(QueueOrigin::Autoplay)
        );
    }

    #[test]
    fn disabling_shuffle_restores_remaining_source_order() {
        let mut queue = AutoplayQueue::default();
        queue.normal = (0..6)
            .map(|index| sample_track(&index.to_string(), &index.to_string(), "A", "", 1))
            .collect();
        queue.original_normal = queue.normal.clone();
        queue.normal_index = Some(1);
        let expected = queue.normal.clone();
        queue.set_shuffle(true);
        assert_eq!(queue.normal[0].stable_key(), expected[0].stable_key());
        assert_eq!(queue.normal[1].stable_key(), expected[1].stable_key());
        queue.set_shuffle(false);
        assert_eq!(
            queue
                .normal
                .iter()
                .map(TrackRow::stable_key)
                .collect::<Vec<_>>(),
            expected
                .iter()
                .map(TrackRow::stable_key)
                .collect::<Vec<_>>()
        );
    }

    #[test]
    fn repeat_queue_restarts_without_consuming_autoplay() {
        let first = sample_track("one", "One", "A", "", 1);
        let second = sample_track("two", "Two", "A", "", 1);
        let mut queue = AutoplayQueue::default();
        queue.repeat_cycle = vec![first.clone(), second];
        queue.normal = queue.repeat_cycle.clone();
        queue.normal_index = Some(1);
        queue
            .recommended
            .push_back(sample_track("auto", "Auto", "A", "", 1));

        let item = queue
            .take_next_with_repeat(true, RepeatMode::Queue)
            .expect("repeat item");
        assert_eq!(item.track.stable_key(), first.stable_key());
        assert_eq!(item.origin, QueueOrigin::Normal);
        assert_eq!(queue.recommended.len(), 1);
    }

    #[test]
    fn duplicate_manual_items_are_rejected() {
        let track = sample_track("one", "One", "A", "", 1);
        let mut queue = AutoplayQueue::default();
        assert!(queue.enqueue_manual(track.clone()));
        assert!(!queue.enqueue_play_next(track));
        assert_eq!(queue.manual.len(), 1);
        assert!(queue.play_next.is_empty());
    }

    #[test]
    fn repeat_off_does_not_consume_autoplay_when_disabled() {
        let mut queue = AutoplayQueue::default();
        queue
            .recommended
            .push_back(sample_track("auto", "Auto", "A", "", 1));
        assert!(
            queue
                .take_next_with_repeat(false, RepeatMode::Off)
                .is_none()
        );
        assert_eq!(queue.recommended.len(), 1);
    }

    #[test]
    fn reorder_remove_and_clear_affect_only_future_items() {
        let one = sample_track("one", "One", "A", "", 1);
        let two = sample_track("two", "Two", "A", "", 1);
        let three = sample_track("three", "Three", "A", "", 1);
        let mut queue = AutoplayQueue::default();
        queue.current = Some(QueueItem {
            track: one.clone(),
            origin: QueueOrigin::Normal,
        });
        queue.manual.extend([two.clone(), three.clone()]);
        let two_id = QueueEntryId {
            lane: QueueLane::Manual,
            key: two.stable_key(),
        };
        let three_id = QueueEntryId {
            lane: QueueLane::Manual,
            key: three.stable_key(),
        };
        assert!(queue.reorder(&three_id, &two_id));
        assert_eq!(
            queue.manual.front().map(TrackRow::stable_key),
            Some(three.stable_key())
        );
        assert!(queue.remove(&two_id));
        queue.clear_future();
        assert!(queue.manual.is_empty());
        assert_eq!(
            queue.current.as_ref().map(|item| item.track.stable_key()),
            Some(one.stable_key())
        );
    }

    #[test]
    fn previous_history_is_shared_across_providers() {
        let spotify = sample_track("spotify", "Spotify", "A", "", 1);
        let mut soundcloud = sample_track("soundcloud", "SoundCloud", "B", "", 1);
        soundcloud.provider = TrackProvider::SoundCloud;
        soundcloud.provider_id = ProviderTrackId::SoundCloud {
            id: "soundcloud".into(),
            urn: Some("soundcloud:tracks:soundcloud".into()),
            permalink_url: None,
        };
        let mut queue = AutoplayQueue::default();
        queue.history.push_back(HistoryItem {
            track: spotify.clone(),
        });
        queue.current = Some(QueueItem {
            track: soundcloud.clone(),
            origin: QueueOrigin::Manual,
        });

        let previous = queue.take_previous_history().expect("history item");
        assert_eq!(previous.track.provider, TrackProvider::Spotify);
        assert_eq!(
            queue.play_next.front().map(|track| track.provider),
            Some(TrackProvider::SoundCloud)
        );
    }

    fn sample_track(
        id: &str,
        title: &str,
        artist: &str,
        album: &str,
        duration_ms: u64,
    ) -> TrackRow {
        TrackRow {
            provider: TrackProvider::Spotify,
            provider_id: ProviderTrackId::Spotify {
                id: id.into(),
                uri: format!("spotify:track:{id}"),
            },
            title: title.into(),
            artist: artist.into(),
            collection: album.into(),
            duration_ms,
            artwork_url: None,
            liked: None,
            playable: true,
        }
    }
}
