//! Windows taskbar thumbnail transport controls.
//!
//! The thumbnail itself is rendered by Windows. This module adds the three
//! native thumbnail-toolbar buttons used for Previous / Play-Pause / Next.

use std::{
    ffi::c_void,
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
    time::{Duration, Instant},
};

use eframe::egui;
use raw_window_handle::{HasWindowHandle, RawWindowHandle};
use windows::{
    Win32::{
        Foundation::{HWND, LPARAM, LRESULT, WPARAM},
        System::Com::{
            CLSCTX_INPROC_SERVER, COINIT_APARTMENTTHREADED, CoCreateInstance, CoInitializeEx,
            CoUninitialize,
        },
        UI::{
            Shell::{
                DefSubclassProc, ITaskbarList3, RemoveWindowSubclass, SetWindowSubclass, THB_FLAGS,
                THB_ICON, THB_TOOLTIP, THBF_ENABLED, THBN_CLICKED, THUMBBUTTON, TaskbarList,
            },
            WindowsAndMessaging::{
                CreateIconFromResourceEx, DestroyIcon, HICON, LR_DEFAULTCOLOR,
                RegisterWindowMessageW, WM_COMMAND, WM_NCDESTROY,
            },
        },
    },
    core::w,
};

/// Provider-neutral action emitted by Windows thumbnail controls.
#[derive(Debug, Clone, Copy)]
pub enum TaskbarAction {
    Previous,
    Toggle,
    Next,
    /// Absolute seek requested by the Windows media flyout, in milliseconds.
    Seek(u32),
}

const BUTTON_PREVIOUS: u32 = 0x5101;
const BUTTON_PLAY_PAUSE: u32 = 0x5102;
const BUTTON_NEXT: u32 = 0x5103;
const SUBCLASS_ID: usize = 0x4551_5350; // "EQSP"
const RETRY_DELAY: Duration = Duration::from_millis(250);

const PREVIOUS_ICO: &[u8] = include_bytes!("../assets/taskbar/previous.ico");
const PLAY_ICO: &[u8] = include_bytes!("../assets/taskbar/play.ico");
const PAUSE_ICO: &[u8] = include_bytes!("../assets/taskbar/pause.ico");
const NEXT_ICO: &[u8] = include_bytes!("../assets/taskbar/next.ico");

struct CallbackState {
    command_tx: flume::Sender<TaskbarAction>,
    taskbar_created_message: u32,
    needs_readd: Arc<AtomicBool>,
}

struct TaskbarIcons {
    previous: HICON,
    play: HICON,
    pause: HICON,
    next: HICON,
}

/// Native Windows controls shown below Spoteq's taskbar thumbnail preview.
pub struct TaskbarControls {
    hwnd: HWND,
    taskbar: Option<ITaskbarList3>,
    callback_state: Box<CallbackState>,
    icons: TaskbarIcons,
    toolbar_added: bool,
    last_playing: Option<bool>,
    next_retry: Instant,
    com_initialized: bool,
    subclass_installed: bool,
    needs_readd: Arc<AtomicBool>,
}

impl TaskbarControls {
    /// Installs the Windows message hook and prepares the taskbar toolbar.
    ///
    /// Toolbar creation itself is retried from [`Self::sync`] because Windows can
    /// create the taskbar button a little later than eframe creates the HWND.
    pub fn install(
        creation_context: &eframe::CreationContext<'_>,
        command_tx: flume::Sender<TaskbarAction>,
    ) -> Result<Self, String> {
        let hwnd = hwnd_from_creation_context(creation_context)?;

        // COM may already be initialized by another Windows component. In that
        // case CoCreateInstance below can still be used; we only balance an
        // initialization call that actually succeeded.
        let com_result = unsafe { CoInitializeEx(None, COINIT_APARTMENTTHREADED) };
        let com_initialized = com_result.is_ok();

        let taskbar: ITaskbarList3 = unsafe {
            CoCreateInstance(&TaskbarList, None, CLSCTX_INPROC_SERVER)
                .map_err(|error| format!("Could not create Windows taskbar interface: {error}"))?
        };
        unsafe {
            taskbar.HrInit().map_err(|error| {
                format!("Could not initialize Windows taskbar interface: {error}")
            })?;
        }

        let icons = TaskbarIcons {
            previous: icon_from_ico(PREVIOUS_ICO)?,
            play: icon_from_ico(PLAY_ICO)?,
            pause: icon_from_ico(PAUSE_ICO)?,
            next: icon_from_ico(NEXT_ICO)?,
        };

        let taskbar_created_message = unsafe { RegisterWindowMessageW(w!("TaskbarButtonCreated")) };
        let needs_readd = Arc::new(AtomicBool::new(false));
        let mut callback_state = Box::new(CallbackState {
            command_tx,
            taskbar_created_message,
            needs_readd: Arc::clone(&needs_readd),
        });
        let callback_ptr = (&mut *callback_state as *mut CallbackState) as usize;

        let subclass_installed = unsafe {
            SetWindowSubclass(hwnd, Some(taskbar_subclass_proc), SUBCLASS_ID, callback_ptr)
                .as_bool()
        };
        if !subclass_installed {
            destroy_icons(&icons);
            drop(taskbar);
            if com_initialized {
                unsafe { CoUninitialize() };
            }
            return Err("Could not install Windows taskbar message hook".to_owned());
        }

        Ok(Self {
            hwnd,
            taskbar: Some(taskbar),
            callback_state,
            icons,
            toolbar_added: false,
            last_playing: None,
            next_retry: Instant::now(),
            com_initialized,
            subclass_installed,
            needs_readd,
        })
    }

    /// Ensures the thumbnail toolbar exists and keeps the center icon in sync
    /// with Spoteq playback state. Safe to call from every eframe logic pass.
    pub fn sync(&mut self, context: &egui::Context, playing: bool) {
        // Explorer sends TaskbarButtonCreated again after recreating its taskbar.
        if self.needs_readd.swap(false, Ordering::AcqRel) {
            self.toolbar_added = false;
            self.last_playing = None;
            self.next_retry = Instant::now();
        }

        if !self.toolbar_added {
            if Instant::now() < self.next_retry {
                context.request_repaint_after(
                    self.next_retry.saturating_duration_since(Instant::now()),
                );
                return;
            }

            match self.add_toolbar(playing) {
                Ok(()) => {
                    self.toolbar_added = true;
                    self.last_playing = Some(playing);
                }
                Err(error) => {
                    tracing::debug!("Windows taskbar toolbar is not ready yet: {error}");
                    self.next_retry = Instant::now() + RETRY_DELAY;
                    context.request_repaint_after(RETRY_DELAY);
                    return;
                }
            }
        }

        if self.last_playing != Some(playing) {
            if let Err(error) = self.update_play_pause(playing) {
                tracing::debug!("Could not update taskbar Play/Pause icon: {error}");
            } else {
                self.last_playing = Some(playing);
            }
        }
    }

    fn add_toolbar(&self, playing: bool) -> Result<(), String> {
        let Some(taskbar) = self.taskbar.as_ref() else {
            return Err("Windows taskbar interface is unavailable".to_owned());
        };

        let buttons = [
            thumb_button(BUTTON_PREVIOUS, self.icons.previous, "Previous"),
            thumb_button(
                BUTTON_PLAY_PAUSE,
                if playing {
                    self.icons.pause
                } else {
                    self.icons.play
                },
                if playing { "Pause" } else { "Play" },
            ),
            thumb_button(BUTTON_NEXT, self.icons.next, "Next"),
        ];

        unsafe {
            taskbar
                .ThumbBarAddButtons(self.hwnd, &buttons)
                .map_err(|error| error.to_string())
        }
    }

    fn update_play_pause(&self, playing: bool) -> Result<(), String> {
        let Some(taskbar) = self.taskbar.as_ref() else {
            return Err("Windows taskbar interface is unavailable".to_owned());
        };

        let button = thumb_button(
            BUTTON_PLAY_PAUSE,
            if playing {
                self.icons.pause
            } else {
                self.icons.play
            },
            if playing { "Pause" } else { "Play" },
        );
        unsafe {
            taskbar
                .ThumbBarUpdateButtons(self.hwnd, &[button])
                .map_err(|error| error.to_string())
        }
    }
}

impl Drop for TaskbarControls {
    fn drop(&mut self) {
        if self.subclass_installed {
            unsafe {
                let _ = RemoveWindowSubclass(self.hwnd, Some(taskbar_subclass_proc), SUBCLASS_ID);
            }
            self.subclass_installed = false;
        }

        // Keep callback_state alive until after the subclass is detached.
        let _ = &self.callback_state;

        // Release the COM interface before balancing CoInitializeEx.
        self.taskbar.take();
        destroy_icons(&self.icons);
        if self.com_initialized {
            unsafe { CoUninitialize() };
            self.com_initialized = false;
        }
    }
}

unsafe extern "system" fn taskbar_subclass_proc(
    hwnd: HWND,
    message: u32,
    wparam: WPARAM,
    lparam: LPARAM,
    _subclass_id: usize,
    ref_data: usize,
) -> LRESULT {
    if ref_data == 0 {
        return unsafe { DefSubclassProc(hwnd, message, wparam, lparam) };
    }

    let state = unsafe { &*(ref_data as *const CallbackState) };

    if message == state.taskbar_created_message {
        state.needs_readd.store(true, Ordering::Release);
    }

    if message == WM_COMMAND {
        let command_id = (wparam.0 & 0xffff) as u32;
        let notification = ((wparam.0 >> 16) & 0xffff) as u32;
        if notification == THBN_CLICKED {
            let command = match command_id {
                BUTTON_PREVIOUS => Some(TaskbarAction::Previous),
                BUTTON_PLAY_PAUSE => Some(TaskbarAction::Toggle),
                BUTTON_NEXT => Some(TaskbarAction::Next),
                _ => None,
            };

            if let Some(command) = command {
                // Send directly to the playback runtime so this also works while
                // Spoteq is minimized and eframe is not painting the main UI.
                let _ = state.command_tx.send(command);
                return LRESULT(0);
            }
        }
    }

    let result = unsafe { DefSubclassProc(hwnd, message, wparam, lparam) };

    // The subclass manager automatically removes entries on WM_NCDESTROY. We
    // still call RemoveWindowSubclass in Drop during normal shutdown.
    if message == WM_NCDESTROY {
        return result;
    }

    result
}

pub(crate) fn hwnd_from_creation_context(
    creation_context: &eframe::CreationContext<'_>,
) -> Result<HWND, String> {
    let handle = creation_context
        .window_handle()
        .map_err(|error| format!("Could not obtain Spoteq window handle: {error}"))?;

    match handle.as_raw() {
        RawWindowHandle::Win32(handle) => Ok(HWND(handle.hwnd.get() as isize as *mut c_void)),
        _ => Err("Spoteq taskbar controls require a Win32 window".to_owned()),
    }
}

fn thumb_button(id: u32, icon: HICON, tooltip: &str) -> THUMBBUTTON {
    THUMBBUTTON {
        dwMask: THB_ICON | THB_TOOLTIP | THB_FLAGS,
        iId: id,
        iBitmap: 0,
        hIcon: icon,
        szTip: tooltip_buffer(tooltip),
        dwFlags: THBF_ENABLED,
    }
}

fn tooltip_buffer(text: &str) -> [u16; 260] {
    let mut buffer = [0u16; 260];
    for (target, value) in buffer.iter_mut().take(259).zip(text.encode_utf16()) {
        *target = value;
    }
    buffer
}

fn icon_from_ico(bytes: &[u8]) -> Result<HICON, String> {
    let payload = ico_payload(bytes)?;
    unsafe {
        CreateIconFromResourceEx(payload, true, 0x0003_0000, 32, 32, LR_DEFAULTCOLOR)
            .map_err(|error| format!("Could not create taskbar transport icon: {error}"))
    }
}

fn ico_payload(bytes: &[u8]) -> Result<&[u8], String> {
    // ICONDIR (6 bytes) + first ICONDIRENTRY (16 bytes). CreateIconFromResourceEx
    // expects the image resource payload, not the outer .ico directory.
    if bytes.len() < 22 {
        return Err("Embedded taskbar icon is truncated".to_owned());
    }
    let image_size = u32::from_le_bytes(bytes[14..18].try_into().unwrap()) as usize;
    let image_offset = u32::from_le_bytes(bytes[18..22].try_into().unwrap()) as usize;
    let end = image_offset
        .checked_add(image_size)
        .ok_or_else(|| "Embedded taskbar icon has an invalid size".to_owned())?;
    bytes
        .get(image_offset..end)
        .ok_or_else(|| "Embedded taskbar icon payload is outside the .ico file".to_owned())
}

fn destroy_icons(icons: &TaskbarIcons) {
    unsafe {
        let _ = DestroyIcon(icons.previous);
        let _ = DestroyIcon(icons.play);
        let _ = DestroyIcon(icons.pause);
        let _ = DestroyIcon(icons.next);
    }
}
