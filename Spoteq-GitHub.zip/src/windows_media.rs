//! Windows System Media Transport Controls (SMTC).
//!
//! This is the single bridge used by the Windows media flyout, lock screen and
//! hardware media keys. It only emits provider-neutral commands; playback
//! remains owned by Spoteq's existing queue coordinator.

use std::time::{Duration, Instant};

use windows::{
    Foundation::{TimeSpan, TypedEventHandler, Uri},
    Media::{
        MediaPlaybackAutoRepeatMode, MediaPlaybackStatus, MediaPlaybackType,
        PlaybackPositionChangeRequestedEventArgs, SystemMediaTransportControls,
        SystemMediaTransportControlsButton, SystemMediaTransportControlsButtonPressedEventArgs,
        SystemMediaTransportControlsTimelineProperties,
    },
    Storage::Streams::RandomAccessStreamReference,
    Win32::System::WinRT::{
        ISystemMediaTransportControlsInterop, RO_INIT_SINGLETHREADED, RoGetActivationFactory,
        RoInitialize, RoUninitialize,
    },
    core::HSTRING,
};

use crate::{settings::RepeatMode, windows_taskbar::TaskbarAction};

const TIMELINE_INTERVAL: Duration = Duration::from_secs(1);

/// Provider-neutral information published to Windows.
#[derive(Debug, Clone)]
pub struct MediaSnapshot {
    pub key: Option<String>,
    pub title: String,
    pub artist: String,
    pub album: String,
    pub artwork_url: Option<String>,
    pub duration_ms: u64,
    pub position_ms: u32,
    pub status: MediaStatus,
    pub has_previous: bool,
    pub has_next: bool,
    pub shuffle: bool,
    pub repeat: RepeatMode,
}

/// Small status enum that keeps WinRT types out of the application state.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MediaStatus {
    Idle,
    Changing,
    Playing,
    Paused,
    Error,
}

/// Owns the desktop SMTC object and its registered event handlers.
pub struct WindowsMediaSession {
    controls: SystemMediaTransportControls,
    button_token: i64,
    seek_token: i64,
    last_key: Option<String>,
    last_status: Option<MediaStatus>,
    last_timeline: Instant,
    ro_initialized: bool,
}

impl WindowsMediaSession {
    pub fn install(
        creation_context: &eframe::CreationContext<'_>,
        command_tx: flume::Sender<TaskbarAction>,
    ) -> Result<Self, String> {
        let hwnd = crate::windows_taskbar::hwnd_from_creation_context(creation_context)?;
        let ro_initialized = unsafe { RoInitialize(RO_INIT_SINGLETHREADED) }.is_ok();
        let class_name = HSTRING::from("Windows.Media.SystemMediaTransportControls");
        let interop: ISystemMediaTransportControlsInterop = unsafe {
            RoGetActivationFactory(&class_name)
                .map_err(|error| format!("Could not create Windows media factory: {error}"))?
        };
        let controls: SystemMediaTransportControls = unsafe {
            interop
                .GetForWindow(hwnd)
                .map_err(|error| format!("Could not attach Windows media session: {error}"))?
        };

        controls
            .SetIsEnabled(true)
            .and_then(|_| controls.SetIsPlayEnabled(true))
            .and_then(|_| controls.SetIsPauseEnabled(true))
            .and_then(|_| controls.SetIsPreviousEnabled(true))
            .and_then(|_| controls.SetIsNextEnabled(true))
            .map_err(|error| format!("Could not enable Windows media controls: {error}"))?;

        let button_tx = command_tx.clone();
        let button_handler = TypedEventHandler::<
            SystemMediaTransportControls,
            SystemMediaTransportControlsButtonPressedEventArgs,
        >::new(move |_, args| {
            if let Some(args) = args.as_ref() {
                let action = match args.Button()? {
                    SystemMediaTransportControlsButton::Play
                    | SystemMediaTransportControlsButton::Pause => Some(TaskbarAction::Toggle),
                    SystemMediaTransportControlsButton::Previous => Some(TaskbarAction::Previous),
                    SystemMediaTransportControlsButton::Next => Some(TaskbarAction::Next),
                    _ => None,
                };
                if let Some(action) = action {
                    let _ = button_tx.send(action);
                }
            }
            Ok(())
        });
        let button_token = controls
            .ButtonPressed(&button_handler)
            .map_err(|error| format!("Could not register Windows media buttons: {error}"))?;

        let seek_handler = TypedEventHandler::<
            SystemMediaTransportControls,
            PlaybackPositionChangeRequestedEventArgs,
        >::new(move |_, args| {
            if let Some(args) = args.as_ref() {
                let ticks = args.RequestedPlaybackPosition()?.Duration.max(0) as u64;
                let milliseconds = (ticks / 10_000).min(u64::from(u32::MAX)) as u32;
                let _ = command_tx.send(TaskbarAction::Seek(milliseconds));
            }
            Ok(())
        });
        let seek_token = controls
            .PlaybackPositionChangeRequested(&seek_handler)
            .map_err(|error| format!("Could not register Windows media seek: {error}"))?;

        tracing::info!("Windows Media Session initialized");
        Ok(Self {
            controls,
            button_token,
            seek_token,
            last_key: None,
            last_status: None,
            last_timeline: Instant::now() - TIMELINE_INTERVAL,
            ro_initialized,
        })
    }

    /// Publishes changes without touching either provider's playback backend.
    pub fn sync(&mut self, snapshot: &MediaSnapshot) {
        let key_changed = self.last_key != snapshot.key;
        if key_changed {
            if let Err(error) = self.update_metadata(snapshot) {
                tracing::warn!("Windows media metadata update failed: {error}");
            } else {
                self.last_key = snapshot.key.clone();
            }
        }

        if self.last_status != Some(snapshot.status) {
            let status = match snapshot.status {
                MediaStatus::Idle => MediaPlaybackStatus::Stopped,
                MediaStatus::Changing => MediaPlaybackStatus::Changing,
                MediaStatus::Playing => MediaPlaybackStatus::Playing,
                MediaStatus::Paused => MediaPlaybackStatus::Paused,
                MediaStatus::Error => MediaPlaybackStatus::Stopped,
            };
            if self.controls.SetPlaybackStatus(status).is_ok() {
                self.last_status = Some(snapshot.status);
            }
        }

        let _ = self.controls.SetIsPreviousEnabled(snapshot.has_previous);
        let _ = self.controls.SetIsNextEnabled(snapshot.has_next);
        let has_track = snapshot.key.is_some();
        let _ = self
            .controls
            .SetIsPlayEnabled(has_track && snapshot.status != MediaStatus::Playing);
        let _ = self
            .controls
            .SetIsPauseEnabled(has_track && snapshot.status == MediaStatus::Playing);
        let _ = self.controls.SetShuffleEnabled(snapshot.shuffle);
        let repeat = match snapshot.repeat {
            RepeatMode::Off => MediaPlaybackAutoRepeatMode::None,
            RepeatMode::Queue => MediaPlaybackAutoRepeatMode::List,
            RepeatMode::Track => MediaPlaybackAutoRepeatMode::Track,
        };
        let _ = self.controls.SetAutoRepeatMode(repeat);

        if self.last_timeline.elapsed() >= TIMELINE_INTERVAL || key_changed {
            if let Err(error) = self.update_timeline(snapshot) {
                tracing::debug!("Windows media timeline update failed: {error}");
            }
            self.last_timeline = Instant::now();
        }
    }

    fn update_metadata(&self, snapshot: &MediaSnapshot) -> windows::core::Result<()> {
        let updater = self.controls.DisplayUpdater()?;
        updater.ClearAll()?;
        if snapshot.key.is_none() {
            updater.Update()?;
            return Ok(());
        }
        updater.SetType(MediaPlaybackType::Music)?;
        updater.SetAppMediaId(&HSTRING::from("Spoteq"))?;
        let music = updater.MusicProperties()?;
        music.SetTitle(&HSTRING::from(&snapshot.title))?;
        music.SetArtist(&HSTRING::from(&snapshot.artist))?;
        music.SetAlbumTitle(&HSTRING::from(&snapshot.album))?;
        if let Some(url) = snapshot.artwork_url.as_deref() {
            if let Ok(uri) = Uri::CreateUri(&HSTRING::from(url)) {
                if let Ok(reference) = RandomAccessStreamReference::CreateFromUri(&uri) {
                    let _ = updater.SetThumbnail(&reference);
                }
            }
        }
        updater.Update()?;
        Ok(())
    }

    fn update_timeline(&self, snapshot: &MediaSnapshot) -> windows::core::Result<()> {
        let timeline = SystemMediaTransportControlsTimelineProperties::new()?;
        let duration = ms_to_timespan(snapshot.duration_ms);
        timeline.SetStartTime(TimeSpan { Duration: 0 })?;
        timeline.SetMinSeekTime(TimeSpan { Duration: 0 })?;
        timeline.SetEndTime(duration)?;
        timeline.SetMaxSeekTime(duration)?;
        timeline.SetPosition(ms_to_timespan(u64::from(snapshot.position_ms)))?;
        self.controls.UpdateTimelineProperties(&timeline)
    }
}

impl Drop for WindowsMediaSession {
    fn drop(&mut self) {
        let _ = self.controls.RemoveButtonPressed(self.button_token);
        let _ = self
            .controls
            .RemovePlaybackPositionChangeRequested(self.seek_token);
        let _ = self.controls.SetPlaybackStatus(MediaPlaybackStatus::Closed);
        let _ = self.controls.SetIsEnabled(false);
        if self.ro_initialized {
            unsafe { RoUninitialize() };
        }
    }
}

fn ms_to_timespan(milliseconds: u64) -> TimeSpan {
    TimeSpan {
        Duration: milliseconds.saturating_mul(10_000).min(i64::MAX as u64) as i64,
    }
}
