//! Top-level eframe application and ownership boundaries.

use std::time::{Duration, Instant};

use eframe::egui;

use crate::{
    audio::dsp::DspSettings,
    error::AppError,
    image_cache::CoverCache,
    settings::{AppSettings, SettingsStore, SettingsWriter, WriterStatus},
    soundcloud::{SoundCloudAvatar, SoundCloudCommand, SoundCloudEvent, SoundCloudRuntime},
    spotify::{SpotifyCommand, SpotifyEvent, SpotifyRuntime},
    state::AppState,
    ui,
};

use crate::{
    catalog::{TrackProvider, TrackRow},
    spotify::PlaybackStatus,
};

#[derive(Debug, Clone)]
enum PauseFadePhase {
    Out {
        provider: TrackProvider,
        started: Instant,
        duration: Duration,
    },
    In {
        provider: TrackProvider,
        started: Instant,
        duration: Duration,
    },
}

#[derive(Debug, Clone)]
enum CrossfadePhase {
    /// True overlap between Spotify and SoundCloud. Both provider backends can
    /// be alive at once, so the old track fades out while the new one fades in.
    CrossProviderPending {
        from: TrackProvider,
        to: TrackProvider,
        target_key: String,
        configured: Duration,
        armed_at: Instant,
        remaining_at_start: u32,
        retries: u8,
    },
    CrossProviderRunning {
        from: TrackProvider,
        to: TrackProvider,
        target_key: String,
        started: Instant,
        duration: Duration,
    },
    /// Same-provider transitions cannot overlap on the existing single
    /// provider decoder. Instead we apply an equal-power fade-out, switch to
    /// the already-prefetched next track at zero gain, then fade it in.
    SameProviderOut {
        provider: TrackProvider,
        target_key: String,
        started: Instant,
        duration: Duration,
        position_ms: u32,
    },
    SameProviderPendingIn {
        provider: TrackProvider,
        target_key: String,
        armed_at: Instant,
        duration: Duration,
    },
    SameProviderIn {
        provider: TrackProvider,
        target_key: String,
        started: Instant,
        duration: Duration,
    },
}

impl CrossfadePhase {
    fn from(&self) -> TrackProvider {
        match self {
            Self::CrossProviderPending { from, .. } | Self::CrossProviderRunning { from, .. } => {
                *from
            }
            Self::SameProviderOut { provider, .. }
            | Self::SameProviderPendingIn { provider, .. }
            | Self::SameProviderIn { provider, .. } => *provider,
        }
    }

    fn to(&self) -> TrackProvider {
        match self {
            Self::CrossProviderPending { to, .. } | Self::CrossProviderRunning { to, .. } => *to,
            Self::SameProviderOut { provider, .. }
            | Self::SameProviderPendingIn { provider, .. }
            | Self::SameProviderIn { provider, .. } => *provider,
        }
    }

    fn target_key(&self) -> &str {
        match self {
            Self::CrossProviderPending { target_key, .. }
            | Self::CrossProviderRunning { target_key, .. }
            | Self::SameProviderOut { target_key, .. }
            | Self::SameProviderPendingIn { target_key, .. }
            | Self::SameProviderIn { target_key, .. } => target_key,
        }
    }

    fn is_cross_provider(&self) -> bool {
        matches!(
            self,
            Self::CrossProviderPending { .. } | Self::CrossProviderRunning { .. }
        )
    }
}

/// Root desktop application. All mutable UI state is owned by this type.
pub struct SpoteqApp {
    state: AppState,
    settings: AppSettings,
    settings_store: SettingsStore,
    settings_writer: SettingsWriter,
    persistence_message: Option<String>,
    spotify_runtime: SpotifyRuntime,
    soundcloud_runtime: SoundCloudRuntime,
    covers: CoverCache,
    soundcloud_avatar: SoundCloudAvatar,
    pause_fade: Option<PauseFadePhase>,
    crossfade: Option<CrossfadePhase>,
    last_history_key: Option<String>,
    last_played_track: Option<TrackRow>,
    last_played_position_ms: u32,
    last_session_status: PlaybackStatus,
    last_session_snapshot_at: Instant,
    pending_resume_seek: Option<(String, u32)>,
    last_auth_trace: Option<String>,
    last_prefetched_key: Option<String>,
    failed_playback_key: Option<String>,
    failed_playback_retries: u8,
    failed_playback_retry_at: Option<Instant>,
    #[cfg(target_os = "windows")]
    taskbar_controls: Option<crate::windows_taskbar::TaskbarControls>,
    #[cfg(target_os = "windows")]
    taskbar_rx: flume::Receiver<crate::windows_taskbar::TaskbarAction>,
    #[cfg(target_os = "windows")]
    media_session: Option<crate::windows_media::WindowsMediaSession>,
    #[cfg(target_os = "windows")]
    tray: Option<crate::windows_tray::WindowsTray>,
}

/// Minimal UI used when a local startup service fails before [`SpoteqApp`]
/// can be constructed. Keeping an `eframe::App` alive here prevents the
/// already-created native viewport from remaining as an unpainted white
/// surface and exposes the original error to the user and logs.
pub struct StartupFailureApp {
    error: String,
}

impl StartupFailureApp {
    /// Creates a visible recovery surface for an application startup error.
    pub fn new(context: &egui::Context, error: impl Into<String>) -> Self {
        ui::theme::install(context, crate::settings::AccentColor::default());
        let error = error.into();
        tracing::error!(reason = %error, "[STARTUP] application initialization failed");
        Self { error }
    }
}

impl eframe::App for StartupFailureApp {
    fn logic(&mut self, _context: &egui::Context, _frame: &mut eframe::Frame) {}

    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        egui::CentralPanel::default()
            .frame(
                egui::Frame::new()
                    .fill(ui::theme::colors::background())
                    .inner_margin(egui::Margin::same(48)),
            )
            .show(ui, |ui| {
                ui.vertical_centered(|ui| {
                    ui.add_space(80.0);
                    ui.label(
                        egui::RichText::new("Spoteq could not finish starting")
                            .size(30.0)
                            .strong()
                            .color(ui::theme::colors::text()),
                    );
                    ui.add_space(12.0);
                    ui.label(
                        egui::RichText::new(
                            "Your accounts and tokens were not changed. Restart Spoteq after resolving the local error below.",
                        )
                        .size(15.0)
                        .color(ui::theme::colors::text_muted()),
                    );
                    ui.add_space(24.0);
                    ui::theme::elevated_frame(ui::theme::colors::surface(), 12)
                        .inner_margin(egui::Margin::symmetric(22, 18))
                        .show(ui, |ui| {
                            ui.set_max_width(760.0);
                            ui.label(
                                egui::RichText::new(&self.error)
                                    .monospace()
                                    .color(ui::theme::colors::error()),
                            );
                        });
                });
            });
    }
}

impl SpoteqApp {
    /// Creates the application and loads the last valid settings snapshot.
    pub fn new(creation_context: &eframe::CreationContext<'_>) -> Result<Self, AppError> {
        tracing::info!("[STARTUP] App::new entered");
        let settings_store = SettingsStore::discover()?;
        let (settings, persistence_message) = match settings_store.load() {
            Ok(settings) => {
                tracing::info!("[STATE] config loaded");
                tracing::info!("[STATE] persisted state restored");
                (settings, None)
            }
            Err(error) => {
                tracing::warn!(%error, "[STATE] config load failed; safe defaults selected");
                (
                    AppSettings::default(),
                    Some(format!("Defaults loaded: {error}")),
                )
            }
        };
        ui::theme::install(&creation_context.egui_ctx, settings.appearance.accent);
        ui::theme::apply_appearance(&creation_context.egui_ctx, &settings.appearance);
        let settings_writer = SettingsWriter::start(settings_store.clone())?;
        let spotify_runtime = SpotifyRuntime::start(
            creation_context.egui_ctx.clone(),
            settings.audio.master_volume,
            settings.audio.output_device.clone(),
            DspSettings::from(&settings.audio),
        )?;
        let soundcloud_runtime = SoundCloudRuntime::start(
            creation_context.egui_ctx.clone(),
            settings.audio.master_volume,
            settings.audio.output_device.clone(),
            spotify_runtime.dsp_controls(),
        )?;

        #[cfg(target_os = "windows")]
        let (taskbar_tx, taskbar_rx) = flume::unbounded();
        #[cfg(target_os = "windows")]
        let taskbar_controls = match crate::windows_taskbar::TaskbarControls::install(
            creation_context,
            taskbar_tx.clone(),
        ) {
            Ok(controls) => Some(controls),
            Err(error) => {
                tracing::warn!("Windows taskbar controls disabled: {error}");
                None
            }
        };
        #[cfg(target_os = "windows")]
        let media_session = match crate::windows_media::WindowsMediaSession::install(
            creation_context,
            taskbar_tx,
        ) {
            Ok(session) => Some(session),
            Err(error) => {
                tracing::warn!("Windows Media Session disabled: {error}");
                None
            }
        };
        #[cfg(target_os = "windows")]
        let tray = match crate::windows_tray::WindowsTray::install() {
            Ok(tray) => Some(tray),
            Err(error) => {
                tracing::warn!("Windows system tray disabled: {error}");
                None
            }
        };
        let mut state = AppState::default();
        state.autoplay.set_shuffle(settings.playback.shuffle);
        Ok(Self {
            state,
            settings,
            settings_store,
            settings_writer,
            persistence_message,
            spotify_runtime,
            soundcloud_runtime,
            covers: CoverCache::default(),
            soundcloud_avatar: SoundCloudAvatar::default(),
            pause_fade: None,
            crossfade: None,
            last_history_key: None,
            last_played_track: None,
            last_played_position_ms: 0,
            last_session_status: PlaybackStatus::Idle,
            last_session_snapshot_at: Instant::now(),
            pending_resume_seek: None,
            last_auth_trace: None,
            last_prefetched_key: None,
            failed_playback_key: None,
            failed_playback_retries: 0,
            failed_playback_retry_at: None,
            #[cfg(target_os = "windows")]
            taskbar_controls,
            #[cfg(target_os = "windows")]
            taskbar_rx,
            #[cfg(target_os = "windows")]
            media_session,
            #[cfg(target_os = "windows")]
            tray,
        })
    }

    fn trace_auth_state(&mut self) {
        let snapshot = format!(
            "spotify={:?}; soundcloud={:?}",
            self.state.spotify.auth, self.state.soundcloud.auth
        );
        if self.last_auth_trace.as_deref() == Some(snapshot.as_str()) {
            return;
        }
        tracing::info!(
            spotify = ?self.state.spotify.auth,
            spotify_authenticated = self.state.spotify.is_authenticated(),
            soundcloud = ?self.state.soundcloud.auth,
            soundcloud_authenticated = self.state.soundcloud.is_authenticated(),
            "[AUTH] auth-state resolution"
        );
        self.last_auth_trace = Some(snapshot);
    }

    fn schedule_save(&mut self) {
        if let Err(error) = self.settings_writer.schedule(&self.settings) {
            self.persistence_message = Some(error.to_string());
        }
    }

    fn poll_writer(&mut self) {
        if let Some(status) = self.settings_writer.try_status() {
            self.persistence_message = match status {
                WriterStatus::Saved => None,
                WriterStatus::Failed(error) => Some(format!("Settings were not saved: {error}")),
            };
        }
    }

    fn note_playback_started(&mut self, stable_key: &str) {
        if self.failed_playback_key.as_deref() == Some(stable_key) {
            self.failed_playback_key = None;
            self.failed_playback_retries = 0;
            self.failed_playback_retry_at = None;
            tracing::info!(track = %stable_key, "Playback retry recovered");
        }
    }

    fn recover_failed_playback(&mut self, stable_key: String) {
        // Crossfade has its own transition state machine; do not let a stale
        // provider error race a transition and advance the shared queue twice.
        if self.crossfade.is_some() {
            return;
        }
        if self.state.autoplay.current_key().as_deref() != Some(stable_key.as_str()) {
            return;
        }

        if self.failed_playback_key.as_deref() != Some(stable_key.as_str()) {
            self.failed_playback_key = Some(stable_key.clone());
            self.failed_playback_retries = 0;
            self.failed_playback_retry_at = None;
        }

        if self.failed_playback_retries > 0
            && self
                .failed_playback_retry_at
                .is_some_and(|started| started.elapsed() < Duration::from_millis(900))
        {
            // Some backends emit more than one Error snapshot for the same
            // failed attempt. Give the retry time to become Playing before
            // treating the track as failed a second time.
            return;
        }

        if self.failed_playback_retries == 0 {
            self.failed_playback_retries = 1;
            self.failed_playback_retry_at = Some(Instant::now());
            if self.state.autoplay.retry_current(
                &mut self.state.spotify,
                &mut self.state.soundcloud,
                &self.spotify_runtime,
                &self.soundcloud_runtime,
            ) {
                tracing::warn!(track = %stable_key, "Provider playback failed; retrying once");
                return;
            }
        }

        tracing::warn!(track = %stable_key, "Provider playback failed twice; skipping to next queue item");
        self.failed_playback_key = None;
        self.failed_playback_retries = 0;
        self.failed_playback_retry_at = None;
        self.state.autoplay.next(
            0,
            self.settings.playback.autoplay_similar,
            self.settings.playback.repeat,
            &mut self.state.spotify,
            &mut self.state.soundcloud,
            &self.spotify_runtime,
            &self.soundcloud_runtime,
        );
    }

    fn poll_spotify(&mut self, context: &egui::Context) {
        let events: Vec<_> = self.spotify_runtime.drain().collect();
        for event in events {
            let suppress_crossfade_playback = matches!(&event, SpotifyEvent::PlaybackChanged(_))
                && self.crossfade.as_ref().is_some_and(|phase| {
                    phase.is_cross_provider() && phase.from() == TrackProvider::Spotify
                });
            if suppress_crossfade_playback {
                continue;
            }
            let account_changed =
                matches!(&event, SpotifyEvent::LoggedIn(_) | SpotifyEvent::LoggedOut);
            let ended = matches!(&event, SpotifyEvent::PlaybackChanged(update) if update.ended);
            let playback_started = match &event {
                SpotifyEvent::PlaybackChanged(update)
                    if update.status == PlaybackStatus::Playing =>
                {
                    update
                        .track
                        .as_ref()
                        .map(|track| TrackRow::from_spotify(track).stable_key())
                }
                _ => None,
            };
            let playback_failed = match &event {
                SpotifyEvent::PlaybackChanged(update)
                    if matches!(update.status, PlaybackStatus::Error(_)) =>
                {
                    update
                        .track
                        .as_ref()
                        .map(|track| TrackRow::from_spotify(track).stable_key())
                }
                _ => None,
            };
            if let Some(returned) = self
                .state
                .spotify
                .handle_event(event, &self.spotify_runtime)
            {
                match returned {
                    SpotifyEvent::ImageFinished { url, result } => match result {
                        Ok(image) => self.covers.insert(context, url, image),
                        Err(error) => {
                            self.covers.fail(url);
                            self.state.spotify.toast_error(error);
                        }
                    },
                    SpotifyEvent::RecommendationsFinished { generation, result } => {
                        self.state.autoplay.accept_recommendations(
                            crate::catalog::TrackProvider::Spotify,
                            generation,
                            result,
                        );
                    }
                    SpotifyEvent::SavedStateLoaded {
                        stable_key,
                        request_id,
                        result,
                    } => {
                        if let Err(error) = self.state.provider_library.accept_loaded(
                            &stable_key,
                            request_id,
                            result,
                        ) {
                            tracing::warn!(reason = %error, "Like request failed");
                        }
                    }
                    SpotifyEvent::SavedChanged {
                        uri,
                        saved,
                        request_id,
                        result,
                    } => {
                        let stable_key = format!("spotify:{uri}");
                        match self.state.provider_library.accept_changed(
                            &stable_key,
                            request_id,
                            result,
                        ) {
                            Ok(liked) => {
                                tracing::info!(track = %uri, "Spotify track {}", if liked { "liked" } else { "unliked" });
                                self.state.spotify.toast_success(if liked {
                                    "Added to your Spotify Liked Songs"
                                } else {
                                    "Removed from your Spotify Liked Songs"
                                });
                                self.state.spotify.load_liked(&self.spotify_runtime, 0);
                            }
                            Err(error) => self
                                .state
                                .spotify
                                .toast_error(provider_like_error("Spotify", &error)),
                        }
                        let _ = saved;
                    }
                    _ => {}
                }
            }
            if account_changed {
                self.state
                    .provider_library
                    .invalidate_provider(crate::catalog::TrackProvider::Spotify);
            }
            if ended
                && self
                    .crossfade
                    .as_ref()
                    .is_none_or(|phase| phase.from() != TrackProvider::Spotify)
            {
                self.state.autoplay.track_finished(
                    self.settings.playback.autoplay_similar,
                    self.settings.playback.repeat,
                    &mut self.state.spotify,
                    &mut self.state.soundcloud,
                    &self.spotify_runtime,
                    &self.soundcloud_runtime,
                );
            }
            if let Some(key) = playback_started.as_deref() {
                self.note_playback_started(key);
            }
            if let Some(key) = playback_failed {
                self.recover_failed_playback(key);
            }
        }
    }

    fn poll_soundcloud(&mut self, context: &egui::Context) {
        let events: Vec<_> = self.soundcloud_runtime.drain().collect();
        for event in events {
            let suppress_crossfade_playback = matches!(&event, SoundCloudEvent::PlaybackChanged(_))
                && self.crossfade.as_ref().is_some_and(|phase| {
                    phase.is_cross_provider() && phase.from() == TrackProvider::SoundCloud
                });
            if suppress_crossfade_playback {
                continue;
            }
            let logged_in = matches!(&event, SoundCloudEvent::LoggedIn(_));
            let account_changed = matches!(
                &event,
                SoundCloudEvent::LoggedIn(_) | SoundCloudEvent::LoggedOut
            );
            let ended = matches!(&event, SoundCloudEvent::PlaybackChanged(update) if update.ended);
            let playback_started = match &event {
                SoundCloudEvent::PlaybackChanged(update)
                    if update.status == PlaybackStatus::Playing =>
                {
                    update.track.as_ref().map(TrackRow::stable_key)
                }
                _ => None,
            };
            let playback_failed = match &event {
                SoundCloudEvent::PlaybackChanged(update)
                    if matches!(update.status, PlaybackStatus::Error(_)) =>
                {
                    update.track.as_ref().map(TrackRow::stable_key)
                }
                _ => None,
            };
            let playback_error = match &event {
                SoundCloudEvent::PlaybackChanged(update) => match &update.status {
                    crate::spotify::PlaybackStatus::Error(error) => Some(error.message.clone()),
                    _ => None,
                },
                _ => None,
            };
            let image_event = self.state.soundcloud.handle_event(event);
            if let Some(error) = playback_error {
                self.state.spotify.toast_error(error);
            }
            if logged_in {
                self.state
                    .soundcloud
                    .search_edited(&self.state.search_query);
            }
            if let Some(image_event) = image_event {
                match image_event {
                    SoundCloudEvent::AvatarFinished { url, result } => match result {
                        Ok(image) => self.soundcloud_avatar.insert(context, url, image),
                        Err(error) => {
                            tracing::warn!(%error, "SoundCloud avatar could not be loaded");
                            self.soundcloud_avatar.fail(url);
                        }
                    },
                    SoundCloudEvent::ArtworkFinished { url, result } => match result {
                        Ok(image) => self.covers.insert_soundcloud(context, url, image),
                        Err(error) => {
                            tracing::warn!(%error, "SoundCloud artwork could not be loaded");
                            self.covers.fail(url);
                        }
                    },
                    SoundCloudEvent::RecommendationsFinished { generation, result } => {
                        self.state.autoplay.accept_recommendations(
                            crate::catalog::TrackProvider::SoundCloud,
                            generation,
                            result,
                        );
                    }
                    SoundCloudEvent::LikedStateLoaded {
                        stable_key,
                        request_id,
                        result,
                    } => {
                        if let Err(error) = self.state.provider_library.accept_loaded(
                            &stable_key,
                            request_id,
                            result,
                        ) {
                            tracing::warn!(reason = %error, "Like request failed");
                        }
                    }
                    SoundCloudEvent::LikedChanged {
                        stable_key,
                        liked,
                        request_id,
                        result,
                    } => {
                        match self.state.provider_library.accept_changed(
                            &stable_key,
                            request_id,
                            result,
                        ) {
                            Ok(saved) => {
                                tracing::info!(track = %stable_key, "SoundCloud track {}", if saved { "liked" } else { "unliked" });
                                self.state.spotify.toast_success(if saved {
                                    "Liked on SoundCloud"
                                } else {
                                    "Removed from SoundCloud Likes"
                                });
                                self.state
                                    .soundcloud
                                    .load_likes(&self.soundcloud_runtime, false);
                            }
                            Err(error) => self
                                .state
                                .spotify
                                .toast_error(provider_like_error("SoundCloud", &error)),
                        }
                        let _ = liked;
                    }
                    _ => {}
                }
            }
            if account_changed {
                self.state
                    .provider_library
                    .invalidate_provider(crate::catalog::TrackProvider::SoundCloud);
            }
            if ended
                && self
                    .crossfade
                    .as_ref()
                    .is_none_or(|phase| phase.from() != TrackProvider::SoundCloud)
            {
                self.state.autoplay.track_finished(
                    self.settings.playback.autoplay_similar,
                    self.settings.playback.repeat,
                    &mut self.state.spotify,
                    &mut self.state.soundcloud,
                    &self.spotify_runtime,
                    &self.soundcloud_runtime,
                );
            }
            if let Some(key) = playback_started.as_deref() {
                self.note_playback_started(key);
            }
            if let Some(key) = playback_failed {
                self.recover_failed_playback(key);
            }
        }
    }

    fn active_playback(&self) -> (Option<TrackRow>, PlaybackStatus, u32) {
        if let Some(phase) = self.crossfade.as_ref() {
            let target = self.playback_for_provider(phase.to());
            if target.0.is_some() {
                return target;
            }
        }
        if self.state.soundcloud.playback.track.is_some() {
            self.playback_for_provider(TrackProvider::SoundCloud)
        } else {
            self.playback_for_provider(TrackProvider::Spotify)
        }
    }

    fn playback_for_provider(
        &self,
        provider: TrackProvider,
    ) -> (Option<TrackRow>, PlaybackStatus, u32) {
        match provider {
            TrackProvider::Spotify => (
                self.state
                    .spotify
                    .playback
                    .track
                    .as_ref()
                    .map(TrackRow::from_spotify),
                self.state.spotify.playback.status.clone(),
                self.state.spotify.playback.displayed_position_ms(),
            ),
            TrackProvider::SoundCloud => (
                self.state.soundcloud.playback.track.clone(),
                self.state.soundcloud.playback.status.clone(),
                self.state.soundcloud.playback.displayed_position_ms(),
            ),
        }
    }

    fn provider_track_key(&self, provider: TrackProvider) -> Option<String> {
        self.playback_for_provider(provider)
            .0
            .map(|track| track.stable_key())
    }

    fn provider_seek_preview(&self, provider: TrackProvider) -> Option<u32> {
        match provider {
            TrackProvider::Spotify => self.state.spotify.playback.seek_preview_ms,
            TrackProvider::SoundCloud => self.state.soundcloud.playback.seek_preview_ms,
        }
    }

    fn cancel_crossfade_for_transport(&mut self, phase: &CrossfadePhase) {
        if phase.from() == phase.to() {
            // Same-provider fades share one decoder. A manual seek/selection
            // should never stop that decoder; simply restore full gain.
            self.set_provider_volume(phase.from(), self.settings.audio.master_volume);
            self.crossfade = None;
            tracing::debug!("Same-provider transition cancelled by manual transport change");
            return;
        }

        let selected_provider = self
            .state
            .autoplay
            .snapshot()
            .current
            .map(|item| item.track.provider);
        match selected_provider {
            Some(provider) if provider == phase.to() => self.stop_provider(phase.from()),
            Some(provider) if provider == phase.from() => self.stop_provider(phase.to()),
            _ => {
                self.stop_provider(phase.from());
                self.stop_provider(phase.to());
            }
        }
        self.set_provider_volume(phase.from(), self.settings.audio.master_volume);
        self.set_provider_volume(phase.to(), self.settings.audio.master_volume);
        self.crossfade = None;
        tracing::debug!("Crossfade cancelled by manual transport change");
    }

    fn hide_provider_playback(&mut self, provider: TrackProvider) {
        match provider {
            TrackProvider::Spotify => {
                self.state.spotify.playback = crate::state::PlaybackView::default();
            }
            TrackProvider::SoundCloud => {
                self.state.soundcloud.playback =
                    crate::soundcloud::SoundCloudPlaybackView::default();
            }
        }
    }

    fn stop_provider(&mut self, provider: TrackProvider) {
        match provider {
            TrackProvider::Spotify => self.state.spotify.stop_playback(&self.spotify_runtime),
            TrackProvider::SoundCloud => self
                .state
                .soundcloud
                .stop_playback(&self.soundcloud_runtime),
        }
    }

    fn set_provider_volume(&mut self, provider: TrackProvider, volume: f32) {
        match provider {
            TrackProvider::Spotify => self.state.spotify.set_volume(&self.spotify_runtime, volume),
            TrackProvider::SoundCloud => self
                .state
                .soundcloud
                .set_volume(&self.soundcloud_runtime, volume),
        }
    }

    fn toggle_provider(&mut self, provider: TrackProvider) {
        match provider {
            TrackProvider::Spotify => self.state.spotify.toggle_playback(&self.spotify_runtime),
            TrackProvider::SoundCloud => self
                .state
                .soundcloud
                .toggle_playback(&self.soundcloud_runtime),
        }
    }

    fn request_playback_toggle(&mut self, context: &egui::Context) {
        if self.crossfade.is_some() {
            self.finish_crossfade_now();
        }
        if self.pause_fade.is_some() {
            return;
        }
        let (track, status, _) = self.active_playback();
        let Some(provider) = track.map(|track| track.provider) else {
            return;
        };
        let duration = Duration::from_millis(u64::from(
            self.settings.playback.pause_fade_ms.clamp(100, 300),
        ));
        match status {
            PlaybackStatus::Playing => {
                self.pause_fade = Some(PauseFadePhase::Out {
                    provider,
                    started: Instant::now(),
                    duration,
                });
            }
            PlaybackStatus::Paused => {
                self.set_provider_volume(provider, 0.0);
                self.toggle_provider(provider);
                self.pause_fade = Some(PauseFadePhase::In {
                    provider,
                    started: Instant::now(),
                    duration,
                });
            }
            _ => return,
        }
        context.request_repaint();
    }

    fn tick_pause_fade(&mut self, context: &egui::Context) {
        let Some(phase) = self.pause_fade.clone() else {
            return;
        };
        let (provider, started, duration, fading_out) = match phase {
            PauseFadePhase::Out {
                provider,
                started,
                duration,
            } => (provider, started, duration, true),
            PauseFadePhase::In {
                provider,
                started,
                duration,
            } => (provider, started, duration, false),
        };
        let active_provider = self.active_playback().0.map(|track| track.provider);
        if active_provider != Some(provider) {
            self.state
                .spotify
                .set_volume(&self.spotify_runtime, self.settings.audio.master_volume);
            self.state
                .soundcloud
                .set_volume(&self.soundcloud_runtime, self.settings.audio.master_volume);
            self.pause_fade = None;
            return;
        }
        let progress = (started.elapsed().as_secs_f32() / duration.as_secs_f32()).clamp(0.0, 1.0);
        let gain = if fading_out { 1.0 - progress } else { progress };
        self.set_provider_volume(provider, self.settings.audio.master_volume * gain);
        if progress >= 1.0 {
            if fading_out {
                self.toggle_provider(provider);
            }
            self.set_provider_volume(provider, self.settings.audio.master_volume);
            self.pause_fade = None;
        } else {
            context.request_repaint_after(Duration::from_millis(16));
        }
    }

    fn request_next_transition(&mut self, context: &egui::Context) {
        if self.crossfade.is_some() {
            self.finish_crossfade_now();
        }
        if let Some(phase) = self.pause_fade.take() {
            let provider = match phase {
                PauseFadePhase::Out { provider, .. } | PauseFadePhase::In { provider, .. } => {
                    provider
                }
            };
            self.set_provider_volume(provider, self.settings.audio.master_volume);
        }

        let (track, status, position_ms) = self.active_playback();
        let Some(track) = track else {
            self.state.autoplay.next(
                position_ms,
                self.settings.playback.autoplay_similar,
                self.settings.playback.repeat,
                &mut self.state.spotify,
                &mut self.state.soundcloud,
                &self.spotify_runtime,
                &self.soundcloud_runtime,
            );
            return;
        };

        if status != PlaybackStatus::Playing
            || self.settings.playback.crossfade_seconds == 0
            || self.settings.playback.repeat == crate::settings::RepeatMode::Track
        {
            self.state.autoplay.next(
                position_ms,
                self.settings.playback.autoplay_similar,
                self.settings.playback.repeat,
                &mut self.state.spotify,
                &mut self.state.soundcloud,
                &self.spotify_runtime,
                &self.soundcloud_runtime,
            );
            return;
        }

        let Some(next) = self.state.autoplay.next_candidate(
            self.settings.playback.autoplay_similar,
            self.settings.playback.repeat,
        ) else {
            self.state.autoplay.next(
                position_ms,
                self.settings.playback.autoplay_similar,
                self.settings.playback.repeat,
                &mut self.state.spotify,
                &mut self.state.soundcloud,
                &self.spotify_runtime,
                &self.soundcloud_runtime,
            );
            return;
        };

        let configured_ms = u32::from(self.settings.playback.crossfade_seconds) * 1_000;
        if next.provider == track.provider {
            let half_ms = (configured_ms / 2).max(120);
            self.crossfade = Some(CrossfadePhase::SameProviderOut {
                provider: track.provider,
                target_key: next.stable_key(),
                started: Instant::now(),
                duration: Duration::from_millis(u64::from(half_ms)),
                position_ms,
            });
            tracing::info!(
                provider = ?track.provider,
                seconds = self.settings.playback.crossfade_seconds,
                "Manual Next smooth transition started"
            );
            context.request_repaint_after(Duration::from_millis(16));
            return;
        }

        let configured = Duration::from_millis(u64::from(configured_ms));
        if let Some((from, to, target_key)) = self.state.autoplay.start_crossfade_next(
            position_ms,
            false,
            self.settings.playback.autoplay_similar,
            self.settings.playback.repeat,
            &mut self.state.spotify,
            &mut self.state.soundcloud,
            &self.spotify_runtime,
            &self.soundcloud_runtime,
        ) {
            self.hide_provider_playback(from);
            self.crossfade = Some(CrossfadePhase::CrossProviderPending {
                from,
                to,
                target_key,
                configured,
                armed_at: Instant::now(),
                remaining_at_start: configured_ms,
                retries: 0,
            });
            tracing::info!(
                ?from,
                ?to,
                seconds = self.settings.playback.crossfade_seconds,
                "Manual Next cross-provider transition started"
            );
            context.request_repaint_after(Duration::from_millis(16));
        }
    }

    fn maybe_start_crossfade(&mut self, context: &egui::Context) {
        if self.crossfade.is_some()
            || self.pause_fade.is_some()
            || self.settings.playback.crossfade_seconds == 0
            || self.settings.playback.repeat == crate::settings::RepeatMode::Track
        {
            return;
        }

        let (track, status, position_ms) = self.active_playback();
        let Some(track) = track else {
            return;
        };
        if status != PlaybackStatus::Playing {
            return;
        }

        let Some(next) = self.state.autoplay.next_candidate(
            self.settings.playback.autoplay_similar,
            self.settings.playback.repeat,
        ) else {
            return;
        };

        let duration_ms = track.duration_ms.min(u64::from(u32::MAX)) as u32;
        let remaining_ms = duration_ms.saturating_sub(position_ms);
        if remaining_ms == 0 {
            return;
        }

        let configured_ms = u32::from(self.settings.playback.crossfade_seconds) * 1_000;

        if next.provider == track.provider {
            // One provider backend owns one decoder/output stream. We therefore
            // use half of the configured transition before the switch and half
            // after it. This makes the setting audible for the common
            // Spotify->Spotify and SoundCloud->SoundCloud cases instead of
            // silently doing nothing.
            let half_ms = (configured_ms / 2).max(120);
            if remaining_ms > half_ms {
                return;
            }
            let target_key = next.stable_key();
            self.crossfade = Some(CrossfadePhase::SameProviderOut {
                provider: track.provider,
                target_key,
                started: Instant::now(),
                duration: Duration::from_millis(u64::from(half_ms)),
                position_ms,
            });
            tracing::info!(
                provider = ?track.provider,
                seconds = self.settings.playback.crossfade_seconds,
                "Same-provider smooth transition armed"
            );
            context.request_repaint_after(Duration::from_millis(16));
            return;
        }

        if remaining_ms > configured_ms {
            return;
        }
        let configured = Duration::from_millis(u64::from(configured_ms));
        if let Some((from, to, target_key)) = self.state.autoplay.start_crossfade_next(
            position_ms,
            true,
            self.settings.playback.autoplay_similar,
            self.settings.playback.repeat,
            &mut self.state.spotify,
            &mut self.state.soundcloud,
            &self.spotify_runtime,
            &self.soundcloud_runtime,
        ) {
            self.hide_provider_playback(from);
            self.crossfade = Some(CrossfadePhase::CrossProviderPending {
                from,
                to,
                target_key,
                configured,
                armed_at: Instant::now(),
                remaining_at_start: remaining_ms,
                retries: 0,
            });
            tracing::info!(
                ?from,
                ?to,
                seconds = self.settings.playback.crossfade_seconds,
                "Equal-power cross-provider crossfade armed"
            );
            context.request_repaint_after(Duration::from_millis(16));
        }
    }

    fn tick_crossfade(&mut self, context: &egui::Context) {
        let Some(phase) = self.crossfade.clone() else {
            return;
        };

        match phase {
            CrossfadePhase::CrossProviderPending {
                from,
                to,
                target_key,
                configured,
                armed_at,
                remaining_at_start,
                retries,
            } => {
                if self.provider_track_key(to).as_deref() != Some(target_key.as_str())
                    || self.provider_seek_preview(to).is_some()
                {
                    self.cancel_crossfade_for_transport(&CrossfadePhase::CrossProviderPending {
                        from,
                        to,
                        target_key,
                        configured,
                        armed_at,
                        remaining_at_start,
                        retries,
                    });
                    return;
                }

                let (_, target_status, _) = self.playback_for_provider(to);
                if matches!(target_status, PlaybackStatus::Error(_)) {
                    // Keep the source audible while the target gets one retry.
                    // Previously the failed target caused the source provider to
                    // be stopped immediately, which could leave Radio/Vibe silent.
                    self.set_provider_volume(from, self.settings.audio.master_volume);
                    if retries == 0
                        && self.state.autoplay.retry_current_overlap(
                            &mut self.state.spotify,
                            &mut self.state.soundcloud,
                            &self.spotify_runtime,
                            &self.soundcloud_runtime,
                        )
                    {
                        self.crossfade = Some(CrossfadePhase::CrossProviderPending {
                            from,
                            to,
                            target_key,
                            configured,
                            armed_at: Instant::now(),
                            remaining_at_start,
                            retries: 1,
                        });
                        context.request_repaint_after(Duration::from_millis(16));
                        return;
                    }

                    self.stop_provider(to);
                    self.crossfade = None;
                    tracing::warn!(
                        ?from,
                        ?to,
                        "Cross-provider target failed after retry; advancing queue"
                    );
                    self.state.autoplay.next(
                        0,
                        self.settings.playback.autoplay_similar,
                        self.settings.playback.repeat,
                        &mut self.state.spotify,
                        &mut self.state.soundcloud,
                        &self.spotify_runtime,
                        &self.soundcloud_runtime,
                    );
                    return;
                }
                if target_status == PlaybackStatus::Playing {
                    let configured_ms = configured.as_millis().min(u128::from(u32::MAX)) as u32;
                    let elapsed_ms =
                        armed_at.elapsed().as_millis().min(u128::from(u32::MAX)) as u32;
                    let remaining = remaining_at_start.saturating_sub(elapsed_ms);
                    let actual_ms = remaining.min(configured_ms).max(180);
                    self.crossfade = Some(CrossfadePhase::CrossProviderRunning {
                        from,
                        to,
                        target_key,
                        started: Instant::now(),
                        duration: Duration::from_millis(u64::from(actual_ms)),
                    });
                    context.request_repaint();
                } else {
                    context.request_repaint_after(Duration::from_millis(16));
                }
            }
            CrossfadePhase::CrossProviderRunning {
                from,
                to,
                target_key,
                started,
                duration,
            } => {
                if self.provider_track_key(to).as_deref() != Some(target_key.as_str())
                    || self.provider_seek_preview(to).is_some()
                {
                    self.cancel_crossfade_for_transport(&CrossfadePhase::CrossProviderRunning {
                        from,
                        to,
                        target_key,
                        started,
                        duration,
                    });
                    return;
                }

                let progress =
                    (started.elapsed().as_secs_f32() / duration.as_secs_f32()).clamp(0.0, 1.0);
                let theta = progress * std::f32::consts::FRAC_PI_2;
                let from_gain = theta.cos();
                let to_gain = theta.sin();
                self.set_provider_volume(from, self.settings.audio.master_volume * from_gain);
                self.set_provider_volume(to, self.settings.audio.master_volume * to_gain);

                if progress >= 1.0 {
                    self.stop_provider(from);
                    self.set_provider_volume(from, self.settings.audio.master_volume);
                    self.set_provider_volume(to, self.settings.audio.master_volume);
                    self.crossfade = None;
                    tracing::info!(?from, ?to, "Equal-power cross-provider crossfade completed");
                } else {
                    context.request_repaint_after(Duration::from_millis(16));
                }
            }
            CrossfadePhase::SameProviderOut {
                provider,
                target_key,
                started,
                duration,
                position_ms,
            } => {
                if self.provider_seek_preview(provider).is_some() {
                    self.cancel_crossfade_for_transport(&CrossfadePhase::SameProviderOut {
                        provider,
                        target_key,
                        started,
                        duration,
                        position_ms,
                    });
                    return;
                }

                let progress =
                    (started.elapsed().as_secs_f32() / duration.as_secs_f32()).clamp(0.0, 1.0);
                let gain = (progress * std::f32::consts::FRAC_PI_2).cos();
                self.set_provider_volume(provider, self.settings.audio.master_volume * gain);

                if progress >= 1.0 {
                    self.set_provider_volume(provider, 0.0);
                    let current_position = self.playback_for_provider(provider).2.max(position_ms);
                    self.state.autoplay.next(
                        current_position,
                        self.settings.playback.autoplay_similar,
                        self.settings.playback.repeat,
                        &mut self.state.spotify,
                        &mut self.state.soundcloud,
                        &self.spotify_runtime,
                        &self.soundcloud_runtime,
                    );
                    self.crossfade = Some(CrossfadePhase::SameProviderPendingIn {
                        provider,
                        target_key,
                        armed_at: Instant::now(),
                        duration,
                    });
                    tracing::debug!(
                        ?provider,
                        "Same-provider transition switched track at zero gain"
                    );
                    context.request_repaint_after(Duration::from_millis(16));
                } else {
                    context.request_repaint_after(Duration::from_millis(16));
                }
            }
            CrossfadePhase::SameProviderPendingIn {
                provider,
                target_key,
                armed_at,
                duration,
            } => {
                if self.provider_seek_preview(provider).is_some() {
                    self.cancel_crossfade_for_transport(&CrossfadePhase::SameProviderPendingIn {
                        provider,
                        target_key,
                        armed_at,
                        duration,
                    });
                    return;
                }

                let current_key = self.provider_track_key(provider);
                let (_, status, _) = self.playback_for_provider(provider);
                if current_key.as_deref() == Some(target_key.as_str())
                    && status == PlaybackStatus::Playing
                {
                    self.set_provider_volume(provider, 0.0);
                    self.crossfade = Some(CrossfadePhase::SameProviderIn {
                        provider,
                        target_key,
                        started: Instant::now(),
                        duration,
                    });
                    context.request_repaint();
                } else if armed_at.elapsed() > Duration::from_secs(8) {
                    self.set_provider_volume(provider, self.settings.audio.master_volume);
                    self.crossfade = None;
                    tracing::warn!(
                        ?provider,
                        "Same-provider transition timed out waiting for next track"
                    );
                } else {
                    context.request_repaint_after(Duration::from_millis(16));
                }
            }
            CrossfadePhase::SameProviderIn {
                provider,
                target_key,
                started,
                duration,
            } => {
                if self.provider_track_key(provider).as_deref() != Some(target_key.as_str())
                    || self.provider_seek_preview(provider).is_some()
                {
                    self.cancel_crossfade_for_transport(&CrossfadePhase::SameProviderIn {
                        provider,
                        target_key,
                        started,
                        duration,
                    });
                    return;
                }

                let progress =
                    (started.elapsed().as_secs_f32() / duration.as_secs_f32()).clamp(0.0, 1.0);
                let gain = (progress * std::f32::consts::FRAC_PI_2).sin();
                self.set_provider_volume(provider, self.settings.audio.master_volume * gain);
                if progress >= 1.0 {
                    self.set_provider_volume(provider, self.settings.audio.master_volume);
                    self.crossfade = None;
                    tracing::info!(?provider, "Same-provider smooth transition completed");
                } else {
                    context.request_repaint_after(Duration::from_millis(16));
                }
            }
        }
    }

    fn finish_crossfade_now(&mut self) {
        let Some(phase) = self.crossfade.take() else {
            return;
        };
        if phase.from() != phase.to() {
            self.stop_provider(phase.from());
        }
        self.set_provider_volume(phase.from(), self.settings.audio.master_volume);
        self.set_provider_volume(phase.to(), self.settings.audio.master_volume);
    }

    fn prefetch_next_audio(&mut self) {
        if self.settings.playback.repeat == crate::settings::RepeatMode::Track {
            self.last_prefetched_key = None;
            return;
        }
        if !self.settings.playback.gapless_enabled && self.settings.playback.crossfade_seconds == 0
        {
            self.last_prefetched_key = None;
            return;
        }
        let next = self.state.autoplay.next_candidate(
            self.settings.playback.autoplay_similar,
            self.settings.playback.repeat,
        );
        let Some(track) = next else {
            self.last_prefetched_key = None;
            return;
        };
        let key = track.stable_key();
        if self.last_prefetched_key.as_deref() == Some(key.as_str()) {
            return;
        }

        match track.provider {
            TrackProvider::Spotify => {
                if let Some(track) = track.to_spotify_track() {
                    let _ = self
                        .spotify_runtime
                        .send(SpotifyCommand::PreloadTrack { uri: track.uri });
                }
            }
            TrackProvider::SoundCloud => {
                let _ = self
                    .soundcloud_runtime
                    .send(SoundCloudCommand::PreloadTrack { track });
            }
        }
        self.last_prefetched_key = Some(key);
    }

    fn sync_session(&mut self) -> bool {
        let (track, status, position_ms) = self.active_playback();
        let Some(track) = track else {
            let mut changed = false;
            if let Some(previous) = self.last_played_track.take() {
                self.settings.session.finish_play(
                    &previous.stable_key(),
                    self.last_played_position_ms,
                    previous.duration_ms,
                );
                changed = true;
            }
            self.last_played_position_ms = 0;
            self.last_history_key = None;
            self.last_session_status = PlaybackStatus::Idle;
            return changed;
        };
        let key = track.stable_key();
        let mut changed = false;
        let previous_key = self.last_played_track.as_ref().map(TrackRow::stable_key);
        if previous_key.as_deref() != Some(key.as_str()) {
            if let Some(previous) = self.last_played_track.replace(track.clone()) {
                self.settings.session.finish_play(
                    &previous.stable_key(),
                    self.last_played_position_ms,
                    previous.duration_ms,
                );
            }
            self.last_played_position_ms = position_ms;
            changed = true;
        } else {
            self.last_played_position_ms = self.last_played_position_ms.max(position_ms);
        }
        if status == PlaybackStatus::Playing
            && self.last_history_key.as_deref() != Some(key.as_str())
        {
            self.settings
                .session
                .record_started(&track, chrono::Utc::now().timestamp_millis());
            self.last_history_key = Some(key.clone());
            changed = true;
        }

        let status_changed = status != self.last_session_status;
        if changed
            || status_changed
            || self.last_session_snapshot_at.elapsed() >= Duration::from_secs(5)
        {
            let snapshot = self.state.autoplay.snapshot();
            self.settings.session.resume = Some(crate::settings::ResumeSession {
                current: Some(track),
                position_ms,
                next_up: snapshot
                    .next_up
                    .into_iter()
                    .map(|item| item.track)
                    .collect(),
                autoplay: snapshot
                    .autoplay
                    .into_iter()
                    .map(|item| item.track)
                    .collect(),
                radio_title: self.state.autoplay.radio_title().map(str::to_owned),
            });
            self.last_session_snapshot_at = Instant::now();
            self.last_session_status = status;
            changed = true;
        }
        changed
    }

    fn apply_pending_resume_seek(&mut self) {
        let Some((key, position_ms)) = self.pending_resume_seek.clone() else {
            return;
        };
        let (track, status, _) = self.active_playback();
        if status != PlaybackStatus::Playing
            || track.as_ref().map(TrackRow::stable_key).as_deref() != Some(key.as_str())
        {
            return;
        }
        match track.map(|track| track.provider) {
            Some(TrackProvider::Spotify) => {
                self.state.spotify.seek(&self.spotify_runtime, position_ms)
            }
            Some(TrackProvider::SoundCloud) => self
                .state
                .soundcloud
                .seek(&self.soundcloud_runtime, position_ms),
            None => {}
        }
        self.pending_resume_seek = None;
    }

    #[cfg(target_os = "windows")]
    fn handle_system_transport(
        &mut self,
        context: &egui::Context,
        action: crate::windows_taskbar::TaskbarAction,
    ) {
        let soundcloud_active = self.state.soundcloud.playback.track.is_some();
        let position = if soundcloud_active {
            self.state.soundcloud.playback.displayed_position_ms()
        } else {
            self.state.spotify.playback.displayed_position_ms()
        };
        match (soundcloud_active, action) {
            (_, crate::windows_taskbar::TaskbarAction::Previous) => self.state.autoplay.previous(
                position,
                &mut self.state.spotify,
                &mut self.state.soundcloud,
                &self.spotify_runtime,
                &self.soundcloud_runtime,
            ),
            (_, crate::windows_taskbar::TaskbarAction::Toggle) => {
                self.request_playback_toggle(context)
            }
            (_, crate::windows_taskbar::TaskbarAction::Next) => {
                self.request_next_transition(context)
            }
            (true, crate::windows_taskbar::TaskbarAction::Seek(position_ms)) => self
                .state
                .soundcloud
                .seek(&self.soundcloud_runtime, position_ms),
            (false, crate::windows_taskbar::TaskbarAction::Seek(position_ms)) => {
                self.state.spotify.seek(&self.spotify_runtime, position_ms)
            }
        }
    }

    #[cfg(target_os = "windows")]
    fn poll_system_controls(&mut self, context: &egui::Context) {
        let actions = self.taskbar_rx.try_iter().collect::<Vec<_>>();
        for action in actions {
            self.handle_system_transport(context, action);
        }
        let tray_actions = self
            .tray
            .as_ref()
            .map(crate::windows_tray::WindowsTray::poll)
            .unwrap_or_default();
        for action in tray_actions {
            match action {
                crate::windows_tray::TrayAction::Open => {
                    context.send_viewport_cmd(egui::ViewportCommand::Visible(true));
                    context.send_viewport_cmd(egui::ViewportCommand::Minimized(false));
                    context.send_viewport_cmd(egui::ViewportCommand::Focus);
                }
                crate::windows_tray::TrayAction::Transport(action) => {
                    self.handle_system_transport(context, action)
                }
                crate::windows_tray::TrayAction::Exit => {
                    context.send_viewport_cmd(egui::ViewportCommand::Close)
                }
            }
        }
    }

    #[cfg(target_os = "windows")]
    fn playing(&self) -> bool {
        if self.state.soundcloud.playback.track.is_some() {
            self.state.soundcloud.playback.status == crate::spotify::PlaybackStatus::Playing
        } else {
            self.state.spotify.playback.status == crate::spotify::PlaybackStatus::Playing
        }
    }

    #[cfg(target_os = "windows")]
    fn media_snapshot(&self) -> crate::windows_media::MediaSnapshot {
        use crate::{spotify::PlaybackStatus, windows_media::MediaStatus};

        let soundcloud_active = self.state.soundcloud.playback.track.is_some();
        let (track, status, position_ms) = if soundcloud_active {
            (
                self.state.soundcloud.playback.track.clone(),
                &self.state.soundcloud.playback.status,
                self.state.soundcloud.playback.displayed_position_ms(),
            )
        } else {
            (
                self.state
                    .spotify
                    .playback
                    .track
                    .as_ref()
                    .map(crate::catalog::TrackRow::from_spotify),
                &self.state.spotify.playback.status,
                self.state.spotify.playback.displayed_position_ms(),
            )
        };
        let status = match status {
            PlaybackStatus::Idle => MediaStatus::Idle,
            PlaybackStatus::Connecting | PlaybackStatus::Authorizing | PlaybackStatus::Loading => {
                MediaStatus::Changing
            }
            PlaybackStatus::Playing => MediaStatus::Playing,
            PlaybackStatus::Paused => MediaStatus::Paused,
            PlaybackStatus::Error(_) => MediaStatus::Error,
        };
        let has_next = self
            .state
            .autoplay
            .has_next(self.settings.playback.autoplay_similar);
        crate::windows_media::MediaSnapshot {
            key: track.as_ref().map(crate::catalog::TrackRow::stable_key),
            title: track
                .as_ref()
                .map(|track| track.title.clone())
                .unwrap_or_default(),
            artist: track
                .as_ref()
                .map(|track| track.artist.clone())
                .unwrap_or_default(),
            album: track
                .as_ref()
                .map(|track| track.collection.clone())
                .unwrap_or_default(),
            artwork_url: track.as_ref().and_then(|track| track.artwork_url.clone()),
            duration_ms: track.as_ref().map_or(0, |track| track.duration_ms),
            position_ms,
            status,
            has_previous: track.is_some(),
            has_next,
            shuffle: self.settings.playback.shuffle,
            repeat: self.settings.playback.repeat,
        }
    }
}

impl eframe::App for SpoteqApp {
    fn logic(&mut self, context: &egui::Context, _frame: &mut eframe::Frame) {
        tracing::debug!("[UI] App::update entered");
        // eframe also calls logic while the native window is hidden/minimized.
        // This keeps playback state and the Windows thumbnail controls alive
        // without requiring Spoteq to be restored.
        self.poll_writer();
        self.poll_spotify(context);
        self.poll_soundcloud(context);
        self.trace_auth_state();
        self.apply_pending_resume_seek();
        self.tick_pause_fade(context);
        if self.sync_session() {
            self.schedule_save();
        }
        if self.state.page == crate::state::MusicPage::SmartLibrary {
            self.state.smart_library_cache.refresh(
                self.state.smart_playlist,
                &self.settings.session,
                &self.state.spotify,
                &self.state.soundcloud,
            );
        }
        for track in &self.state.spotify.liked.tracks {
            self.state
                .provider_library
                .observe(&crate::catalog::TrackRow::from_spotify(track));
        }
        for track in &self.state.soundcloud.likes.tracks {
            self.state.provider_library.observe(track);
        }
        let current_track = self.state.soundcloud.playback.track.clone().or_else(|| {
            self.state
                .spotify
                .playback
                .track
                .as_ref()
                .map(crate::catalog::TrackRow::from_spotify)
        });
        self.state.provider_library.ensure_current(
            current_track.as_ref(),
            &self.spotify_runtime,
            &self.soundcloud_runtime,
        );
        self.state
            .autoplay
            .set_shuffle(self.settings.playback.shuffle);
        self.state.autoplay.prefetch_if_needed(
            self.settings.playback.autoplay_similar,
            self.state.spotify.is_authenticated(),
            self.state.soundcloud.is_authenticated(),
            &self.spotify_runtime,
            &self.soundcloud_runtime,
        );
        self.state.autoplay.resume_if_ready(
            &mut self.state.spotify,
            &mut self.state.soundcloud,
            &self.spotify_runtime,
            &self.soundcloud_runtime,
        );
        self.prefetch_next_audio();
        self.maybe_start_crossfade(context);
        self.tick_crossfade(context);
        #[cfg(target_os = "windows")]
        self.poll_system_controls(context);

        #[cfg(target_os = "windows")]
        {
            let playing = self.playing();
            let media_snapshot = self.media_snapshot();
            if let Some(controls) = self.taskbar_controls.as_mut() {
                controls.sync(context, playing);
            }
            if let Some(tray) = self.tray.as_mut() {
                tray.sync(playing);
            }
            if let Some(session) = self.media_session.as_mut() {
                session.sync(&media_snapshot);
            }
        }
    }

    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        tracing::debug!("[UI] App::ui entered");
        if let Some(remaining) = self.state.spotify.update_toast() {
            ui.ctx().request_repaint_after(remaining);
        }
        let spotify_was_debouncing = self.state.search_filter.includes_spotify()
            && self.state.spotify.search.status == crate::state::SearchStatus::Debouncing;
        let soundcloud_was_debouncing = self.state.search_filter.includes_soundcloud()
            && self.state.soundcloud.search.status
                == crate::soundcloud::SoundCloudSearchStatus::Debouncing;
        if self.state.search_filter.includes_spotify() {
            self.state.spotify.dispatch_search(
                &self.state.search_query,
                self.state.search_scope,
                &self.spotify_runtime,
            );
        }
        if self.state.search_filter.includes_soundcloud() {
            self.state
                .soundcloud
                .dispatch_search(&self.state.search_query, &self.soundcloud_runtime);
        }
        if self.state.library_filter.includes_spotify() {
            self.state
                .spotify
                .ensure_liked_loaded(&self.spotify_runtime);
        }
        if self.state.library_filter.includes_soundcloud() {
            self.state
                .soundcloud
                .ensure_likes_loaded(&self.soundcloud_runtime);
        }

        let search_dispatched = (spotify_was_debouncing
            && self.state.spotify.search.status == crate::state::SearchStatus::Loading)
            || (soundcloud_was_debouncing
                && self.state.soundcloud.search.status
                    == crate::soundcloud::SoundCloudSearchStatus::Loading);
        let history_changed = search_dispatched
            && self
                .settings
                .search_history
                .record_query(&self.state.search_query);

        let previous_query = self.state.search_query.clone();
        let previous_search_filter = self.state.search_filter;
        let previous_search_scope = self.state.search_scope;
        let previous_dsp = DspSettings::from(&self.settings.audio);
        let previous_output = self.settings.audio.output_device.clone();
        let previous_appearance = self.settings.appearance.clone();

        let mut toggle_playback_requested = false;
        let previous_page = self.state.page;
        let settings_changed = ui::root::show(
            ui,
            &mut self.state,
            &mut self.settings,
            self.settings_store.path(),
            self.persistence_message.as_deref(),
            &mut self.covers,
            &self.spotify_runtime,
            &self.soundcloud_runtime,
            &self.soundcloud_avatar,
            &mut toggle_playback_requested,
        );
        if self.state.page != previous_page {
            tracing::info!(from = ?previous_page, to = ?self.state.page, "[UI] navigation selection");
        }

        ui::mini_player::show(
            ui.ctx(),
            &mut self.state.mini_player_open,
            &mut self.state.spotify,
            &mut self.state.soundcloud,
            &mut self.state.autoplay,
            &mut self.state.provider_library,
            &mut self.covers,
            &self.spotify_runtime,
            &self.soundcloud_runtime,
            &self.settings.playback,
            &self.settings.session,
            &mut self.state.queue_open,
            &mut toggle_playback_requested,
        );

        if let Some(request) = ui::transport_request::take(ui.ctx()) {
            match request {
                ui::transport_request::TransportRequest::Next => {
                    self.request_next_transition(ui.ctx());
                }
            }
        }

        if let Some(request) = ui::radio_request::take(ui.ctx()) {
            self.state.autoplay.start_radio(
                request.seed,
                request.kind,
                &mut self.state.spotify,
                &mut self.state.soundcloud,
                &self.spotify_runtime,
                &self.soundcloud_runtime,
            );
        }

        if let Some(session) = ui::session_request::take(ui.ctx())
            && let Some(key) = self.state.autoplay.resume_session(
                &session,
                &mut self.state.spotify,
                &mut self.state.soundcloud,
                &self.spotify_runtime,
                &self.soundcloud_runtime,
            )
        {
            self.pending_resume_seek = Some((key, session.position_ms));
        }
        if toggle_playback_requested {
            self.request_playback_toggle(ui.ctx());
        }

        if self.state.search_query != previous_query {
            self.state.spotify.search_edited(&self.state.search_query);
            self.state
                .soundcloud
                .search_edited(&self.state.search_query);
        }
        if self.state.search_filter != previous_search_filter
            && self.state.search_filter.includes_soundcloud()
        {
            self.state
                .soundcloud
                .search_edited(&self.state.search_query);
        }
        if self.state.search_scope != previous_search_scope {
            self.state.spotify.search_edited(&self.state.search_query);
            self.state
                .soundcloud
                .search_edited(&self.state.search_query);
        }
        let current_dsp = DspSettings::from(&self.settings.audio);
        if current_dsp != previous_dsp {
            self.spotify_runtime.apply_dsp_settings(&current_dsp);
            ui.ctx().request_repaint();
        }
        if self.settings.audio.output_device != previous_output {
            self.state.soundcloud.set_output_device(
                &self.soundcloud_runtime,
                self.settings.audio.output_device.clone(),
            );
        }
        if self.settings.appearance != previous_appearance {
            ui::theme::apply_appearance(ui.ctx(), &self.settings.appearance);
        }
        if self.state.search_filter.includes_spotify()
            && self.state.spotify.is_authenticated()
            && self.state.spotify.search.status == crate::state::SearchStatus::Debouncing
        {
            ui.ctx()
                .request_repaint_after(std::time::Duration::from_millis(50));
        }
        if self.state.search_filter.includes_soundcloud()
            && self.state.soundcloud.is_authenticated()
            && self.state.soundcloud.search.status
                == crate::soundcloud::SoundCloudSearchStatus::Debouncing
        {
            ui.ctx()
                .request_repaint_after(std::time::Duration::from_millis(50));
        }
        if self.state.spotify.playback.status == crate::spotify::PlaybackStatus::Playing
            || self.state.soundcloud.playback.status == crate::spotify::PlaybackStatus::Playing
        {
            ui.ctx()
                .request_repaint_after(std::time::Duration::from_millis(33));
        }

        if settings_changed || history_changed {
            self.schedule_save();
        }
    }
}

fn provider_like_error(provider: &str, error: &str) -> String {
    if error.contains("403") {
        if provider == "Spotify" {
            return "Spotify needs to be reconnected to grant Liked Songs permission.".to_owned();
        }
        return "SoundCloud denied this Like request. Reconnect the account and try again."
            .to_owned();
    }
    if error.contains("401") {
        return format!("{provider} authorization expired. Reconnect the account and try again.");
    }
    if error.contains("429") || error.to_ascii_lowercase().contains("rate limit") {
        return format!("{provider} rate limit reached. Please try again shortly.");
    }
    format!("{provider} Like request failed: {error}")
}

impl Drop for SpoteqApp {
    fn drop(&mut self) {
        let _ = self.sync_session();
        self.settings_writer.shutdown(&self.settings);
    }
}
