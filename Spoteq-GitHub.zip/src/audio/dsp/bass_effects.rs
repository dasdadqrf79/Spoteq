//! Stereo-linked bass dynamics. Only the low band is distorted or compressed.
//! Fixed-size state: no allocation or locks in the per-frame processing path.
use super::{BassToneSettings, BiquadCoefficients, SAMPLE_RATE, StereoBiquad, db_to_gain};

#[derive(Clone)]
pub(super) struct BassEffects {
    settings: BassToneSettings,
    enabled: bool,
    low: StereoBiquad,
    fast: f64,
    slow: f64,
    level: f64,
    dynamic_gain: f64,
    fast_attack: f64,
    fast_release: f64,
    slow_rate: f64,
    level_attack: f64,
    level_release: f64,
    dynamic_attack: f64,
    dynamic_release: f64,
    density_makeup: f64,
}

impl BassEffects {
    pub(super) fn new() -> Self {
        let rate = |ms: f64| 1.0 - (-1.0 / (SAMPLE_RATE * ms / 1000.0)).exp();
        Self {
            settings: BassToneSettings::default(),
            enabled: false,
            low: StereoBiquad::new(BiquadCoefficients::pass(180.0, false)),
            fast: 0.0,
            slow: 0.0,
            level: 0.0,
            dynamic_gain: 1.0,
            fast_attack: rate(2.0),
            fast_release: rate(30.0),
            slow_rate: rate(80.0),
            level_attack: rate(10.0),
            level_release: rate(150.0),
            dynamic_attack: rate(3.0),
            dynamic_release: rate(120.0),
            density_makeup: 1.0,
        }
    }

    pub(super) fn set_settings(&mut self, mut settings: BassToneSettings, enabled: bool) {
        settings.sanitize();
        self.settings = settings;
        self.enabled = enabled;
        self.density_makeup = db_to_gain(4.0 * f64::from(settings.density) / 100.0);
    }

    pub(super) fn process(&mut self, input: [f64; 2]) -> [f64; 2] {
        let s = self.settings;
        if !self.enabled
            || (s.punch == 0.0
                && s.saturation == 0.0
                && s.density == 0.0
                && s.dynamic == 0.0
                && s.width == 100.0
                && !s.mono_bass)
        {
            return input;
        }
        let mut low = [self.low.process(0, input[0]), self.low.process(1, input[1])];
        let high = [input[0] - low[0], input[1] - low[1]];
        // The same detector and gain act on both channels to preserve stereo balance.
        let peak = low[0].abs().max(low[1].abs());
        self.fast += (peak - self.fast)
            * if peak > self.fast {
                self.fast_attack
            } else {
                self.fast_release
            };
        self.slow += (peak - self.slow) * self.slow_rate;
        self.level += (peak - self.level)
            * if peak > self.level {
                self.level_attack
            } else {
                self.level_release
            };
        let transient = ((self.fast - self.slow) / self.slow.max(0.02)).clamp(0.0, 1.0);
        let punch_gain = 1.0 + 0.8 * f64::from(s.punch) / 100.0 * transient;
        let density_gain = if s.density > 0.0 {
            (0.1 / self.level.max(0.1)).powf(0.75 * f64::from(s.density) / 100.0)
                * self.density_makeup
        } else {
            1.0
        };
        let full_peak = input[0].abs().max(input[1].abs());
        let pressure = ((full_peak - 0.5) / full_peak.max(0.5)).clamp(0.0, 1.0);
        let target = 1.0 - 0.85 * f64::from(s.dynamic) / 100.0 * pressure;
        self.dynamic_gain += (target - self.dynamic_gain)
            * if target < self.dynamic_gain {
                self.dynamic_attack
            } else {
                self.dynamic_release
            };
        let amount = f64::from(s.saturation) / 100.0;
        let drive = 1.0 + 10.0 * amount;
        for sample in &mut low {
            *sample *= punch_gain * density_gain * self.dynamic_gain;
            if amount > 0.0 {
                // Odd-symmetric soft saturation adds harmonics without generating DC.
                let saturated = (*sample * drive).tanh() / drive;
                *sample += amount * (saturated - *sample);
            }
        }
        let mid = (high[0] + high[1] + low[0] + low[1]) * 0.5;
        let side = ((high[0] - high[1]) + if s.mono_bass { 0.0 } else { low[0] - low[1] })
            * 0.5
            * f64::from(s.width)
            / 100.0;
        [mid + side, mid - side]
    }
}
