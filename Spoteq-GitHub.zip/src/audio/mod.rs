//! Real-time local audio processing.

pub mod dsp;
