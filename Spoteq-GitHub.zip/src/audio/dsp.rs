//! Lock-free real-time DSP inserted immediately before the output sink.

use std::array;
use std::f64::consts::PI;
use std::sync::atomic::{AtomicBool, AtomicU32, AtomicU64, Ordering};
use std::sync::{Arc, Mutex};

use librespot_playback::{
    audio_backend::{Sink, SinkResult},
    convert::Converter,
    decoder::AudioPacket,
};

use crate::settings::{
    AudioSettings, BASS_BAND_COUNT, BassBand, BassFilterKind, BassStudioSettings, BassToneSettings,
    EQ_BAND_COUNT, EQ_FREQUENCIES_HZ,
};

const SAMPLE_RATE: f64 = librespot_playback::SAMPLE_RATE as f64;
const CHANNELS: usize = librespot_playback::NUM_CHANNELS as usize;
const TONE_FILTER_START: usize = EQ_BAND_COUNT + 2 + BASS_BAND_COUNT;
const FILTER_COUNT: usize = TONE_FILTER_START + 2;
const GRAPHIC_EQ_Q: f64 = 1.4;
const BYPASS_RAMP_SAMPLES: f64 = 882.0;
const PARAMETER_RAMP_SAMPLES: u32 = 882;
const LIMITER_THRESHOLD: f64 = 0.98;

mod bass_effects;
use bass_effects::BassEffects;

/// Copyable parameters consumed by the real-time DSP processor.
#[derive(Debug, Clone, PartialEq)]
pub struct DspSettings {
    /// Enables the complete EQ chain. Disabling it performs an A/B bypass.
    pub enabled: bool,
    /// Gain before the filters, in decibels.
    pub preamp_db: f32,
    /// Low-shelf gain at 45 Hz, in decibels.
    pub sub_bass_db: f32,
    /// Parametric bass gain, in decibels.
    pub bass_gain_db: f32,
    /// Parametric bass center frequency in hertz.
    pub bass_frequency_hz: f32,
    /// Parametric bass Q factor.
    pub bass_q: f32,
    /// Gains for the fixed ten-band graphic equalizer.
    pub eq_db: [f32; EQ_BAND_COUNT],
    pub bass_studio: BassStudioSettings,
}

impl From<&AudioSettings> for DspSettings {
    fn from(audio: &AudioSettings) -> Self {
        let mut eq_db = [0.0; EQ_BAND_COUNT];
        for (target, source) in eq_db.iter_mut().zip(&audio.eq_db) {
            *target = source.clamp(-12.0, 12.0);
        }
        let mut bass_studio = audio.bass_studio.clone();
        for band in &mut bass_studio.bands {
            band.sanitize();
        }
        bass_studio.tone.sanitize();
        Self {
            bass_studio,
            enabled: audio.eq_enabled,
            preamp_db: audio.preamp_db.clamp(-24.0, 6.0),
            sub_bass_db: audio.sub_bass_db.clamp(-12.0, 12.0),
            bass_gain_db: audio.bass_gain_db.clamp(-12.0, 12.0),
            bass_frequency_hz: audio.bass_frequency_hz.clamp(35.0, 180.0),
            bass_q: audio.bass_q.clamp(0.30, 3.00),
            eq_db,
        }
    }
}

/// Atomically published DSP controls shared by the UI actor and audio sink.
pub struct DspControls {
    generation: AtomicU64,
    enabled: AtomicBool,
    preamp_db: AtomicU32,
    sub_bass_db: AtomicU32,
    bass_gain_db: AtomicU32,
    bass_frequency_hz: AtomicU32,
    bass_q: AtomicU32,
    eq_db: [AtomicU32; EQ_BAND_COUNT],
    limiter_prevented_samples: AtomicU64,
    bass_enabled: AtomicBool,
    bass_bypass: AtomicBool,
    bass_bands: [[AtomicU32; 5]; BASS_BAND_COUNT],
    bass_tone: [AtomicU32; 8],
    pre_limiter_peak: AtomicU32,
    output_peak: AtomicU32,
}

impl DspControls {
    /// Creates one lock-free parameter block.
    pub fn new(settings: &DspSettings) -> Arc<Self> {
        Arc::new(Self {
            bass_enabled: AtomicBool::new(settings.bass_studio.enabled),
            bass_bypass: AtomicBool::new(settings.bass_studio.bypass),
            bass_bands: array::from_fn(|i| {
                band_words(settings.bass_studio.bands[i]).map(AtomicU32::new)
            }),
            bass_tone: tone_words(settings.bass_studio.tone).map(AtomicU32::new),
            pre_limiter_peak: AtomicU32::new(0),
            output_peak: AtomicU32::new(0),
            generation: AtomicU64::new(2),
            enabled: AtomicBool::new(settings.enabled),
            preamp_db: AtomicU32::new(settings.preamp_db.to_bits()),
            sub_bass_db: AtomicU32::new(settings.sub_bass_db.to_bits()),
            bass_gain_db: AtomicU32::new(settings.bass_gain_db.to_bits()),
            bass_frequency_hz: AtomicU32::new(settings.bass_frequency_hz.to_bits()),
            bass_q: AtomicU32::new(settings.bass_q.to_bits()),
            eq_db: array::from_fn(|index| AtomicU32::new(settings.eq_db[index].to_bits())),
            limiter_prevented_samples: AtomicU64::new(0),
        })
    }

    /// Publishes a complete settings snapshot without locking the audio thread.
    pub fn apply(&self, settings: &DspSettings) {
        self.generation.fetch_add(1, Ordering::AcqRel);
        self.enabled.store(settings.enabled, Ordering::Relaxed);
        self.bass_enabled
            .store(settings.bass_studio.enabled, Ordering::Relaxed);
        self.bass_bypass
            .store(settings.bass_studio.bypass, Ordering::Relaxed);
        for (word, value) in self
            .bass_tone
            .iter()
            .zip(tone_words(settings.bass_studio.tone))
        {
            word.store(value, Ordering::Relaxed);
        }
        for (target, band) in self.bass_bands.iter().zip(settings.bass_studio.bands) {
            for (word, value) in target.iter().zip(band_words(band)) {
                word.store(value, Ordering::Relaxed);
            }
        }
        self.preamp_db
            .store(settings.preamp_db.to_bits(), Ordering::Relaxed);
        self.sub_bass_db
            .store(settings.sub_bass_db.to_bits(), Ordering::Relaxed);
        self.bass_gain_db
            .store(settings.bass_gain_db.to_bits(), Ordering::Relaxed);
        self.bass_frequency_hz
            .store(settings.bass_frequency_hz.to_bits(), Ordering::Relaxed);
        self.bass_q
            .store(settings.bass_q.to_bits(), Ordering::Relaxed);
        for (target, gain) in self.eq_db.iter().zip(settings.eq_db) {
            target.store(gain.to_bits(), Ordering::Relaxed);
        }
        self.generation.fetch_add(1, Ordering::Release);
    }

    /// Returns and clears the number of samples caught by the limiter.
    pub fn take_limiter_count(&self) -> u64 {
        self.limiter_prevented_samples.swap(0, Ordering::Relaxed)
    }

    /// Sample peaks at the DSP boundary, before master output volume. Multiple sources
    /// publish maxima without locks; the UI consumes them without touching filter state.
    pub fn take_meter_peaks(&self) -> (f32, f32) {
        (
            f32::from_bits(self.pre_limiter_peak.swap(0, Ordering::Relaxed)),
            f32::from_bits(self.output_peak.swap(0, Ordering::Relaxed)),
        )
    }

    fn snapshot_if_changed(&self, previous_generation: u64) -> Option<(u64, DspSettings)> {
        let generation = self.generation.load(Ordering::Acquire);
        if generation == previous_generation || generation % 2 != 0 {
            return None;
        }
        let mut eq_db = [0.0; EQ_BAND_COUNT];
        for (gain, source) in eq_db.iter_mut().zip(&self.eq_db) {
            *gain = f32::from_bits(source.load(Ordering::Relaxed));
        }
        let bass_studio = BassStudioSettings {
            enabled: self.bass_enabled.load(Ordering::Relaxed),
            bypass: self.bass_bypass.load(Ordering::Relaxed),
            tone: {
                let words = self.bass_tone.each_ref().map(|v| v.load(Ordering::Relaxed));
                BassToneSettings {
                    depth_db: f32::from_bits(words[0]),
                    punch: f32::from_bits(words[1]),
                    saturation: f32::from_bits(words[2]),
                    density: f32::from_bits(words[3]),
                    rumble_hz: f32::from_bits(words[4]),
                    dynamic: f32::from_bits(words[5]),
                    width: f32::from_bits(words[6]),
                    mono_bass: words[7] != 0,
                }
            },
            bands: array::from_fn(|index| {
                let words = self.bass_bands[index]
                    .each_ref()
                    .map(|word| word.load(Ordering::Relaxed));
                BassBand {
                    enabled: words[0] != 0,
                    kind: if words[1] == 0 {
                        BassFilterKind::Bell
                    } else {
                        BassFilterKind::LowShelf
                    },
                    frequency_hz: f32::from_bits(words[2]),
                    gain_db: f32::from_bits(words[3]),
                    q: f32::from_bits(words[4]),
                }
            }),
        };
        let settings = DspSettings {
            bass_studio,
            enabled: self.enabled.load(Ordering::Relaxed),
            preamp_db: f32::from_bits(self.preamp_db.load(Ordering::Relaxed)),
            sub_bass_db: f32::from_bits(self.sub_bass_db.load(Ordering::Relaxed)),
            bass_gain_db: f32::from_bits(self.bass_gain_db.load(Ordering::Relaxed)),
            bass_frequency_hz: f32::from_bits(self.bass_frequency_hz.load(Ordering::Relaxed)),
            bass_q: f32::from_bits(self.bass_q.load(Ordering::Relaxed)),
            eq_db,
        };
        if self.generation.load(Ordering::Acquire) != generation {
            return None;
        }
        Some((generation, settings))
    }
}

fn band_words(band: BassBand) -> [u32; 5] {
    [
        u32::from(band.enabled),
        u32::from(band.kind == BassFilterKind::LowShelf),
        band.frequency_hz.to_bits(),
        band.gain_db.to_bits(),
        band.q.to_bits(),
    ]
}

fn tone_words(mut tone: BassToneSettings) -> [u32; 8] {
    tone.sanitize();
    [
        tone.depth_db.to_bits(),
        tone.punch.to_bits(),
        tone.saturation.to_bits(),
        tone.density.to_bits(),
        tone.rumble_hz.to_bits(),
        tone.dynamic.to_bits(),
        tone.width.to_bits(),
        u32::from(tone.mono_bass),
    ]
}

fn tone_coefficients(tone: BassToneSettings) -> [BiquadCoefficients; 2] {
    [
        BiquadCoefficients::low_shelf(40.0, f64::from(tone.depth_db)),
        if tone.rumble_hz > 0.0 {
            BiquadCoefficients::pass(f64::from(tone.rumble_hz.max(15.0)), true)
        } else {
            BiquadCoefficients::identity()
        },
    ]
}

fn bass_coefficients(mut band: BassBand) -> BiquadCoefficients {
    band.sanitize();
    if !band.enabled {
        return BiquadCoefficients::identity();
    }
    match band.kind {
        BassFilterKind::Bell => BiquadCoefficients::peaking(
            band.frequency_hz as f64,
            band.q as f64,
            band.gain_db as f64,
        ),
        BassFilterKind::LowShelf => BiquadCoefficients::low_shelf_q(
            band.frequency_hz as f64,
            band.gain_db as f64,
            band.q as f64,
        ),
    }
}

/// Exact small-signal response of the same biquads used by the audio processor.
/// Includes depth and rumble filters, but excludes dynamics, harmonics, stereo, legacy EQ and preamp.
pub fn bass_response_db(settings: &BassStudioSettings, frequency_hz: f32) -> f32 {
    if !settings.enabled || settings.bypass {
        return 0.0;
    }
    let omega = 2.0 * PI * frequency_hz as f64 / SAMPLE_RATE;
    let (sin1, cos1) = omega.sin_cos();
    let (sin2, cos2) = (2.0 * omega).sin_cos();
    settings
        .bands
        .iter()
        .map(|band| bass_coefficients(*band))
        .chain(tone_coefficients(settings.tone))
        .map(|c| {
            let numerator =
                (c.b0 + c.b1 * cos1 + c.b2 * cos2).powi(2) + (c.b1 * sin1 + c.b2 * sin2).powi(2);
            let denominator =
                (1.0 + c.a1 * cos1 + c.a2 * cos2).powi(2) + (c.a1 * sin1 + c.a2 * sin2).powi(2);
            (10.0 * (numerator / denominator.max(1e-30)).max(1e-30).log10()) as f32
        })
        .sum()
}

/// Shared real-time DSP state for audio sources whose samples are already queued
/// inside an output backend. Unlike `DspSink`, this processes PCM at the moment
/// the backend pulls samples, so EQ changes are audible without flushing the queue.
pub struct DspPlaybackProcessor {
    processor: Mutex<DspProcessor>,
}

impl DspPlaybackProcessor {
    /// Creates one stateful DSP processor for a pull-based output source.
    pub fn new(controls: Arc<DspControls>) -> Arc<Self> {
        Arc::new(Self {
            processor: Mutex::new(DspProcessor::new(controls)),
        })
    }

    /// Processes one short interleaved stereo block.
    pub fn process_f64(&self, samples: &mut [f64]) {
        if samples.is_empty() {
            return;
        }
        match self.processor.lock() {
            Ok(mut processor) => processor.process(samples),
            Err(poisoned) => poisoned.into_inner().process(samples),
        }
    }
}

/// A librespot sink decorator that processes decoded PCM before Rodio output.
pub struct DspSink {
    inner: Box<dyn Sink>,
    processor: DspProcessor,
}

impl DspSink {
    /// Wraps the selected output backend with the shared DSP controls.
    pub fn new(inner: Box<dyn Sink>, controls: Arc<DspControls>) -> Self {
        Self {
            inner,
            processor: DspProcessor::new(controls),
        }
    }
}

impl Sink for DspSink {
    fn start(&mut self) -> SinkResult<()> {
        self.inner.start()
    }

    fn stop(&mut self) -> SinkResult<()> {
        self.inner.stop()
    }

    fn write(&mut self, packet: AudioPacket, converter: &mut Converter) -> SinkResult<()> {
        let packet = match packet {
            AudioPacket::Samples(mut samples) => {
                self.processor.process(&mut samples);
                AudioPacket::Samples(samples)
            }
            AudioPacket::Raw(raw) => AudioPacket::Raw(raw),
        };
        self.inner.write(packet, converter)
    }
}

struct DspProcessor {
    controls: Arc<DspControls>,
    generation: u64,
    enabled: bool,
    bypass_mix: f64,
    preamp_gain: f64,
    filters: [StereoBiquad; FILTER_COUNT],
    previous_preamp_gain: f64,
    previous_filters: Option<[StereoBiquad; FILTER_COUNT]>,
    parameter_ramp_remaining: u32,
    effects: BassEffects,
    previous_effects: Option<BassEffects>,
}

impl DspProcessor {
    fn new(controls: Arc<DspControls>) -> Self {
        let mut processor = Self {
            controls,
            generation: 0,
            enabled: false,
            bypass_mix: 0.0,
            preamp_gain: 1.0,
            filters: array::from_fn(|_| StereoBiquad::default()),
            previous_preamp_gain: 1.0,
            previous_filters: None,
            parameter_ramp_remaining: 0,
            effects: BassEffects::new(),
            previous_effects: None,
        };
        processor.refresh_settings();
        processor.bypass_mix = if processor.enabled { 1.0 } else { 0.0 };
        processor
    }

    fn process(&mut self, samples: &mut [f64]) {
        self.refresh_settings();
        let target_mix = if self.enabled { 1.0 } else { 0.0 };
        let ramp_step = 1.0 / BYPASS_RAMP_SAMPLES;
        let mut prevented = 0_u64;
        let mut pre_peak = 0.0_f64;
        let mut out_peak = 0.0_f64;

        for frame in samples.chunks_mut(CHANNELS) {
            if self.bypass_mix < target_mix {
                self.bypass_mix = (self.bypass_mix + ramp_step).min(target_mix);
            } else if self.bypass_mix > target_mix {
                self.bypass_mix = (self.bypass_mix - ramp_step).max(target_mix);
            }

            let mut dry = [0.0; CHANNELS];
            let mut wet = [0.0; CHANNELS];
            for (channel, sample) in frame.iter().enumerate() {
                dry[channel] = if sample.is_finite() { *sample } else { 0.0 };
                wet[channel] = process_filter_chain(
                    &mut self.filters,
                    channel,
                    dry[channel] * self.preamp_gain,
                );
            }
            wet = self.effects.process(wet);
            if let Some(previous_filters) = self.previous_filters.as_mut() {
                let mut previous = [0.0; CHANNELS];
                for channel in 0..frame.len() {
                    previous[channel] = process_filter_chain(
                        previous_filters,
                        channel,
                        dry[channel] * self.previous_preamp_gain,
                    );
                }
                if let Some(effects) = self.previous_effects.as_mut() {
                    previous = effects.process(previous);
                }
                let blend = 1.0
                    - f64::from(self.parameter_ramp_remaining) / f64::from(PARAMETER_RAMP_SAMPLES);
                for channel in 0..frame.len() {
                    wet[channel] = previous[channel] + blend * (wet[channel] - previous[channel]);
                }
                self.parameter_ramp_remaining = self
                    .parameter_ramp_remaining
                    .saturating_sub(frame.len() as u32);
                if self.parameter_ramp_remaining == 0 {
                    self.previous_filters = None;
                    self.previous_effects = None;
                }
            }
            for (channel, sample) in frame.iter_mut().enumerate() {
                pre_peak = pre_peak
                    .max((dry[channel] + self.bypass_mix * (wet[channel] - dry[channel])).abs());
                let (limited, clipped) = soft_limit(wet[channel]);
                if clipped && self.bypass_mix > 0.0 {
                    prevented = prevented.saturating_add(1);
                }
                *sample = dry[channel] + self.bypass_mix * (limited - dry[channel]);
                out_peak = out_peak.max(sample.abs());
            }
        }

        self.controls.pre_limiter_peak.fetch_max(
            (pre_peak.min(f32::MAX as f64) as f32).to_bits(),
            Ordering::Relaxed,
        );
        self.controls.output_peak.fetch_max(
            (out_peak.min(f32::MAX as f64) as f32).to_bits(),
            Ordering::Relaxed,
        );
        if prevented > 0 {
            self.controls
                .limiter_prevented_samples
                .fetch_add(prevented, Ordering::Relaxed);
        }
    }

    fn refresh_settings(&mut self) {
        let Some((generation, settings)) = self.controls.snapshot_if_changed(self.generation)
        else {
            return;
        };
        let is_initial_snapshot = self.generation == 0;
        self.generation = generation;
        self.enabled = settings.enabled;
        if !is_initial_snapshot {
            self.previous_preamp_gain = self.preamp_gain;
            self.previous_filters = Some(self.filters.clone());
            self.parameter_ramp_remaining = PARAMETER_RAMP_SAMPLES;
            self.previous_effects = Some(self.effects.clone());
        }
        self.effects.set_settings(
            settings.bass_studio.tone,
            settings.bass_studio.enabled && !settings.bass_studio.bypass,
        );
        self.preamp_gain = db_to_gain(f64::from(settings.preamp_db));
        let sub_bass = BiquadCoefficients::low_shelf(45.0, f64::from(settings.sub_bass_db));
        let bass = BiquadCoefficients::peaking(
            f64::from(settings.bass_frequency_hz),
            f64::from(settings.bass_q),
            f64::from(settings.bass_gain_db),
        );

        for (filter, band) in self.filters[2 + EQ_BAND_COUNT..TONE_FILTER_START]
            .iter_mut()
            .zip(settings.bass_studio.bands)
        {
            filter.coefficients = if settings.bass_studio.enabled && !settings.bass_studio.bypass {
                bass_coefficients(band)
            } else {
                BiquadCoefficients::identity()
            };
        }
        for (filter, coefficients) in self.filters[TONE_FILTER_START..]
            .iter_mut()
            .zip(tone_coefficients(settings.bass_studio.tone))
        {
            filter.coefficients = if settings.bass_studio.enabled && !settings.bass_studio.bypass {
                coefficients
            } else {
                BiquadCoefficients::identity()
            };
        }
        self.filters[0].coefficients = sub_bass;
        self.filters[1].coefficients = bass;
        for (filter, (frequency, gain)) in self.filters[2..2 + EQ_BAND_COUNT]
            .iter_mut()
            .zip(EQ_FREQUENCIES_HZ.iter().zip(settings.eq_db))
        {
            filter.coefficients =
                BiquadCoefficients::peaking(f64::from(*frequency), GRAPHIC_EQ_Q, f64::from(gain));
        }
    }
}

#[derive(Clone, Copy)]
struct BiquadCoefficients {
    b0: f64,
    b1: f64,
    b2: f64,
    a1: f64,
    a2: f64,
}

impl BiquadCoefficients {
    /// Butterworth low/high pass, RBJ cookbook: https://www.w3.org/TR/audio-eq-cookbook/
    fn pass(frequency_hz: f64, high: bool) -> Self {
        let omega = 2.0 * PI * frequency_hz.clamp(10.0, SAMPLE_RATE * 0.49) / SAMPLE_RATE;
        let cosine = omega.cos();
        let alpha = omega.sin() / (2.0 * std::f64::consts::FRAC_1_SQRT_2);
        let a0 = 1.0 + alpha;
        let b0 = if high {
            (1.0 + cosine) * 0.5
        } else {
            (1.0 - cosine) * 0.5
        };
        Self {
            b0: b0 / a0,
            b1: (if high { -2.0 } else { 2.0 }) * b0 / a0,
            b2: b0 / a0,
            a1: -2.0 * cosine / a0,
            a2: (1.0 - alpha) / a0,
        }
    }
    fn identity() -> Self {
        Self {
            b0: 1.0,
            b1: 0.0,
            b2: 0.0,
            a1: 0.0,
            a2: 0.0,
        }
    }

    fn peaking(frequency_hz: f64, q: f64, gain_db: f64) -> Self {
        let omega = 2.0 * PI * frequency_hz.clamp(10.0, SAMPLE_RATE * 0.49) / SAMPLE_RATE;
        let alpha = omega.sin() / (2.0 * q.max(0.01));
        let cosine = omega.cos();
        let amplitude = 10.0_f64.powf(gain_db / 40.0);
        let a0 = 1.0 + alpha / amplitude;
        Self {
            b0: (1.0 + alpha * amplitude) / a0,
            b1: (-2.0 * cosine) / a0,
            b2: (1.0 - alpha * amplitude) / a0,
            a1: (-2.0 * cosine) / a0,
            a2: (1.0 - alpha / amplitude) / a0,
        }
    }

    fn low_shelf(frequency_hz: f64, gain_db: f64) -> Self {
        Self::low_shelf_q(frequency_hz, gain_db, std::f64::consts::FRAC_1_SQRT_2)
    }

    fn low_shelf_q(frequency_hz: f64, gain_db: f64, q: f64) -> Self {
        let omega = 2.0 * PI * frequency_hz.clamp(10.0, SAMPLE_RATE * 0.49) / SAMPLE_RATE;
        let cosine = omega.cos();
        let sine = omega.sin();
        let amplitude = 10.0_f64.powf(gain_db / 40.0);
        let alpha = sine / (2.0 * q.max(0.01));
        let two_sqrt_a_alpha = 2.0 * amplitude.sqrt() * alpha;
        let a0 = amplitude + 1.0 + (amplitude - 1.0) * cosine + two_sqrt_a_alpha;
        Self {
            b0: amplitude * (amplitude + 1.0 - (amplitude - 1.0) * cosine + two_sqrt_a_alpha) / a0,
            b1: 2.0 * amplitude * (amplitude - 1.0 - (amplitude + 1.0) * cosine) / a0,
            b2: amplitude * (amplitude + 1.0 - (amplitude - 1.0) * cosine - two_sqrt_a_alpha) / a0,
            a1: -2.0 * (amplitude - 1.0 + (amplitude + 1.0) * cosine) / a0,
            a2: (amplitude + 1.0 + (amplitude - 1.0) * cosine - two_sqrt_a_alpha) / a0,
        }
    }
}

#[derive(Clone, Copy, Default)]
struct FilterState {
    z1: f64,
    z2: f64,
}

#[derive(Clone)]
struct StereoBiquad {
    coefficients: BiquadCoefficients,
    state: [FilterState; CHANNELS],
}

impl Default for StereoBiquad {
    fn default() -> Self {
        Self::new(BiquadCoefficients::identity())
    }
}

impl StereoBiquad {
    fn new(coefficients: BiquadCoefficients) -> Self {
        Self {
            coefficients,
            state: [FilterState::default(); CHANNELS],
        }
    }

    #[inline]
    fn process(&mut self, channel: usize, input: f64) -> f64 {
        let coefficients = self.coefficients;
        let state = &mut self.state[channel];
        let output = coefficients.b0 * input + state.z1;
        if !output.is_finite() {
            *state = FilterState::default();
            return 0.0;
        }
        state.z1 = coefficients.b1 * input - coefficients.a1 * output + state.z2;
        state.z2 = coefficients.b2 * input - coefficients.a2 * output;
        if state.z1.abs() < 1.0e-30 {
            state.z1 = 0.0;
        }
        if state.z2.abs() < 1.0e-30 {
            state.z2 = 0.0;
        }
        output
    }
}

fn process_filter_chain(
    filters: &mut [StereoBiquad; FILTER_COUNT],
    channel: usize,
    mut sample: f64,
) -> f64 {
    for filter in filters {
        sample = filter.process(channel, sample);
    }
    sample
}

#[inline]
fn db_to_gain(db: f64) -> f64 {
    10.0_f64.powf(db / 20.0)
}

#[inline]
fn soft_limit(sample: f64) -> (f64, bool) {
    if !sample.is_finite() {
        return (0.0, true);
    }
    let magnitude = sample.abs();
    if magnitude <= LIMITER_THRESHOLD {
        return (sample, false);
    }
    let headroom = 1.0 - LIMITER_THRESHOLD;
    let normalized_excess = (magnitude - LIMITER_THRESHOLD) / headroom;
    let limited = LIMITER_THRESHOLD + headroom * (1.0 - (-normalized_excess).exp());
    (sample.signum() * limited.min(1.0), true)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn settings(enabled: bool) -> DspSettings {
        DspSettings {
            enabled,
            preamp_db: 0.0,
            sub_bass_db: 0.0,
            bass_gain_db: 0.0,
            bass_frequency_hz: 70.0,
            bass_q: 0.8,
            eq_db: [0.0; EQ_BAND_COUNT],
            bass_studio: BassStudioSettings::default(),
        }
    }

    #[test]
    fn bypass_preserves_pcm() {
        let controls = DspControls::new(&settings(false));
        let mut processor = DspProcessor::new(controls);
        let mut samples = vec![0.25, -0.25, 0.5, -0.5];
        let expected = samples.clone();
        processor.process(&mut samples);
        assert_eq!(samples, expected);
    }

    #[test]
    fn preamp_changes_pcm_and_limiter_bounds_output() {
        let mut active = settings(true);
        active.preamp_db = 6.0;
        let controls = DspControls::new(&active);
        let mut processor = DspProcessor::new(controls.clone());
        let mut samples = vec![0.75; 2_000];
        processor.process(&mut samples);
        assert!(samples.iter().all(|sample| sample.abs() <= 1.0));
        assert!(samples.iter().any(|sample| *sample > 0.75));
        assert!(controls.take_limiter_count() > 0);
    }

    #[test]
    fn one_kilohertz_band_changes_sine_rms() {
        let flat_controls = DspControls::new(&settings(true));
        let mut boosted = settings(true);
        boosted.eq_db[5] = 9.0;
        let boosted_controls = DspControls::new(&boosted);
        let mut flat_processor = DspProcessor::new(flat_controls);
        let mut boosted_processor = DspProcessor::new(boosted_controls);
        let mut flat = sine_wave(1_000.0, 0.05, 44_100);
        let mut raised = flat.clone();
        flat_processor.process(&mut flat);
        boosted_processor.process(&mut raised);
        assert!(rms(&raised[4_000..]) > rms(&flat[4_000..]) * 1.5);
    }

    #[test]
    fn global_bypass_wins_over_enabled_bass_studio() {
        let mut active = settings(false);
        active.bass_studio.enabled = true;
        for band in &mut active.bass_studio.bands {
            band.gain_db = 12.0;
        }
        let mut samples = sine_wave(55.0, 0.1, 8_000);
        let expected = samples.clone();
        DspProcessor::new(DspControls::new(&active)).process(&mut samples);
        assert_eq!(samples, expected);
    }

    #[test]
    fn bass_response_matches_processed_pcm_for_bell_and_shelf() {
        for kind in [BassFilterKind::Bell, BassFilterKind::LowShelf] {
            for frequency in [28.0, 78.0, 200.0] {
                let mut active = settings(true);
                active.bass_studio.enabled = true;
                for band in &mut active.bass_studio.bands {
                    band.enabled = false;
                }
                active.bass_studio.bands[0] = BassBand {
                    enabled: true,
                    kind,
                    frequency_hz: 78.0,
                    gain_db: 6.0,
                    q: 1.2,
                };
                let dry = sine_wave(frequency, 0.01, 88_200);
                let mut wet = dry.clone();
                DspProcessor::new(DspControls::new(&active)).process(&mut wet);
                let observed = 20.0 * (rms(&wet[88_200..]) / rms(&dry[88_200..])).log10();
                let predicted = bass_response_db(&active.bass_studio, frequency as f32) as f64;
                assert!(
                    (observed - predicted).abs() < 0.12,
                    "{kind:?}: predicted {predicted}, measured {observed}"
                );
            }
        }
    }

    #[test]
    fn bass_bypass_and_band_switches_do_not_change_legacy_eq() {
        let mut flat = settings(true);
        flat.eq_db[5] = 3.0;
        let mut active = flat.clone();
        active.bass_studio.enabled = true;
        active.bass_studio.bands[2].gain_db = 12.0;
        let mut reference = sine_wave(78.0, 0.01, 22_050);
        DspProcessor::new(DspControls::new(&flat)).process(&mut reference);
        for mode in 0..3 {
            let mut bypassed = active.clone();
            if mode == 0 {
                bypassed.bass_studio.bypass = true;
            }
            if mode == 1 {
                bypassed.bass_studio.bands[2].enabled = false;
            }
            if mode == 2 {
                bypassed.bass_studio.enabled = false;
            }
            let mut samples = sine_wave(78.0, 0.01, 22_050);
            DspProcessor::new(DspControls::new(&bypassed)).process(&mut samples);
            assert!(
                samples
                    .iter()
                    .zip(&reference)
                    .all(|(a, b)| (a - b).abs() < 1e-12)
            );
            assert!(bass_response_db(&bypassed.bass_studio, 78.0).abs() < 0.001);
        }
    }

    #[test]
    fn bass_parameter_updates_publish_all_bands_and_stay_finite() {
        let mut active = settings(true);
        let controls = DspControls::new(&active);
        let mut processor = DspProcessor::new(controls.clone());
        active.bass_studio.enabled = true;
        for (index, band) in active.bass_studio.bands.iter_mut().enumerate() {
            band.frequency_hz = if index % 2 == 0 { 20.0 } else { 250.0 };
            band.gain_db = 12.0;
            band.q = 6.0;
            band.kind = BassFilterKind::LowShelf;
        }
        controls.apply(&active);
        let (_, snapshot) = controls.snapshot_if_changed(0).unwrap();
        assert_eq!(snapshot.bass_studio, active.bass_studio);
        let mut signal = sine_wave(35.0, 0.2, 44_100);
        processor.process(&mut signal);
        assert!(signal.iter().all(|v| v.is_finite() && v.abs() <= 1.0));
        let (pre, post) = controls.take_meter_peaks();
        assert!(pre > 1.0 && post > 0.9 && post <= 1.0);
        assert_eq!(controls.take_meter_peaks(), (0.0, 0.0));
        active.bass_studio.bypass = true;
        controls.apply(&active);
        let mut next = sine_wave(35.0, 0.2, 44_100);
        processor.process(&mut next);
        assert!(next.iter().all(|v| v.is_finite() && v.abs() <= 1.0));
        assert!((rms(&next[44_100..]) - rms(&sine_wave(35.0, 0.2, 22_050))).abs() < 0.001);
    }

    #[test]
    fn bass_q_changes_bandwidth_and_graph_combines_filters() {
        let mut bass = BassStudioSettings {
            enabled: true,
            ..Default::default()
        };
        for band in &mut bass.bands {
            band.enabled = false;
        }
        bass.bands[0] = BassBand {
            enabled: true,
            frequency_hz: 78.0,
            gain_db: 6.0,
            q: 0.5,
            ..Default::default()
        };
        assert!((bass_response_db(&bass, 78.0) - 6.0).abs() < 0.01);
        let wide = bass_response_db(&bass, 100.0);
        bass.bands[0].q = 4.0;
        assert!(bass_response_db(&bass, 100.0) < wide);
        bass.bands[1] = bass.bands[0];
        assert!((bass_response_db(&bass, 78.0) - 12.0).abs() < 0.01);
    }

    fn tone_render(tone: BassToneSettings, mut samples: Vec<f64>) -> Vec<f64> {
        let mut active = settings(true);
        active.bass_studio.enabled = true;
        active.bass_studio.tone = tone;
        DspProcessor::new(DspControls::new(&active)).process(&mut samples);
        samples
    }

    #[test]
    fn depth_and_rumble_graph_match_actual_audio() {
        for tone in [
            BassToneSettings {
                depth_db: 9.0,
                ..Default::default()
            },
            BassToneSettings {
                rumble_hz: 35.0,
                ..Default::default()
            },
            BassToneSettings {
                depth_db: 6.0,
                rumble_hz: 25.0,
                ..Default::default()
            },
        ] {
            for frequency in [10.0, 30.0, 80.0, 1000.0] {
                let dry = sine_wave(frequency, 0.01, 88_200);
                let wet = tone_render(tone, dry.clone());
                let observed = 20.0 * (rms(&wet[88_200..]) / rms(&dry[88_200..])).log10();
                let studio = BassStudioSettings {
                    enabled: true,
                    tone,
                    ..Default::default()
                };
                let predicted = bass_response_db(&studio, frequency as f32) as f64;
                assert!(
                    (observed - predicted).abs() < 0.12,
                    "{tone:?} at {frequency}: {observed} vs {predicted}"
                );
            }
        }
    }

    #[test]
    fn saturation_adds_bass_harmonics_without_dc_or_changing_silence() {
        let wet = tone_render(
            BassToneSettings {
                saturation: 100.0,
                ..Default::default()
            },
            sine_wave(60.0, 0.3, 88_200),
        );
        let tail: Vec<_> = wet[88_200..].iter().step_by(2).copied().collect();
        let magnitude = |hz: f64| {
            let (real, imag) = tail.iter().enumerate().fold((0.0, 0.0), |(r, i), (n, x)| {
                let phase = 2.0 * PI * hz * n as f64 / SAMPLE_RATE;
                (r + x * phase.cos(), i + x * phase.sin())
            });
            2.0 * real.hypot(imag) / tail.len() as f64
        };
        assert!(magnitude(180.0) > 0.005);
        assert!((tail.iter().sum::<f64>() / tail.len() as f64).abs() < 1e-5);
        assert!(
            tone_render(
                BassToneSettings {
                    saturation: 100.0,
                    ..Default::default()
                },
                vec![0.0; 4000]
            )
            .iter()
            .all(|v| *v == 0.0)
        );
    }

    #[test]
    fn density_reduces_bass_level_contrast_and_dynamic_bass_reduces_loud_passages() {
        let gain = |amplitude| {
            let dry = sine_wave(60.0, amplitude, 88_200);
            let wet = tone_render(
                BassToneSettings {
                    density: 100.0,
                    ..Default::default()
                },
                dry.clone(),
            );
            rms(&wet[88_200..]) / rms(&dry[88_200..])
        };
        assert!(gain(0.02) > 1.2);
        assert!(gain(0.4) < gain(0.02) * 0.8);
        let dry = sine_wave(60.0, 0.8, 88_200);
        let wet = tone_render(
            BassToneSettings {
                dynamic: 100.0,
                ..Default::default()
            },
            dry.clone(),
        );
        assert!(rms(&wet[88_200..]) < rms(&dry[88_200..]) * 0.95);
    }

    #[test]
    fn punch_changes_attack_in_both_directions() {
        let dry = sine_wave(70.0, 0.1, 4410);
        let softer = tone_render(
            BassToneSettings {
                punch: -100.0,
                ..Default::default()
            },
            dry.clone(),
        );
        let sharper = tone_render(
            BassToneSettings {
                punch: 100.0,
                ..Default::default()
            },
            dry.clone(),
        );
        assert!(rms(&sharper[200..1600]) > rms(&dry[200..1600]) * 1.15);
        assert!(rms(&softer[200..1600]) < rms(&dry[200..1600]) * 0.85);
    }

    #[test]
    fn stereo_width_and_centered_bass_preserve_mono_and_control_side_signal() {
        let mono = sine_wave(1000.0, 0.1, 22_050);
        let wide = tone_render(
            BassToneSettings {
                width: 150.0,
                ..Default::default()
            },
            mono.clone(),
        );
        assert!(wide.iter().zip(&mono).all(|(a, b)| (a - b).abs() < 1e-12));
        for (frequency, center_bass) in [(30.0, true), (1000.0, false)] {
            let mut stereo = sine_wave(frequency, 0.1, 44_100);
            for frame in stereo.chunks_mut(2) {
                frame[1] = -frame[0];
            }
            let tone = if center_bass {
                BassToneSettings {
                    mono_bass: true,
                    ..Default::default()
                }
            } else {
                BassToneSettings {
                    width: 0.0,
                    ..Default::default()
                }
            };
            let wet = tone_render(tone, stereo.clone());
            assert!(rms(&wet[44_100..]) < rms(&stereo[44_100..]) * 0.4);
        }
    }

    #[test]
    fn tone_updates_are_atomic_bypassable_finite_and_independent_of_stereo_block_size() {
        let tone = BassToneSettings {
            depth_db: 9.0,
            punch: 100.0,
            saturation: 100.0,
            density: 100.0,
            rumble_hz: 25.0,
            dynamic: 100.0,
            width: 150.0,
            mono_bass: true,
        };
        let mut active = settings(true);
        active.bass_studio.enabled = true;
        active.bass_studio.tone = tone;
        let controls = DspControls::new(&settings(true));
        controls.apply(&active);
        assert_eq!(
            controls.snapshot_if_changed(0).unwrap().1.bass_studio.tone,
            tone
        );
        let dry = sine_wave(55.0, 0.8, 22_050);
        let full = tone_render(tone, dry.clone());
        let mut split = dry.clone();
        let mut processor = DspProcessor::new(DspControls::new(&active));
        for block in split.chunks_mut(126) {
            processor.process(block);
        }
        assert_eq!(full, split);
        assert!(full.iter().all(|v| v.is_finite() && v.abs() <= 1.0));
        for mode in 0..3 {
            let mut bypassed = active.clone();
            match mode {
                0 => bypassed.bass_studio.bypass = true,
                1 => bypassed.bass_studio.enabled = false,
                _ => bypassed.enabled = false,
            }
            let mut wet = dry.clone();
            DspProcessor::new(DspControls::new(&bypassed)).process(&mut wet);
            assert_eq!(wet, dry);
        }
        // Changing tone controls during playback settles to the new DSP result.
        let mut changed_processor = DspProcessor::new(controls.clone());
        for index in 0..16 {
            active.bass_studio.tone.punch = if index % 2 == 0 { -100.0 } else { 100.0 };
            active.bass_studio.bypass = index % 3 == 0;
            controls.apply(&active);
            let mut block = dry[..2000].to_vec();
            changed_processor.process(&mut block);
            assert!(block.iter().all(|v| v.is_finite() && v.abs() <= 1.0));
        }
    }

    fn sine_wave(frequency: f64, amplitude: f64, frames: usize) -> Vec<f64> {
        (0..frames)
            .flat_map(|frame| {
                let sample = amplitude * (2.0 * PI * frequency * frame as f64 / SAMPLE_RATE).sin();
                [sample, sample]
            })
            .collect()
    }

    fn rms(samples: &[f64]) -> f64 {
        (samples.iter().map(|sample| sample * sample).sum::<f64>() / samples.len() as f64).sqrt()
    }
}
