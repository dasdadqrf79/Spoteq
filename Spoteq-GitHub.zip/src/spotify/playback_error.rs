//! Typed failures produced by direct local playback.

/// Broad playback failure category used by the UI and retry policy.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PlaybackErrorKind {
    /// The Spotify account session is missing or could not be refreshed.
    AccountAuthentication,
    /// The OAuth token was issued without the `streaming` permission.
    MissingStreamingScope,
    /// The connected account is not eligible for on-demand playback.
    PremiumRequired,
    /// Spotify rejected credentials used by the direct librespot session.
    InvalidCredentials,
    /// Spotify did not provide playable audio for the selected track.
    TrackUnavailable,
    /// A connection to Spotify failed or timed out.
    Network,
    /// The local mixer or output device could not be initialized.
    AudioBackend,
}

/// User-facing direct playback error with a stable machine-readable category.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PlaybackError {
    /// Category used to decide whether playback must stop.
    pub kind: PlaybackErrorKind,
    /// Concise recovery guidance shown in the application.
    pub message: String,
}

impl PlaybackError {
    pub(crate) fn new(kind: PlaybackErrorKind, message: impl Into<String>) -> Self {
        Self {
            kind,
            message: message.into(),
        }
    }
}
