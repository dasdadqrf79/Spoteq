use std::{
    fs::{self, File},
    io::{BufReader, BufWriter, Write},
    path::{Path, PathBuf},
};

use crate::{
    spotify::{SpotifyError, auth::StoredToken},
    storage::{DirectoryKind, app_directory},
};

/// Single-owner persistent store for OAuth credentials.
#[derive(Debug, Clone)]
pub(crate) struct TokenStore {
    path: PathBuf,
}

impl TokenStore {
    pub fn discover() -> Result<Self, SpotifyError> {
        let path = app_directory(DirectoryKind::DataLocal)
            .map(|directory| directory.join("spotify-token.json"))
            .ok_or(SpotifyError::DataDirectoryUnavailable)?;
        Ok(Self { path })
    }

    pub fn load(&self) -> Result<Option<StoredToken>, SpotifyError> {
        match File::open(&self.path) {
            Ok(file) => Ok(Some(serde_json::from_reader(BufReader::new(file))?)),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(None),
            Err(error) => Err(error.into()),
        }
    }

    pub fn save(&self, token: &StoredToken) -> Result<(), SpotifyError> {
        if let Some(parent) = self.path.parent() {
            fs::create_dir_all(parent)?;
        }

        let temporary = self.path.with_extension("json.tmp");
        {
            let file = create_private_file(&temporary)?;
            let mut writer = BufWriter::new(file);
            serde_json::to_writer_pretty(&mut writer, token)?;
            writer.write_all(b"\n")?;
            writer.flush()?;
            writer.get_ref().sync_all()?;
        }

        replace_file(&temporary, &self.path)?;
        Ok(())
    }

    pub fn clear(&self) -> Result<(), SpotifyError> {
        match fs::remove_file(&self.path) {
            Ok(()) => Ok(()),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(()),
            Err(error) => Err(error.into()),
        }
    }
}

#[cfg(unix)]
fn create_private_file(path: &Path) -> Result<File, std::io::Error> {
    use std::os::unix::fs::OpenOptionsExt;

    fs::OpenOptions::new()
        .create(true)
        .truncate(true)
        .write(true)
        .mode(0o600)
        .open(path)
}

#[cfg(not(unix))]
fn create_private_file(path: &Path) -> Result<File, std::io::Error> {
    File::create(path)
}

fn replace_file(temporary: &Path, destination: &Path) -> Result<(), std::io::Error> {
    if destination.exists() {
        fs::remove_file(destination)?;
    }
    fs::rename(temporary, destination)
}
