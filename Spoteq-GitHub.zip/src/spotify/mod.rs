//! Spotify authorization, Web API access and background orchestration.

mod api;
mod auth;
mod error;
mod image;
mod model;
mod playback;
mod playback_auth;
mod playback_error;
mod runtime;
mod token_store;

pub use error::SpotifyError;
pub use model::{DecodedImage, Page, Track, UserProfile};
pub use playback::{PlaybackStatus, PlaybackUpdate};
pub use playback_error::{PlaybackError, PlaybackErrorKind};
pub use runtime::{SpotifyCommand, SpotifyEvent, SpotifyRuntime};

/// Redirect URI to add to the Spotify Developer Dashboard.
pub const REGISTERED_REDIRECT_URI: &str = "http://127.0.0.1:8000/callback";
