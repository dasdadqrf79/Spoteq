use std::{sync::Arc, thread, thread::JoinHandle, time::Duration};

use eframe::egui;
use flume::{Receiver, Sender};
use reqwest::Client;

use crate::audio::dsp::{DspControls, DspSettings};
use crate::catalog::{ProviderTrackId, SearchScope, TrackRow};
use crate::spotify::{
    DecodedImage, Page, PlaybackUpdate, SpotifyError, Track, UserProfile,
    api::SpotifyApi,
    auth::{AuthSession, SharedAuth},
    image::load_cover,
    playback::{self, PlaybackCommand},
    token_store::TokenStore,
};

/// Commands accepted by the background Spotify runtime.
#[derive(Debug, Clone)]
pub enum SpotifyCommand {
    /// Begin browser-based Authorization Code with PKCE.
    Login {
        client_id: String,
    },
    /// Remove locally stored credentials.
    Logout,
    /// Search the Spotify catalog.
    Search {
        query: String,
        scope: SearchScope,
        generation: u64,
    },
    /// Generate similar catalog tracks from current/recent real track seeds.
    Recommend {
        seeds: Vec<TrackRow>,
        generation: u64,
        limit: usize,
    },
    /// Load a page of the user's Spotify Liked Songs.
    LoadLiked {
        offset: usize,
        generation: u64,
    },
    /// Add or remove one Spotify item from the real account library.
    SetSaved {
        uri: String,
        saved: bool,
        request_id: u64,
    },
    /// Query one URI against the real Spotify library.
    LoadSavedState {
        uri: String,
        stable_key: String,
        request_id: u64,
    },
    /// Resolve one album cover through the disk cache.
    LoadImage {
        url: String,
    },
    /// Replace the local queue and start one selected track.
    PlayQueue {
        tracks: Vec<Track>,
        index: usize,
    },
    /// Warms librespot audio for a likely next/hovered track without starting it.
    PreloadTrack {
        uri: String,
    },
    /// Toggle the current direct Player between playing and paused.
    TogglePlayback,
    /// Move backward in the local queue, or restart the current track.
    Previous,
    /// Move forward in the local queue.
    Next,
    /// Seek the current track to a position in milliseconds.
    Seek {
        position_ms: u32,
    },
    /// Set the local soft mixer immediately.
    SetVolume {
        volume: f32,
    },
    /// Recreate the local audio backend on the Windows default or a named device.
    SetOutputDevice {
        device: Option<String>,
    },
    /// Refresh the list of CPAL/WASAPI output devices.
    RefreshAudioDevices,
    /// Publish a complete DSP snapshot to the real-time audio sink.
    SetDspSettings(DspSettings),
    /// Stops local Spotify audio without clearing its playback authorization.
    StopPlayback,
    Shutdown,
}

/// Immutable results delivered to the UI thread.
#[derive(Debug)]
pub enum SpotifyEvent {
    /// No reusable token exists.
    LoggedOut,
    /// Browser authorization is waiting for the user.
    Authorizing,
    /// A stored token is being checked or refreshed.
    Restoring,
    /// Authorization is ready and account metadata is available.
    LoggedIn(UserProfile),
    /// The stored grant predates provider-native Like/Unlike permissions.
    LibraryPermissionMissing,
    /// Authorization failed without terminating the application.
    AuthFailed(String),
    /// Search completed for a specific query generation.
    SearchFinished {
        generation: u64,
        result: Result<Vec<Track>, String>,
    },
    /// Autoplay recommendation batch completed.
    RecommendationsFinished {
        generation: u64,
        result: Result<Vec<TrackRow>, String>,
    },
    /// One offset page of Liked Songs completed.
    LikedFinished {
        offset: usize,
        generation: u64,
        result: Result<Page<Track>, String>,
    },
    /// A library mutation completed.
    SavedChanged {
        uri: String,
        saved: bool,
        request_id: u64,
        result: Result<(), String>,
    },
    /// Provider source-of-truth state for one Heart.
    SavedStateLoaded {
        stable_key: String,
        request_id: u64,
        result: Result<bool, String>,
    },
    /// A cover was decoded and is ready for GPU upload.
    ImageFinished {
        url: String,
        result: Result<DecodedImage, String>,
    },
    /// Direct playback state changed.
    PlaybackChanged(PlaybackUpdate),
    /// Available local outputs and the current Windows default output.
    AudioDevicesChanged {
        devices: Vec<String>,
        default_device: Option<String>,
    },
    /// The runtime itself could not start.
    RuntimeFailed(String),
}

/// Non-blocking UI handle for the Spotify worker runtime.
pub struct SpotifyRuntime {
    command_tx: Sender<SpotifyCommand>,
    event_rx: Receiver<SpotifyEvent>,
    dsp_controls: Arc<DspControls>,
    thread: Option<JoinHandle<()>>,
}

impl SpotifyRuntime {
    /// Disconnected, in-memory handle for UI tests; starts no workers or authentication.
    #[cfg(test)]
    pub(crate) fn for_ui_test() -> Self {
        let (command_tx, _) = flume::unbounded();
        let (_, event_rx) = flume::unbounded();
        Self {
            command_tx,
            event_rx,
            thread: None,
            dsp_controls: DspControls::new(&DspSettings::from(
                &crate::settings::AudioSettings::default(),
            )),
        }
    }

    /// Starts the Tokio runtime on a dedicated coordinator thread.
    pub fn start(
        context: egui::Context,
        initial_volume: f32,
        initial_output_device: Option<String>,
        initial_dsp: DspSettings,
    ) -> Result<Self, std::io::Error> {
        let (command_tx, command_rx) = flume::unbounded();
        let (event_tx, event_rx) = flume::unbounded();
        let dsp_controls = DspControls::new(&initial_dsp);
        let runtime_dsp_controls = dsp_controls.clone();
        let thread = thread::Builder::new()
            .name("spotify-runtime".to_owned())
            .spawn(move || {
                runtime_thread(
                    command_rx,
                    event_tx,
                    context,
                    initial_volume,
                    initial_output_device,
                    initial_dsp,
                    runtime_dsp_controls,
                )
            })?;

        Ok(Self {
            command_tx,
            event_rx,
            dsp_controls,
            thread: Some(thread),
        })
    }

    /// Queues work without waiting for network or disk I/O.
    pub fn send(&self, command: SpotifyCommand) -> Result<(), SpotifyError> {
        self.command_tx
            .send(command)
            .map_err(|_| SpotifyError::RuntimeStopped)
    }

    /// Returns a lightweight command sender for native platform integrations.
    #[cfg(target_os = "windows")]
    pub(crate) fn command_sender(&self) -> Sender<SpotifyCommand> {
        self.command_tx.clone()
    }

    /// Drains all currently available worker events.
    pub fn drain(&self) -> flume::TryIter<'_, SpotifyEvent> {
        self.event_rx.try_iter()
    }

    /// Publishes DSP controls directly to the real-time audio sink.
    ///
    /// This intentionally bypasses the coordinator/playback command queues so slider
    /// movements are audible on the next audio callback instead of waiting for two
    /// asynchronous actors to schedule the update.
    pub fn apply_dsp_settings(&self, settings: &DspSettings) {
        self.dsp_controls.apply(settings);
    }

    /// Shares the existing lock-free DSP parameters with another native provider backend.
    pub(crate) fn dsp_controls(&self) -> Arc<DspControls> {
        self.dsp_controls.clone()
    }
}

impl Drop for SpotifyRuntime {
    fn drop(&mut self) {
        let _ = self.command_tx.send(SpotifyCommand::Shutdown);
        if let Some(thread) = self.thread.take() {
            let _ = thread.join();
        }
    }
}

fn runtime_thread(
    command_rx: Receiver<SpotifyCommand>,
    event_tx: Sender<SpotifyEvent>,
    context: egui::Context,
    initial_volume: f32,
    initial_output_device: Option<String>,
    initial_dsp: DspSettings,
    dsp_controls: Arc<DspControls>,
) {
    let runtime = match tokio::runtime::Builder::new_multi_thread()
        .worker_threads(3)
        .enable_all()
        .build()
    {
        Ok(runtime) => runtime,
        Err(error) => {
            emit(
                &event_tx,
                &context,
                SpotifyEvent::RuntimeFailed(error.to_string()),
            );
            return;
        }
    };

    runtime.block_on(async move {
        let client = match Client::builder()
            .user_agent(format!("Spoteq/{}", env!("CARGO_PKG_VERSION")))
            .connect_timeout(Duration::from_secs(8))
            .timeout(Duration::from_secs(25))
            .build()
        {
            Ok(client) => client,
            Err(error) => {
                emit(
                    &event_tx,
                    &context,
                    SpotifyEvent::RuntimeFailed(error.to_string()),
                );
                return;
            }
        };
        let store = match TokenStore::discover() {
            Ok(store) => store,
            Err(error) => {
                emit(
                    &event_tx,
                    &context,
                    SpotifyEvent::RuntimeFailed(error.to_string()),
                );
                return;
            }
        };
        let auth: SharedAuth = std::sync::Arc::new(AuthSession::new(store));
        let api = SpotifyApi::new(client.clone(), auth.clone());
        let playback_tx = playback::spawn(
            event_tx.clone(),
            context.clone(),
            initial_volume,
            initial_output_device,
            initial_dsp,
            dsp_controls,
        );

        emit(&event_tx, &context, SpotifyEvent::Restoring);
        spawn_restore(
            client.clone(),
            auth.clone(),
            api.clone(),
            playback_tx.clone(),
            event_tx.clone(),
            context.clone(),
        );

        while let Ok(command) = command_rx.recv_async().await {
            match command {
                SpotifyCommand::Login { client_id } => {
                    spawn_login(
                        client.clone(),
                        auth.clone(),
                        api.clone(),
                        client_id,
                        playback_tx.clone(),
                        event_tx.clone(),
                        context.clone(),
                    );
                }
                SpotifyCommand::Logout => {
                    let _ = playback_tx.send(PlaybackCommand::StopAndClear);
                    let auth = auth.clone();
                    let tx = event_tx.clone();
                    let ctx = context.clone();
                    tokio::spawn(async move {
                        match auth.logout().await {
                            Ok(()) => emit(&tx, &ctx, SpotifyEvent::LoggedOut),
                            Err(error) => {
                                emit(&tx, &ctx, SpotifyEvent::AuthFailed(error.to_string()))
                            }
                        }
                    });
                }
                SpotifyCommand::Search {
                    query,
                    scope,
                    generation,
                } => {
                    let api = api.clone();
                    let tx = event_tx.clone();
                    let ctx = context.clone();
                    tokio::spawn(async move {
                        let result = api
                            .search_scoped(&query, scope)
                            .await
                            .map_err(|error| error.to_string());
                        emit(
                            &tx,
                            &ctx,
                            SpotifyEvent::SearchFinished { generation, result },
                        );
                    });
                }
                SpotifyCommand::Recommend {
                    seeds,
                    generation,
                    limit,
                } => {
                    let api = api.clone();
                    let tx = event_tx.clone();
                    let ctx = context.clone();
                    tokio::spawn(async move {
                        let current_is_spotify = seeds.first().is_some_and(|track| {
                            matches!(&track.provider_id, ProviderTrackId::Spotify { .. })
                        });
                        let mut ids = if current_is_spotify {
                            seeds
                                .iter()
                                .filter_map(|track| match &track.provider_id {
                                    ProviderTrackId::Spotify { id, .. } => Some(id.clone()),
                                    ProviderTrackId::SoundCloud { .. } => None,
                                })
                                .take(5)
                                .collect::<Vec<_>>()
                        } else {
                            Vec::new()
                        };

                        // A cross-service seed is mapped to a real Spotify catalog item
                        // before asking Spotify for recommendations.
                        if ids.is_empty() {
                            if let Some(seed) = seeds.first() {
                                let query = format!("{} {}", seed.artist, seed.title);
                                if let Ok(matches) = api.search(&query).await {
                                    if let Some(track) = matches.first() {
                                        ids.push(track.id.clone());
                                    }
                                }
                            }
                        }

                        let result = match api.recommendations(&ids, limit).await {
                            Ok(tracks) => Ok(tracks),
                            Err(error) => {
                                // Some applications no longer have access to Spotify's
                                // recommendations endpoint. Build a real catalog fallback
                                // from several recent contexts (artist top tracks plus
                                // album/title searches) instead of repeating one artist.
                                tracing::warn!(%error, "Spotify recommendations unavailable; using contextual catalog fallback");
                                let mut fallback = Vec::new();
                                for seed in seeds.iter().take(3) {
                                    if let Ok(mut top) = api
                                        .search_scoped(&seed.artist, SearchScope::Artists)
                                        .await
                                    {
                                        fallback.append(&mut top);
                                    }
                                    let context_query = if seed.collection.trim().is_empty() {
                                        format!("{} {}", seed.artist, seed.title)
                                    } else {
                                        format!("{} {}", seed.artist, seed.collection)
                                    };
                                    if let Ok(mut matches) = api.search(&context_query).await {
                                        fallback.append(&mut matches);
                                    }
                                    if fallback.len() >= limit.saturating_mul(4) {
                                        break;
                                    }
                                }
                                if fallback.is_empty() {
                                    Err(error)
                                } else {
                                    Ok(fallback)
                                }
                            }
                        }
                        .map(|tracks| tracks.iter().map(TrackRow::from_spotify).collect())
                        .map_err(|error| error.to_string());
                        emit(
                            &tx,
                            &ctx,
                            SpotifyEvent::RecommendationsFinished { generation, result },
                        );
                    });
                }
                SpotifyCommand::LoadLiked { offset, generation } => {
                    let api = api.clone();
                    let tx = event_tx.clone();
                    let ctx = context.clone();
                    tokio::spawn(async move {
                        let result = api.liked(offset).await.map_err(|error| error.to_string());
                        emit(
                            &tx,
                            &ctx,
                            SpotifyEvent::LikedFinished {
                                offset,
                                generation,
                                result,
                            },
                        );
                    });
                }
                SpotifyCommand::SetSaved { uri, saved, request_id } => {
                    let api = api.clone();
                    let tx = event_tx.clone();
                    let ctx = context.clone();
                    tokio::spawn(async move {
                        let result = api
                            .set_saved(&uri, saved)
                            .await
                            .map_err(|error| error.to_string());
                        emit(&tx, &ctx, SpotifyEvent::SavedChanged { uri, saved, request_id, result });
                    });
                }
                SpotifyCommand::LoadSavedState { uri, stable_key, request_id } => {
                    let api = api.clone();
                    let tx = event_tx.clone();
                    let ctx = context.clone();
                    tokio::spawn(async move {
                        let result = api.is_saved(&uri).await.map_err(|error| error.to_string());
                        emit(&tx, &ctx, SpotifyEvent::SavedStateLoaded { stable_key, request_id, result });
                    });
                }
                SpotifyCommand::LoadImage { url } => {
                    let image_client = client.clone();
                    let tx = event_tx.clone();
                    let ctx = context.clone();
                    tokio::spawn(async move {
                        let result = load_cover(image_client, url.clone())
                            .await
                            .map_err(|error| error.to_string());
                        emit(&tx, &ctx, SpotifyEvent::ImageFinished { url, result });
                    });
                }
                SpotifyCommand::PlayQueue { tracks, index } => {
                    if playback_tx
                        .send(PlaybackCommand::PlayQueue { tracks, index })
                        .is_err()
                    {
                        emit(
                            &event_tx,
                            &context,
                            SpotifyEvent::RuntimeFailed(
                                "The direct playback service stopped".to_owned(),
                            ),
                        );
                    }
                }
                SpotifyCommand::PreloadTrack { uri } => {
                    let _ = playback_tx.send(PlaybackCommand::Preload(uri));
                }
                SpotifyCommand::TogglePlayback => {
                    let _ = playback_tx.send(PlaybackCommand::Toggle);
                }
                SpotifyCommand::Previous => {
                    let _ = playback_tx.send(PlaybackCommand::Previous);
                }
                SpotifyCommand::Next => {
                    let _ = playback_tx.send(PlaybackCommand::Next);
                }
                SpotifyCommand::Seek { position_ms } => {
                    let _ = playback_tx.send(PlaybackCommand::Seek(position_ms));
                }
                SpotifyCommand::SetVolume { volume } => {
                    let _ = playback_tx.send(PlaybackCommand::SetVolume(volume));
                }
                SpotifyCommand::SetOutputDevice { device } => {
                    let _ = playback_tx.send(PlaybackCommand::SetOutputDevice(device));
                }
                SpotifyCommand::RefreshAudioDevices => {
                    let _ = playback_tx.send(PlaybackCommand::RefreshAudioDevices);
                }
                SpotifyCommand::SetDspSettings(settings) => {
                    let _ = playback_tx.send(PlaybackCommand::SetDspSettings(settings));
                }
                SpotifyCommand::StopPlayback => {
                    let _ = playback_tx.send(PlaybackCommand::Suspend);
                }
                SpotifyCommand::Shutdown => {
                    let _ = playback_tx.send(PlaybackCommand::Shutdown);
                    break;
                }
            }
        }
    });
}

fn spawn_restore(
    client: Client,
    auth: SharedAuth,
    api: SpotifyApi,
    playback_tx: tokio::sync::mpsc::UnboundedSender<PlaybackCommand>,
    tx: Sender<SpotifyEvent>,
    ctx: egui::Context,
) {
    tokio::spawn(async move {
        match auth.restore(&client).await {
            Ok(false) => emit(&tx, &ctx, SpotifyEvent::LoggedOut),
            Ok(true) => match api.profile().await {
                Ok(profile) => {
                    let account_id = profile.id.clone();
                    let product = profile.product.clone();
                    emit(&tx, &ctx, SpotifyEvent::LoggedIn(profile));
                    if !auth.has_scope("user-library-modify").await {
                        emit(&tx, &ctx, SpotifyEvent::LibraryPermissionMissing);
                    }
                    let _ = playback_tx.send(PlaybackCommand::Prepare {
                        account_id,
                        product,
                    });
                }
                Err(error) => emit(&tx, &ctx, SpotifyEvent::AuthFailed(error.to_string())),
            },
            Err(error) => emit(&tx, &ctx, SpotifyEvent::AuthFailed(error.to_string())),
        }
    });
}

fn spawn_login(
    client: Client,
    auth: SharedAuth,
    api: SpotifyApi,
    client_id: String,
    playback_tx: tokio::sync::mpsc::UnboundedSender<PlaybackCommand>,
    tx: Sender<SpotifyEvent>,
    ctx: egui::Context,
) {
    emit(&tx, &ctx, SpotifyEvent::Authorizing);
    tokio::spawn(async move {
        match auth.login(&client, client_id).await {
            Ok(()) => match api.profile().await {
                Ok(profile) => {
                    let account_id = profile.id.clone();
                    let product = profile.product.clone();
                    emit(&tx, &ctx, SpotifyEvent::LoggedIn(profile));
                    if !auth.has_scope("user-library-modify").await {
                        emit(&tx, &ctx, SpotifyEvent::LibraryPermissionMissing);
                    }
                    let _ = playback_tx.send(PlaybackCommand::Prepare {
                        account_id,
                        product,
                    });
                }
                Err(error) => emit(&tx, &ctx, SpotifyEvent::AuthFailed(error.to_string())),
            },
            Err(error) => emit(&tx, &ctx, SpotifyEvent::AuthFailed(error.to_string())),
        }
    });
}

fn emit(tx: &Sender<SpotifyEvent>, context: &egui::Context, event: SpotifyEvent) {
    if tx.send(event).is_ok() {
        context.request_repaint();
    }
}
