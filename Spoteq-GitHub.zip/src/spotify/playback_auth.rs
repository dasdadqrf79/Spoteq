//! Independent OAuth token storage for direct librespot playback.

use std::{
    fs::{self, File},
    io::{BufReader, BufWriter, Write},
    path::{Path, PathBuf},
    time::{Duration, Instant, SystemTime, UNIX_EPOCH},
};

use librespot_core::SessionConfig;
use librespot_oauth::{OAuthClient, OAuthClientBuilder, OAuthToken};
use serde::{Deserialize, Serialize};

use crate::{
    spotify::{PlaybackError, PlaybackErrorKind},
    storage::{DirectoryKind, app_directory},
};

pub(crate) const PLAYBACK_REDIRECT_URI: &str = "http://127.0.0.1:8898/login";
const PLAYBACK_SCOPES: &[&str] = &["streaming"];

#[derive(Debug, Clone, Serialize, Deserialize)]
struct StoredPlaybackToken {
    access_token: String,
    refresh_token: String,
    expires_at: u64,
    scopes: Vec<String>,
}

/// Owns the OAuth token used only by the direct librespot Session.
pub(crate) struct PlaybackAuth {
    token: Option<StoredPlaybackToken>,
    path: PathBuf,
}

impl PlaybackAuth {
    pub fn discover() -> Result<Self, PlaybackError> {
        let path = app_directory(DirectoryKind::DataLocal)
            .map(|directory| directory.join("spotify-playback-token.json"))
            .ok_or_else(|| auth_error("Spotify playback data directory is unavailable."))?;
        let token: Option<StoredPlaybackToken> = match File::open(&path) {
            Ok(file) => match serde_json::from_reader(BufReader::new(file)) {
                Ok(token) => Some(token),
                Err(_) => {
                    let _ = fs::remove_file(&path);
                    None
                }
            },
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => None,
            Err(error) => {
                return Err(auth_error(format!(
                    "Could not read Spotify playback authorization: {error}"
                )));
            }
        };
        Ok(Self { token, path })
    }

    pub fn has_saved_token(&self) -> bool {
        self.token.is_some()
    }

    /// Restores or refreshes a token without opening a browser.
    pub async fn restore(&mut self) -> Result<Option<String>, PlaybackError> {
        let Some(token) = self.token.as_ref() else {
            return Ok(None);
        };
        if !token.scopes.iter().any(|scope| scope == "streaming") {
            self.clear()?;
            return Ok(None);
        }
        if token.expires_at > unix_time().saturating_add(60) {
            return Ok(Some(token.access_token.clone()));
        }

        let refresh_token = token.refresh_token.clone();
        if refresh_token.is_empty() {
            self.clear()?;
            return Ok(None);
        }
        let client = oauth_client()?;
        match client.refresh_token_async(&refresh_token).await {
            Ok(refreshed) => {
                self.save_oauth_token(refreshed, Some(refresh_token))?;
                Ok(self.token.as_ref().map(|token| token.access_token.clone()))
            }
            Err(_) => {
                self.clear()?;
                Err(auth_error(
                    "Playback authorization expired. Reconnect Spotify playback.",
                ))
            }
        }
    }

    /// Returns a token, opening the official Spotify authorization page when needed.
    pub async fn authorize_if_needed(&mut self) -> Result<String, PlaybackError> {
        if let Some(token) = self.restore().await? {
            return Ok(token);
        }

        let token = tokio::task::spawn_blocking(|| {
            oauth_client().and_then(|client| {
                client.get_access_token().map_err(|error| {
                    auth_error(format!(
                        "Direct playback authentication failed. \
                             Reconnect Spotify playback. ({error})"
                    ))
                })
            })
        })
        .await
        .map_err(|error| auth_error(format!("Playback OAuth task failed: {error}")))??;

        self.save_oauth_token(token, None)?;
        self.token
            .as_ref()
            .map(|token| token.access_token.clone())
            .ok_or_else(|| auth_error("Playback OAuth did not return an access token."))
    }

    pub fn clear(&mut self) -> Result<(), PlaybackError> {
        self.token = None;
        match fs::remove_file(&self.path) {
            Ok(()) => Ok(()),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(()),
            Err(error) => Err(auth_error(format!(
                "Could not clear Spotify playback authorization: {error}"
            ))),
        }
    }

    fn save_oauth_token(
        &mut self,
        token: OAuthToken,
        previous_refresh_token: Option<String>,
    ) -> Result<(), PlaybackError> {
        if !token.scopes.iter().any(|scope| scope == "streaming") {
            return Err(PlaybackError::new(
                PlaybackErrorKind::MissingStreamingScope,
                "Spotify did not grant playback permission. Reconnect Spotify playback.",
            ));
        }
        let refresh_token = if token.refresh_token.is_empty() {
            previous_refresh_token.unwrap_or_default()
        } else {
            token.refresh_token
        };
        let remaining = token.expires_at.saturating_duration_since(Instant::now());
        let stored = StoredPlaybackToken {
            access_token: token.access_token,
            refresh_token,
            expires_at: unix_time().saturating_add(remaining.as_secs()),
            scopes: token.scopes,
        };
        save_token(&self.path, &stored)?;
        self.token = Some(stored);
        Ok(())
    }
}

fn oauth_client() -> Result<OAuthClient, PlaybackError> {
    let client_id = SessionConfig::default().client_id;
    OAuthClientBuilder::new(&client_id, PLAYBACK_REDIRECT_URI, PLAYBACK_SCOPES.to_vec())
        .open_in_browser()
        .with_custom_message("Spoteq playback is connected. You can close this tab.")
        .build()
        .map_err(|error| auth_error(format!("Could not configure playback OAuth: {error}")))
}

fn save_token(path: &Path, token: &StoredPlaybackToken) -> Result<(), PlaybackError> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).map_err(|error| {
            auth_error(format!(
                "Could not create playback token directory: {error}"
            ))
        })?;
    }
    let temporary = path.with_extension("json.tmp");
    {
        let file = create_private_file(&temporary).map_err(|error| {
            auth_error(format!("Could not create playback token file: {error}"))
        })?;
        let mut writer = BufWriter::new(file);
        serde_json::to_writer_pretty(&mut writer, token).map_err(|error| {
            auth_error(format!("Could not encode playback authorization: {error}"))
        })?;
        writer
            .write_all(b"\n")
            .and_then(|_| writer.flush())
            .and_then(|_| writer.get_ref().sync_all())
            .map_err(|error| {
                auth_error(format!("Could not save playback authorization: {error}"))
            })?;
    }
    if path.exists() {
        fs::remove_file(path).map_err(|error| {
            auth_error(format!("Could not replace playback authorization: {error}"))
        })?;
    }
    fs::rename(&temporary, path)
        .map_err(|error| auth_error(format!("Could not commit playback authorization: {error}")))
}

#[cfg(unix)]
fn create_private_file(path: &Path) -> Result<File, std::io::Error> {
    use std::os::unix::fs::OpenOptionsExt;
    fs::OpenOptions::new()
        .create(true)
        .truncate(true)
        .write(true)
        .mode(0o600)
        .open(path)
}

#[cfg(not(unix))]
fn create_private_file(path: &Path) -> Result<File, std::io::Error> {
    File::create(path)
}

fn auth_error(message: impl Into<String>) -> PlaybackError {
    PlaybackError::new(PlaybackErrorKind::AccountAuthentication, message)
}

fn unix_time() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or(Duration::ZERO)
        .as_secs()
}
