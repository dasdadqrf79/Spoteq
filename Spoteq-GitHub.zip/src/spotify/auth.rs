use std::{
    sync::Arc,
    time::{Duration, SystemTime, UNIX_EPOCH},
};

use base64::{Engine as _, engine::general_purpose::URL_SAFE_NO_PAD};
use reqwest::Client;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use tokio::{
    io::{AsyncReadExt, AsyncWriteExt},
    net::TcpListener,
    sync::Mutex,
    time::timeout,
};
use url::Url;

use crate::spotify::{REGISTERED_REDIRECT_URI, SpotifyError, token_store::TokenStore};

const AUTHORIZE_URL: &str = "https://accounts.spotify.com/authorize";
const TOKEN_URL: &str = "https://accounts.spotify.com/api/token";
const SCOPES: &str = "user-read-private user-library-read user-library-modify";
const CALLBACK_TIMEOUT: Duration = Duration::from_secs(180);

/// OAuth token snapshot stored between launches.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub(crate) struct StoredToken {
    pub client_id: String,
    pub access_token: String,
    pub refresh_token: String,
    pub expires_at: u64,
    pub scope: String,
}

#[derive(Debug, Deserialize)]
struct TokenResponse {
    access_token: String,
    expires_in: u64,
    refresh_token: Option<String>,
    #[serde(default)]
    scope: String,
}

/// Serializes refreshes so concurrent API calls cannot race token replacement.
pub(crate) struct AuthSession {
    token: Mutex<Option<StoredToken>>,
    store: TokenStore,
}

impl AuthSession {
    pub fn new(store: TokenStore) -> Self {
        Self {
            token: Mutex::new(None),
            store,
        }
    }

    pub async fn restore(&self, client: &Client) -> Result<bool, SpotifyError> {
        let loaded = self.store.load()?;
        {
            let mut token = self.token.lock().await;
            *token = loaded;
        }
        if self.token.lock().await.is_none() {
            return Ok(false);
        }
        self.access_token(client).await?;
        Ok(true)
    }

    pub async fn login(&self, client: &Client, client_id: String) -> Result<(), SpotifyError> {
        let client_id = client_id.trim().to_owned();
        if client_id.is_empty() {
            return Err(SpotifyError::MissingClientId);
        }

        let token = authorize(client, client_id).await?;
        self.store.save(&token)?;
        *self.token.lock().await = Some(token);
        Ok(())
    }

    pub async fn logout(&self) -> Result<(), SpotifyError> {
        self.store.clear()?;
        *self.token.lock().await = None;
        Ok(())
    }

    pub async fn access_token(&self, client: &Client) -> Result<String, SpotifyError> {
        let mut token_guard = self.token.lock().await;
        let token = token_guard.as_mut().ok_or(SpotifyError::NotAuthenticated)?;

        if token.expires_at <= unix_time().saturating_add(60) {
            refresh(client, token).await?;
            self.store.save(token)?;
        }
        Ok(token.access_token.clone())
    }

    pub async fn force_refresh(&self, client: &Client) -> Result<String, SpotifyError> {
        let mut token_guard = self.token.lock().await;
        let token = token_guard.as_mut().ok_or(SpotifyError::NotAuthenticated)?;
        refresh(client, token).await?;
        self.store.save(token)?;
        Ok(token.access_token.clone())
    }

    /// Reports whether the currently stored grant includes one exact scope.
    pub async fn has_scope(&self, required: &str) -> bool {
        self.token.lock().await.as_ref().is_some_and(|token| {
            token
                .scope
                .split_whitespace()
                .any(|scope| scope == required)
        })
    }
}

async fn authorize(client: &Client, client_id: String) -> Result<StoredToken, SpotifyError> {
    let listener = TcpListener::bind("127.0.0.1:8000").await?;
    let redirect_uri = REGISTERED_REDIRECT_URI.to_owned();

    let verifier = random_urlsafe(64)?;
    let state = random_urlsafe(24)?;
    let challenge = URL_SAFE_NO_PAD.encode(Sha256::digest(verifier.as_bytes()));

    let mut authorization_url = Url::parse(AUTHORIZE_URL)?;
    authorization_url
        .query_pairs_mut()
        .append_pair("client_id", &client_id)
        .append_pair("response_type", "code")
        .append_pair("redirect_uri", &redirect_uri)
        .append_pair("scope", SCOPES)
        .append_pair("state", &state)
        .append_pair("code_challenge_method", "S256")
        .append_pair("code_challenge", &challenge);

    let browser_url = authorization_url.to_string();
    tokio::task::spawn_blocking(move || webbrowser::open(&browser_url))
        .await
        .map_err(|error| SpotifyError::Browser(error.to_string()))?
        .map_err(|error| SpotifyError::Browser(error.to_string()))?;

    let callback = timeout(CALLBACK_TIMEOUT, receive_callback(listener, &state))
        .await
        .map_err(|_| SpotifyError::AuthorizationTimeout)??;

    let response = client
        .post(TOKEN_URL)
        .form(&[
            ("client_id", client_id.as_str()),
            ("grant_type", "authorization_code"),
            ("code", callback.as_str()),
            ("redirect_uri", redirect_uri.as_str()),
            ("code_verifier", verifier.as_str()),
        ])
        .send()
        .await?;
    let token_response: TokenResponse = parse_token_response(response).await?;
    let refresh_token = token_response
        .refresh_token
        .ok_or_else(|| SpotifyError::Api {
            status: 200,
            message: "authorization response did not contain a refresh token".to_owned(),
        })?;

    Ok(StoredToken {
        client_id,
        access_token: token_response.access_token,
        refresh_token,
        expires_at: unix_time().saturating_add(token_response.expires_in),
        scope: token_response.scope,
    })
}

async fn refresh(client: &Client, token: &mut StoredToken) -> Result<(), SpotifyError> {
    let response = client
        .post(TOKEN_URL)
        .form(&[
            ("grant_type", "refresh_token"),
            ("refresh_token", token.refresh_token.as_str()),
            ("client_id", token.client_id.as_str()),
        ])
        .send()
        .await?;
    let refreshed = parse_token_response(response).await?;
    token.access_token = refreshed.access_token;
    token.expires_at = unix_time().saturating_add(refreshed.expires_in);
    if let Some(refresh_token) = refreshed.refresh_token {
        token.refresh_token = refresh_token;
    }
    if !refreshed.scope.is_empty() {
        token.scope = refreshed.scope;
    }
    Ok(())
}

async fn parse_token_response(response: reqwest::Response) -> Result<TokenResponse, SpotifyError> {
    let status = response.status();
    if status.is_success() {
        return Ok(response.json().await?);
    }
    let message = response
        .text()
        .await
        .unwrap_or_else(|_| "unknown error".to_owned());
    Err(SpotifyError::Api {
        status: status.as_u16(),
        message,
    })
}

async fn receive_callback(
    listener: TcpListener,
    expected_state: &str,
) -> Result<String, SpotifyError> {
    let (mut stream, _) = listener.accept().await?;
    let mut bytes = Vec::with_capacity(2048);
    let mut chunk = [0_u8; 1024];
    while bytes.len() < 16 * 1024 {
        let read = stream.read(&mut chunk).await?;
        if read == 0 {
            break;
        }
        bytes.extend_from_slice(&chunk[..read]);
        if bytes.windows(4).any(|window| window == b"\r\n\r\n") {
            break;
        }
    }
    let request = String::from_utf8_lossy(&bytes);
    let target = request
        .lines()
        .next()
        .and_then(|line| line.split_whitespace().nth(1))
        .ok_or(SpotifyError::InvalidCallback)?;
    let callback_url = Url::parse(&format!("http://127.0.0.1{target}"))?;

    let mut code = None;
    let mut state = None;
    let mut oauth_error = None;
    for (key, value) in callback_url.query_pairs() {
        match key.as_ref() {
            "code" => code = Some(value.into_owned()),
            "state" => state = Some(value.into_owned()),
            "error" => oauth_error = Some(value.into_owned()),
            _ => {}
        }
    }

    let success =
        oauth_error.is_none() && state.as_deref() == Some(expected_state) && code.is_some();
    let body = if success {
        "Spoteq is connected to Spotify. You can close this tab."
    } else {
        "Spoteq could not complete Spotify authorization. Return to the application."
    };
    let reply = format!(
        concat!(
            "HTTP/1.1 200 OK\r\n",
            "Content-Type: text/plain; charset=utf-8\r\n",
            "Content-Length: {}\r\n",
            "Connection: close\r\n\r\n{}"
        ),
        body.len(),
        body
    );
    let _ = stream.write_all(reply.as_bytes()).await;
    let _ = stream.shutdown().await;

    if let Some(error) = oauth_error {
        return Err(SpotifyError::AuthorizationDenied(error));
    }
    if state.as_deref() != Some(expected_state) {
        return Err(SpotifyError::InvalidCallback);
    }
    code.ok_or(SpotifyError::InvalidCallback)
}

fn random_urlsafe(length: usize) -> Result<String, SpotifyError> {
    let mut bytes = vec![0_u8; length];
    getrandom::fill(&mut bytes).map_err(|error| SpotifyError::Random(error.to_string()))?;
    Ok(URL_SAFE_NO_PAD.encode(bytes))
}

fn unix_time() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

pub(crate) type SharedAuth = Arc<AuthSession>;
