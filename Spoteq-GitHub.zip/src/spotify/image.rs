use std::{
    fs,
    path::Path,
    time::{SystemTime, UNIX_EPOCH},
};

use reqwest::Client;
use sha2::{Digest, Sha256};

use crate::{
    spotify::{DecodedImage, SpotifyError},
    storage::{DirectoryKind, app_directory},
};

const MAX_IMAGE_BYTES: u64 = 10 * 1024 * 1024;
const MAX_DISK_CACHE_BYTES: u64 = 256 * 1024 * 1024;

/// Downloads, persists and decodes one cover outside the UI thread.
pub(crate) async fn load_cover(client: Client, url: String) -> Result<DecodedImage, SpotifyError> {
    let cache_dir = app_directory(DirectoryKind::Cache)
        .map(|directory| directory.join("covers"))
        .ok_or(SpotifyError::DataDirectoryUnavailable)?;
    let cache_path = cache_dir.join(cache_key(&url));

    let cached_path = cache_path.clone();
    let cached = tokio::task::spawn_blocking(move || {
        let bytes = fs::read(&cached_path)?;
        // One rewrite per process-level cache miss refreshes mtime for disk LRU eviction.
        let _ = fs::write(&cached_path, &bytes);
        Ok::<_, std::io::Error>(bytes)
    })
    .await
    .map_err(|error| SpotifyError::Image(error.to_string()))?;
    let bytes = match cached {
        Ok(bytes) => bytes,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
            let response = client.get(&url).send().await?;
            if !response.status().is_success() {
                return Err(SpotifyError::Api {
                    status: response.status().as_u16(),
                    message: "album cover download failed".to_owned(),
                });
            }
            if response
                .content_length()
                .is_some_and(|size| size > MAX_IMAGE_BYTES)
            {
                return Err(SpotifyError::Image("album cover is too large".to_owned()));
            }
            let bytes = response.bytes().await?.to_vec();
            if bytes.len() as u64 > MAX_IMAGE_BYTES {
                return Err(SpotifyError::Image("album cover is too large".to_owned()));
            }

            let write_bytes = bytes.clone();
            let write_dir = cache_dir.clone();
            let write_path = cache_path.clone();
            tokio::task::spawn_blocking(move || {
                fs::create_dir_all(&write_dir)?;
                let temporary = write_path.with_extension("tmp");
                fs::write(&temporary, write_bytes)?;
                if write_path.exists() {
                    let _ = fs::remove_file(&write_path);
                }
                fs::rename(temporary, write_path)?;
                evict_disk_cache(&write_dir)
            })
            .await
            .map_err(|error| SpotifyError::Image(error.to_string()))??;
            bytes
        }
        Err(error) => return Err(error.into()),
    };

    tokio::task::spawn_blocking(move || decode(bytes))
        .await
        .map_err(|error| SpotifyError::Image(error.to_string()))?
}

fn decode(bytes: Vec<u8>) -> Result<DecodedImage, SpotifyError> {
    let image = image::load_from_memory(&bytes)
        .map_err(|error| SpotifyError::Image(error.to_string()))?
        .thumbnail(320, 320)
        .to_rgba8();
    let size = [image.width() as usize, image.height() as usize];
    Ok(DecodedImage {
        size,
        rgba: image.into_raw(),
    })
}

fn cache_key(url: &str) -> String {
    let digest = Sha256::digest(url.as_bytes());
    format!("{digest:x}.img")
}

fn evict_disk_cache(directory: &Path) -> Result<(), std::io::Error> {
    let mut entries = Vec::new();
    let mut total = 0_u64;
    for entry in fs::read_dir(directory)? {
        let entry = entry?;
        let metadata = entry.metadata()?;
        if !metadata.is_file()
            || entry.path().extension().and_then(|value| value.to_str()) != Some("img")
        {
            continue;
        }
        let size = metadata.len();
        total = total.saturating_add(size);
        entries.push((modified_or_epoch(&metadata), entry.path(), size));
    }
    if total <= MAX_DISK_CACHE_BYTES {
        return Ok(());
    }
    entries.sort_by_key(|entry| entry.0);
    for (_, path, size) in entries {
        if total <= MAX_DISK_CACHE_BYTES {
            break;
        }
        if fs::remove_file(path).is_ok() {
            total = total.saturating_sub(size);
        }
    }
    Ok(())
}

fn modified_or_epoch(metadata: &fs::Metadata) -> SystemTime {
    metadata.modified().unwrap_or(UNIX_EPOCH)
}
