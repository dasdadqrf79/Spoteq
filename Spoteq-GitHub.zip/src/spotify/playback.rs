//! Single-owner direct librespot playback actor.

use std::{
    sync::Arc,
    time::{Duration, Instant},
};

use cpal::traits::{DeviceTrait, HostTrait};
use eframe::egui;
use librespot_core::{
    Error as LibrespotError, Session, SessionConfig, SpotifyUri, authentication::Credentials,
    error::ErrorKind as LibrespotErrorKind,
};
use librespot_playback::{
    audio_backend,
    config::{AudioFormat, Bitrate, PlayerConfig},
    mixer::{self, Mixer, MixerConfig},
    player::{Player, PlayerEvent, PlayerEventChannel},
};
use tokio::sync::mpsc;

use crate::{
    audio::dsp::{DspControls, DspSettings, DspSink},
    spotify::{PlaybackError, PlaybackErrorKind, Track, playback_auth::PlaybackAuth},
};

/// Playback state rendered by the UI.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum PlaybackStatus {
    /// No track has been selected.
    Idle,
    /// A direct librespot session is being established.
    Connecting,
    /// A separate browser authorization is being completed for playback.
    Authorizing,
    /// Track metadata or audio is being buffered.
    Loading,
    /// Audio is currently playing.
    Playing,
    /// The current track is paused.
    Paused,
    /// Playback failed without terminating the application.
    Error(PlaybackError),
}

/// Immutable playback snapshot sent from the actor to the UI thread.
#[derive(Debug, Clone)]
pub struct PlaybackUpdate {
    /// Current queue item, if one is selected.
    pub track: Option<Track>,
    /// Current player state.
    pub status: PlaybackStatus,
    /// Position reported by librespot in milliseconds.
    pub position_ms: u32,
    /// Zero-based queue index.
    pub queue_index: Option<usize>,
    /// Number of tracks in the local queue.
    pub queue_len: usize,
    /// True only for the terminal snapshot emitted when the active queue item ends.
    pub ended: bool,
}

/// Commands serialized by the playback actor.
#[derive(Debug)]
pub(crate) enum PlaybackCommand {
    Prepare {
        account_id: String,
        product: Option<String>,
    },
    PlayQueue {
        tracks: Vec<Track>,
        index: usize,
    },
    /// Requests librespot to warm the encrypted audio/cache for one likely track.
    Preload(String),
    Toggle,
    Previous,
    Next,
    Seek(u32),
    SetVolume(f32),
    SetOutputDevice(Option<String>),
    RefreshAudioDevices,
    SetDspSettings(DspSettings),
    StopAndClear,
    Suspend,
    Shutdown,
}

struct PlaybackEngine {
    session: Session,
    player: Arc<Player>,
    events: PlayerEventChannel,
    mixer: Arc<dyn Mixer>,
}

enum ActorInput {
    Command(Option<PlaybackCommand>),
    PlayerEvent(Option<PlayerEvent>),
    DspPoll,
}

/// Starts the only task allowed to own or control a librespot Player.
pub(crate) fn spawn(
    event_tx: flume::Sender<crate::spotify::SpotifyEvent>,
    context: egui::Context,
    initial_volume: f32,
    initial_output_device: Option<String>,
    initial_dsp: DspSettings,
    dsp_controls: Arc<DspControls>,
) -> mpsc::UnboundedSender<PlaybackCommand> {
    let (command_tx, command_rx) = mpsc::unbounded_channel();
    tokio::spawn(run(
        command_rx,
        event_tx,
        context,
        initial_volume,
        initial_output_device,
        initial_dsp,
        dsp_controls,
    ));
    command_tx
}

async fn run(
    mut commands: mpsc::UnboundedReceiver<PlaybackCommand>,
    event_tx: flume::Sender<crate::spotify::SpotifyEvent>,
    context: egui::Context,
    initial_volume: f32,
    initial_output_device: Option<String>,
    initial_dsp: DspSettings,
    dsp_controls: Arc<DspControls>,
) {
    let mut playback_auth = PlaybackAuth::discover();
    let mut engine: Option<PlaybackEngine> = None;
    let mut queue = Vec::<Track>::new();
    let mut index = None;
    let mut position_ms = 0_u32;
    let mut status = PlaybackStatus::Idle;
    let mut volume = initial_volume.clamp(0.0, 1.0);
    let mut output_device = normalize_output_device(initial_output_device);
    let mut dsp_enabled = initial_dsp.enabled;
    let mut last_dsp_apply_log = None::<Instant>;
    let mut dsp_poll = tokio::time::interval(Duration::from_secs(1));
    dsp_poll.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
    let mut play_request_id = None;
    let mut premium_account = None;
    let mut expected_account_id = None;
    let mut pending_preload_uri: Option<String> = None;

    emit_audio_devices(&event_tx, &context);
    tracing::info!(bands = crate::settings::EQ_BAND_COUNT, "DSP initialized");

    loop {
        let input = if let Some(active) = engine.as_mut() {
            tokio::select! {
                command = commands.recv() => ActorInput::Command(command),
                event = active.events.recv() => ActorInput::PlayerEvent(event),
                _ = dsp_poll.tick() => ActorInput::DspPoll,
            }
        } else {
            ActorInput::Command(commands.recv().await)
        };

        match input {
            ActorInput::Command(Some(PlaybackCommand::Prepare {
                account_id,
                product,
            })) => {
                expected_account_id = Some(account_id);
                premium_account = product.map(|tier| tier.eq_ignore_ascii_case("premium"));
                if premium_account == Some(false) {
                    engine = None;
                    continue;
                }
                let has_saved_token = playback_auth
                    .as_ref()
                    .is_ok_and(PlaybackAuth::has_saved_token);
                let needs_engine = has_saved_token
                    && engine
                        .as_ref()
                        .is_none_or(|active| active.player.is_invalid());
                if needs_engine {
                    match create_engine(
                        &mut playback_auth,
                        false,
                        expected_account_id.as_deref(),
                        volume,
                        output_device.clone(),
                        dsp_controls.clone(),
                    )
                    .await
                    {
                        Ok(created) => {
                            engine = Some(created);
                            if let (Some(active), Some(uri)) =
                                (engine.as_ref(), pending_preload_uri.take())
                            {
                                if let Ok(parsed) = SpotifyUri::from_uri(&uri) {
                                    active.player.preload(parsed);
                                }
                            }
                        }
                        Err(error) => {
                            status = PlaybackStatus::Error(error);
                            emit_snapshot(&event_tx, &context, &queue, index, &status, position_ms);
                        }
                    }
                }
            }
            ActorInput::Command(Some(PlaybackCommand::PlayQueue {
                tracks,
                index: requested,
            })) => {
                if requested >= tracks.len() {
                    emit_error(
                        &event_tx,
                        &context,
                        &queue,
                        index,
                        position_ms,
                        PlaybackError::new(
                            PlaybackErrorKind::TrackUnavailable,
                            "The selected track is outside the local queue.",
                        ),
                    );
                    continue;
                }
                queue = tracks;
                index = Some(requested);
                position_ms = 0;
                play_request_id = None;
                if premium_account == Some(false) {
                    status = PlaybackStatus::Error(PlaybackError::new(
                        PlaybackErrorKind::PremiumRequired,
                        "Direct playback requires a Spotify Premium account.",
                    ));
                    emit_snapshot(&event_tx, &context, &queue, index, &status, position_ms);
                    continue;
                }
                let needs_browser = playback_auth
                    .as_ref()
                    .is_ok_and(|auth| !auth.has_saved_token());
                status = if needs_browser {
                    PlaybackStatus::Authorizing
                } else {
                    PlaybackStatus::Connecting
                };
                emit_snapshot(&event_tx, &context, &queue, index, &status, position_ms);

                let needs_engine = engine
                    .as_ref()
                    .is_none_or(|active| active.player.is_invalid());
                if needs_engine {
                    match create_engine(
                        &mut playback_auth,
                        true,
                        expected_account_id.as_deref(),
                        volume,
                        output_device.clone(),
                        dsp_controls.clone(),
                    )
                    .await
                    {
                        Ok(created) => {
                            engine = Some(created);
                            if let (Some(active), Some(uri)) =
                                (engine.as_ref(), pending_preload_uri.take())
                            {
                                if let Ok(parsed) = SpotifyUri::from_uri(&uri) {
                                    active.player.preload(parsed);
                                }
                            }
                        }
                        Err(error) => {
                            status = PlaybackStatus::Error(error);
                            emit_snapshot(&event_tx, &context, &queue, index, &status, position_ms);
                            engine = None;
                            continue;
                        }
                    }
                }

                if let Err(error) = load_index(&engine, &queue, requested, 0, true) {
                    status = PlaybackStatus::Error(error);
                } else {
                    status = PlaybackStatus::Loading;
                }
                emit_snapshot(&event_tx, &context, &queue, index, &status, position_ms);
            }
            ActorInput::Command(Some(PlaybackCommand::Preload(uri))) => {
                if let Some(active) = engine.as_ref() {
                    if let Ok(parsed) = SpotifyUri::from_uri(&uri) {
                        tracing::debug!(track_uri = %uri, "Spotify fast-start preload requested");
                        active.player.preload(parsed);
                    }
                } else {
                    pending_preload_uri = Some(uri);
                }
            }
            ActorInput::Command(Some(PlaybackCommand::Toggle)) => {
                if let Some(active) = engine.as_ref() {
                    if status == PlaybackStatus::Playing {
                        active.player.pause();
                    } else if status == PlaybackStatus::Paused {
                        let at_end =
                            index
                                .and_then(|current| queue.get(current))
                                .is_some_and(|track| {
                                    u64::from(position_ms).saturating_add(500) >= track.duration_ms
                                });
                        if at_end {
                            if let Some(current) = index {
                                play_request_id = None;
                                position_ms = 0;
                                if let Err(error) = load_index(&engine, &queue, current, 0, true) {
                                    status = PlaybackStatus::Error(error);
                                } else {
                                    status = PlaybackStatus::Loading;
                                }
                                emit_snapshot(
                                    &event_tx,
                                    &context,
                                    &queue,
                                    index,
                                    &status,
                                    position_ms,
                                );
                            }
                        } else {
                            active.player.play();
                        }
                    }
                }
            }
            ActorInput::Command(Some(PlaybackCommand::Previous)) => {
                if let Some(active) = engine.as_ref() {
                    if position_ms > 5_000 {
                        active.player.seek(0);
                    } else if let Some(current) = index {
                        let previous = current.saturating_sub(1);
                        index = Some(previous);
                        position_ms = 0;
                        play_request_id = None;
                        if let Err(error) = load_index(&engine, &queue, previous, 0, true) {
                            status = PlaybackStatus::Error(error);
                        } else {
                            status = PlaybackStatus::Loading;
                        }
                        emit_snapshot(&event_tx, &context, &queue, index, &status, position_ms);
                    }
                }
            }
            ActorInput::Command(Some(PlaybackCommand::Next)) => {
                if let Some(current) = index {
                    let next = current.saturating_add(1);
                    if next < queue.len() {
                        index = Some(next);
                        position_ms = 0;
                        play_request_id = None;
                        if let Err(error) = load_index(&engine, &queue, next, 0, true) {
                            status = PlaybackStatus::Error(error);
                        } else {
                            status = PlaybackStatus::Loading;
                        }
                        emit_snapshot(&event_tx, &context, &queue, index, &status, position_ms);
                    }
                }
            }
            ActorInput::Command(Some(PlaybackCommand::Seek(requested))) => {
                if let (Some(active), Some(current)) = (engine.as_ref(), index) {
                    let duration = queue
                        .get(current)
                        .map(|track| track.duration_ms.min(u64::from(u32::MAX)) as u32)
                        .unwrap_or(0);
                    let target = requested.min(duration);
                    active.player.seek(target);
                    position_ms = target;
                    emit_snapshot(&event_tx, &context, &queue, index, &status, position_ms);
                }
            }
            ActorInput::Command(Some(PlaybackCommand::SetVolume(requested))) => {
                volume = requested.clamp(0.0, 1.0);
                if let Some(active) = engine.as_ref() {
                    active.mixer.set_volume(volume_to_u16(volume));
                }
            }
            ActorInput::Command(Some(PlaybackCommand::SetOutputDevice(requested))) => {
                output_device = normalize_output_device(requested);
                let resume_playback = matches!(
                    &status,
                    PlaybackStatus::Playing | PlaybackStatus::Loading | PlaybackStatus::Connecting
                );

                if let Some(previous) = engine.take() {
                    previous.player.stop();
                    let session = previous.session.clone();
                    drop(previous);

                    match build_engine(session, volume, output_device.clone(), dsp_controls.clone())
                    {
                        Ok(created) => {
                            engine = Some(created);
                            play_request_id = None;
                            if let Some(current) = index {
                                if let Err(error) = load_index(
                                    &engine,
                                    &queue,
                                    current,
                                    position_ms,
                                    resume_playback,
                                ) {
                                    status = PlaybackStatus::Error(error);
                                } else {
                                    status = if resume_playback {
                                        PlaybackStatus::Loading
                                    } else {
                                        PlaybackStatus::Paused
                                    };
                                }
                                emit_snapshot(
                                    &event_tx,
                                    &context,
                                    &queue,
                                    index,
                                    &status,
                                    position_ms,
                                );
                            }
                        }
                        Err(error) => {
                            status = PlaybackStatus::Error(error);
                            emit_snapshot(&event_tx, &context, &queue, index, &status, position_ms);
                        }
                    }
                }
                emit_audio_devices(&event_tx, &context);
            }
            ActorInput::Command(Some(PlaybackCommand::RefreshAudioDevices)) => {
                emit_audio_devices(&event_tx, &context);
            }
            ActorInput::Command(Some(PlaybackCommand::SetDspSettings(settings))) => {
                if settings.enabled != dsp_enabled {
                    dsp_enabled = settings.enabled;
                    if dsp_enabled {
                        tracing::info!("EQ enabled");
                    } else {
                        tracing::info!("EQ disabled");
                    }
                }
                dsp_controls.apply(&settings);
                if last_dsp_apply_log
                    .is_none_or(|last| last.elapsed() >= Duration::from_millis(500))
                {
                    tracing::info!("EQ settings applied");
                    last_dsp_apply_log = Some(Instant::now());
                }
            }
            ActorInput::Command(Some(PlaybackCommand::StopAndClear)) => {
                if let Some(active) = engine.as_ref() {
                    active.player.stop();
                }
                engine = None;
                queue.clear();
                index = None;
                position_ms = 0;
                play_request_id = None;
                status = PlaybackStatus::Idle;
                if let Ok(auth) = playback_auth.as_mut() {
                    let _ = auth.clear();
                }
                let _ = dsp_controls.take_limiter_count();
                emit_snapshot(&event_tx, &context, &queue, index, &status, position_ms);
            }
            ActorInput::Command(Some(PlaybackCommand::Suspend)) => {
                if let Some(active) = engine.as_ref() {
                    active.player.stop();
                }
                queue.clear();
                index = None;
                position_ms = 0;
                play_request_id = None;
                status = PlaybackStatus::Idle;
                emit_snapshot(&event_tx, &context, &queue, index, &status, position_ms);
            }
            ActorInput::Command(Some(PlaybackCommand::Shutdown)) | ActorInput::Command(None) => {
                if let Some(active) = engine.as_ref() {
                    active.player.stop();
                }
                break;
            }
            ActorInput::PlayerEvent(Some(event)) => {
                handle_player_event(
                    event,
                    &engine,
                    &queue,
                    &mut index,
                    &mut position_ms,
                    &mut status,
                    &mut play_request_id,
                    &event_tx,
                    &context,
                );
            }
            ActorInput::PlayerEvent(None) => {
                status = PlaybackStatus::Error(PlaybackError::new(
                    PlaybackErrorKind::AudioBackend,
                    "The local audio player stopped unexpectedly.",
                ));
                emit_snapshot(&event_tx, &context, &queue, index, &status, position_ms);
                engine = None;
                play_request_id = None;
            }
            ActorInput::DspPoll => {
                let prevented = dsp_controls.take_limiter_count();
                if prevented > 0 {
                    tracing::warn!(
                        prevented_samples = prevented,
                        "limiter active/clipping prevented"
                    );
                }
            }
        }
    }
}

async fn create_engine(
    playback_auth: &mut Result<PlaybackAuth, PlaybackError>,
    interactive: bool,
    expected_account_id: Option<&str>,
    volume: f32,
    output_device: Option<String>,
    dsp_controls: Arc<DspControls>,
) -> Result<PlaybackEngine, PlaybackError> {
    let auth = playback_auth.as_mut().map_err(|error| (*error).clone())?;
    let access_token = if interactive {
        auth.authorize_if_needed().await?
    } else {
        auth.restore().await?.ok_or_else(|| {
            PlaybackError::new(
                PlaybackErrorKind::AccountAuthentication,
                "Spotify playback is not connected. Select a track to connect it.",
            )
        })?
    };

    let session = Session::new(SessionConfig::default(), None);
    if let Err(error) = session
        .connect(Credentials::with_access_token(access_token), false)
        .await
    {
        let failure = classify_librespot_auth_error(error);
        let _ = auth.clear();
        return Err(failure);
    }
    if expected_account_id.is_some_and(|expected| session.username() != expected) {
        let _ = auth.clear();
        return Err(PlaybackError::new(
            PlaybackErrorKind::AccountAuthentication,
            "Spotify playback was authorized for another account. Reconnect Spotify playback.",
        ));
    }

    // Audio metadata uses login5 after the AP login. Validate it before a Player
    // can start walking a queue so one account error produces one UI error.
    if let Err(error) = session.login5().auth_token().await {
        let failure = classify_librespot_auth_error(error);
        let _ = auth.clear();
        return Err(failure);
    }

    build_engine(session, volume, output_device, dsp_controls)
}

fn build_engine(
    session: Session,
    volume: f32,
    output_device: Option<String>,
    dsp_controls: Arc<DspControls>,
) -> Result<PlaybackEngine, PlaybackError> {
    let (backend_output, resolved_output) = resolve_output_device(output_device.as_deref())?;
    let mixer_builder = mixer::find(Some("softvol")).ok_or_else(|| {
        PlaybackError::new(
            PlaybackErrorKind::AudioBackend,
            "The local soft-volume mixer is unavailable.",
        )
    })?;
    let mixer = mixer_builder(MixerConfig::default()).map_err(|error| {
        PlaybackError::new(
            PlaybackErrorKind::AudioBackend,
            format!("Could not initialize local volume: {error}"),
        )
    })?;
    mixer.set_volume(volume_to_u16(volume));

    let backend = audio_backend::find(Some("rodio".to_owned())).ok_or_else(|| {
        PlaybackError::new(
            PlaybackErrorKind::AudioBackend,
            "No supported local audio output is available.",
        )
    })?;
    let mut config = PlayerConfig::default();
    config.bitrate = Bitrate::Bitrate320;
    config.gapless = true;
    config.position_update_interval = Some(Duration::from_millis(200));
    let audio_format = AudioFormat::S16;
    tracing::info!(
        requested_output = output_device.as_deref().unwrap_or("Windows default"),
        resolved_output = %resolved_output,
        "Opening local audio output"
    );
    let player = Player::new(
        config,
        session.clone(),
        mixer.get_soft_volume(),
        move || {
            Box::new(DspSink::new(
                backend(backend_output.clone(), audio_format),
                dsp_controls,
            )) as Box<dyn audio_backend::Sink>
        },
    );
    let events = player.get_player_event_channel();

    Ok(PlaybackEngine {
        session,
        player,
        events,
        mixer,
    })
}

#[allow(clippy::too_many_arguments)]
fn handle_player_event(
    event: PlayerEvent,
    engine: &Option<PlaybackEngine>,
    queue: &[Track],
    index: &mut Option<usize>,
    position_ms: &mut u32,
    status: &mut PlaybackStatus,
    play_request_id: &mut Option<u64>,
    event_tx: &flume::Sender<crate::spotify::SpotifyEvent>,
    context: &egui::Context,
) {
    match event {
        PlayerEvent::PlayRequestIdChanged {
            play_request_id: request,
        } if !matches!(&*status, PlaybackStatus::Error(_)) => {
            *play_request_id = Some(request);
        }
        PlayerEvent::Loading {
            play_request_id: request,
            track_id,
            position_ms: position,
        } if event_is_current(*play_request_id, request, &track_id, queue, *index)
            && !matches!(&*status, PlaybackStatus::Error(_)) =>
        {
            *position_ms = position;
            *status = PlaybackStatus::Loading;
            emit_snapshot(event_tx, context, queue, *index, status, *position_ms);
        }
        PlayerEvent::Playing {
            play_request_id: request,
            track_id,
            position_ms: position,
        } if event_is_current(*play_request_id, request, &track_id, queue, *index)
            && !matches!(&*status, PlaybackStatus::Error(_)) =>
        {
            *position_ms = position;
            *status = PlaybackStatus::Playing;
            emit_snapshot(event_tx, context, queue, *index, status, *position_ms);
        }
        PlayerEvent::Paused {
            play_request_id: request,
            track_id,
            position_ms: position,
        } if event_is_current(*play_request_id, request, &track_id, queue, *index)
            && !matches!(&*status, PlaybackStatus::Error(_)) =>
        {
            *position_ms = position;
            *status = PlaybackStatus::Paused;
            emit_snapshot(event_tx, context, queue, *index, status, *position_ms);
        }
        PlayerEvent::PositionChanged {
            play_request_id: request,
            track_id,
            position_ms: position,
        }
        | PlayerEvent::PositionCorrection {
            play_request_id: request,
            track_id,
            position_ms: position,
        }
        | PlayerEvent::Seeked {
            play_request_id: request,
            track_id,
            position_ms: position,
        } if event_is_current(*play_request_id, request, &track_id, queue, *index)
            && !matches!(&*status, PlaybackStatus::Error(_)) =>
        {
            *position_ms = position;
            emit_snapshot(event_tx, context, queue, *index, status, *position_ms);
        }
        PlayerEvent::TimeToPreloadNextTrack {
            play_request_id: request,
            track_id,
        } if event_is_current(*play_request_id, request, &track_id, queue, *index)
            && !matches!(&*status, PlaybackStatus::Error(_)) =>
        {
            if let (Some(active), Some(current)) = (engine.as_ref(), *index) {
                if let Some(next) = queue.get(current.saturating_add(1)) {
                    if let Ok(uri) = SpotifyUri::from_uri(&next.uri) {
                        active.player.preload(uri);
                    }
                }
            }
        }
        PlayerEvent::EndOfTrack {
            play_request_id: request,
            track_id,
        } if event_is_current(*play_request_id, request, &track_id, queue, *index)
            && !matches!(&*status, PlaybackStatus::Error(_)) =>
        {
            if let Some(current) = *index {
                let next = current.saturating_add(1);
                if next < queue.len() {
                    *index = Some(next);
                    *position_ms = 0;
                    *play_request_id = None;
                    if let Err(error) = load_index(engine, queue, next, 0, true) {
                        *status = PlaybackStatus::Error(error);
                    } else {
                        *status = PlaybackStatus::Loading;
                    }
                } else {
                    *position_ms = queue
                        .get(current)
                        .map(|track| track.duration_ms.min(u64::from(u32::MAX)) as u32)
                        .unwrap_or(*position_ms);
                    *status = PlaybackStatus::Paused;
                }
                emit_snapshot_with_end(
                    event_tx,
                    context,
                    queue,
                    *index,
                    status,
                    *position_ms,
                    next >= queue.len(),
                );
            }
        }
        PlayerEvent::Unavailable {
            play_request_id: request,
            track_id,
        } if event_is_current(*play_request_id, request, &track_id, queue, *index)
            && !matches!(&*status, PlaybackStatus::Error(_)) =>
        {
            if let Some(active) = engine.as_ref() {
                active.player.stop();
            }
            *play_request_id = None;
            *status = PlaybackStatus::Error(PlaybackError::new(
                PlaybackErrorKind::TrackUnavailable,
                "Spotify could not provide playable audio for this track.",
            ));
            emit_snapshot(event_tx, context, queue, *index, status, *position_ms);
        }
        PlayerEvent::Stopped {
            play_request_id: request,
            track_id,
        } if event_is_current(*play_request_id, request, &track_id, queue, *index) => {
            *status = PlaybackStatus::Paused;
            emit_snapshot(event_tx, context, queue, *index, status, *position_ms);
        }
        _ => {}
    }
}

fn event_is_current(
    current_request: Option<u64>,
    incoming_request: u64,
    incoming_track: &SpotifyUri,
    queue: &[Track],
    index: Option<usize>,
) -> bool {
    if current_request != Some(incoming_request) {
        return false;
    }
    index
        .and_then(|current| queue.get(current))
        .and_then(|track| SpotifyUri::from_uri(&track.uri).ok())
        .is_some_and(|current_track| &current_track == incoming_track)
}

fn load_index(
    engine: &Option<PlaybackEngine>,
    queue: &[Track],
    index: usize,
    position_ms: u32,
    start_playing: bool,
) -> Result<(), PlaybackError> {
    let active = engine.as_ref().ok_or_else(|| {
        PlaybackError::new(
            PlaybackErrorKind::AudioBackend,
            "The direct audio player is not initialized.",
        )
    })?;
    let track = queue.get(index).ok_or_else(|| {
        PlaybackError::new(
            PlaybackErrorKind::TrackUnavailable,
            "The selected track is outside the local queue.",
        )
    })?;
    let uri = SpotifyUri::from_uri(&track.uri).map_err(|error| {
        PlaybackError::new(
            PlaybackErrorKind::TrackUnavailable,
            format!("Invalid Spotify track URI: {error}"),
        )
    })?;
    active.player.load(uri, start_playing, position_ms);
    Ok(())
}

fn normalize_output_device(device: Option<String>) -> Option<String> {
    device
        .map(|name| name.trim().to_owned())
        .filter(|name| !name.is_empty())
}

fn resolve_output_device(
    requested: Option<&str>,
) -> Result<(Option<String>, String), PlaybackError> {
    let host = cpal::default_host();
    if let Some(name) = requested {
        let selected = host
            .output_devices()
            .map_err(|error| {
                PlaybackError::new(
                    PlaybackErrorKind::AudioBackend,
                    format!("Could not list local audio outputs: {error}"),
                )
            })?
            .find(|device| device.name().ok().as_deref() == Some(name));
        if let Some(device) = selected {
            let label = device.name().map_err(|error| {
                PlaybackError::new(
                    PlaybackErrorKind::AudioBackend,
                    format!("Could not read the selected audio output name: {error}"),
                )
            })?;
            return Ok((Some(name.to_owned()), label));
        }
        tracing::warn!(
            requested = name,
            "Selected audio output disappeared; using Windows default"
        );
    }

    let device = host.default_output_device().ok_or_else(|| {
        PlaybackError::new(
            PlaybackErrorKind::AudioBackend,
            "Windows did not report a default audio output.",
        )
    })?;

    let label = device.name().map_err(|error| {
        PlaybackError::new(
            PlaybackErrorKind::AudioBackend,
            format!("Could not read the selected audio output name: {error}"),
        )
    })?;
    Ok((None, label))
}

fn audio_device_snapshot() -> (Vec<String>, Option<String>) {
    let host = cpal::default_host();
    let default_device = host
        .default_output_device()
        .and_then(|device| device.name().ok());
    let mut devices = match host.output_devices() {
        Ok(outputs) => outputs.filter_map(|device| device.name().ok()).collect(),
        Err(error) => {
            tracing::warn!(%error, "Could not enumerate local audio outputs");
            Vec::new()
        }
    };
    devices.sort_unstable();
    devices.dedup();
    (devices, default_device)
}

fn emit_audio_devices(
    event_tx: &flume::Sender<crate::spotify::SpotifyEvent>,
    context: &egui::Context,
) {
    let (devices, default_device) = audio_device_snapshot();
    tracing::info!(
        windows_default_output = default_device.as_deref().unwrap_or("unavailable"),
        output_count = devices.len(),
        "Refreshed local audio outputs"
    );
    if event_tx
        .send(crate::spotify::SpotifyEvent::AudioDevicesChanged {
            devices,
            default_device,
        })
        .is_ok()
    {
        context.request_repaint();
    }
}

fn emit_error(
    event_tx: &flume::Sender<crate::spotify::SpotifyEvent>,
    context: &egui::Context,
    queue: &[Track],
    index: Option<usize>,
    position_ms: u32,
    error: PlaybackError,
) {
    emit_snapshot(
        event_tx,
        context,
        queue,
        index,
        &PlaybackStatus::Error(error),
        position_ms,
    );
}

fn emit_snapshot(
    event_tx: &flume::Sender<crate::spotify::SpotifyEvent>,
    context: &egui::Context,
    queue: &[Track],
    index: Option<usize>,
    status: &PlaybackStatus,
    position_ms: u32,
) {
    emit_snapshot_with_end(event_tx, context, queue, index, status, position_ms, false);
}

fn emit_snapshot_with_end(
    event_tx: &flume::Sender<crate::spotify::SpotifyEvent>,
    context: &egui::Context,
    queue: &[Track],
    index: Option<usize>,
    status: &PlaybackStatus,
    position_ms: u32,
    ended: bool,
) {
    let update = PlaybackUpdate {
        track: index.and_then(|current| queue.get(current).cloned()),
        status: status.clone(),
        position_ms,
        queue_index: index,
        queue_len: queue.len(),
        ended,
    };
    if event_tx
        .send(crate::spotify::SpotifyEvent::PlaybackChanged(update))
        .is_ok()
    {
        context.request_repaint();
    }
}

fn volume_to_u16(volume: f32) -> u16 {
    (volume.clamp(0.0, 1.0) * f32::from(u16::MAX)).round() as u16
}

fn classify_librespot_auth_error(error: LibrespotError) -> PlaybackError {
    let detail = format!("{error:?}");
    let invalid_credentials = detail.contains("INVALID_CREDENTIALS")
        || matches!(
            error.kind,
            LibrespotErrorKind::Unauthenticated
                | LibrespotErrorKind::PermissionDenied
                | LibrespotErrorKind::FailedPrecondition
                | LibrespotErrorKind::InvalidArgument
        );
    if invalid_credentials {
        PlaybackError::new(
            PlaybackErrorKind::InvalidCredentials,
            "Direct playback authentication failed. Reconnect Spotify playback.",
        )
    } else if matches!(
        error.kind,
        LibrespotErrorKind::Unavailable | LibrespotErrorKind::DeadlineExceeded
    ) {
        PlaybackError::new(
            PlaybackErrorKind::Network,
            format!("Could not reach Spotify playback services: {error}"),
        )
    } else {
        PlaybackError::new(
            PlaybackErrorKind::AccountAuthentication,
            format!("Could not authenticate direct Spotify playback: {error}"),
        )
    }
}
