use serde::Deserialize;

/// Minimal account information displayed by the client.
#[derive(Debug, Clone, Deserialize)]
pub struct UserProfile {
    /// Stable Spotify user identifier.
    pub id: String,
    /// User-facing Spotify name, when configured.
    pub display_name: Option<String>,
    /// Account country, available with `user-read-private`.
    pub country: Option<String>,
    /// Spotify product tier, available with `user-read-private`.
    pub product: Option<String>,
    /// Profile image URL.
    #[serde(rename = "images", default, deserialize_with = "first_image")]
    pub image_url: Option<String>,
}

impl UserProfile {
    /// Best available label for the top application bar.
    pub fn label(&self) -> &str {
        self.display_name.as_deref().unwrap_or(&self.id)
    }
}

/// Track metadata used by Search and Liked Songs.
#[derive(Debug, Clone)]
pub struct Track {
    /// Stable Spotify track identifier.
    pub id: String,
    /// Spotify URI used by the unified library endpoint.
    pub uri: String,
    /// Track title.
    pub name: String,
    /// Comma-separated artist names.
    pub artists: String,
    /// Album title.
    pub album: String,
    /// Track duration in milliseconds.
    pub duration_ms: u64,
    /// Best available album cover URL.
    pub image_url: Option<String>,
    /// Whether the track currently belongs to the Spotify library.
    pub saved: bool,
}

/// One offset-based Spotify page.
#[derive(Debug, Clone)]
pub struct Page<T> {
    /// Items returned for this page.
    pub items: Vec<T>,
    /// Offset returned by Spotify.
    pub offset: usize,
    /// Page size returned by Spotify.
    pub limit: usize,
    /// Total number of available items.
    pub total: usize,
    /// Whether another page exists.
    pub has_more: bool,
}

/// RGBA cover pixels decoded outside the UI thread.
#[derive(Debug, Clone)]
pub struct DecodedImage {
    /// Pixel width and height.
    pub size: [usize; 2],
    /// Unmultiplied RGBA8 pixels.
    pub rgba: Vec<u8>,
}

#[derive(Debug, Deserialize)]
pub(crate) struct SearchResponse {
    pub tracks: RawPage<RawTrack>,
}

#[derive(Debug, Deserialize)]
pub(crate) struct RecommendationsResponse {
    #[serde(default)]
    pub tracks: Vec<RawTrack>,
}

#[derive(Debug, Deserialize)]
#[serde(bound(deserialize = "T: Deserialize<'de>"))]
pub(crate) struct RawPage<T> {
    #[serde(default)]
    pub items: Vec<T>,
    pub offset: usize,
    pub limit: usize,
    pub total: usize,
    pub next: Option<String>,
}

impl<T> Default for RawPage<T> {
    fn default() -> Self {
        Self {
            items: Vec::new(),
            offset: 0,
            limit: 0,
            total: 0,
            next: None,
        }
    }
}

#[derive(Debug, Deserialize)]
pub(crate) struct SavedTrack {
    pub track: RawTrack,
}

#[derive(Debug, Deserialize)]
pub(crate) struct RawTrack {
    pub id: Option<String>,
    pub uri: String,
    pub name: String,
    #[serde(default)]
    pub artists: Vec<NamedItem>,
    pub album: RawAlbum,
    pub duration_ms: u64,
}

#[derive(Debug, Deserialize)]
pub(crate) struct RawAlbum {
    pub name: String,
    #[serde(default)]
    pub images: Vec<SpotifyImage>,
}

#[derive(Debug, Deserialize)]
pub(crate) struct NamedItem {
    pub name: String,
}

#[derive(Debug, Deserialize)]
pub(crate) struct SpotifyImage {
    pub url: String,
    pub width: Option<u32>,
    pub height: Option<u32>,
}

impl RawTrack {
    pub fn into_track(self, saved: bool) -> Option<Track> {
        let id = self.id?;
        let image_url = best_image(&self.album.images);
        Some(Track {
            id,
            uri: self.uri,
            name: self.name,
            artists: self
                .artists
                .into_iter()
                .map(|artist| artist.name)
                .collect::<Vec<_>>()
                .join(", "),
            album: self.album.name,
            duration_ms: self.duration_ms,
            image_url,
            saved,
        })
    }
}

fn best_image(images: &[SpotifyImage]) -> Option<String> {
    images
        .iter()
        .min_by_key(|image| {
            let width = image.width.unwrap_or(300);
            let height = image.height.unwrap_or(width);
            width.abs_diff(300) + height.abs_diff(300)
        })
        .map(|image| image.url.clone())
}

fn first_image<'de, D>(deserializer: D) -> Result<Option<String>, D::Error>
where
    D: serde::Deserializer<'de>,
{
    let images = Vec::<SpotifyImage>::deserialize(deserializer)?;
    Ok(images.first().map(|image| image.url.clone()))
}

#[cfg(test)]
mod tests {
    use super::{RawPage, RawTrack, SavedTrack, SearchResponse};

    #[test]
    fn generic_pages_deserialize_without_item_default() {
        let search = r#"{
            "tracks": {"items": [], "offset": 0, "limit": 10, "total": 0, "next": null}
        }"#;
        let liked = r#"{
            "items": [], "offset": 0, "limit": 50, "total": 0, "next": null
        }"#;

        let search_result: Result<SearchResponse, _> = serde_json::from_str(search);
        let raw_result: Result<RawPage<RawTrack>, _> = serde_json::from_str(liked);
        let saved_result: Result<RawPage<SavedTrack>, _> = serde_json::from_str(liked);

        assert!(search_result.is_ok());
        assert!(raw_result.is_ok());
        assert!(saved_result.is_ok());
    }

    #[test]
    fn raw_page_default_does_not_require_item_default() {
        let raw_tracks: RawPage<RawTrack> = RawPage::default();
        let saved_tracks: RawPage<SavedTrack> = RawPage::default();

        assert!(raw_tracks.items.is_empty());
        assert!(saved_tracks.items.is_empty());
    }
}
