use thiserror::Error;

/// Recoverable failures produced by Spotify services.
#[derive(Debug, Error)]
pub enum SpotifyError {
    #[error("Spotify account is not connected")]
    NotAuthenticated,
    #[error("Spotify Client ID is empty")]
    MissingClientId,
    #[error("Spotify authorization timed out")]
    AuthorizationTimeout,
    #[error("Spotify authorization was cancelled: {0}")]
    AuthorizationDenied(String),
    #[error("Spotify returned an invalid callback")]
    InvalidCallback,
    #[error("Spotify rejected the request ({status}): {message}")]
    Api { status: u16, message: String },
    #[error("network error: {0}")]
    Network(#[from] reqwest::Error),
    #[error("invalid URL: {0}")]
    Url(#[from] url::ParseError),
    #[error("file error: {0}")]
    Io(#[from] std::io::Error),
    #[error("invalid stored Spotify data: {0}")]
    Json(#[from] serde_json::Error),
    #[error("could not open the browser: {0}")]
    Browser(String),
    #[error("could not create secure random data: {0}")]
    Random(String),
    #[error("image error: {0}")]
    Image(String),
    #[error("Spotify background service stopped")]
    RuntimeStopped,
    #[error("Spotify data directory is unavailable")]
    DataDirectoryUnavailable,
}
