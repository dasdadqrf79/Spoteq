use spoteq::settings::{AccentColor, AppSettings, SettingsStore};

#[test]
fn settings_round_trip_preserves_audio_values() {
    let directory = tempfile::tempdir().expect("temporary directory");
    let store = SettingsStore::from_path(directory.path().join("settings.json"));
    let mut expected = AppSettings::default();
    expected.audio.preamp_db = -9.5;
    expected.audio.eq_db[3] = 4.0;
    expected.audio.bass_q = 1.25;
    expected.appearance.accent = AccentColor::Cyan;
    store.save_now(&expected).expect("save settings");
    let actual = store.load().expect("load settings");

    assert_eq!(actual, expected);
}

#[test]
fn appearance_exposes_exactly_ten_accents() {
    assert_eq!(AccentColor::ALL.len(), 10);
}

#[test]
fn invalid_values_are_clamped_during_load() {
    let directory = tempfile::tempdir().expect("temporary directory");
    let store = SettingsStore::from_path(directory.path().join("settings.json"));
    let mut invalid = AppSettings::default();
    invalid.audio.master_volume = 4.0;
    invalid.audio.bass_frequency_hz = 500.0;
    invalid.playback.pause_fade_ms = 900;
    invalid.playback.crossfade_seconds = 99;
    store.save_now(&invalid).expect("save settings");

    let loaded = store.load().expect("load settings");

    assert_eq!(loaded.audio.master_volume, 1.0);
    assert_eq!(loaded.audio.bass_frequency_hz, 180.0);
    assert_eq!(loaded.playback.pause_fade_ms, 300);
    assert_eq!(loaded.playback.crossfade_seconds, 12);
}

#[test]
fn fourteen_band_settings_are_migrated_to_ten_bands() {
    let directory = tempfile::tempdir().expect("temporary directory");
    let store = SettingsStore::from_path(directory.path().join("settings.json"));
    let mut previous = AppSettings::default();
    previous.audio.eq_db = (0..14).map(|index| index as f32).collect();
    store.save_now(&previous).expect("save v0.3 settings");

    let migrated = store.load().expect("migrate settings");

    assert_eq!(migrated.audio.eq_db.len(), 10);
    assert_eq!(migrated.audio.eq_db[0], 0.5);
    assert_eq!(migrated.audio.eq_db[9], 12.0);
}

#[test]
fn previous_snapshot_recovers_a_damaged_current_file() {
    let directory = tempfile::tempdir().expect("temporary directory");
    let path = directory.path().join("settings.json");
    let store = SettingsStore::from_path(path.clone());

    let mut previous = AppSettings::default();
    previous.audio.preamp_db = -10.0;
    store.save_now(&previous).expect("save previous snapshot");

    let mut current = previous.clone();
    current.audio.preamp_db = -4.0;
    store.save_now(&current).expect("save current snapshot");
    std::fs::write(path, b"not valid json").expect("damage current snapshot");

    let recovered = store.load().expect("recover backup snapshot");
    assert_eq!(recovered.audio.preamp_db, previous.audio.preamp_db);
}

#[test]
fn bass_studio_round_trip_migrates_old_settings_and_sanitizes_bands() {
    use spoteq::settings::{AudioSettings, BassFilterKind};
    let old: AudioSettings =
        serde_json::from_str(r#"{"eq_enabled":true,"preamp_db":-9.5}"#).unwrap();
    assert!(!old.bass_studio.enabled);
    assert_eq!(old.preamp_db, -9.5);
    let directory = tempfile::tempdir().unwrap();
    let store = SettingsStore::from_path(directory.path().join("settings.json"));
    let mut expected = AppSettings::default();
    expected.audio.bass_studio.enabled = true;
    expected.audio.bass_studio.bands[2].kind = BassFilterKind::LowShelf;
    expected.audio.bass_studio.bands[2].frequency_hz = 83.5;
    expected.audio.bass_studio.bands[2].gain_db = 4.5;
    expected.audio.bass_studio.bands[2].q = 1.25;
    store.save_now(&expected).unwrap();
    assert_eq!(store.load().unwrap(), expected);
    expected.audio.bass_studio.bands[0].frequency_hz = 999.0;
    expected.audio.bass_studio.bands[0].gain_db = -99.0;
    expected.audio.bass_studio.bands[0].q = 0.0;
    store.save_now(&expected).unwrap();
    let band = store.load().unwrap().audio.bass_studio.bands[0];
    assert_eq!(
        (band.frequency_hz, band.gain_db, band.q),
        (250.0, -12.0, 0.3)
    );
}
